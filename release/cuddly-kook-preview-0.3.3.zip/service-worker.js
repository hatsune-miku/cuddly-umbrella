const ACTIVE_KEY = 'cuddly.activePreviews'
const PREVIEW_ALARM_PREFIX = 'cuddly.previewExpiry.'
const EXTENSION_PROTOCOL_VERSION = 2
const EXTENSION_CAPABILITIES_COMMAND = 'get-extension-capabilities'
const EXTENSION_RELOAD_REQUIRED =
  '扩展前后台版本不一致，请在 chrome://extensions 重新加载 Cuddly KOOK Preview'
const PREVIEW_REVOKE_TIMEOUT_MS = 3_000
let mutationQueue = Promise.resolve()

function serializeMutation(task) {
  const result = mutationQueue.then(task, task)
  mutationQueue = result.catch(() => undefined)
  return result
}

async function readActivePreviews() {
  return (await chrome.storage.local.get(ACTIVE_KEY))[ACTIVE_KEY] || {}
}

async function writeActivePreviews(value) {
  await chrome.storage.local.set({ [ACTIVE_KEY]: value })
}

function previewAlarmName(tabId) {
  return `${PREVIEW_ALARM_PREFIX}${tabId}`
}

function previewAlarmTabId(name) {
  if (!name.startsWith(PREVIEW_ALARM_PREFIX)) return null
  const tabId = Number(name.slice(PREVIEW_ALARM_PREFIX.length))
  return Number.isInteger(tabId) && tabId >= 0 ? tabId : null
}

function previewExpiresAt(active) {
  return Date.parse(active?.preview?.expiresAt || '')
}

async function schedulePreviewExpiry(tabId, active) {
  const when = previewExpiresAt(active)
  if (!Number.isFinite(when) || when <= Date.now()) {
    throw new Error('Preview session has already expired')
  }
  await chrome.alarms.create(previewAlarmName(tabId), { when })
}

async function revokeActivePreview(active) {
  const token = active?.preview?.token
  if (typeof token !== 'string' || !token || !active?.controlOrigin) return false
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), PREVIEW_REVOKE_TIMEOUT_MS)
  try {
    const origin = new URL(active.controlOrigin).origin
    const response = await fetch(`${origin}/api/v1/previews/${encodeURIComponent(token)}`, {
      method: 'DELETE',
      cache: 'no-store',
      credentials: 'omit',
      keepalive: true,
      signal: controller.signal,
    })
    return response.ok || response.status === 404
  } catch {
    return false
  } finally {
    clearTimeout(timeout)
  }
}

async function clearPreviewState(tabId) {
  const active = await readActivePreviews()
  const current = active[String(tabId)] || null
  if (current?.ruleIds?.length) {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: current.ruleIds })
  }
  delete active[String(tabId)]
  await writeActivePreviews(active)
  await chrome.alarms.clear(previewAlarmName(tabId))
  return current
}

async function removePreview(tabId) {
  const current = await clearPreviewState(tabId)
  await revokeActivePreview(current)
  return current
}

async function nextRuleIds(count) {
  const rules = await chrome.declarativeNetRequest.getSessionRules()
  const first = rules.reduce((maximum, rule) => Math.max(maximum, rule.id), 1000) + 1
  return Array.from({ length: count }, (_value, index) => first + index)
}

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function sitePreviewRules({ tabId, previewOrigin, token, previewHeaderRuleId }) {
  const origin = new URL(previewOrigin).origin
  return [
    {
      id: previewHeaderRuleId,
      priority: 3,
      action: {
        type: 'modifyHeaders',
        requestHeaders: [
          {
            header: 'x-cuddly-preview-token',
            operation: 'set',
            value: token,
          },
        ],
      },
      condition: {
        regexFilter: `^${escapeRegex(origin)}(?:/|$)`,
        tabIds: [tabId],
      },
    },
  ]
}

function rulesForActivePreview(tabId, active) {
  try {
    if (
      active?.mode === 'site' &&
      active.ruleIds?.length === 1 &&
      typeof active.preview?.token === 'string'
    ) {
      return sitePreviewRules({
        tabId,
        previewOrigin: active.previewOrigin,
        token: active.preview.token,
        previewHeaderRuleId: active.ruleIds[0],
      })
    }
  } catch {
    return null
  }
  return null
}

function activePreviewMatchesTab(active, tab) {
  if (active?.mode !== 'site' || !active.previewOrigin || !tab?.url) return false
  try {
    return new URL(tab.url).origin === new URL(active.previewOrigin).origin
  } catch {
    return false
  }
}

function officialUrlForActivePreview(active, tab) {
  if (!activePreviewMatchesTab(active, tab) || !active?.officialOrigin) return null
  try {
    const destination = new URL(active.officialOrigin)
    const current = new URL(tab.url)
    destination.pathname = current.pathname
    destination.search = current.search
    destination.hash = current.hash
    return destination.href
  } catch {
    return null
  }
}

async function storeActive(tabId, value) {
  const active = await readActivePreviews()
  active[String(tabId)] = value
  await writeActivePreviews(active)
  try {
    await schedulePreviewExpiry(tabId, value)
  } catch (error) {
    delete active[String(tabId)]
    await writeActivePreviews(active)
    await chrome.alarms.clear(previewAlarmName(tabId))
    throw error
  }
  return value
}

async function restoreActive(tabId, value) {
  if (!value) return null
  const rules = rulesForActivePreview(tabId, value)
  if (!rules?.length) throw new Error('Previous preview state cannot be restored')
  await chrome.declarativeNetRequest.updateSessionRules({ addRules: rules })
  try {
    return await storeActive(tabId, value)
  } catch (error) {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: rules.map((rule) => rule.id),
    })
    throw error
  }
}

async function reconcilePreviewLifecycles() {
  const active = await readActivePreviews()
  const tabs = await chrome.tabs.query({})
  const tabsById = new Map(tabs.flatMap((tab) => (tab.id === undefined ? [] : [[tab.id, tab]])))
  const expectedAlarms = new Set()
  const restoredRules = []
  const restoredPreviews = []
  const stalePreviews = []
  const redirects = []
  const usedRuleIds = new Set()

  for (const [tabKey, preview] of Object.entries(active)) {
    const tabId = Number(tabKey)
    const tab = tabsById.get(tabId)
    const expiresAt = previewExpiresAt(preview)
    const rules =
      Number.isInteger(tabId) && tabId >= 0 ? rulesForActivePreview(tabId, preview) : null
    const ruleIds = rules?.map((rule) => rule.id) || []
    const rulesAreUnique = ruleIds.every(
      (ruleId) => Number.isInteger(ruleId) && ruleId > 0 && !usedRuleIds.has(ruleId)
    )
    if (
      !tab ||
      !Number.isFinite(expiresAt) ||
      expiresAt <= Date.now() ||
      !rules?.length ||
      !rulesAreUnique ||
      !activePreviewMatchesTab(preview, tab)
    ) {
      delete active[tabKey]
      stalePreviews.push(preview)
      const officialUrl = officialUrlForActivePreview(preview, tab)
      if (officialUrl) redirects.push([tabId, officialUrl])
      if (Number.isInteger(tabId) && tabId >= 0) await chrome.alarms.clear(previewAlarmName(tabId))
      continue
    }
    for (const ruleId of ruleIds) usedRuleIds.add(ruleId)
    restoredRules.push(...rules)
    restoredPreviews.push([tabId, preview])
    expectedAlarms.add(previewAlarmName(tabId))
  }

  const currentRules = await chrome.declarativeNetRequest.getSessionRules()
  if (currentRules.length || restoredRules.length) {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: currentRules.map((rule) => rule.id),
      addRules: restoredRules,
    })
  }
  await writeActivePreviews(active)
  await Promise.all(stalePreviews.map((preview) => revokeActivePreview(preview)))
  for (const [tabId, preview] of restoredPreviews) {
    await schedulePreviewExpiry(tabId, preview)
  }

  const alarms = await chrome.alarms.getAll()
  await Promise.all(
    alarms
      .filter(
        (alarm) => alarm.name.startsWith(PREVIEW_ALARM_PREFIX) && !expectedAlarms.has(alarm.name)
      )
      .map((alarm) => chrome.alarms.clear(alarm.name))
  )
  await Promise.all(
    redirects.map(([tabId, url]) => chrome.tabs.update(tabId, { url }).catch(() => undefined))
  )
}

async function applySitePreview(message) {
  const tabId = message.tabId
  if (!Number.isInteger(tabId) || tabId < 0) throw new Error('Preview tab is invalid')
  const [previewHeaderRuleId] = await nextRuleIds(1)
  const origin = new URL(message.previewOrigin).origin
  const controlOrigin = new URL(message.controlOrigin).origin
  const officialOrigin = new URL(message.officialOrigin).origin
  const pending = {
    mode: 'site',
    ruleIds: [previewHeaderRuleId],
    preview: message.preview,
    previewOrigin: origin,
    controlOrigin,
    officialOrigin,
    originalUrl: message.originalUrl,
    targetUrl: message.targetUrl,
    appliedAt: new Date().toISOString(),
  }
  const rules = sitePreviewRules({
    tabId,
    previewOrigin: origin,
    token: message.preview.token,
    previewHeaderRuleId,
  })
  const previous = await clearPreviewState(tabId)
  try {
    await chrome.declarativeNetRequest.updateSessionRules({ addRules: rules })
    const active = await storeActive(tabId, pending)
    await revokeActivePreview(previous)
    return active
  } catch (error) {
    await chrome.declarativeNetRequest
      .updateSessionRules({ removeRuleIds: [previewHeaderRuleId] })
      .catch(() => undefined)
    await revokeActivePreview(pending)
    try {
      await restoreActive(tabId, previous)
    } catch {
      await revokeActivePreview(previous)
    }
    throw error
  }
}

function extensionCapabilities() {
  return {
    protocolVersion: EXTENSION_PROTOCOL_VERSION,
    commands: ['apply-site-preview', 'remove-preview'],
  }
}

chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  const task = serializeMutation(() => {
    if (message?.type === EXTENSION_CAPABILITIES_COMMAND) return extensionCapabilities()
    if (message?.type === 'apply-site-preview') return applySitePreview(message)
    if (message?.type === 'remove-preview') return removePreview(message.tabId)
    if (message?.type === 'apply-preview' || message?.type === 'apply-remote-preview') {
      return Promise.reject(new Error(EXTENSION_RELOAD_REQUIRED))
    }
    return Promise.reject(new Error('Unsupported extension command'))
  })

  task
    .then((active) =>
      respond(
        message?.type === EXTENSION_CAPABILITIES_COMMAND
          ? { ok: true, capabilities: active }
          : { ok: true, active }
      )
    )
    .catch((error) => respond({ ok: false, message: error.message }))
  return true
})

chrome.tabs.onRemoved.addListener((tabId) => {
  void serializeMutation(() => removePreview(tabId))
})

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!changeInfo.url) return
  void serializeMutation(async () => {
    const active = await readActivePreviews()
    const current = active[String(tabId)] || null
    if (current && !activePreviewMatchesTab(current, tab)) await removePreview(tabId)
  })
})

chrome.alarms.onAlarm.addListener((alarm) => {
  const tabId = previewAlarmTabId(alarm.name)
  if (tabId === null) return
  void serializeMutation(async () => {
    const active = await readActivePreviews()
    const current = active[String(tabId)] || null
    if (!current) {
      await chrome.alarms.clear(alarm.name)
      return
    }
    if (previewExpiresAt(current) > Date.now()) {
      await schedulePreviewExpiry(tabId, current)
      return
    }
    const tab = await chrome.tabs.get(tabId).catch(() => null)
    const officialUrl = officialUrlForActivePreview(current, tab)
    await removePreview(tabId)
    if (officialUrl) await chrome.tabs.update(tabId, { url: officialUrl }).catch(() => undefined)
  })
})

chrome.runtime.onStartup.addListener(() => {
  void serializeMutation(reconcilePreviewLifecycles)
})

chrome.runtime.onInstalled.addListener(() => {
  void serializeMutation(reconcilePreviewLifecycles)
})
