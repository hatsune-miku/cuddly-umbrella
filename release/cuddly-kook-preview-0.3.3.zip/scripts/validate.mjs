import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const manifest = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8'))
if (manifest.manifest_version !== 3) throw new Error('Browser extension must use Manifest V3')
if (!manifest.permissions?.includes('alarms')) {
  throw new Error('Browser extension must declare the alarms permission')
}
for (const file of [
  'popup.html',
  'popup.css',
  'popup.js',
  'popup-identity.js',
  'preview-routing.js',
  'extension-protocol.js',
  'service-worker.js',
]) {
  await readFile(path.join(root, file))
}
console.log('[browser-extension] manifest and entry files are valid')
