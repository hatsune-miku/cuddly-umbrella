import { randomUUID } from 'node:crypto'

import type { Artifact, SiteBinding } from '@cuddly/contracts'
import { describe, expect, it } from 'vitest'

import { MemoryStore } from './memory-store'
import { PREVIEW_REVOKE_GRACE_MS } from './store'

describe('built-in project templates', () => {
  it('includes every KOOK Remote as an explicit disabled build target', async () => {
    const store = new MemoryStore()
    const targets = await store.listBuildTargets(true)
    const webapp = targets.find((target) => target.id === 'webapp')
    const base = targets.find((target) => target.id === 'base')
    const voiceRuntime = targets.find((target) => target.id === 'voice_runtime')

    expect(webapp).toMatchObject({
      installCommand: 'npm run i',
      buildCommand: 'npm run build_fast',
      outputDirectory: 'build',
    })
    expect(base).toMatchObject({
      kind: 'remote',
      installCommand:
        "corepack pnpm --filter '{./apps/base}...' --fail-if-no-match install --frozen-lockfile",
      buildCommand: 'corepack pnpm --dir apps/base run build:prod',
      outputDirectory: 'apps/base/dist',
      siteAdapter: 'kook-remote-v1',
      enabled: false,
    })
    expect(voiceRuntime).toMatchObject({
      kind: 'remote',
      installCommand:
        "corepack pnpm --filter '{./apps/voice_runtime}...' --fail-if-no-match install --frozen-lockfile",
      buildCommand: 'corepack pnpm --dir apps/voice_runtime run build:prod',
      outputDirectory: 'apps/voice_runtime/dist',
    })
  })
})

function artifact(jobId: string, branch: string): Artifact {
  const id = randomUUID()
  const builtAt = new Date().toISOString()
  return {
    id,
    buildJobId: jobId,
    targetId: 'online-h5',
    branch,
    status: 'READY',
    storageKey: `ready/online-h5/${id}`,
    builtAt,
    createdBy: 'gz',
    manifest: {
      schemaVersion: 1,
      artifactId: id,
      target: 'online-h5',
      branch,
      builtAt,
      serve: {
        siteAdapter: 'kook-online-h5-v1',
        entrypoints: ['index.htm'],
        publicBase: `/__cuddly/artifacts/${id}/`,
      },
      files: [
        {
          path: 'index.htm',
          size: 1,
          contentType: 'text/html; charset=utf-8',
          digest: 'sha256:test',
          cacheClass: 'html',
        },
      ],
    },
  }
}

function remoteArtifact(branch: string): Artifact {
  const id = randomUUID()
  const builtAt = new Date().toISOString()
  const providerName = `cuddly_base_${id.replaceAll('-', '').slice(0, 12)}`
  return {
    id,
    buildJobId: randomUUID(),
    targetId: 'base',
    branch,
    status: 'READY',
    storageKey: `ready/base/${id}`,
    builtAt,
    createdBy: 'gz',
    manifest: {
      schemaVersion: 1,
      artifactId: id,
      target: 'base',
      branch,
      builtAt,
      serve: {
        siteAdapter: 'kook-remote-v1',
        entrypoints: ['remoteEntry.js'],
        publicBase: `https://bifrost.example.test/__cuddly/preview-artifacts/${id}/${providerName}/`,
        remote: { moduleKey: 'base', providerName, entryPath: 'remoteEntry.js' },
      },
      files: [
        {
          path: 'remoteEntry.js',
          size: 1,
          contentType: 'text/javascript',
          digest: 'sha256:test',
          cacheClass: 'asset',
        },
      ],
    },
  }
}

describe('MemoryStore environment publication', () => {
  it('keeps a completed build separate from the active environment until publication', async () => {
    const store = new MemoryStore()
    const job = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/qa-panel',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const built = artifact(job.id, job.branch)
    await store.createArtifact(built)

    expect(await store.resolveCurrentArtifact('shared', 'online-h5')).toBeNull()

    const revision = await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: null,
      message: 'QA publish',
      createdBy: 'gz',
      selections: [{ targetId: 'online-h5', artifactId: built.id }],
    })

    expect((await store.resolveCurrentArtifact('shared', 'online-h5'))?.id).toBe(built.id)
    expect(await store.isArtifactReferenced(revision.environmentId, built.id)).toBe(true)
  })

  it('keeps artifacts from older revisions referenced after switching', async () => {
    const store = new MemoryStore()
    const first = artifact(randomUUID(), 'release/one')
    const second = artifact(randomUUID(), 'release/two')
    await store.createArtifact(first)
    await store.createArtifact(second)

    const revisionOne = await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: null,
      message: 'one',
      createdBy: 'gz',
      selections: [{ targetId: 'online-h5', artifactId: first.id }],
    })
    await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: revisionOne.id,
      message: 'two',
      createdBy: 'gz',
      selections: [{ targetId: 'online-h5', artifactId: second.id }],
    })

    const environment = await store.getEnvironment('shared')
    expect(environment).not.toBeNull()
    expect(await store.isArtifactReferenced(environment!.id, first.id)).toBe(true)
    expect((await store.resolveCurrentArtifact('shared', 'online-h5'))?.id).toBe(second.id)
  })

  it('resolves enabled Remote selections in one snapshot and retains old assets', async () => {
    const store = new MemoryStore()
    await store.saveBuildTarget(
      {
        ...(await store.getBuildTarget('base'))!,
        repositoryUrl: 'ssh://git.example.test/kook.git',
        enabled: true,
        configurationSource: 'database',
      },
      'gz'
    )
    const remote = remoteArtifact('feature/base')
    await store.createArtifact(remote)
    const first = await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: null,
      message: 'remote on',
      createdBy: 'gz',
      selections: [{ targetId: 'base', artifactId: remote.id }],
    })

    expect((await store.resolveCurrentRemoteArtifacts('shared', ['base']))[0]?.id).toBe(remote.id)
    expect(await store.isRemoteArtifactReferenced(remote.id)).toBe(true)

    await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: first.id,
      message: 'remote off',
      createdBy: 'gz',
      selections: [],
    })
    expect(await store.resolveCurrentRemoteArtifacts('shared', ['base'])).toEqual([])
    expect(await store.isRemoteArtifactReferenced(remote.id)).toBe(true)
  })
})

describe('MemoryStore build queue', () => {
  it('exposes running jobs before queued jobs and preserves queue order', async () => {
    const store = new MemoryStore()
    const first = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000001',
      targetId: 'online-h5',
      branch: 'feature/first',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const second = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000002',
      targetId: 'online-h5',
      branch: 'feature/second',
      profile: 'qa-web',
      requestedBy: 'qa-two',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const third = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000003',
      targetId: 'online-h5',
      branch: 'feature/third',
      profile: 'qa-web',
      requestedBy: 'qa-three',
      idempotencyKey: null,
      targetSnapshot: null,
    })

    expect((await store.claimNextBuildJob('worker-1'))?.id).toBe(first.id)

    const queue = await store.listBuildQueue()
    expect(queue.map((job) => job.id)).toEqual([first.id, second.id, third.id])

    await store.updateBuildJob(first.id, { status: 'SUCCEEDED' })
    expect((await store.listBuildQueue()).map((job) => job.id)).toEqual([second.id, third.id])
  })

  it('keeps the project execution snapshot on the queued job', async () => {
    const store = new MemoryStore()
    const snapshot = {
      id: 'online-h5',
      repositoryUrl: 'https://git.example.test/mobile.git',
      installCommand: 'pnpm install',
      buildCommand: 'pnpm build',
      outputDirectory: 'build',
      siteAdapter: 'kook-online-h5-v1',
    }
    const job = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'master',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: snapshot,
    })

    await store.saveBuildTarget(
      {
        ...(await store.getBuildTarget('online-h5'))!,
        buildCommand: 'pnpm build:changed',
        configurationSource: 'database',
      },
      'gz'
    )

    expect(job.targetSnapshot).toEqual(snapshot)
  })

  it('runs different projects in parallel while keeping each project serial', async () => {
    const store = new MemoryStore()
    const firstOnline = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000011',
      targetId: 'online-h5',
      branch: 'feature/online-first',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const secondOnline = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000012',
      targetId: 'online-h5',
      branch: 'feature/online-second',
      profile: 'qa-web',
      requestedBy: 'qa-two',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const webapp = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000013',
      targetId: 'webapp',
      branch: 'feature/webapp',
      profile: 'qa-web',
      requestedBy: 'qa-three',
      idempotencyKey: null,
      targetSnapshot: null,
    })

    expect((await store.claimNextBuildJob('worker-1'))?.id).toBe(firstOnline.id)
    expect((await store.claimNextBuildJob('worker-1'))?.id).toBe(webapp.id)
    expect(await store.claimNextBuildJob('worker-1')).toBeNull()

    await store.updateBuildJob(firstOnline.id, { status: 'SUCCEEDED' })
    expect((await store.claimNextBuildJob('worker-1'))?.id).toBe(secondOnline.id)
  })

  it('cancels queued jobs immediately and keeps repeated requests idempotent', async () => {
    const store = new MemoryStore()
    const job = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/cancel-queued',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })

    const first = await store.requestBuildJobCancellation(job.id, 'qa-one')
    const repeated = await store.requestBuildJobCancellation(job.id, 'qa-two')

    expect(first.outcome).toBe('CANCELED')
    expect(first.job).toMatchObject({
      status: 'CANCELED',
      failureCode: 'BUILD_CANCELED',
    })
    expect(first.job?.finishedAt).not.toBeNull()
    expect(repeated).toEqual(first)
    expect(await store.claimNextBuildJob('worker-1')).toBeNull()
    expect((await store.listBuildJobEvents(job.id)).map((event) => event.status)).toEqual([
      'QUEUED',
      'CANCELED',
    ])
  })

  it('keeps a canceling project occupied and rejects stale stage updates', async () => {
    const store = new MemoryStore()
    const running = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/cancel-running',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    await store.claimNextBuildJob('worker-1')
    const next = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/next',
      profile: 'qa-web',
      requestedBy: 'qa-two',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    expect((await store.requestBuildJobCancellation(running.id, 'qa-one')).outcome).toBe(
      'CANCELING'
    )
    expect(
      await store.transitionBuildJob(running.id, ['LEASED'], { status: 'CHECKOUT' })
    ).toBeNull()
    expect((await store.getBuildJob(running.id))?.status).toBe('CANCELING')
    expect(await store.claimNextBuildJob('worker-1')).toBeNull()

    await store.transitionBuildJob(running.id, ['CANCELING'], {
      status: 'CANCELED',
      finishedAt: new Date().toISOString(),
      failureCode: 'BUILD_CANCELED',
      failureMessage: '构建已被提前中断',
    })
    expect((await store.claimNextBuildJob('worker-1'))?.id).toBe(next.id)
  })

  it('commits success and its Artifact atomically against cancellation', async () => {
    const store = new MemoryStore()
    const canceled = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/cancel-before-publish',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    await store.claimNextBuildJob('worker-1')
    for (const [from, to] of [
      ['LEASED', 'CHECKOUT'],
      ['CHECKOUT', 'INSTALLING'],
      ['INSTALLING', 'BUILDING'],
      ['BUILDING', 'VALIDATING'],
      ['VALIDATING', 'UPLOADING'],
    ] as const) {
      await store.transitionBuildJob(canceled.id, [from], { status: to })
    }
    await store.requestBuildJobCancellation(canceled.id, 'qa-one')
    const canceledArtifact = artifact(canceled.id, canceled.branch)
    expect(
      await store.completeBuildJob(canceled.id, {
        artifact: canceledArtifact,
        finishedAt: new Date().toISOString(),
        logPath: '/logs/canceled.log',
      })
    ).toBeNull()
    expect(await store.getArtifact(canceledArtifact.id)).toBeNull()

    await store.transitionBuildJob(canceled.id, ['CANCELING'], {
      status: 'CANCELED',
      finishedAt: new Date().toISOString(),
    })
    const succeeded = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/success-before-cancel',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    await store.claimNextBuildJob('worker-1')
    for (const [from, to] of [
      ['LEASED', 'CHECKOUT'],
      ['CHECKOUT', 'INSTALLING'],
      ['INSTALLING', 'BUILDING'],
      ['BUILDING', 'VALIDATING'],
      ['VALIDATING', 'UPLOADING'],
    ] as const) {
      await store.transitionBuildJob(succeeded.id, [from], { status: to })
    }
    const succeededArtifact = artifact(succeeded.id, succeeded.branch)
    expect(
      await store.completeBuildJob(succeeded.id, {
        artifact: succeededArtifact,
        finishedAt: new Date().toISOString(),
        logPath: '/logs/succeeded.log',
      })
    ).toMatchObject({ status: 'SUCCEEDED' })
    expect((await store.requestBuildJobCancellation(succeeded.id, 'qa-one')).outcome).toBe(
      'NOT_CANCELABLE'
    )
    expect((await store.getArtifact(succeededArtifact.id))?.status).toBe('READY')
  })
})

describe('MemoryStore preview sessions', () => {
  it('expires preview tokens and stops retaining their artifacts', async () => {
    const store = new MemoryStore()
    const remote = remoteArtifact('feature/expired')
    await store.createArtifact(remote)
    await store.createPreviewSession({
      token: 'expired-preview',
      createdBy: 'gz',
      expiresAt: new Date(Date.now() - 1000).toISOString(),
      selections: [
        {
          moduleKey: 'base',
          targetId: 'base',
          artifactId: remote.id,
          branch: 'feature/expired',
          builtAt: new Date().toISOString(),
          providerName: 'cuddly_base_expired',
          version: 'cuddly_base_expired',
          entryPath: 'remoteEntry.js',
        },
      ],
    })

    expect(await store.getPreviewSession('expired-preview')).toBeNull()
    expect(await store.isArtifactReferencedByActivePreview(remote.id)).toBe(false)
  })

  it('revokes an exact token immediately but retains its artifact through the gateway cache grace', async () => {
    let now = Date.parse('2026-08-25T08:00:00.000Z')
    const store = new MemoryStore(() => now)
    const remote = remoteArtifact('feature/revoked')
    const latest = remoteArtifact('feature/revoked')
    remote.builtAt = '2026-08-25T07:00:00.000Z'
    latest.builtAt = '2026-08-25T07:30:00.000Z'
    await store.createArtifact(remote)
    await store.createArtifact(latest)
    await store.createPreviewSession({
      token: 'preview-to-revoke',
      createdBy: 'gz',
      expiresAt: new Date(now + 60_000).toISOString(),
      selections: [
        {
          moduleKey: 'base',
          targetId: 'base',
          artifactId: remote.id,
          branch: remote.branch,
          builtAt: remote.builtAt,
          providerName: remote.manifest.serve.remote!.providerName,
          version: remote.manifest.serve.remote!.providerName,
          entryPath: remote.manifest.serve.remote!.entryPath,
        },
      ],
    })

    expect(await store.isArtifactReferencedByActivePreview(remote.id)).toBe(true)
    await expect(store.revokePreviewSession('another-preview')).resolves.toBe(false)
    expect(await store.getPreviewSession('preview-to-revoke')).not.toBeNull()
    await expect(store.revokePreviewSession('preview-to-revoke')).resolves.toBe(true)
    await expect(store.revokePreviewSession('preview-to-revoke')).resolves.toBe(false)
    expect(await store.getPreviewSession('preview-to-revoke')).toBeNull()
    expect(await store.isArtifactReferencedByActivePreview(remote.id)).toBe(true)
    await expect(store.claimArtifactCleanupCandidates(50)).resolves.toEqual([])

    now += PREVIEW_REVOKE_GRACE_MS + 1
    expect(await store.isArtifactReferencedByActivePreview(remote.id)).toBe(false)
    await expect(store.claimArtifactCleanupCandidates(50)).resolves.toEqual([
      expect.objectContaining({ id: remote.id }),
    ])
  })
})

describe('MemoryStore Artifact retention', () => {
  it('gets a unique ordered batch of existing Artifacts by id', async () => {
    const store = new MemoryStore()
    const first = artifact(randomUUID(), 'feature/batch')
    const second = artifact(randomUUID(), 'feature/batch')
    await store.createArtifact(first)
    await store.createArtifact(second)

    await expect(
      store.getArtifactsByIds([second.id, randomUUID(), first.id, second.id])
    ).resolves.toEqual([second, first])
    await expect(store.getArtifactsByIds([])).resolves.toEqual([])
  })

  it('claims every unreferenced superseded package and keeps the newest candidate READY', async () => {
    const store = new MemoryStore()
    const oldest = artifact(randomUUID(), 'feature/one')
    const middle = artifact(randomUUID(), 'feature/one')
    const newest = artifact(randomUUID(), 'feature/one')
    oldest.builtAt = '2026-08-25T01:00:00.000Z'
    middle.builtAt = '2026-08-25T02:00:00.000Z'
    newest.builtAt = '2026-08-25T03:00:00.000Z'
    await store.createArtifact(oldest)
    await store.createArtifact(middle)
    await store.createArtifact(newest)

    const claimed = await store.claimArtifactCleanupCandidates(50)

    expect(claimed.map((candidate) => candidate.id)).toEqual([oldest.id, middle.id])
    expect((await store.getArtifact(oldest.id))?.status).toBe('DELETING')
    expect((await store.getArtifact(newest.id))?.status).toBe('READY')
    await store.completeArtifactDeletion(oldest.id)
    await store.completeArtifactDeletion(middle.id)
    expect((await store.getArtifact(oldest.id))?.status).toBe('DELETED')
    expect((await store.listArtifacts('online-h5', 'feature/one')).map((item) => item.id)).toEqual([
      newest.id,
    ])
  })

  it('keeps the serving package until a newer package becomes the current Revision', async () => {
    const store = new MemoryStore()
    const serving = artifact(randomUUID(), 'master')
    const candidate = artifact(randomUUID(), 'master')
    serving.builtAt = '2026-08-25T01:00:00.000Z'
    candidate.builtAt = '2026-08-25T02:00:00.000Z'
    await store.createArtifact(serving)
    await store.createArtifact(candidate)
    const firstRevision = await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: null,
      message: 'old package serving',
      createdBy: 'gz',
      selections: [{ targetId: 'online-h5', artifactId: serving.id }],
    })

    await expect(store.claimArtifactCleanupCandidates(50)).resolves.toEqual([])

    await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: firstRevision.id,
      message: 'new package serving',
      createdBy: 'gz',
      selections: [{ targetId: 'online-h5', artifactId: candidate.id }],
    })
    await expect(store.claimArtifactCleanupCandidates(50)).resolves.toEqual([
      expect.objectContaining({ id: serving.id }),
    ])
  })

  it('protects an active Preview and refuses to reference a package already being deleted', async () => {
    const store = new MemoryStore()
    const previewed = remoteArtifact('feature/base')
    const newest = remoteArtifact('feature/base')
    previewed.builtAt = '2026-08-25T01:00:00.000Z'
    newest.builtAt = '2026-08-25T02:00:00.000Z'
    await store.createArtifact(previewed)
    await store.createArtifact(newest)
    const selection = {
      moduleKey: 'base',
      targetId: 'base',
      artifactId: previewed.id,
      branch: previewed.branch,
      builtAt: previewed.builtAt,
      providerName: previewed.manifest.serve.remote!.providerName,
      version: previewed.manifest.serve.remote!.providerName,
      entryPath: previewed.manifest.serve.remote!.entryPath,
    }
    await store.createPreviewSession({
      token: 'active-preview',
      createdBy: 'gz',
      expiresAt: new Date(Date.now() + 60_000).toISOString(),
      selections: [selection],
    })
    await expect(store.claimArtifactCleanupCandidates(50)).resolves.toEqual([])

    const unreferencedStore = new MemoryStore()
    await unreferencedStore.createArtifact(previewed)
    await unreferencedStore.createArtifact(newest)
    await expect(unreferencedStore.claimArtifactCleanupCandidates(50)).resolves.toEqual([
      expect.objectContaining({ id: previewed.id }),
    ])
    await expect(
      unreferencedStore.createPreviewSession({
        token: 'too-late',
        createdBy: 'gz',
        expiresAt: new Date(Date.now() + 60_000).toISOString(),
        selections: [selection],
      })
    ).rejects.toThrow(`Artifact is not ready: ${previewed.id}`)
    await expect(
      unreferencedStore.publishRevision({
        environmentId: 'shared',
        baseRevisionId: null,
        message: 'too late',
        createdBy: 'gz',
        selections: [{ targetId: 'base', artifactId: previewed.id }],
      })
    ).rejects.toThrow(`Artifact is not ready: ${previewed.id}`)
  })

  it('restores a package after a failed physical deletion', async () => {
    const store = new MemoryStore()
    const old = artifact(randomUUID(), 'feature/retry')
    const latest = artifact(randomUUID(), 'feature/retry')
    old.builtAt = '2026-08-25T01:00:00.000Z'
    latest.builtAt = '2026-08-25T02:00:00.000Z'
    await store.createArtifact(old)
    await store.createArtifact(latest)
    await store.claimArtifactCleanupCandidates(50)

    await store.restoreArtifactDeletion(old.id)

    expect((await store.getArtifact(old.id))?.status).toBe('READY')
  })
})

describe('MemoryStore site bindings', () => {
  it('supports CRUD and enabled hostname/origin resolution', async () => {
    const store = new MemoryStore()
    const main: SiteBinding = {
      id: 'main',
      name: 'KOOK 网页端',
      hostname: 'MAIN.BIFROST.VANILLACAKE.CN.',
      targetId: 'webapp',
      environmentSlug: 'shared',
      upstreamOrigin: 'https://www.kookapp.cn/',
      officialOrigin: 'https://www.kookapp.cn/',
      enabled: true,
      remoteTargetIds: ['base'],
      resourceProxyPrefixes: [
        'https://static.kookapp.cn/static/',
        'https://img.kookapp.cn/assets/',
      ],
    }
    await store.saveSiteBinding(main, 'gz')
    main.resourceProxyPrefixes.push('https://unexpected.kookapp.cn/')
    await store.saveSiteBinding(
      {
        ...main,
        id: 'disabled',
        hostname: 'disabled.bifrost.vanillacake.cn',
        officialOrigin: 'https://disabled.kookapp.cn',
        enabled: false,
      },
      'gz'
    )

    expect((await store.listSiteBindings()).map((binding) => binding.id)).toEqual(['main'])
    expect(await store.getSiteBindingByHostname('MAIN.BIFROST.VANILLACAKE.CN:443')).toMatchObject({
      id: 'main',
      hostname: 'main.bifrost.vanillacake.cn',
      resourceProxyPrefixes: [
        'https://static.kookapp.cn/static/',
        'https://img.kookapp.cn/assets/',
      ],
    })
    expect(await store.getSiteBindingByOfficialOrigin('https://www.kookapp.cn/path')).toMatchObject(
      {
        id: 'main',
        officialOrigin: 'https://www.kookapp.cn',
      }
    )
    expect(await store.getSiteBindingByHostname('disabled.bifrost.vanillacake.cn')).toBeNull()

    const firstRead = await store.getSiteBinding('main')
    firstRead!.resourceProxyPrefixes.push('https://mutated.kookapp.cn/')
    expect((await store.getSiteBinding('main'))?.resourceProxyPrefixes).toEqual([
      'https://static.kookapp.cn/static/',
      'https://img.kookapp.cn/assets/',
    ])

    expect(await store.deleteSiteBinding('main', 'gz')).toBe(true)
    expect(await store.getSiteBinding('main')).toBeNull()
    expect(await store.deleteSiteBinding('main', 'gz')).toBe(false)
  })
})
