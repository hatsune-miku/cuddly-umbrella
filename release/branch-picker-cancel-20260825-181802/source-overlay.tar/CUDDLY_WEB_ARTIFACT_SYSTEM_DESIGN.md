# Cuddly Web Artifact 与 Bifrost 网关系统设计

状态：Draft v2（实施约束已确认）  
日期：2026-08-11  
范围：打包模块、webapp / 在线 H5 / biz 前端制品、Bifrost 后端代理、QA 选择与发布

## 1. 结论与核心决策

本设计把“打包”和“环境正在使用什么”彻底分开：

1. 构建任务只产生不可变 Artifact，不自动修改任何环境。
2. QA 面板展示每个站点或包当前固定使用的 Artifact，以及该 Artifact 的分支标签和打包时间。
3. “某分支最新包”只表示候选 Artifact，不能作为运行时动态引用。
4. QA 点击“使用新包”后，系统创建完整的 Environment Revision，并原子切换当前 Revision。
5. Bifrost 网关从当前 Revision 读取前端 Artifact，静态服务 HTML/JS/CSS；API、登录、上传等请求继续代理官网后端。
6. 不允许在 Artifact 缺文件时偷偷回退到官网前端。缺失的静态文件应明确返回 404/502，防止一个页面混用两套前端。
7. QA 不需要看到 commit SHA。业务模型以目标、分支、打包时间和 Artifact ID 为准。
8. 首期 HTTP API 经过 Bifrost；Gateway WebSocket 和 RTC 继续使用官网返回的地址直连，后续再独立评估全代理。
9. 首个开发切片选择在线 H5，不以 biz 作为 PoC；biz 在 OAuth 回调、Cookie 和重定向链路完成专项验证后再接入。

## 2. 设计范围

### 2.1 本期包含

- `kook/apps/webapp` 的网页制品构建、保存、选择和服务。
- `html_h5` 在线 H5 的多入口制品构建、保存、选择和服务。
- `biz-fe` 的 SPA 制品构建、保存、选择和服务。
- Bifrost 已有官网 HTTP 代理、Cookie/Location 改写、接口覆盖规则的继承。
- Build Job、Artifact、Branch Catalog、Environment Revision 的控制面 API。
- QA 面板所需的查询、打包、暂存和发布操作。
- 服务器本地文件 Artifact Store，以及后续可切换 OSS/S3 的存储接口。

### 2.2 本期不包含

- Electron 外壳和 PC 安装包构建。
- 替代 KOOK 后端。
- 通用 Mock 平台。
- 任意 JavaScript 代理规则编辑器。
- 首期代理 Gateway WebSocket、语音和 RTC 媒体流。
- 自动把某分支的新构建推到正在测试的环境。

### 2.3 已确认的实施约束

- 所有正式开发只发生在 `cuddly-umbrella` 目录内。
- 开始实现时把 `bifrost-kookapp` 和 `bifrost-frontend/bifrost-mis` 的必要代码迁入 Cuddly，之后不再把原 Bifrost 仓库作为运行时或发布依赖。
- 不修改、不提交、不推送原 Bifrost Git 远端。
- 业务源码仓库由 Runner 在构建任务中临时 clone。需要的构建适配存放在 Cuddly 内，不要求向业务仓库远端提交。
- Bifrost Gateway、Build Worker 和 Runner 首期部署在同一台服务器。
- 使用 Docker Compose 部署。
- Artifact 首期使用服务器本地磁盘，保留可切换 OSS/S3 的存储接口。
- PostgreSQL 由 Docker Compose 一并启动，不依赖服务器预装实例。
- 首期不接飞书 SSO，普通 QA 功能不做鉴权；客户端操作标识仅用于队列展示和弱审计。
- 开发过程中允许修改 Cuddly 内代码，但禁止向任何 Git 远端 push。

## 3. 关键语义

### 3.1 最新候选不等于当前使用

```text
feature/A 在 10:30 构建出 artifact-101
QA 在 10:40 选择 artifact-101
feature/A 在 11:00 构建出 artifact-102

环境仍然使用 artifact-101。
面板显示“有新包可用：artifact-102”。
只有 QA 点击“使用新包”后，环境才切换到 artifact-102。
```

Environment Revision 中只能存具体 `artifact_id`，禁止存 `branch = feature/A, use_latest = true` 一类动态选择。

### 3.2 发布是完整快照

QA 可以先修改多行选择，形成待发布矩阵，然后一次提交。服务端在一个数据库事务中：

1. 校验基础 Revision 没有变化。
2. 校验所有 Artifact 都为 `READY`，并属于正确 Build Target。
3. 创建包含完整选择表的新 Revision。
4. 原子更新 Environment 的 `current_revision_id`。
5. 写入审计事件。

网关只读取 `current_revision_id`，不会看到半套配置。

## 4. 总体架构

```mermaid
flowchart LR
    QA["QA / 研发"] --> CONSOLE["Cuddly Console"]
    QA --> BOT["打包嘟嘟 / CLI"]

    CONSOLE --> API["Control API"]
    BOT --> API
    API --> AUTH["飞书 SSO / RBAC"]
    API --> DB[("PostgreSQL")]
    API --> QUEUE["PostgreSQL Job Queue"]

    QUEUE --> WORKER["Build Worker"]
    WORKER --> RUNNER["隔离 Runner 容器"]
    RUNNER --> GIT["Git 仓库"]
    RUNNER --> STORE["Artifact Store\nLocal / OSS / S3"]
    WORKER --> DB

    BROWSER["KOOK 网页 / 浏览器扩展"] --> EDGE["Nginx / TLS"]
    EDGE --> GW["Bifrost Gateway"]
    GW --> DB
    GW --> STORE
    GW --> UPSTREAM["www / m / biz 官网后端"]
```

### 4.1 进程边界

后端保持一个仓库，但按职责运行四个进程：

| 进程           | 职责                                                 | 是否直接执行构建命令 |
| -------------- | ---------------------------------------------------- | -------------------- |
| `control-api`  | 项目配置、Build Job、Artifact、Environment、审计 API | 否                   |
| `build-worker` | 从 PostgreSQL 领取任务、调度 Runner、登记 Artifact   | 否                   |
| `runner-agent` | 在隔离目录或容器内 checkout、安装、构建、校验、上传  | 是                   |
| `gateway`      | 解析环境、服务制品、代理官网后端、应用 Bifrost 规则  | 否                   |

首期把 `control-api`、`build-worker`、`gateway` 和 `runner-agent` 部署在同一台服务器，但保持独立进程和容器。这样不需要跨机器传输源码、日志和 Artifact，也保留以后拆分 Runner 的能力。

### 4.2 Cuddly 单工作区结构

```text
cuddly-umbrella/
  apps/
    console/                    # 原 bifrost-mis 能力迁入这里
    control-api/
    gateway/                    # 原 bifrost-kookapp 代理能力迁入这里
    build-worker/
    runner-agent/
  packages/
    domain/
    db/
    contracts/
    artifact-store/
    build-adapters/
    site-adapters/
    bifrost-rules/
    observability/
  patches/
    html-h5/                    # 不推业务仓库的确定性构建适配
  deploy/
    nginx/
    docker/
  data/                         # 本地开发数据，生产使用 /srv/cuddly
  docker-compose.yml
  pnpm-workspace.yaml
```

前后端仍是独立应用和包，但统一放在一个 Git 工作区中开发和部署。原 Bifrost 代码迁入后按新模块边界整理，不保留“双仓同步”机制。

建议技术栈：

- 后端：Node.js 22 LTS、TypeScript、pnpm workspace。
- Control API：Fastify + Zod/OpenAPI。
- Gateway：Express 5 + `http-proxy-middleware`，优先复用现有 Bifrost 代码。
- 数据访问：PostgreSQL + Kysely，migration 进入后端仓库。
- 任务队列：首期 PostgreSQL `FOR UPDATE SKIP LOCKED` + lease。
- 前端：React + TypeScript + Vite + TanStack Query。
- 日志：Pino JSON 日志；构建日志单独持久化。
- 测试：Vitest、API 集成测试、Playwright。

### 4.3 单机 Docker Compose 拓扑

```mermaid
flowchart TB
    N["Host Nginx / TLS"] --> C["console"]
    N --> A["control-api"]
    N --> G["gateway"]

    A --> P[("postgres")]
    G --> P
    W["build-worker"] --> P
    W --> R["runner-agent"]

    R --> GC["Git shallow object cache"]
    R --> JW["Job workspaces"]
    R --> AS["Local Artifact Store"]
    G --> AS

    GC -. bind mount .-> D["/srv/cuddly/git-cache"]
    JW -. bind mount .-> E["/srv/cuddly/jobs"]
    AS -. bind mount .-> F["/srv/cuddly/artifacts"]
    P -. bind mount .-> H["/srv/cuddly/postgres"]
```

Compose 服务：

| 服务           | 说明                                    |
| -------------- | --------------------------------------- |
| `postgres`     | PostgreSQL 16，保存控制面数据和任务队列 |
| `control-api`  | QA API、Environment 和 Artifact 管理    |
| `gateway`      | Bifrost 网关和移动站数据面              |
| `build-worker` | PostgreSQL lease、任务状态和调度        |
| `runner-agent` | 首期单并发执行在线 H5 构建              |
| `console`      | QA 管理页面静态容器                     |

生产数据使用 `/srv/cuddly/*` bind mount，不把重要数据只留在容器可写层。`postgres` 和 Artifact 目录需要进入服务器备份计划。

## 5. 环境与域名模型

### 5.1 域名格式

生产设计使用一张通配符证书 `*.bifrost.qa.vanillacake.cn`，站点和环境编码在一个 label 中：

```text
<environment>-www.bifrost.qa.vanillacake.cn
<environment>-m.bifrost.qa.vanillacake.cn
<environment>-biz.bifrost.qa.vanillacake.cn
```

示例：

```text
feature-a-www.bifrost.qa.vanillacake.cn
feature-a-m.bifrost.qa.vanillacake.cn
feature-a-biz.bifrost.qa.vanillacake.cn
```

现有三个域名作为 `shared` 环境的兼容别名：

| 兼容域名                            | 环境     | 站点      |
| ----------------------------------- | -------- | --------- |
| `bifrost-api.vanillacake.cn`        | `shared` | webapp    |
| `bifrost-api-mobile.vanillacake.cn` | `shared` | online-h5 |
| `bifrost-api-biz.vanillacake.cn`    | `shared` | biz       |

长期应引导 QA 使用新域名。新域名可以把 KOOK 登录 Cookie 限制在 `.bifrost.qa.vanillacake.cn`，避免为了三站共享登录态而把 Cookie 扩大到整个 `.vanillacake.cn`。

### 5.2 Host 解析

Gateway 不依靠 Cookie 决定环境。请求 Host 解析成：

```ts
interface RequestSiteContext {
  environmentId: string
  environmentSlug: string
  site: 'webapp' | 'online-h5' | 'biz'
  revisionId: string
}
```

因此不同环境可以在同一个浏览器中同时打开，不会因为切换 Cookie 而互相覆盖。

## 6. 领域模型

### 6.1 Project

描述源码仓库和访问方式。

| 字段             | 说明                          |
| ---------------- | ----------------------------- |
| `id`             | 稳定 ID，例如 `kook-monorepo` |
| `name`           | 展示名称                      |
| `repository_url` | Git 地址                      |
| `default_branch` | 默认分支                      |
| `credential_ref` | 凭据引用，不保存明文私钥      |
| `enabled`        | 是否允许创建任务              |

### 6.2 Build Target

描述一个可独立构建和选择的目标。

| 字段          | 说明                                               |
| ------------- | -------------------------------------------------- |
| `id`          | `webapp`、`online-h5`、`biz`，未来可扩展 `base` 等 |
| `project_id`  | 所属 Project                                       |
| `kind`        | `webapp`、`h5-site`、`spa-site`、`remote`          |
| `adapter_key` | 构建适配器                                         |
| `required`    | 新 Revision 是否必须包含该目标                     |
| `enabled`     | 是否允许构建和选择                                 |

Build Target 配置由 Cuddly 管理，不要求写入业务仓库。

### 6.3 Build Job

一次明确的构建请求。

| 字段                                        | 说明                                           |
| ------------------------------------------- | ---------------------------------------------- |
| `id`                                        | UUID/ULID，同时可作为 Artifact ID 的预分配来源 |
| `target_id`                                 | 构建目标                                       |
| `branch`                                    | 用户选择的分支标签                             |
| `profile`                                   | `qa-web` 等构建 profile                        |
| `status`                                    | 任务状态                                       |
| `requested_by`                              | 发起人                                         |
| `idempotency_key`                           | 防止按钮重试重复创建                           |
| `created_at` / `started_at` / `finished_at` | 时间                                           |
| `failure_code` / `failure_message`          | 结构化失败原因                                 |
| `log_uri`                                   | 完整日志地址                                   |

状态机：

```mermaid
stateDiagram-v2
    [*] --> QUEUED
    QUEUED --> LEASED
    LEASED --> CHECKOUT
    CHECKOUT --> INSTALLING
    INSTALLING --> BUILDING
    BUILDING --> VALIDATING
    VALIDATING --> UPLOADING
    UPLOADING --> SUCCEEDED
    QUEUED --> CANCELED
    LEASED --> CANCELING
    CHECKOUT --> CANCELING
    INSTALLING --> CANCELING
    BUILDING --> CANCELING
    VALIDATING --> CANCELING
    UPLOADING --> CANCELING
    CANCELING --> CANCELED
    CHECKOUT --> FAILED
    INSTALLING --> FAILED
    BUILDING --> FAILED
    VALIDATING --> FAILED
    UPLOADING --> FAILED
```

### 6.4 Artifact

Artifact 是构建成功后登记的不可变制品。

| 字段                  | 说明                                                     |
| --------------------- | -------------------------------------------------------- |
| `id`                  | 稳定 Artifact ID                                         |
| `build_job_id`        | 来源任务，唯一                                           |
| `target_id`           | 所属 Build Target                                        |
| `branch`              | QA 展示用分支标签                                        |
| `status`              | `STAGING`、`READY`、`QUARANTINED`、`DELETING`、`DELETED` |
| `storage_key`         | 对象存储根路径                                           |
| `manifest`            | 服务入口、文件清单、MIME、大小和摘要                     |
| `built_at`            | 打包完成时间                                             |
| `created_by`          | 发起人                                                   |
| `deletion_started_at` | 进入两阶段回收的时间                                     |

环境只能引用 `READY` Artifact。Artifact 一旦 `READY`，文件和 manifest 都不能原地覆盖。

### 6.5 Branch Build Catalog

Catalog 不需要独立真相表，可以由 Git 分支列表、Build Job 和 Artifact 聚合得到：

```text
target + branch
  分支是否存在
  是否正在构建
  最近一次任务状态
  最近一次成功 Artifact
  最近一次成功打包时间
```

分支的“最近成功 Artifact”只用于专用分支选择器和“有新包可用”提示。选择器支持搜索，按最近构建
活动排序，并把全局队列中的实时阶段和排队位置叠加到对应分支；队列轮询不重复查询 Git。

### 6.6 Environment

| 字段                  | 说明                           |
| --------------------- | ------------------------------ |
| `id` / `slug`         | 环境标识和域名片段             |
| `name`                | QA 展示名称                    |
| `current_revision_id` | 当前生效 Revision              |
| `status`              | `ACTIVE`、`FROZEN`、`ARCHIVED` |
| `upstream_profile`    | 官网或指定测试后端组合         |
| `expires_at`          | 可选 TTL                       |
| `created_by`          | 创建人                         |

### 6.7 Environment Revision

Revision 是环境完整配置的不可变快照。

```text
Environment Revision
  webapp    -> artifact-webapp-101
  online-h5 -> artifact-h5-205
  biz       -> artifact-biz-088
  base      -> artifact-base-1842       # 后续扩展
  gift      -> artifact-gift-930        # 后续扩展
  rule_set  -> ruleset-12
```

Revision Item 同时冗余保存 `branch` 和 `built_at`，用于保证审计展示不受后续元数据变更影响。

### 6.8 Environment Artifact Reference

Gateway 需要在环境切换后继续服务旧页面正在请求的异步 chunk，因此维护 `environment_artifact_refs`：

| 字段                 | 说明                        |
| -------------------- | --------------------------- |
| `environment_id`     | Artifact 被哪个环境使用过   |
| `artifact_id`        | 被 Revision 引用的 Artifact |
| `first_revision_id`  | 首次引用它的 Revision       |
| `last_revision_id`   | 最近一次引用它的 Revision   |
| `last_referenced_at` | 最近引用时间                |

发布 Revision 时在同一事务内 upsert 引用。Artifact 专属 URL 在某环境 Host 下，只有 `READY` 且被当前或历史 Revision 授权过的 Artifact 才可能读取；历史引用只保留访问审计关系，不构成文件保留承诺。尚未发布的候选 Artifact 不能通过环境域名直接读取。

## 7. Artifact Manifest

manifest 由 Runner 在构建后扫描输出目录生成，不能只信任项目自身生成的 manifest。

```json
{
  "schemaVersion": 1,
  "artifactId": "01JWEBAPP101",
  "target": "webapp",
  "branch": "feature/A_1",
  "builtAt": "2026-08-11T14:30:00+08:00",
  "serve": {
    "siteAdapter": "kook-webapp-v1",
    "entrypoints": [
      "index.htm",
      "activity.htm",
      "browser.htm",
      "picture.htm",
      "widget.htm",
      "toolbar.htm",
      "countdown.htm",
      "private_voice.htm",
      "exp/index.htm",
      "exp/qh.htm"
    ],
    "publicBase": "/__cuddly/artifacts/01JWEBAPP101/app/"
  },
  "files": [
    {
      "path": "index.htm",
      "size": 18342,
      "contentType": "text/html; charset=utf-8",
      "digest": "sha256:...",
      "cacheClass": "html"
    },
    {
      "path": "static/js/main.a1b2c3d4.js",
      "size": 940123,
      "contentType": "text/javascript; charset=utf-8",
      "digest": "sha256:...",
      "cacheClass": "immutable"
    }
  ]
}
```

摘要只用于完整性校验、ETag 和去重，不向 QA 展示，也不等同于 Git commit SHA。

## 8. 构建与发布流水线

```mermaid
sequenceDiagram
    participant QA as QA 面板
    participant API as Control API
    participant DB as PostgreSQL
    participant W as Build Worker
    participant R as Runner
    participant S as Artifact Store

    QA->>API: POST Build Job(target, branch)
    API->>DB: 写入 QUEUED
    API-->>QA: 202 + jobId
    W->>DB: lease job
    W->>R: 执行隔离构建
    R->>R: clone / checkout / install / build
    R->>R: 校验入口、文件、MIME、引用完整性
    R->>S: 上传到 staging/{artifactId}
    R->>S: 校验上传结果
    R->>S: 原子发布到 artifacts/{targetId}/{artifactId}
    W->>DB: Artifact READY + Job SUCCEEDED
    API-->>QA: SSE 推送“新包已就绪”
    Note over QA,DB: 环境仍未发生变化
```

### 8.1 源码隔离

禁止在共享 clone 中切分支，也不使用 Git worktree。

Runner 维护持久的 shallow bare 对象缓存，每个 Job 创建一次性独立 clone：

```text
/srv/cuddly/git-cache/v1/repositories/<hmac>.git # 按仓库与凭据隔离，只做浅 fetch
/srv/cuddly/runner-jobs/<jobId>/source           # 一次性 depth-1 clone
```

缓存键为设置密钥对“仓库地址 + HTTP 认证头或 SSH 身份指纹”的 HMAC，不在磁盘路径中暴露仓库或
凭据。每次 checkout 都先强制 fetch 所选远端分支，成功解析本次 commit 后才从缓存通过本机 Git
传输物化工作目录；远端失败时不读取已有 tip。工作目录恢复真实分支、`origin` 和 upstream，且不含
alternates，所以缓存清理不会破坏正在运行的 Job。

同一缓存键的初始化、fetch 与对象复制由进程内锁和文件锁串行化；复制完成后立即释放仓库锁，
checkout、Git LFS、依赖安装和构建继续在各自 Job 中并行。不同缓存键从一开始即可并行。fetch 前
清除缓存中的旧 tag 引用，再由本次远端 fetch 恢复当前分支可达的 tag，避免删除或移动过的 tag
泄漏到新工作目录。

只有缓存自身明确不可用时，Runner 才删除未完成目录并重试原有的远端
`--depth 1 --single-branch` clone；远端网络、鉴权、分支、磁盘压力和未知 I/O 错误不回退，避免
重复下载、陈旧结果和容量保护绕过。缓存默认采用 14 天 LRU、1 GiB 目标软上限、4 GiB 清理水位
和 2 GiB 拒绝水位；缓存物化与直接 clone 共用容量预留。当前部署约束为一个 Runner 实例，文件锁
负责异常恢复与未来多进程冲突保护，但不将其视为完整的跨实例调度协议。

任务结束后删除 Job 目录。不同任务之间不共享工作目录、`node_modules` 或构建输出。依赖下载缓存
使用包管理器缓存目录，不复用源码目录。

### 8.2 Runner 安全边界

- 每个任务运行在独立容器中。
- 仓库凭据只在 checkout 阶段短期挂载，构建阶段尽可能移除。
- CPU、内存、磁盘和最大运行时间均有限额。
- 默认禁止访问 Docker Socket。
- 构建网络按 Project/Target allowlist 配置。
- 分支名只作为 Git 参数，不拼接到 shell 命令或存储路径。
- Artifact 存储路径使用内部 ID，不使用原始分支名。

### 8.3 Build Adapter

```ts
interface BuildAdapter {
  key: string
  checkout: {
    projectId: string
    workdir: string
  }
  runtime: {
    image: string
    cpu: number
    memoryMb: number
    timeoutSeconds: number
  }
  build: {
    install: string[]
    commands: string[]
    outputDir: string
    env: Record<string, string>
  }
  validation: ArtifactValidationSpec
  siteAdapter: string
}
```

首批适配器：

| Target      | workdir       | 构建命令                     | 输出     | 关键校验                                              |
| ----------- | ------------- | ---------------------------- | -------- | ----------------------------------------------------- |
| `webapp`    | `apps/webapp` | `npm run build:ttt:nosource` | `build/` | `index.htm`、全部入口、`static/`、动态 chunk 引用     |
| `online-h5` | 仓库根        | `pnpm run build`             | `build/` | 五个 `.htm` 入口、manifest 全文件、`public/` 复制结果 |
| `biz`       | 仓库根        | `npm run build`              | `build/` | `index.html`、`static/`、`statics/`                   |

### 8.4 Artifact 专属资源前缀

环境切换时，已经打开的旧页面仍可能继续加载异步 chunk。若所有资源都使用 `/static/*`，环境切换后旧页面会去新 Artifact 查旧 chunk，产生 404。

因此每次构建在开始前预分配 Artifact ID，并把资源 public path 设置为不可变路径：

```text
/__cuddly/artifacts/<artifactId>/app/      # webapp
/__cuddly/artifacts/<artifactId>/          # online-h5
/__cuddly/artifacts/<artifactId>/          # biz
```

具体处理：

- webapp 已支持 `PUB_PATH`，构建时传入 Artifact 专属 `/app/` 前缀。
- biz 已支持 `PUB_PATH`，直接传入 Artifact 专属前缀。
- online H5 当前固定 `/` 的 `assetPrefix` 由 Cuddly Build Adapter 在临时 clone 中应用确定性补丁，使其允许构建环境变量覆盖。补丁保存在 `patches/html-h5/`，不推送业务仓库远端。
- HTML 入口仍通过环境域名的正常路径访问，但 HTML 内的 JS/CSS 和动态 chunk 都指向 Artifact 专属路径。

Artifact ID 隔离可避免新旧页面在 Revision 切换瞬间混用文件。当前 Revision 使用的旧包不会被
回收；一旦它退出当前 Revision 且没有有效 Preview，保留任务可以删除其文件，因此已打开的历史
页面不提供无限期的异步 chunk 可用保证。

## 9. Artifact 存储

### 9.1 存储接口

```ts
interface ArtifactStore {
  putStaging(artifactId: string, files: AsyncIterable<ArtifactFile>): Promise<void>
  verifyStaging(artifactId: string, manifest: ArtifactManifest): Promise<void>
  publish(targetId: string, artifactId: string): Promise<string>
  open(storageKey: string, path: string, range?: ByteRange): Promise<ArtifactObject>
  delete(storageKey: string): Promise<void>
}
```

实现：

- 首期开发和正式部署：服务器本地文件系统，根目录 `/srv/cuddly/artifacts`。临时目录完成后通过同文件系统 rename 原子发布。
- 后续扩展：阿里云 OSS 或 S3 兼容存储。ArtifactStore 接口从第一天保留，但首期不部署对象存储依赖。

本地磁盘目录：

```text
/srv/cuddly/artifacts/staging/<artifactId>/
/srv/cuddly/artifacts/ready/<targetId>/<artifactId>/
/srv/cuddly/build-logs/<yyyy>/<mm>/<jobId>.log
```

`staging` 和 `ready` 必须位于同一文件系统，确保 rename 原子性。Gateway 只读取 `ready`，并且仍以数据库 `Artifact.status = READY` 作为可见条件。

### 9.2 存储键

```text
artifacts/<targetId>/<artifactId>/manifest.json
artifacts/<targetId>/<artifactId>/files/...
build-logs/<yyyy>/<mm>/<jobId>.log
```

不创建 `latest/` 可变目录，也不让 Gateway 按 `branch/latest` 取运行时文件。

### 9.3 保留策略

- 每个 `target + branch` 保留一个最新 READY 候选 Artifact。
- 当前 Environment Revision、当前站点及尚未过期 Preview 使用的 Artifact 禁止删除；所以仍在
  服役的旧包可以和最新候选并存，构建成功不会自动发布或替换当前 Revision。
- 历史 Revision 继续保留 Artifact ID、分支和时间等轻量审计信息，但不作为文件保留依据。
- 成功构建登记新包后立即触发清理；Worker 启动时及运行期间每分钟 sweep，回收 Preview 到期或
  Revision 切换后新近解除引用的旧包。
- 删除采用两阶段流程：数据库原子标记 `DELETING`，Runner 校验精确 storage key 后把目录原子移动
  到同文件系统回收区、完成物理删除，最后记录 `DELETED` tombstone。请求超时、断网或 5xx 的结果
  均视为不确定并保持 `DELETING`，5 分钟后幂等重试；绝不让 READY 指向可能已删或残缺的目录。
- 发布失败会清理 staging；Worker 还会定期核对 Runner 磁盘清单，超过安全宽限期且数据库无记录的
  orphan 目录也会进入同一幂等删除链路，避免异常或崩溃绕过单槽上限。
- Preview 创建和 Revision 发布与候选标记共用短事务锁，并在事务内复验 READY，避免引用刚被
  选中删除的旧包。

## 10. Bifrost Gateway 设计

### 10.1 请求处理顺序

```mermaid
flowchart TD
    R["收到请求"] --> H["解析 Host -> Environment + Site"]
    H --> C{"/__cuddly 或控制端保留路径?"}
    C -->|是| I["内部端点"]
    C -->|否| B{"命中明确后端路由?"}
    B -->|是| P["代理官网后端并应用规则"]
    B -->|否| A{"命中 Artifact 精确文件?"}
    A -->|是| S["流式返回 Artifact"]
    A -->|否| M{"属于静态资源命名空间?"}
    M -->|是| N["404，不回退官网前端"]
    M -->|否| V{"浏览器 HTML 导航?"}
    V -->|是| E["返回当前 Artifact 的入口 HTML"]
    V -->|否| X{"XHR/JSON 等应用请求?"}
    X -->|是| P
    X -->|否| N
```

### 10.2 路由判定接口

```ts
interface SiteAdapter {
  id: string
  site: 'webapp' | 'online-h5' | 'biz'
  upstream: URL

  isBackendRequest(req: Request): boolean
  resolveArtifactFile(req: Request, manifest: ArtifactManifest): ArtifactFileMatch | null
  isExpectedStaticPath(req: Request): boolean
  resolveNavigationEntry(req: Request, manifest: ArtifactManifest): string | null

  rewriteProxyRequest(req: Request): void
  proxyRules: ProxyRule[]
}
```

判定原则：

1. `POST/PUT/PATCH/DELETE` 默认视为后端请求，内部控制路径除外。
2. 已知 `/api/`、`/mis/` 等前缀优先代理。
3. Artifact 文件必须通过 manifest 精确命中，禁止直接拼接磁盘路径。
4. 带静态扩展名或位于静态命名空间的请求，找不到文件就返回 404。
5. HTML fallback 只接受 `GET/HEAD` 且请求是浏览器导航。
6. 非导航 XHR/fetch 可以作为上游应用请求代理，但必须记录未登记路由指标，逐步收敛 allowlist。

### 10.3 静态响应链

静态制品不经过现有 `responseInterceptor`：

- HTML 由轻量 `HtmlShellRenderer` 读取并注入环境 bootstrap，然后返回。
- JS/CSS/字体/图片直接从 Artifact Store 流式返回。
- 支持 `HEAD`、`Range`、`If-None-Match` 和正确 MIME。
- 对象存储异常返回明确的 502，不回退官网静态文件。

Artifact 专属 URL 的授权规则：

1. 先根据 Host 确认用户有权访问该 Environment。
2. 再校验 URL 中的 Artifact ID 存在于该环境的 `environment_artifact_refs`。
3. Artifact 还必须为 READY；当前 Revision 和有效 Preview 引用会阻止其进入删除流程。
4. 仅存在于 Branch Catalog、尚未发布到该环境的候选 Artifact 不可读取。
5. 需要预览候选包时，由 Control API 生成短时效、只读的 preview token，不放宽环境网关授权。
6. 历史 Revision 仅保留审计记录；其 Artifact 若已标记 DELETED，即使 ID 仍在引用历史中也不可读。

缓存策略：

| 类型                            | Cache-Control                         |
| ------------------------------- | ------------------------------------- |
| 环境入口 HTML                   | `no-cache, must-revalidate`           |
| Artifact 专属且带 hash 的文件   | `public, max-age=31536000, immutable` |
| Artifact 专属但不带 hash 的文件 | `public, max-age=86400`               |
| `/__cuddly/runtime`             | `no-store`                            |
| API 代理响应                    | 保留上游语义，覆盖规则另行决定        |

### 10.4 HTML bootstrap

Gateway 只改写入口 HTML，不改写普通 JS/CSS：

```html
<script src="/__cuddly/bootstrap.js"></script>
<script src="/__cuddly/hooks/k-inject-12.js"></script>
```

`bootstrap.js` 返回当前 Environment、Revision、Site 和 Artifact，并设置 `window.__CUDDLY__`。它使用 `no-store`，实际输出必须用安全 JSON 序列化并转义 `<`。采用同源外部脚本而不是内联脚本，便于收紧 CSP。

Gateway 以同源、版本化路径服务审核过的 `k-inject` 文件，避免页面依赖管理端跨域地址。Hook 加载失败不能阻塞主页面。Revision 或 Gateway 配置中记录 hook 版本，便于回滚和审计。

### 10.5 后端代理链

继续复用 Bifrost 的：

- `changeOrigin`。
- Cookie Domain 改写。
- 3xx Location 改写。
- 接口 JSON 覆盖。
- CDN/站点绝对 URL 改写。

但响应处理需要从“所有文本响应完整缓冲”演进为：

```text
请求是否可能命中响应规则？
  是 -> 限制最大响应大小，缓冲并改写
  否 -> 原生流式 proxy.pipe(res)
```

这样下载、长响应和普通 API 不承担无意义的缓冲成本。

## 11. 三站点路由适配

### 11.1 webapp

Artifact 根目录是 `apps/webapp/build`。

| 请求               | Artifact 映射                 |
| ------------------ | ----------------------------- |
| `/`                | `index.htm`                   |
| `/app/<file>`      | `<file>`                      |
| `/app/<spa-route>` | `index.htm`，仅 HTML 导航     |
| `/exp/<file>`      | `exp/<file>`                  |
| `/exp/<route>`     | `exp/index.htm`，仅 HTML 导航 |
| `/widget`          | `widget.htm`                  |
| `/api/*`           | 代理 `https://www.kookapp.cn` |

必须校验全部 Rspack HTML 入口。`/app/static/*` 请求在 Artifact 中映射到 `static/*`。

Module Federation：

- 当前环境选中的 webapp Artifact 使用 Artifact 专属 public path。
- Remote 仍可由现有 hot-module 接口映射；未来 Remote Artifact 也使用同一不可变 URL 规范。
- 首期网页 shell 已加载 bootstrap，因此 Artifact 自身的普通 chunk 不再走 `remoteEntryInject`。
- 从官网 CDN 镜像回来的 Remote 继续保留现有注入规则，直到浏览器扩展或统一 bootstrap 完全接管。

### 11.2 在线 H5

Artifact 根目录是 `html_h5/build`。

正式入口：

```text
index.htm
topup.htm
gift-gacha.htm
card-collect.htm
ratings-preview.htm
```

路由规则：

- 精确命中任意 Artifact 文件时直接返回。
- 上述入口路径精确映射对应 HTML。
- 主站未知导航路径 fallback 到 `index.htm`。
- `/api/*` 和非导航应用请求代理 `https://m.kookapp.cn`。
- `/app/*` 保留当前移动站跳转语义，是否 301 由 Site Adapter 明确实现。

校验必须检查：

- 五个正式入口全部存在。
- Runner 生成的 manifest 中每个文件都存在且大小大于零。
- HTML 引用的本地 JS/CSS/字体存在。
- `public/` 中需要上线的历史页面和 SDK 被完整复制。
- HTTPS 页面不包含会触发混合内容的关键 HTTP 资源。

在线 H5 是首个 PoC 目标。它具备多入口和历史静态资源，足以验证 Artifact 完整性、资源路径、HTML fallback、API 代理、Cookie 和环境发布，同时不需要先处理 biz OAuth 的额外不确定性。

### 11.3 biz

Artifact 根目录是 `biz-fe/build`。

| 请求             | 处理                                                                     |
| ---------------- | ------------------------------------------------------------------------ |
| `/api/*`         | 代理 `https://biz.kookapp.cn`                                            |
| `/mis/*`         | 首期代理 `https://biz.kookapp.cn`，通过抓包确认后再决定是否拆分 upstream |
| 精确静态文件     | 返回 Artifact 文件                                                       |
| 其它 HTML 导航   | `index.html`                                                             |
| 找不到的静态路径 | 404                                                                      |

biz 不作为首个 PoC。接入前需要先完成 OAuth 专项验证：

- 登录入口和真正的授权服务域名。
- `redirect_uri`、`state`、PKCE 或其它防重放参数。
- OAuth 回调落在哪个 Host 和路径。
- 302 Location 是否会跳回官网域名。
- 登录 Cookie 的 Domain、SameSite、Secure 和跨站行为。
- `/api`、`/mis` 是否实际由同一 upstream 处理。

这些信息收敛后再决定 Site Adapter 的 OAuth 路由是透明代理、回调域名改写，还是使用独立认证 upstream。

## 12. Control API

所有写 API 接受 `Idempotency-Key`。Environment 更新同时接受 `baseRevisionId`，用于乐观并发控制。

### 12.1 分支与候选制品

```http
GET /api/v1/build-targets/{targetId}/branches?query=feature%2FA
```

```json
{
  "items": [
    {
      "branch": "feature/A_1",
      "buildStatus": "IDLE",
      "latestArtifact": {
        "id": "artifact-webapp-102",
        "builtAt": "2026-08-11T11:00:00+08:00"
      }
    },
    {
      "branch": "feature/A_2",
      "buildStatus": "IDLE",
      "latestArtifact": null
    }
  ]
}
```

### 12.2 发起构建

```http
POST /api/v1/build-jobs
Idempotency-Key: 4ecb...
Content-Type: application/json

{
  "targetId": "webapp",
  "branch": "feature/A_1",
  "profile": "qa-web"
}
```

返回 `202 Accepted` 和 `jobId`。重复幂等键返回同一个 Job。

运行中或排队任务可由构建记录详情中断：

```http
POST /api/v1/build-jobs/{jobId}/cancel
```

排队任务原子进入 `CANCELED`；运行任务原子进入 `CANCELING`，Runner 终止完整命令进程组且执行器
真正退出后才进入 `CANCELED`。同一项目在 `CANCELING` 期间仍保持占用，避免新旧构建并行写入。

### 12.3 构建状态与日志

```text
GET /api/v1/build-jobs/{jobId}
GET /api/v1/build-jobs/{jobId}/events     # SSE
POST /api/v1/build-jobs/{jobId}/cancel
```

SSE 只推送状态和增量日志位置；完整日志由分页接口或对象存储读取，避免连接重放超大日志。

### 12.4 环境矩阵

```http
GET /api/v1/environments/{environmentId}/matrix
```

每行返回：

- target/package。
- 当前 Artifact、分支、打包时间。
- 所选分支最近成功 Artifact。
- 是否有新包可用。
- 当前构建任务。

### 12.5 原子发布新 Revision

前端在本地暂存多行变更，最终提交完整选择：

```http
POST /api/v1/environments/{environmentId}/revisions
Idempotency-Key: 93a2...
Content-Type: application/json

{
  "baseRevisionId": "revision-41",
  "message": "切换 webapp 和 online-h5 到 A 需求",
  "selections": [
    { "targetId": "webapp", "artifactId": "artifact-webapp-102" },
    { "targetId": "online-h5", "artifactId": "artifact-h5-205" },
    { "targetId": "biz", "artifactId": "artifact-biz-088" }
  ]
}
```

如果当前 Revision 已不是 `revision-41`，返回 `409 REVISION_CONFLICT`，附带最新矩阵，前端要求 QA 重新确认。

### 12.6 回滚

```http
POST /api/v1/environments/{environmentId}/rollback

{
  "baseRevisionId": "revision-42",
  "targetRevisionId": "revision-40"
}
```

实现上创建一条内容等同于历史 Revision 的新 Revision，而不是把 `current_revision_id` 指回旧记录。这样审计时间线保持单向增长。每分支单槽策略下，只有目标 Artifact 仍为 `READY` 时才能回滚；已回收的历史 Revision 仅用于审计，需要先重新打包对应分支才能再次使用。

## 13. 数据库表与约束

核心表：

```text
projects
build_targets
build_jobs
build_job_events
artifacts
environments
environment_hosts
environment_revisions
environment_revision_items
environment_artifact_refs
proxy_rule_sets
audit_events
idempotency_records
```

关键约束：

- `artifacts.build_job_id` 唯一。
- `environment_hosts.hostname` 唯一。
- `environment_revisions(environment_id, revision_no)` 唯一。
- `environment_revision_items(revision_id, target_id)` 唯一。
- `environment_artifact_refs(environment_id, artifact_id)` 唯一。
- Revision Item 的 Artifact `target_id` 必须与 Item `target_id` 相同。
- `current_revision_id` 必须属于同一 Environment。
- 当前 `Environment.current_revision_id` 对应 Revision Item 使用的 Artifact 不能物理删除；历史
  Revision Item 只保留审计元数据，不阻止文件回收。

发布事务伪代码：

```sql
BEGIN;
SELECT current_revision_id FROM environments WHERE id = $1 FOR UPDATE;
-- 与 baseRevisionId 比较
-- 校验 Artifact READY、target 匹配、必选 target 完整
INSERT INTO environment_revisions (...);
INSERT INTO environment_revision_items (...完整矩阵...);
INSERT INTO environment_artifact_refs (...) ON CONFLICT (...) DO UPDATE ...;
UPDATE environments SET current_revision_id = $newRevision WHERE id = $1;
INSERT INTO audit_events (...);
COMMIT;
```

## 14. QA 面板契约

环境首页必须直接展示完整当前状态，不以操作历史代替：

| 包/站点   | 当前使用分支  | 当前包时间 | 查看分支      | 分支最新包 | 状态/操作               |
| --------- | ------------- | ---------- | ------------- | ---------- | ----------------------- |
| webapp    | `feature/A_1` | 10:30      | `feature/A_1` | 11:00      | `使用新包` / `打最新包` |
| online-h5 | `master`      | 昨天 18:20 | `feature/A_1` | 暂无       | `打最新包`              |
| biz       | `master`      | 昨天 16:00 | `master`      | 昨天 16:00 | 已是最新                |

交互规则：

1. 在专用分支选择器中切换分支只是查看候选，不改变环境。
2. `打最新包` 只创建 Build Job。
3. 构建完成后当前行显示新候选，但不自动加入待发布选择。
4. `使用新包` 把具体 Artifact 放入前端暂存矩阵。
5. 页面统一显示“发布 N 项变更”，一次确认后原子生效。
6. 每行可查看 Artifact 历史，但主表永远优先展示当前真相。
7. SHA 不出现在默认页面。

## 15. 身份、权限与 Cookie

### 15.1 角色

| 角色      | 权限                                       |
| --------- | ------------------------------------------ |
| Viewer    | 查看环境、矩阵、构建状态和日志             |
| QA        | 创建构建、修改和发布 QA 环境、回滚         |
| Developer | QA 权限 + 管理自己负责的 Build Target 配置 |
| Admin     | 管理项目、Runner、规则集、权限和保留策略   |

首期暂不实现完整 RBAC。QA 与配置接口均匿名开放，可以查看、构建、发布、回滚 `shared` 环境并维护项目配置；请求携带的操作标识仅用于队列展示和审计，不能证明真实身份。浏览器扩展默认生成稳定的本机匿名标识，并允许在折叠的高级设置中填写可选显示名。部署者应使用网络边界限制控制台访问者，接入飞书 SSO 时再启用上表角色。

### 15.2 飞书登录

飞书登录不进入首期：

- 普通 QA API 不做鉴权，控制台无需登录即可使用。
- 操作标识通过请求头传递，仅用于队列展示和弱审计；扩展默认使用稳定的本机匿名标识，可选显示名不代表认证身份。
- 项目仓库、构建命令和代理订阅等配置首期不单独鉴权，由 Nginx 内网/IP allowlist 等网络边界保护控制面。
- Gateway 数据面同样可由 Nginx 内网/IP allowlist 保护，不向 KOOK 页面注入管理凭据。
- 发布、回滚和配置变更写审计日志，操作者首期记录为自报显示名。
- 后续飞书 SSO 只替换身份提供者和角色解析，不改变 Build、Artifact 和 Revision API。

### 15.3 业务站 Cookie

首期没有 Cuddly 管理授权 Cookie。KOOK 上游 Cookie 由 Gateway 代理登录接口时改写 Domain。

新域名下统一改写到 `.bifrost.qa.vanillacake.cn`。必须保留 `Secure`、`HttpOnly` 和合理的 `SameSite`，并用真实登录流程测试，而不是只看响应头。

## 16. 一致性、缓存与故障处理

### 16.1 Revision 缓存

Gateway 缓存 `hostname -> current revision`，默认 TTL 2 秒。发布成功后 Control API 发送失效通知；通知丢失时 TTL 兜底。

入口 HTML 返回 `X-Cuddly-Revision` 和 `X-Cuddly-Artifact`，便于定位 QA 截图对应的版本。

### 16.2 故障策略

| 故障                      | 行为                                                            |
| ------------------------- | --------------------------------------------------------------- |
| Artifact 文件缺失         | 404/502 + 结构化日志，绝不回退官网前端                          |
| Artifact Store 暂时不可用 | 502，可由 Nginx 短时缓存已有静态对象                            |
| PostgreSQL 暂时不可用     | Gateway 使用短期 last-known-good Revision；控制面写操作失败关闭 |
| Build Worker 宕机         | lease 超时后任务重新入队；Runner 操作必须幂等                   |
| 构建成功但 DB 未登记      | staging 内容由清理任务回收，不对环境可见                        |
| DB 已 READY 但对象缺失    | 健康检查将 Artifact 标记 `QUARANTINED`，禁止新 Revision 引用    |
| 上游 API 超时             | 返回明确 502/504，记录 site/environment/upstream                |

### 16.3 不允许的降级

- 不允许从 Artifact 页面静默切回官网 HTML。
- 不允许找不到当前 Artifact 时自动改用该分支最新 Artifact。
- 不允许部分 Revision Item 成功、部分失败。
- 不允许 Build Job 成功后直接调用环境发布接口。

## 17. 可观测性与诊断

每个请求日志至少包含：

```text
request_id
environment_id
revision_id
site
artifact_id（静态请求）
upstream（代理请求）
route_decision
status
duration_ms
response_bytes
```

诊断端点：

```text
GET /__cuddly/whoami
GET /__cuddly/runtime
GET /__cuddly/health/live
GET /__cuddly/health/ready
```

`whoami` 返回收到的 Host、环境、站点、Revision、当前 Artifact 和最终路由判断，不返回凭据或完整 Cookie。

关键指标：

- Build Job 排队时间、构建时间、成功率、失败阶段。
- Artifact 上传时间、校验失败次数、存储字节数。
- Gateway 静态命中率、Artifact 404、上游代理延迟和 5xx。
- Revision 发布次数、冲突次数、回滚次数。
- 未登记但被代理的应用路径，用于收敛 backend allowlist。

## 18. 测试策略

### 18.1 单元测试

- Site Adapter 路径映射和导航判定。
- manifest 生成和路径穿越防护。
- Branch Catalog 最新候选计算。
- Revision 完整性和 Artifact target 匹配。
- Cookie Domain、Location 和文本 URL 改写。

### 18.2 集成测试

- 使用临时 PostgreSQL、MinIO 和假上游服务跑完整 Control API/Gateway。
- 构建成功后只产生 Artifact，不改变 Environment。
- 多项选择一次发布且不存在半发布状态。
- 旧页面在环境切换后仍能加载 Artifact 专属异步 chunk。
- Artifact 缺文件时不会请求官网同名静态文件。

### 18.3 真实链路 E2E

- 匿名配置面、KOOK 登录、Cookie 共享和退出登录；后续补飞书登录回归。
- webapp 主页面、频道导航、动态 chunk、Module Federation。
- H5 五个入口和历史 public 页面。
- biz 登录、刷新深层 SPA 路由、`/api` 和 `/mis`。
- 构建、显示新候选、使用新包、发布、回滚。
- 两个 QA 环境同时使用不同 Artifact，互不影响。
- Gateway API 获取官方 Gateway URL后的 WebSocket 直连。

## 19. 分阶段实施

### 阶段 A：Artifact 基础设施

- 在 `cuddly-umbrella` 内建立 pnpm workspace 和 Docker Compose。
- 将 Bifrost 前后端必要代码迁入 `apps/gateway`、`apps/console` 和 `packages/bifrost-rules`，原仓库不再参与运行和发布。
- Compose 启动 PostgreSQL 16，并使用 `/srv/cuddly/postgres` 持久化。
- PostgreSQL schema、Control API、Build Job queue。
- Console 直接调用 Control API；KOOK Bot 客户端不进入首个切片。
- Runner 一次性 clone、构建、manifest 校验和 Artifact 上传。
- `/srv/cuddly/artifacts` 本地 Artifact Store，同时保留 OSS/S3 接口边界。
- Branch Catalog API。
- QA 与配置 API 首期匿名开放，由部署网络边界控制访问范围。

完成标准：同一目标的每个分支保留一个最新候选 Artifact；服役旧包在新包完成前不被删除，构建不改变环境。

### 阶段 B：在线 H5 闭环 PoC

- `shared` Environment 和 Revision。
- H5 构建 public path 环境变量。
- 五入口和 public 文件校验。
- mobile Site Adapter、登录和 Cookie 验证。
- 最小 QA 矩阵、打最新包、使用新包、发布和回滚。

完成标准：`bifrost-api-mobile` 的五个入口均来自所选 Artifact，API 走官网代理，登录态正常，制品缺失不会混用官网静态资源，并能原子发布和回滚。

### 阶段 C：webapp

- `/app/`、`/exp/`、`/widget` 等路径映射。
- HTML bootstrap 和现有 `k-inject` 迁移。
- Module Federation、动态 chunk、Gateway API/WebSocket 边界验证。

完成标准：主页面、频道路由、异步 chunk 和现有 Bifrost 覆盖全部正常。

### 阶段 D：biz 与 OAuth

- 抓取并固化完整 OAuth 登录、授权、回调和退出登录时序。
- 明确 `/api`、`/mis` 和认证服务的 upstream 划分。
- 实现 biz Site Adapter、OAuth Location 改写和 Cookie 策略。
- 验证 SPA 深层路由、刷新、登录过期和重新授权。

完成标准：biz 页面来自所选 Artifact，OAuth 全链路不跳出环境域名，后端请求仍走正确 upstream，登录和退出登录可重复执行。

### 阶段 E：多环境与公网化

- 通配符环境域名、环境克隆、TTL、成员权限。
- 飞书 SSO/RBAC、审计、限流和公网安全加固。
- 浏览器扩展环境选择与明确环境标识。

完成标准：两个需求可以并行测试不同 webapp/H5/biz 组合，QA 能从面板一眼确认完整当前状态。

## 20. 对现有项目的改造边界

### 20.1 `kook-builder`

首期正式实现不依赖原 `kook-builder` 仓库。Shell 构建逻辑在 Cuddly 内重新落入 Runner/Build Adapter。若需要继续保留 KOOK Bot 交互，再把最小 Bot 客户端迁入 `cuddly-umbrella`，只调用 Control API 和展示 Job 状态。

### 20.2 `bifrost-kookapp`

开始实现时把必要代码迁入 Cuddly，之后原 `bifrost-kookapp` 不再作为独立项目维护。优先迁移并复用：

- Host 分流。
- Cookie Domain 和 Location 改写。
- JSON/文本响应规则模型。
- CDN 镜像和站点 URL 映射。
- `whoami` 诊断思路。

需要替换：

- 全局 `misData` 文件改为 Environment Revision + Rule Set。
- 所有请求统一走官网代理，改为 Artifact 静态服务与后端代理分流。
- 所有文本响应统一缓冲，改为只缓冲可能命中规则的响应。
- 无鉴权管理接口迁入 Control API，并由部署网络边界限制访问；飞书会话和 RBAC 后续接入。

### 20.3 `bifrost-frontend/bifrost-mis`

把可复用的账号上下文、配置交互和页面 Hook 资源迁入 `apps/console`。不保留对原 Bifrost 管理端部署地址的运行时依赖，`k-inject` 改由 Gateway 通过同源版本化路径服务。

### 20.4 三个前端仓库

- webapp：Runner 在临时 clone 中传入 Artifact 专属 `PUB_PATH`，不要求推送业务仓库。
- biz：Runner 在临时 clone 中传入 Artifact 专属 `PUB_PATH`，不要求推送业务仓库。
- online H5：Runner 在临时 clone 中应用 Cuddly 自带补丁，再传入 Artifact 专属 `assetPrefix`。
- 三个原仓库都只作为构建源码来源，不负责上传、环境选择或自动部署。
- 不向这些业务仓库的 Git 远端 push Cuddly 适配代码。

### 20.5 主站 Remote 标签页预览

主站热更复用公共 Environment Revision，并允许浏览器扩展为当前标签页创建优先级更高的独立 Preview Session：

- Control API 保存 `Preview Token -> Remote module key -> 精确 Artifact`，默认有效期 8 小时。
- 项目标识必须与 KOOK Remote key 一致，并使用 `kook-remote-v1` Build Adapter。
- Remote 默认安装命令使用 `--filter "{./apps/<module>}..." --fail-if-no-match`，只安装目标应用及其 workspace 依赖闭包；不能为方便而回退到全仓安装。
- Runner 为每个 Artifact 生成唯一 Module Federation provider name，并将 `PUB_PATH` 指向 Artifact 专属路径；历史分支缺少 `.remote-version` 时，必须在 `remoteEntry.js` 中校验精确 provider 声明，不能仅凭 URL 或文件名放行。
- Runner 在临时 clone 中关闭 Remote 的 Sentry Webpack release/sourcemap 上传，避免 QA 候选包创建正式 Sentry release；运行时 SDK、业务 bundle 逻辑和 Git 仓库均不修改。
- Gateway 代理 KOOK 的完整 `hot-module` 响应，只覆盖当前 Revision 或 Preview 明确选择的 module key；未选择模块和批次元数据原样保留。
- 覆盖项首期统一下发 `restartRequired: true`，以刷新/重启后加载为安全边界，不承诺进程内无刷新热切换。
- 原始 `app`、`addon`、`id` 查询参数、Cookie 和 Authorization 只转发到站点配置的 KOOK 上游；`x-cuddly-*` 内部头不会外传。
- 扩展不再跨域重定向官网热更请求，而是把目标标签页导航到对应站点的隔离预览域名，并附加标签页级 Preview Token。
- 旧版 token-scoped 稀疏热更接口返回 `410`；无效、过期或跨站点 Token 返回 `404`，不得回退公共 Revision。
- 只选择 Remote 时，Gateway 代理官网页面；选择页面 Artifact 时，页面和 Remote 使用同一个 Preview Token。
- Candidate Remote Artifact 在被有效 Preview 或当前 Environment Revision 使用时保持可读；历史
  Revision 只保留审计元数据，不保证文件仍可用于回滚。
- 关闭标签页、离开预览域、替换组合或手动停用后，扩展清理对应 DNR 规则并通过普通 QA API 幂等撤销精确 Preview Token；撤销后新查询立即失效，同时为 Gateway 最长 30 秒的正缓存保留 35 秒 Artifact 回收保护窗。Preview Token 到期后 Gateway 立即拒绝访问，扩展同时把仍停留在预览域名的标签页送回对应官网路径。

该链路同时支持公共环境组合和互不干扰的标签页组合；构建完成只产生候选 Artifact，不会自动改变任何组合。

## 21. 首个可开发切片

第一个代码切片只实现在线 H5，但接口和数据模型按完整方案建立：

1. 在 Cuddly 内建立 pnpm workspace、Docker Compose 和 `/srv/cuddly` 数据目录约定。
2. 迁入 Bifrost Gateway、管理端和规则代码，解除对原 Bifrost 仓库和部署地址的依赖。
3. Compose 启动 PostgreSQL、Control API、Gateway、Worker、Runner 和 Console。
4. 建立 `build_targets`、`build_jobs`、`artifacts`、`environments`、`environment_revisions` 和 items 表。
5. QA 与配置接口首期匿名开放，由部署网络边界控制访问范围。
6. 在 `patches/html-h5/` 保存 `assetPrefix` 构建适配，由 Runner 对临时 clone 应用。
7. 写 `online-h5` Build Adapter，在一次性 clone 中构建并原子发布到 `/srv/cuddly/artifacts`。
8. 写 H5 Artifact validator：校验五个 `.htm` 入口、manifest 全文件、HTML 本地引用和 `public/` 复制结果。
9. 写 `online-h5` Site Adapter：`/api` 代理、精确静态文件、五入口映射、主入口 HTML fallback 和 `/app` 跳转语义。
10. 写最小 Revision 发布 API，使用完整矩阵和 `baseRevisionId`。
11. QA 页面只做三行矩阵骨架，首期启用 online-h5 行。
12. 完成“打包不生效 -> 新候选提示 -> 使用新包 -> 发布 -> 五入口访问 -> 回滚”的 E2E。
13. 补充真实移动站登录、Cookie Domain/SameSite/Secure 和 302 Location 改写测试。

这个切片可以验证最重要的架构契约，同时避开 biz OAuth 和 webapp Module Federation 的额外复杂度。在线 H5 自身的多入口和历史 `public/` 资源也足以检验 Artifact 发布方案是否真正完整。

## 22. 正式实现前剩余信息

当前信息已经足够开始本地开发、Bifrost 迁入、数据库 schema、Compose 和在线 H5 构建链路。以下内容不阻塞项目初始化，但必须在服务器 E2E 前确认。

### 22.1 服务器与入口

- 服务器 Linux 发行版、CPU/内存/磁盘容量。
- 部署账号及 `/srv/cuddly` 的目录权限。
- 当前 Nginx 配置位置和可用端口。
- 首期继续使用 `bifrost-api-mobile.vanillacake.cn`，还是增加灰度域名。
- TLS 证书由现有 Nginx 管理还是需要 Compose 内处理。

### 22.2 构建访问

- `html_h5` 在服务器上实际使用的 Git URL 和只读 SSH 凭据安装方式。
- 在线 H5 正式使用的 Node、pnpm 版本和构建网络代理。
- 打包机能否访问 npm、私有 Git 和构建期间使用的外部资源。

### 22.3 移动站验收

- 一个可以完成真实登录的 QA 测试账号，凭据不写入仓库和文档。
- 登录、退出、登录过期、文件上传和至少一个主要业务页面的验收路径。
- 一次浏览器 Network/HAR 采集，用于固化 `/api` 之外的后端路由和 302 跳转。

### 22.4 运维默认值

- `/srv/cuddly` 可使用的磁盘上限和告警阈值。
- PostgreSQL 与 Artifact 目录的备份位置和频率。
- 控制台与配置 API 的网络访问边界和后续飞书 SSO 接入计划。
- 构建日志和未引用 Artifact 的最终保留周期；无特别要求时采用本文默认值。

除上述服务器事实和验收凭据外，不需要再等待新的架构决策即可开始正式实现。
