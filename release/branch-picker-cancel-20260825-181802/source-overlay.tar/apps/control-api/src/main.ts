import { createStore, PROJECT_TEMPLATES } from '@cuddly/db'
import { readOrCreateSecret } from '@cuddly/domain'

import { createControlApp } from './app'
import { ProxySettingsService } from './proxy-settings'

const store = createStore()
await store.initialize()

const settingsSecret = await readOrCreateSecret('/srv/cuddly/secrets/settings.key')
const internalApiToken = await readOrCreateSecret('/srv/cuddly/cert-auth/token')
const proxySettings = new ProxySettingsService({
  store,
  settingsSecret,
  configPath: '/srv/cuddly/secrets/mihomo/config.yaml',
  mihomoConfigPath: '/root/.config/mihomo/config.yaml',
  mihomoControllerUrl: 'http://mihomo:9090',
  mihomoControllerSecret: '',
})
await proxySettings.start()

const app = createControlApp({
  store,
  internalApiToken,
  proxySettings,
  projectTemplates: PROJECT_TEMPLATES,
  settingsSecret,
  logDirectory: '/srv/cuddly/logs',
  previewBaseDomain: process.env.CUDDLY_PREVIEW_BASE_DOMAIN ?? 'bifrost.vanillacake.cn',
})

const server = app.listen(9880, () => console.log('[control-api] listening on 9880'))

async function shutdown() {
  server.close()
  proxySettings.stop()
  await store.close()
}

process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)
