import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type FormEvent,
  type KeyboardEvent as ReactKeyboardEvent,
  type RefObject,
} from 'react'
import {
  siteBindingIdPattern,
  siteBuildAdapters,
  type SiteBuildAdapter,
  type BranchCatalogItem,
  type BuildJob,
  type BuildJobDetail,
  type BuildJobLogView,
  type BuildJobStatus,
  type BuildQueueItem,
  type BuildQueueSnapshot,
  type BuildTargetSettingsView,
  type EnvironmentMatrix,
  type MatrixRow,
  type ProxySettingsView,
  type SiteBinding,
  type SystemSettingsView,
} from '@cuddly/contracts'
import {
  Check,
  CircleAlert,
  Clock3,
  Copy,
  Download,
  ExternalLink,
  FolderGit2,
  Hammer,
  History,
  ListOrdered,
  LoaderCircle,
  Network,
  LockKeyhole,
  PackageCheck,
  Plus,
  RefreshCw,
  Rocket,
  Settings,
  ServerCog,
  ShieldCheck,
  SlidersHorizontal,
  SquareTerminal,
  Trash2,
  UserRound,
  X,
} from 'lucide-react'

import {
  ApiError,
  cancelBuildJob,
  createBuild,
  deleteSiteBinding,
  getActorName,
  getBranches,
  getBuildHistory,
  getBuildJobDetail,
  getBuildJobLog,
  getBuildQueue,
  getMatrix,
  getProjectSettings,
  getPublicRuntimeSettings,
  getProxySettings,
  getSiteBindings,
  getSystemSettings,
  publishRevision,
  refreshProxySettings,
  resetProjectSettings,
  resetProxySettings,
  saveProjectSettings,
  saveSiteBinding,
  setActorName,
  updateProxySettings,
  updateSystemSettings,
} from './api'
import { BranchPicker } from './BranchPicker'
import { buildStatusText } from './branch-picker'

type StatusTone = 'idle' | 'busy' | 'success' | 'warning'
type ManagementTab = 'projects' | 'runtime' | 'proxy'
type MainView = 'environment' | 'history'
type JobDetailTab = 'overview' | 'console'

interface StatusState {
  tone: StatusTone
  text: string
}

interface StagedArtifact {
  id: string | null
  targetId: string
  targetName: string
  branch: string
  builtAt: string
}

export function revisionArtifactId(
  currentArtifactId: string | null | undefined,
  stagedArtifactId: string | null | undefined
): string | null {
  return stagedArtifactId === undefined ? currentArtifactId || null : stagedArtifactId
}

export function isRevisionSelectionChanged(
  currentArtifactId: string | null | undefined,
  stagedArtifactId: string | null
): boolean {
  return (currentArtifactId || null) !== stagedArtifactId
}

interface BranchState {
  items: BranchCatalogItem[]
  remoteAvailable: boolean
}

const emptyQueue: BuildQueueSnapshot = { running: [], queued: [], generatedAt: '' }

const buildStatusOptions: BuildJobStatus[] = [
  'QUEUED',
  'LEASED',
  'CHECKOUT',
  'INSTALLING',
  'BUILDING',
  'VALIDATING',
  'UPLOADING',
  'CANCELING',
  'SUCCEEDED',
  'FAILED',
  'CANCELED',
]

const terminalBuildStatuses = new Set<BuildJobStatus>(['SUCCEEDED', 'FAILED', 'CANCELED'])

const dialogFocusableSelector = [
  'a[href]',
  'button:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(',')

function dialogFocusableElements(container: HTMLElement): HTMLElement[] {
  return [...container.querySelectorAll<HTMLElement>(dialogFocusableSelector)].filter(
    (element) =>
      element.getAttribute('aria-hidden') !== 'true' &&
      (element.offsetWidth > 0 || element.offsetHeight > 0 || element === document.activeElement)
  )
}

function formatTime(value: string | null | undefined): string {
  if (!value) return '暂无产物'
  return new Intl.DateTimeFormat('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(new Date(value))
}

function queueTargetSignatures(snapshot: BuildQueueSnapshot): Map<string, string> {
  const signatures = new Map<string, string[]>()
  for (const item of [...snapshot.running, ...snapshot.queued]) {
    const values = signatures.get(item.targetId) || []
    values.push(item.id)
    signatures.set(item.targetId, values)
  }
  return new Map([...signatures].map(([targetId, values]) => [targetId, values.sort().join('|')]))
}

function completedQueueTargets(
  previous: Map<string, string>,
  current: Map<string, string>
): Set<string> {
  return new Set(
    [...previous].flatMap(([targetId, signature]) => {
      const currentIds = new Set((current.get(targetId) || '').split('|').filter(Boolean))
      const completed = signature
        .split('|')
        .filter(Boolean)
        .some((id) => !currentIds.has(id))
      return completed ? [targetId] : []
    })
  )
}

function formatQueueTime(value: string): string {
  return new Intl.DateTimeFormat('zh-CN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(new Date(value))
}

function formatFullTime(value: string | null | undefined): string {
  if (!value) return '尚未开始'
  return new Intl.DateTimeFormat('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).format(new Date(value))
}

function formatDuration(job: Pick<BuildJob, 'createdAt' | 'startedAt' | 'finishedAt'>): string {
  const start = new Date(job.startedAt || job.createdAt).getTime()
  const end = job.finishedAt ? new Date(job.finishedAt).getTime() : Date.now()
  const seconds = Math.max(0, Math.floor((end - start) / 1000))
  if (seconds < 60) return `${seconds} 秒`
  const minutes = Math.floor(seconds / 60)
  const remainingSeconds = seconds % 60
  if (minutes < 60) return `${minutes} 分 ${remainingSeconds} 秒`
  return `${Math.floor(minutes / 60)} 小时 ${minutes % 60} 分`
}

function errorMessage(error: unknown): string {
  if (error instanceof ApiError && error.status === 409) {
    if (error.body && typeof error.body === 'object' && 'message' in error.body) {
      const message = error.body.message
      if (typeof message === 'string') return message
    }
    return '环境已被其他人更新，刷新后可重新发布'
  }
  if (error instanceof ApiError && error.body && typeof error.body === 'object') {
    const message = 'message' in error.body ? error.body.message : null
    if (typeof message === 'string') return message
    const issues = 'issues' in error.body ? error.body.issues : null
    if (Array.isArray(issues) && issues[0] && typeof issues[0] === 'object') {
      const issueMessage = 'message' in issues[0] ? issues[0].message : null
      if (typeof issueMessage === 'string') return issueMessage
    }
  }
  if (error instanceof Error) return error.message
  return '操作没有完成，服务未返回可识别的原因'
}

function QueueRow({
  item,
  targetName,
  onOpen,
}: {
  item: BuildQueueItem
  targetName: string
  onOpen: () => void
}) {
  const queued = item.status === 'QUEUED'
  return (
    <button type="button" className={`queue-row ${item.isMine ? 'mine' : ''}`} onClick={onOpen}>
      <span
        className="queue-position"
        aria-label={queued ? `排队第 ${item.queuePosition} 位` : '正在构建'}
      >
        {queued ? item.queuePosition : <LoaderCircle className="spin" size={15} />}
      </span>
      <div className="queue-copy">
        <div className="queue-branch-line">
          <strong title={item.branch}>{item.branch}</strong>
          {item.isMine ? <span className="mine-badge">我的</span> : null}
        </div>
        <span>
          {targetName} · {item.requestedBy} · {formatQueueTime(item.createdAt)}
        </span>
      </div>
      <span className={`queue-state ${queued ? 'waiting' : 'working'}`}>
        {queued ? `第 ${item.queuePosition} 位` : buildStatusText[item.status] || item.status}
      </span>
    </button>
  )
}

function BuildHistoryView({
  jobs,
  loading,
  error,
  targetId,
  status,
  query,
  targets,
  onTargetChange,
  onStatusChange,
  onQueryChange,
  onRefresh,
  nextCursor,
  onLoadMore,
  onOpen,
}: {
  jobs: BuildJob[]
  loading: boolean
  error: string
  targetId: string
  status: BuildJobStatus | ''
  query: string
  targets: Array<{ id: string; name: string }>
  onTargetChange: (value: string) => void
  onStatusChange: (value: BuildJobStatus | '') => void
  onQueryChange: (value: string) => void
  onRefresh: () => void
  nextCursor: string | null
  onLoadMore: () => void
  onOpen: (jobId: string) => void
}) {
  return (
    <section className="history-view" aria-label="构建记录">
      <div className="history-filters">
        <label>
          <span>项目</span>
          <select value={targetId} onChange={(event) => onTargetChange(event.target.value)}>
            <option value="">全部项目</option>
            {targets.map((target) => (
              <option value={target.id} key={target.id}>
                {target.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span>结果</span>
          <select
            value={status}
            onChange={(event) => onStatusChange(event.target.value as BuildJobStatus | '')}
          >
            <option value="">全部状态</option>
            {buildStatusOptions.map((option) => (
              <option value={option} key={option}>
                {buildStatusText[option]}
              </option>
            ))}
          </select>
        </label>
        <label className="history-query">
          <span>查找</span>
          <input
            value={query}
            onChange={(event) => onQueryChange(event.target.value)}
            placeholder="分支、发起人或任务 ID"
          />
        </label>
        <button
          type="button"
          className="icon-button history-refresh"
          onClick={onRefresh}
          title="刷新构建记录"
        >
          {loading ? <LoaderCircle className="spin" size={17} /> : <RefreshCw size={17} />}
        </button>
      </div>

      {error ? <InlineError message={error} /> : null}
      <div className="history-table" role="table" aria-label="历史任务">
        <div className="history-table-head" role="row">
          <span>状态</span>
          <span>项目与分支</span>
          <span>发起人</span>
          <span>开始时间</span>
          <span>耗时</span>
        </div>
        {jobs.map((job) => (
          <button
            type="button"
            className="history-row"
            role="row"
            key={job.id}
            onClick={() => onOpen(job.id)}
          >
            <span className={`job-status job-status-${job.status.toLowerCase()}`} role="cell">
              {buildStatusText[job.status] || job.status}
            </span>
            <span className="history-job" role="cell">
              <strong>
                {targets.find((target) => target.id === job.targetId)?.name || job.targetId}
              </strong>
              <small title={job.branch}>{job.branch}</small>
            </span>
            <span role="cell">{job.requestedBy}</span>
            <span role="cell">{formatTime(job.startedAt || job.createdAt)}</span>
            <span role="cell">{formatDuration(job)}</span>
          </button>
        ))}
        {!loading && jobs.length === 0 ? (
          <div className="history-empty">
            <History size={18} />
            没有符合条件的构建记录
          </div>
        ) : null}
        {nextCursor ? (
          <div className="history-pagination">
            <button type="button" className="text-button" onClick={onLoadMore} disabled={loading}>
              {loading ? <LoaderCircle className="spin" size={15} /> : <History size={15} />}
              加载更早记录
            </button>
          </div>
        ) : null}
      </div>
    </section>
  )
}

function JobDetailPanel({
  detail,
  log,
  loading,
  error,
  tab,
  copied,
  logRef,
  targetName,
  canceling,
  onTabChange,
  onCancel,
  onCopy,
  onClose,
}: {
  detail: BuildJobDetail | null
  log: BuildJobLogView | null
  loading: boolean
  error: string
  tab: JobDetailTab
  copied: boolean
  logRef: RefObject<HTMLPreElement | null>
  targetName: string
  canceling: boolean
  onTabChange: (tab: JobDetailTab) => void
  onCancel: () => void
  onCopy: () => void
  onClose: () => void
}) {
  const job = detail?.job
  return (
    <div className="job-detail-scrim" role="presentation" onMouseDown={onClose}>
      <aside
        className="job-detail-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="job-detail-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <header className="job-detail-header">
          <div>
            <span className="eyebrow">构建任务</span>
            <h2 id="job-detail-title">{job?.branch || '正在读取'}</h2>
            {job ? (
              <p>
                {targetName} · {job.requestedBy} · {job.id.slice(0, 8)}
              </p>
            ) : null}
          </div>
          <div className="job-detail-actions">
            {job && !terminalBuildStatuses.has(job.status) ? (
              <button
                type="button"
                className="cancel-build-button"
                onClick={onCancel}
                disabled={canceling || job.status === 'CANCELING'}
              >
                {canceling || job.status === 'CANCELING' ? (
                  <LoaderCircle className="spin" size={15} />
                ) : (
                  <X size={15} />
                )}
                {canceling || job.status === 'CANCELING' ? '正在中断' : '中断构建'}
              </button>
            ) : null}
            <button className="icon-button" onClick={onClose} title="关闭任务详情">
              <X size={18} />
            </button>
          </div>
        </header>

        <nav className="job-detail-tabs" aria-label="任务详情分类">
          <button
            className={tab === 'overview' ? 'active' : ''}
            onClick={() => onTabChange('overview')}
          >
            <ListOrdered size={15} />
            概览
          </button>
          <button
            className={tab === 'console' ? 'active' : ''}
            onClick={() => onTabChange('console')}
          >
            <SquareTerminal size={15} />
            控制台
          </button>
        </nav>

        <div className="job-detail-content">
          {loading && !detail ? (
            <div className="detail-loading">
              <LoaderCircle className="spin" size={18} />
              正在读取任务
            </div>
          ) : error ? (
            <InlineError message={error} />
          ) : detail && tab === 'overview' ? (
            <>
              <section className="job-summary">
                <div className="job-summary-primary">
                  <span className={`job-status job-status-${detail.job.status.toLowerCase()}`}>
                    {buildStatusText[detail.job.status] || detail.job.status}
                  </span>
                  <strong>{formatDuration(detail.job)}</strong>
                </div>
                <dl>
                  <div>
                    <dt>提交</dt>
                    <dd>{formatFullTime(detail.job.createdAt)}</dd>
                  </div>
                  <div>
                    <dt>开始</dt>
                    <dd>{formatFullTime(detail.job.startedAt)}</dd>
                  </div>
                  <div>
                    <dt>结束</dt>
                    <dd>
                      {detail.job.finishedAt ? formatFullTime(detail.job.finishedAt) : '仍在执行'}
                    </dd>
                  </div>
                </dl>
                {detail.job.failureMessage ? (
                  <div className="job-failure">
                    <CircleAlert size={16} />
                    <div>
                      <strong>{detail.job.failureCode || 'BUILD_FAILED'}</strong>
                      <span>{detail.job.failureMessage}</span>
                    </div>
                  </div>
                ) : null}
              </section>

              <section className="detail-section">
                <h3>执行时间线</h3>
                <ol className="job-timeline">
                  {detail.events.map((event) => (
                    <li key={event.id}>
                      <span className={`timeline-dot timeline-${event.status.toLowerCase()}`} />
                      <div>
                        <strong>{buildStatusText[event.status] || event.status}</strong>
                        <time>{formatFullTime(event.createdAt)}</time>
                      </div>
                    </li>
                  ))}
                </ol>
              </section>

              <section className="detail-section">
                <h3>执行命令</h3>
                <div className="command-list">
                  {detail.commands.map((step) => (
                    <div className="command-step" key={step.stage}>
                      <span>{step.label}</span>
                      <code>{step.command}</code>
                    </div>
                  ))}
                </div>
              </section>

              <section className="detail-section artifact-result">
                <h3>构建结果</h3>
                {detail.artifact ? (
                  <dl>
                    <div>
                      <dt>Artifact</dt>
                      <dd title={detail.artifact.id}>{detail.artifact.id.slice(0, 12)}</dd>
                    </div>
                    <div>
                      <dt>文件</dt>
                      <dd>{detail.artifact.fileCount} 个</dd>
                    </div>
                    <div>
                      <dt>生成时间</dt>
                      <dd>{formatFullTime(detail.artifact.builtAt)}</dd>
                    </div>
                  </dl>
                ) : (
                  <p>
                    {terminalBuildStatuses.has(detail.job.status)
                      ? '任务没有生成可用产物'
                      : '构建完成后显示产物信息'}
                  </p>
                )}
              </section>
            </>
          ) : detail ? (
            <section className="job-console-section">
              <div className="job-console-toolbar">
                <span>
                  {log?.complete ? '日志已结束' : '实时日志'}
                  {log?.truncated ? ' · 已截断' : ''}
                </span>
                <div>
                  <button className="icon-button" onClick={onCopy} title="复制日志">
                    {copied ? <Check size={16} /> : <Copy size={16} />}
                  </button>
                  <a
                    className="icon-button"
                    href={`/api/v1/build-jobs/${detail.job.id}/log?download=1`}
                    title="下载脱敏日志"
                  >
                    <Download size={16} />
                  </a>
                </div>
              </div>
              <pre className="job-console" ref={logRef} tabIndex={0}>
                {log?.content || (log?.complete ? '没有日志输出' : '等待 Runner 输出...')}
              </pre>
            </section>
          ) : null}
        </div>
      </aside>
    </div>
  )
}

function InlineError({ message }: { message: string }) {
  return (
    <div className="inline-error" role="alert">
      <CircleAlert size={16} />
      <span>{message}</span>
    </div>
  )
}

function ProxySettingsForm({
  settings,
  onChange,
}: {
  settings: ProxySettingsView
  onChange: (view: ProxySettingsView) => void
}) {
  const [enabled, setEnabled] = useState(settings.enabled)
  const [subscriptionUrl, setSubscriptionUrl] = useState('')
  const [refreshMinutes, setRefreshMinutes] = useState(settings.refreshIntervalMinutes)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  useEffect(() => {
    setEnabled(settings.enabled)
    setRefreshMinutes(settings.refreshIntervalMinutes)
    setSubscriptionUrl('')
  }, [settings])

  async function run(action: () => Promise<ProxySettingsView>, success: string) {
    setBusy(true)
    setError('')
    setNotice('')
    try {
      onChange(await action())
      setNotice(success)
    } catch (requestError) {
      setError(errorMessage(requestError))
    } finally {
      setBusy(false)
    }
  }

  return (
    <form
      className="management-form"
      onSubmit={(event) => {
        event.preventDefault()
        void run(
          () =>
            updateProxySettings({
              enabled,
              refreshIntervalMinutes: refreshMinutes,
              ...(subscriptionUrl.trim() ? { subscriptionUrl: subscriptionUrl.trim() } : {}),
            }),
          '代理配置已保存并应用'
        )
      }}
    >
      <div className="health-line">
        <span className={`health-dot ${settings.status.mihomoReachable ? 'ok' : 'bad'}`} />
        <div>
          <strong>
            {settings.status.mihomoReachable ? 'Mihomo 运行正常' : 'Mihomo 当前不可达'}
          </strong>
          <span>{settings.status.lastError || '最近一次配置检查未发现错误'}</span>
        </div>
      </div>

      <label className="toggle-row">
        <div>
          <strong>内网代理</strong>
          <span>分支查询与代码拉取按订阅规则访问网络</span>
        </div>
        <input
          type="checkbox"
          checked={enabled}
          onChange={(event) => setEnabled(event.target.checked)}
        />
      </label>

      <label className="field">
        <span>订阅链接</span>
        <input
          type="password"
          value={subscriptionUrl}
          onChange={(event) => setSubscriptionUrl(event.target.value)}
          placeholder={settings.subscriptionUrlMasked || '尚未配置'}
          autoComplete="off"
        />
        <small>
          {settings.sources.subscriptionUrl === 'database' ? '后台配置' : '系统默认'} ·{' '}
          {settings.subscriptionUrlMasked || '未设置'}
        </small>
      </label>

      <label className="field compact-field">
        <span>自动刷新</span>
        <select
          value={refreshMinutes}
          onChange={(event) => setRefreshMinutes(Number(event.target.value))}
        >
          <option value={15}>15 分钟</option>
          <option value={30}>30 分钟</option>
          <option value={60}>1 小时</option>
          <option value={360}>6 小时</option>
          <option value={1440}>24 小时</option>
        </select>
      </label>

      {error ? <InlineError message={error} /> : null}
      {notice ? (
        <div className="inline-success">
          <Check size={15} />
          {notice}
        </div>
      ) : null}
      <div className="form-actions">
        <button
          type="button"
          className="text-button"
          disabled={busy}
          onClick={() =>
            void run(
              () => resetProxySettings(['enabled', 'subscriptionUrl', 'refreshIntervalMinutes']),
              '已恢复系统默认配置'
            )
          }
        >
          恢复系统默认
        </button>
        <button
          type="button"
          className="secondary-button"
          disabled={busy}
          onClick={() => void run(refreshProxySettings, '订阅已重新拉取并应用')}
        >
          <RefreshCw size={15} />
          立即刷新
        </button>
        <button className="primary-button" disabled={busy}>
          {busy ? <LoaderCircle className="spin" size={16} /> : <Check size={16} />}
          保存
        </button>
      </div>
    </form>
  )
}

function newProject(): BuildTargetSettingsView {
  return {
    id: '',
    name: '',
    kind: 'spa-site',
    repositoryUrl: null,
    defaultBranch: 'master',
    installCommand: 'corepack pnpm install --frozen-lockfile',
    buildCommand: 'corepack pnpm run build',
    outputDirectory: 'dist',
    siteAdapter: 'generic-static-v1',
    enabled: false,
    required: false,
    configurationSource: 'database',
    canReset: false,
    gitAuthorizationConfigured: false,
  }
}

function ProjectsSettings({
  projects,
  setProjects,
  bindings,
  setBindings,
  autoSslEnabled,
  previewBaseDomain,
  onChanged,
}: {
  projects: BuildTargetSettingsView[]
  setProjects: (items: BuildTargetSettingsView[]) => void
  bindings: SiteBinding[]
  setBindings: (items: SiteBinding[]) => void
  autoSslEnabled: boolean
  previewBaseDomain: string
  onChanged: () => void
}) {
  const [selectedId, setSelectedId] = useState(projects[0]?.id || '')
  const selected = projects.find((item) => item.id === selectedId) || null
  const [draft, setDraft] = useState<BuildTargetSettingsView>(selected || newProject())
  const [creating, setCreating] = useState(projects.length === 0)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [gitAuthorizationHeader, setGitAuthorizationHeader] = useState('')
  const [clearGitAuthorizationHeader, setClearGitAuthorizationHeader] = useState(false)

  useEffect(() => {
    if (creating) return
    const next = projects.find((item) => item.id === selectedId) || projects[0]
    if (next) {
      setSelectedId(next.id)
      setDraft(next)
    }
  }, [creating, projects, selectedId])

  function selectProject(project: BuildTargetSettingsView) {
    setCreating(false)
    setSelectedId(project.id)
    setDraft(project)
    setError('')
    setNotice('')
    setGitAuthorizationHeader('')
    setClearGitAuthorizationHeader(false)
  }

  async function save(event: FormEvent) {
    event.preventDefault()
    setBusy(true)
    setError('')
    setNotice('')
    try {
      const saved = await saveProjectSettings({
        id: draft.id.trim(),
        name: draft.name.trim(),
        kind: draft.kind,
        repositoryUrl: draft.repositoryUrl?.trim() || null,
        defaultBranch: draft.defaultBranch.trim(),
        installCommand: draft.installCommand.trim(),
        buildCommand: draft.buildCommand.trim(),
        outputDirectory: draft.outputDirectory.trim(),
        siteAdapter: draft.siteAdapter.trim(),
        enabled: draft.enabled,
        required: draft.required,
        ...(gitAuthorizationHeader.trim()
          ? { gitAuthorizationHeader: gitAuthorizationHeader.trim() }
          : {}),
        ...(clearGitAuthorizationHeader ? { clearGitAuthorizationHeader: true } : {}),
      })
      setProjects(
        [...projects.filter((item) => item.id !== saved.id), saved].sort((a, b) =>
          a.name.localeCompare(b.name)
        )
      )
      setSelectedId(saved.id)
      setDraft(saved)
      setCreating(false)
      setGitAuthorizationHeader('')
      setClearGitAuthorizationHeader(false)
      setNotice('项目配置已保存；新提交的任务会使用这份配置')
      onChanged()
    } catch (requestError) {
      setError(errorMessage(requestError))
    } finally {
      setBusy(false)
    }
  }

  async function reset() {
    setBusy(true)
    setError('')
    setNotice('')
    try {
      const restored = await resetProjectSettings(draft.id)
      setProjects(projects.map((item) => (item.id === restored.id ? restored : item)))
      setDraft(restored)
      setGitAuthorizationHeader('')
      setClearGitAuthorizationHeader(false)
      setNotice('已恢复内置项目模板')
      onChanged()
    } catch (requestError) {
      setError(errorMessage(requestError))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="projects-layout">
      <aside className="project-index" aria-label="项目列表">
        <div className="project-index-heading">
          <strong>项目</strong>
          <button
            className="icon-button"
            title="新增项目"
            onClick={() => {
              setCreating(true)
              setSelectedId('')
              setDraft(newProject())
              setError('')
              setNotice('')
            }}
          >
            <Plus size={17} />
          </button>
        </div>
        <div className="project-index-list">
          {projects.map((project) => (
            <button
              className={`project-index-item ${!creating && project.id === selectedId ? 'active' : ''}`}
              key={project.id}
              onClick={() => selectProject(project)}
            >
              <span>{project.name}</span>
              <small>
                {project.enabled ? '启用' : '停用'} · {projectSiteSummary(project, bindings)}
              </small>
            </button>
          ))}
        </div>
      </aside>

      <div className="project-workspace">
        <form className="project-editor management-form" onSubmit={save}>
          <div className="editor-heading">
            <div>
              <span className="eyebrow">{creating ? '新项目' : draft.id}</span>
              <h3>{creating ? '添加打包项目' : draft.name}</h3>
            </div>
            {!creating && draft.configurationSource === 'database' ? (
              <span className="source-badge">后台配置</span>
            ) : null}
          </div>

          <div className="field-grid">
            <label className="field">
              <span>项目名称</span>
              <input
                value={draft.name}
                onChange={(event) => setDraft({ ...draft, name: event.target.value })}
                required
              />
            </label>
            <label className="field">
              <span>项目标识</span>
              <input
                value={draft.id}
                onChange={(event) => setDraft({ ...draft, id: event.target.value.toLowerCase() })}
                placeholder="example-site"
                pattern="[a-z0-9][a-z0-9-]*"
                readOnly={!creating}
                required
              />
            </label>
            <label className="field field-wide">
              <span>Git 仓库地址</span>
              <input
                value={draft.repositoryUrl || ''}
                onChange={(event) => setDraft({ ...draft, repositoryUrl: event.target.value })}
                placeholder="https://git.example.cn/group/project.git"
                required={draft.enabled}
              />
            </label>
            <label className="field field-wide">
              <span>Git HTTP 认证头</span>
              <input
                type="password"
                value={gitAuthorizationHeader}
                onChange={(event) => {
                  setGitAuthorizationHeader(event.target.value)
                  setClearGitAuthorizationHeader(false)
                }}
                placeholder={
                  draft.gitAuthorizationConfigured
                    ? '已配置，留空保持不变'
                    : '例如 Authorization: Basic ***'
                }
                autoComplete="off"
              />
              <small>
                {draft.gitAuthorizationConfigured
                  ? '凭证已加密保存且不会回显'
                  : '仅 HTTPS 私有仓库需要；SSH 仓库可留空'}
              </small>
            </label>
            {draft.gitAuthorizationConfigured ? (
              <label className="toggle-row field-wide credential-clear-row">
                <div>
                  <strong>清除已保存凭证</strong>
                  <span>保存项目时删除现有 Git HTTP 认证头</span>
                </div>
                <input
                  type="checkbox"
                  checked={clearGitAuthorizationHeader}
                  onChange={(event) => {
                    setClearGitAuthorizationHeader(event.target.checked)
                    if (event.target.checked) setGitAuthorizationHeader('')
                  }}
                />
              </label>
            ) : null}
            <label className="field">
              <span>默认分支</span>
              <input
                value={draft.defaultBranch}
                onChange={(event) => setDraft({ ...draft, defaultBranch: event.target.value })}
                required
              />
            </label>
            <label className="field">
              <span>项目类型</span>
              <select
                value={draft.kind}
                onChange={(event) => {
                  const kind = event.target.value as BuildTargetSettingsView['kind']
                  const currentSiteAdapter = draft.siteAdapter as SiteBuildAdapter
                  setDraft({
                    ...draft,
                    kind,
                    siteAdapter:
                      kind === 'remote'
                        ? 'kook-remote-v1'
                        : siteBuildAdapters.includes(currentSiteAdapter)
                          ? currentSiteAdapter
                          : 'generic-static-v1',
                  })
                }}
              >
                <option value="h5-site">移动 H5</option>
                <option value="webapp">网页端</option>
                <option value="spa-site">单页站点</option>
                <option value="remote">远程项目</option>
              </select>
            </label>
          </div>

          <div className="toggle-stack">
            <label className="toggle-row">
              <div>
                <strong>启用项目</strong>
                <span>启用后 QA 可以查询分支并发起打包</span>
              </div>
              <input
                type="checkbox"
                checked={draft.enabled}
                onChange={(event) =>
                  setDraft({
                    ...draft,
                    enabled: event.target.checked,
                    required: event.target.checked ? draft.required : false,
                  })
                }
              />
            </label>
            <label className="toggle-row">
              <div>
                <strong>发布时必选</strong>
                <span>公共环境发布时必须为该项目选择产物</span>
              </div>
              <input
                type="checkbox"
                checked={draft.required}
                disabled={!draft.enabled}
                onChange={(event) => setDraft({ ...draft, required: event.target.checked })}
              />
            </label>
          </div>

          <details className="advanced-settings">
            <summary>
              <SlidersHorizontal size={15} />
              构建细节
            </summary>
            <div className="advanced-fields">
              <label className="field">
                <span>安装命令</span>
                <input
                  value={draft.installCommand}
                  onChange={(event) => setDraft({ ...draft, installCommand: event.target.value })}
                  required
                />
              </label>
              <label className="field">
                <span>打包命令</span>
                <input
                  value={draft.buildCommand}
                  onChange={(event) => setDraft({ ...draft, buildCommand: event.target.value })}
                  required
                />
              </label>
              <div className="field-grid">
                <label className="field">
                  <span>产物目录</span>
                  <input
                    value={draft.outputDirectory}
                    onChange={(event) =>
                      setDraft({ ...draft, outputDirectory: event.target.value })
                    }
                    required
                  />
                </label>
                <label className="field">
                  <span>站点适配器</span>
                  <select
                    value={draft.siteAdapter}
                    onChange={(event) => setDraft({ ...draft, siteAdapter: event.target.value })}
                  >
                    {draft.kind === 'remote' ? (
                      <option value="kook-remote-v1">KOOK Remote</option>
                    ) : (
                      <>
                        <option value="kook-online-h5-v1">KOOK 移动 H5</option>
                        <option value="generic-static-v1">通用静态站点</option>
                      </>
                    )}
                  </select>
                </label>
              </div>
            </div>
          </details>

          {error ? <InlineError message={error} /> : null}
          {notice ? (
            <div className="inline-success">
              <Check size={15} />
              {notice}
            </div>
          ) : null}
          <div className="form-actions">
            {!creating && draft.canReset ? (
              <button
                type="button"
                className="text-button"
                disabled={busy}
                onClick={() => void reset()}
              >
                恢复内置模板
              </button>
            ) : (
              <span />
            )}
            <button className="primary-button" disabled={busy}>
              {busy ? <LoaderCircle className="spin" size={16} /> : <Check size={16} />}
              保存项目
            </button>
          </div>
        </form>

        {!creating && selected && selected.kind !== 'remote' ? (
          <ProjectSitesSettings
            key={selected.id}
            project={selected}
            bindings={bindings}
            setBindings={setBindings}
            projects={projects}
            autoSslEnabled={autoSslEnabled}
            previewBaseDomain={previewBaseDomain}
          />
        ) : null}
      </div>
    </div>
  )
}

export function projectSiteSummary(
  project: Pick<BuildTargetSettingsView, 'id' | 'kind'>,
  bindings: SiteBinding[]
): string {
  if (project.kind === 'remote') return 'Remote'
  const projectBindings = bindings.filter((binding) => binding.targetId === project.id)
  if (projectBindings.length === 0) return '未配置站点'
  if (projectBindings.length === 1) return projectBindings[0]!.hostname
  return `${projectBindings.length} 个站点`
}

function isBindableSiteProject(project: BuildTargetSettingsView): boolean {
  return (
    project.enabled &&
    project.kind !== 'remote' &&
    siteBuildAdapters.includes(project.siteAdapter as SiteBuildAdapter)
  )
}

export const DEFAULT_PREVIEW_BASE_DOMAIN = 'bifrost.vanillacake.cn'
export const DEFAULT_RESOURCE_PROXY_PREFIXES = ['https://img.kookapp.cn/']

export function siteHostnameForId(
  id: string,
  previewBaseDomain = DEFAULT_PREVIEW_BASE_DOMAIN
): string {
  const baseDomain = previewBaseDomain
    .trim()
    .toLowerCase()
    .replace(/^\.+|\.+$/g, '')
  return siteBindingIdPattern.test(id) && baseDomain ? `${id}.${baseDomain}` : ''
}

function newSiteBinding(project: BuildTargetSettingsView): SiteBinding {
  const upstreamOrigin =
    project.kind === 'h5-site' ? 'https://m.kookapp.cn' : 'https://www.kookapp.cn'
  return {
    id: '',
    name: project.name,
    hostname: '',
    targetId: project.id,
    environmentSlug: 'shared',
    upstreamOrigin,
    officialOrigin: upstreamOrigin,
    enabled: false,
    remoteTargetIds: [],
    resourceProxyPrefixes: [...DEFAULT_RESOURCE_PROXY_PREFIXES],
  }
}

function ProjectSitesSettings({
  project,
  bindings,
  setBindings,
  projects,
  autoSslEnabled,
  previewBaseDomain,
}: {
  project: BuildTargetSettingsView
  bindings: SiteBinding[]
  setBindings: (items: SiteBinding[]) => void
  projects: BuildTargetSettingsView[]
  autoSslEnabled: boolean
  previewBaseDomain: string
}) {
  const projectBindings = useMemo(
    () =>
      bindings
        .filter((binding) => binding.targetId === project.id)
        .sort((a, b) => a.name.localeCompare(b.name)),
    [bindings, project.id]
  )
  const [selectedId, setSelectedId] = useState(projectBindings[0]?.id || '')
  const selected = projectBindings.find((item) => item.id === selectedId) || null
  const [draft, setDraft] = useState<SiteBinding>(selected || newSiteBinding(project))
  const [creating, setCreating] = useState(projectBindings.length === 0)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const remoteProjects = projects.filter((project) => project.kind === 'remote')
  const editable = isBindableSiteProject(project)

  useEffect(() => {
    if (creating) return
    const next = projectBindings.find((item) => item.id === selectedId) || projectBindings[0]
    if (next) {
      setSelectedId(next.id)
      setDraft(next)
    } else {
      setSelectedId('')
      setDraft(newSiteBinding(project))
      setCreating(true)
    }
  }, [creating, project, projectBindings, selectedId])

  function selectBinding(binding: SiteBinding) {
    setCreating(false)
    setSelectedId(binding.id)
    setDraft(binding)
    setError('')
    setNotice('')
  }

  function startCreating() {
    setCreating(true)
    setSelectedId('')
    setDraft(newSiteBinding(project))
    setError('')
    setNotice('')
  }

  async function save(event: FormEvent) {
    event.preventDefault()
    setBusy(true)
    setError('')
    setNotice('')
    try {
      const saved = await saveSiteBinding({
        ...draft,
        id: draft.id.trim().toLowerCase(),
        name: draft.name.trim(),
        hostname: draft.hostname.trim().toLowerCase(),
        targetId: project.id,
        environmentSlug: draft.environmentSlug.trim(),
        upstreamOrigin: draft.upstreamOrigin.trim(),
        officialOrigin: draft.officialOrigin.trim(),
        resourceProxyPrefixes: (draft.resourceProxyPrefixes || [])
          .map((prefix) => prefix.trim())
          .filter(Boolean),
      })
      setBindings(
        [...bindings.filter((item) => item.id !== saved.id), saved].sort((a, b) =>
          a.name.localeCompare(b.name)
        )
      )
      setSelectedId(saved.id)
      setDraft(saved)
      setCreating(false)
      setNotice('站点绑定已保存；网关会按 Host 读取这份配置')
    } catch (requestError) {
      setError(errorMessage(requestError))
    } finally {
      setBusy(false)
    }
  }

  async function remove() {
    if (!window.confirm(`删除站点“${draft.name}”？这个域名将不再由 Cuddly 提供预览。`)) return
    setBusy(true)
    setError('')
    setNotice('')
    try {
      await deleteSiteBinding(draft.id)
      const remaining = bindings.filter((item) => item.id !== draft.id)
      setBindings(remaining)
      const remainingProjectBindings = projectBindings.filter((item) => item.id !== draft.id)
      if (remainingProjectBindings[0]) {
        setSelectedId(remainingProjectBindings[0].id)
        setDraft(remainingProjectBindings[0])
        setCreating(false)
      } else {
        setSelectedId('')
        setDraft(newSiteBinding(project))
        setCreating(true)
      }
    } catch (requestError) {
      setError(errorMessage(requestError))
    } finally {
      setBusy(false)
    }
  }

  return (
    <section className="project-sites-section" aria-labelledby={`project-sites-${project.id}`}>
      <header className="project-sites-heading">
        <div>
          <span className="eyebrow">发布入口</span>
          <h3 id={`project-sites-${project.id}`}>预览站点</h3>
        </div>
        <div className="project-site-controls">
          {projectBindings.length ? (
            <label className="project-site-picker">
              <span className="sr-only">选择预览站点</span>
              <select
                aria-label="选择预览站点"
                value={creating ? '' : selectedId}
                onChange={(event) => {
                  const binding = projectBindings.find((item) => item.id === event.target.value)
                  if (binding) selectBinding(binding)
                }}
              >
                {creating ? <option value="">新站点</option> : null}
                {projectBindings.map((binding) => (
                  <option value={binding.id} key={binding.id}>
                    {binding.name} · {binding.hostname}
                  </option>
                ))}
              </select>
            </label>
          ) : null}
          <button
            type="button"
            className="icon-button"
            title="新增预览站点"
            disabled={!editable}
            onClick={startCreating}
          >
            <Plus size={17} />
          </button>
        </div>
      </header>

      {!editable ? (
        <div className="project-site-unavailable">
          <CircleAlert size={16} />
          <span>
            {project.enabled
              ? '当前站点适配器不支持页面预览。'
              : '启用并保存项目后，才能新增或修改预览站点。'}
          </span>
        </div>
      ) : null}

      {editable || projectBindings.length ? (
        <form className="management-form embedded-site-editor" onSubmit={save}>
          <fieldset className="site-editor-fieldset" disabled={!editable || busy}>
            <div className="editor-heading site-editor-heading">
              <div>
                <span className="eyebrow">{creating ? '新站点' : draft.id}</span>
                <h3>{creating ? '添加预览站点' : draft.name}</h3>
              </div>
              {!creating && draft.hostname ? (
                <a
                  className="site-preview-link"
                  href={`https://${draft.hostname}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  打开站点
                  <ExternalLink size={14} />
                </a>
              ) : null}
            </div>

            <div className="field-grid">
              <label className="field">
                <span>站点名称</span>
                <input
                  value={draft.name}
                  onChange={(event) => setDraft({ ...draft, name: event.target.value })}
                  placeholder="KOOK 网页端"
                  required
                />
              </label>
              <label className="field">
                <span>站点标识</span>
                <input
                  value={draft.id}
                  onChange={(event) => {
                    const id = event.target.value.toLowerCase()
                    const generatedHostname = siteHostnameForId(draft.id, previewBaseDomain)
                    setDraft({
                      ...draft,
                      id,
                      hostname:
                        !draft.hostname || draft.hostname === generatedHostname
                          ? siteHostnameForId(id, previewBaseDomain)
                          : draft.hostname,
                    })
                  }}
                  placeholder="main"
                  pattern={siteBindingIdPattern.source}
                  maxLength={63}
                  readOnly={!creating}
                  required
                />
              </label>
              <label className="field field-wide">
                <span>预览域名</span>
                <input
                  value={draft.hostname}
                  onChange={(event) => setDraft({ ...draft, hostname: event.target.value })}
                  placeholder={siteHostnameForId('main', previewBaseDomain)}
                  required
                />
                <small>
                  {autoSslEnabled
                    ? `保存并启用后，自动 SSL 会维护 ${previewBaseDomain} 下这个域名的证书。`
                    : `当前预览根域为 ${previewBaseDomain}；自动 SSL 关闭时证书由部署环境提供。`}
                </small>
              </label>
              <label className="field">
                <span>对应官网</span>
                <input
                  type="url"
                  value={draft.officialOrigin}
                  onChange={(event) => setDraft({ ...draft, officialOrigin: event.target.value })}
                  placeholder="https://www.kookapp.cn"
                  required
                />
                <small>扩展在这个官网页面展示本站点的分支。</small>
              </label>
              <label className="field">
                <span>接口上游</span>
                <input
                  type="url"
                  value={draft.upstreamOrigin}
                  onChange={(event) => setDraft({ ...draft, upstreamOrigin: event.target.value })}
                  placeholder="https://www.kookapp.cn"
                  required
                />
                <small>非页面资源与接口请求由网关转发到这里。</small>
              </label>
              <label className="field field-wide">
                <span>资源代理路径白名单</span>
                <textarea
                  value={(draft.resourceProxyPrefixes || []).join('\n')}
                  onChange={(event) =>
                    setDraft({ ...draft, resourceProxyPrefixes: event.target.value.split(/\r?\n/) })
                  }
                  placeholder="https://img.kookapp.cn/"
                  rows={3}
                />
                <small>
                  每行一个 HTTP(S) 路径前缀；命中的图片、脚本、样式与数据仅通过 GET/HEAD
                  转发，且不会携带登录凭据。
                </small>
              </label>
            </div>

            <label className="toggle-row site-enabled-toggle">
              <div>
                <strong>启用站点</strong>
                <span>启用后，网关接受这个 Host，扩展也会显示对应项目。</span>
              </div>
              <input
                type="checkbox"
                checked={draft.enabled}
                onChange={(event) => setDraft({ ...draft, enabled: event.target.checked })}
              />
            </label>

            <fieldset className="remote-project-fieldset">
              <legend>关联热更项目</legend>
              <p>访问对应官网或预览域名时，扩展一并列出这些 Remote 项目。</p>
              <div className="remote-project-list">
                {remoteProjects.length ? (
                  remoteProjects.map((remoteProject) => {
                    const checked = draft.remoteTargetIds.includes(remoteProject.id)
                    return (
                      <label className="remote-project-option" key={remoteProject.id}>
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={(event) =>
                            setDraft({
                              ...draft,
                              remoteTargetIds: event.target.checked
                                ? [...draft.remoteTargetIds, remoteProject.id]
                                : draft.remoteTargetIds.filter((id) => id !== remoteProject.id),
                            })
                          }
                        />
                        <span>
                          <strong>{remoteProject.name}</strong>
                          <small>
                            {remoteProject.id}
                            {remoteProject.enabled ? '' : ' · 已停用'}
                          </small>
                        </span>
                      </label>
                    )
                  })
                ) : (
                  <span className="fieldset-empty">当前没有 Remote 项目。</span>
                )}
              </div>
            </fieldset>

            <details className="advanced-settings">
              <summary>
                <SlidersHorizontal size={15} />
                环境细节
              </summary>
              <div className="advanced-fields">
                <label className="field compact-field">
                  <span>环境标识</span>
                  <input
                    value={draft.environmentSlug}
                    onChange={(event) =>
                      setDraft({ ...draft, environmentSlug: event.target.value })
                    }
                    pattern="[a-z0-9][a-z0-9_-]*"
                    required
                  />
                  <small>首期统一使用 shared。</small>
                </label>
              </div>
            </details>
          </fieldset>

          {error ? <InlineError message={error} /> : null}
          {notice ? (
            <div className="inline-success">
              <Check size={15} />
              {notice}
            </div>
          ) : null}
          <div className="form-actions">
            {!creating ? (
              <button
                type="button"
                className="text-button danger-text-button"
                disabled={busy}
                onClick={() => void remove()}
              >
                <Trash2 size={15} />
                删除站点
              </button>
            ) : (
              <span />
            )}
            <button className="primary-button" disabled={busy || !editable}>
              {busy ? <LoaderCircle className="spin" size={16} /> : <Check size={16} />}
              保存站点
            </button>
          </div>
        </form>
      ) : null}
    </section>
  )
}

function SystemSettingsForm({
  settings,
  onChange,
}: {
  settings: SystemSettingsView
  onChange: (view: SystemSettingsView) => void
}) {
  const [draft, setDraft] = useState(settings)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  useEffect(() => setDraft(settings), [settings])

  async function save(event: FormEvent) {
    event.preventDefault()
    setBusy(true)
    setError('')
    setNotice('')
    try {
      const saved = await updateSystemSettings({
        mobileUpstream: draft.mobileUpstream.trim(),
        publicMobileOrigin: draft.publicMobileOrigin.trim(),
        webappUpstream: draft.webappUpstream.trim(),
        publicPreviewOrigin: draft.publicPreviewOrigin.trim(),
        mobileHostnames: draft.mobileHostnames.map((value) => value.trim()).filter(Boolean),
        cookieDomain: draft.cookieDomain.trim(),
        buildMaxConcurrency: draft.buildMaxConcurrency,
        runnerRequestTimeoutMinutes: draft.runnerRequestTimeoutMinutes,
        useChinaRegistry: draft.useChinaRegistry,
        proxyRewriteMaxMegabytes: draft.proxyRewriteMaxMegabytes,
        autoSslEnabled: draft.autoSslEnabled,
        autoSslEmail: draft.autoSslEmail.trim(),
      })
      onChange(saved)
      setNotice('系统配置已保存并应用')
    } catch (requestError) {
      setError(errorMessage(requestError))
    } finally {
      setBusy(false)
    }
  }

  return (
    <form className="management-form system-settings-form" onSubmit={save}>
      <section className="settings-section" aria-labelledby="gateway-settings-title">
        <div className="settings-section-heading">
          <Network size={17} />
          <div>
            <h3 id="gateway-settings-title">移动站网关</h3>
            <p>页面资源走打包产物，接口请求转发到业务站点。</p>
          </div>
        </div>
        <div className="field-grid">
          <label className="field">
            <span>业务站上游</span>
            <input
              type="url"
              value={draft.mobileUpstream}
              onChange={(event) => setDraft({ ...draft, mobileUpstream: event.target.value })}
              required
            />
          </label>
          <label className="field">
            <span>QA 移动站地址</span>
            <input
              type="url"
              value={draft.publicMobileOrigin}
              onChange={(event) => setDraft({ ...draft, publicMobileOrigin: event.target.value })}
              required
            />
          </label>
          <label className="field field-wide">
            <span>允许访问的 Host</span>
            <input
              value={draft.mobileHostnames.join(', ')}
              onChange={(event) =>
                setDraft({
                  ...draft,
                  mobileHostnames: event.target.value.split(',').map((value) => value.trim()),
                })
              }
              required
            />
            <small>多个域名使用英文逗号分隔；本地访问需要包含 localhost。</small>
          </label>
          <label className="field">
            <span>业务 Cookie 域</span>
            <input
              value={draft.cookieDomain}
              onChange={(event) => setDraft({ ...draft, cookieDomain: event.target.value })}
              placeholder=".vanillacake.cn"
            />
          </label>
          <label className="field">
            <span>响应改写上限</span>
            <div className="number-field">
              <input
                type="number"
                min={1}
                max={32}
                value={draft.proxyRewriteMaxMegabytes}
                onChange={(event) =>
                  setDraft({ ...draft, proxyRewriteMaxMegabytes: Number(event.target.value) })
                }
              />
              <span>MB</span>
            </div>
          </label>
        </div>
      </section>

      <section className="settings-section" aria-labelledby="preview-settings-title">
        <div className="settings-section-heading">
          <PackageCheck size={17} />
          <div>
            <h3 id="preview-settings-title">主站与热更预览</h3>
            <p>浏览器扩展按标签页选择页面与热更产物，其他标签页继续使用官网版本。</p>
          </div>
        </div>
        <div className="field-grid">
          <label className="field">
            <span>KOOK 主站地址</span>
            <input
              type="url"
              value={draft.webappUpstream}
              onChange={(event) => setDraft({ ...draft, webappUpstream: event.target.value })}
              required
            />
          </label>
          <label className="field">
            <span>预览资源地址</span>
            <input
              type="url"
              value={draft.publicPreviewOrigin}
              onChange={(event) => setDraft({ ...draft, publicPreviewOrigin: event.target.value })}
              required
            />
            <small>正式使用时必须配置可被浏览器访问的 HTTPS 地址。</small>
          </label>
        </div>
      </section>

      <section className="settings-section" aria-labelledby="ssl-settings-title">
        <div className="settings-section-heading">
          <LockKeyhole size={17} />
          <div>
            <h3 id="ssl-settings-title">自动 SSL</h3>
            <p>为已启用的站点域名申请并续期独立的 Let's Encrypt 证书。</p>
          </div>
        </div>
        <div className="field-grid">
          <label className="toggle-row field-wide ssl-toggle">
            <div>
              <strong>自动维护证书</strong>
              <span>
                {draft.autoSslEnabled
                  ? 'Certbot 会同步所有已启用站点；新增域名无需手工改证书配置。'
                  : '已关闭；Cuddly 不会调用 Certbot，也不会改动现有证书。'}
              </span>
            </div>
            <input
              type="checkbox"
              checked={draft.autoSslEnabled}
              onChange={(event) => setDraft({ ...draft, autoSslEnabled: event.target.checked })}
            />
          </label>
          {draft.autoSslEnabled ? (
            <label className="field field-wide ssl-email-field">
              <span>Let's Encrypt 联系邮箱</span>
              <input
                type="email"
                value={draft.autoSslEmail}
                onChange={(event) => setDraft({ ...draft, autoSslEmail: event.target.value })}
                placeholder="可留空"
                autoComplete="email"
              />
              <small>用于证书到期与安全通知；留空时使用无邮箱注册。</small>
            </label>
          ) : null}
        </div>
      </section>

      <section className="settings-section" aria-labelledby="build-settings-title">
        <div className="settings-section-heading">
          <ServerCog size={17} />
          <div>
            <h3 id="build-settings-title">打包机</h3>
            <p>不同项目可并行，同一项目仍然保持串行。</p>
          </div>
        </div>
        <div className="field-grid">
          <label className="toggle-row field-wide build-registry-toggle">
            <div>
              <strong>使用国内源</strong>
              <span>依赖安装使用 npmmirror；关闭后遵循项目仓库自身配置。</span>
            </div>
            <input
              type="checkbox"
              checked={draft.useChinaRegistry}
              onChange={(event) => setDraft({ ...draft, useChinaRegistry: event.target.checked })}
            />
          </label>
          <label className="field">
            <span>最大并行项目数</span>
            <input
              type="number"
              min={1}
              max={16}
              value={draft.buildMaxConcurrency}
              onChange={(event) =>
                setDraft({ ...draft, buildMaxConcurrency: Number(event.target.value) })
              }
            />
          </label>
          <label className="field">
            <span>单次打包超时</span>
            <div className="number-field">
              <input
                type="number"
                min={1}
                max={180}
                value={draft.runnerRequestTimeoutMinutes}
                onChange={(event) =>
                  setDraft({ ...draft, runnerRequestTimeoutMinutes: Number(event.target.value) })
                }
              />
              <span>分钟</span>
            </div>
          </label>
        </div>
      </section>

      {error ? <InlineError message={error} /> : null}
      {notice ? (
        <div className="inline-success">
          <Check size={15} />
          {notice}
        </div>
      ) : null}
      <div className="form-actions">
        <button className="primary-button" disabled={busy}>
          {busy ? <LoaderCircle className="spin" size={16} /> : <Check size={16} />}
          保存系统配置
        </button>
      </div>
    </form>
  )
}

function ManagementPanel({
  onClose,
  onProjectsChanged,
  previewBaseDomain,
}: {
  onClose: () => void
  onProjectsChanged: () => void
  previewBaseDomain: string
}) {
  const [tab, setTab] = useState<ManagementTab>('projects')
  const [proxy, setProxy] = useState<ProxySettingsView | null>(null)
  const [projects, setProjects] = useState<BuildTargetSettingsView[]>([])
  const [siteBindings, setSiteBindings] = useState<SiteBinding[]>([])
  const [systemSettings, setSystemSettings] = useState<SystemSettingsView | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const dialogRef = useRef<HTMLElement>(null)
  const returnFocusRef = useRef<HTMLElement | null>(null)

  useEffect(() => {
    returnFocusRef.current =
      document.activeElement instanceof HTMLElement ? document.activeElement : null
    return () => {
      const returnTarget = returnFocusRef.current
      window.requestAnimationFrame(() => {
        if (returnTarget?.isConnected) returnTarget.focus()
      })
    }
  }, [])

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      const dialog = dialogRef.current
      if (!dialog) return
      const initial = dialog.querySelector<HTMLElement>('[data-dialog-initial-focus]')
      const fallback = dialogFocusableElements(dialog)[0] || dialog
      const focusTarget = initial || fallback
      focusTarget.focus()
    })
    return () => window.cancelAnimationFrame(frame)
  }, [tab])

  const handleDialogKeyDown = useCallback(
    (event: ReactKeyboardEvent<HTMLElement>) => {
      if (event.key === 'Escape' && !event.nativeEvent.isComposing) {
        event.preventDefault()
        event.stopPropagation()
        onClose()
        return
      }
      if (event.key !== 'Tab') return

      const dialog = dialogRef.current
      if (!dialog) return
      const focusable = dialogFocusableElements(dialog)
      if (focusable.length === 0) {
        event.preventDefault()
        dialog.focus()
        return
      }
      const first = focusable[0]!
      const last = focusable[focusable.length - 1]!
      const active = document.activeElement
      if (event.shiftKey && (active === first || !dialog.contains(active))) {
        event.preventDefault()
        last.focus()
      } else if (!event.shiftKey && (active === last || !dialog.contains(active))) {
        event.preventDefault()
        first.focus()
      }
    },
    [onClose]
  )

  const load = useCallback(async () => {
    const [proxyView, projectView, siteView, systemView] = await Promise.all([
      getProxySettings(),
      getProjectSettings(),
      getSiteBindings(),
      getSystemSettings(),
    ])
    setProxy(proxyView)
    setProjects(projectView.items)
    setSiteBindings(siteView.items)
    setSystemSettings(systemView)
  }, [])

  useEffect(() => {
    setLoading(true)
    setError('')
    void load()
      .catch((requestError) => setError(errorMessage(requestError)))
      .finally(() => setLoading(false))
  }, [load])

  return (
    <div className="management-scrim" role="presentation" onMouseDown={onClose}>
      <section
        ref={dialogRef}
        className="management-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="management-title"
        tabIndex={-1}
        onKeyDown={handleDialogKeyDown}
        onMouseDown={(event) => event.stopPropagation()}
      >
        <header className="management-header">
          <div>
            <span className="eyebrow">管理</span>
            <h2 id="management-title">环境与项目</h2>
          </div>
          <button className="icon-button" title="关闭管理后台" onClick={onClose}>
            <X size={18} />
          </button>
        </header>

        <nav className="management-tabs" aria-label="管理分类">
          <button className={tab === 'projects' ? 'active' : ''} onClick={() => setTab('projects')}>
            <FolderGit2 size={16} />
            项目
          </button>
          <button className={tab === 'proxy' ? 'active' : ''} onClick={() => setTab('proxy')}>
            <Network size={16} />
            代理
          </button>
          <button className={tab === 'runtime' ? 'active' : ''} onClick={() => setTab('runtime')}>
            <ServerCog size={16} />
            系统
          </button>
        </nav>
        <div className="management-content">
          {loading ? (
            <div className="detail-loading">
              <LoaderCircle className="spin" size={18} />
              正在读取环境与项目设置
            </div>
          ) : error ? (
            <InlineError message={error} />
          ) : tab === 'projects' ? (
            <ProjectsSettings
              projects={projects}
              setProjects={setProjects}
              bindings={siteBindings}
              setBindings={setSiteBindings}
              autoSslEnabled={Boolean(systemSettings?.autoSslEnabled)}
              previewBaseDomain={previewBaseDomain}
              onChanged={onProjectsChanged}
            />
          ) : tab === 'runtime' && systemSettings ? (
            <SystemSettingsForm settings={systemSettings} onChange={setSystemSettings} />
          ) : proxy ? (
            <ProxySettingsForm settings={proxy} onChange={setProxy} />
          ) : null}
        </div>
      </section>
    </div>
  )
}

function TargetRow({
  row,
  branchState,
  queueItems,
  selectedBranch,
  staged,
  busy,
  onBranchChange,
  onBuild,
  onStage,
}: {
  row: MatrixRow
  branchState: BranchState
  queueItems: BuildQueueItem[]
  selectedBranch: string
  staged: StagedArtifact | null
  busy: boolean
  onBranchChange: (branch: string) => void
  onBuild: () => void
  onStage: (artifact: StagedArtifact) => void
}) {
  const selected = branchState.items.find((item) => item.branch === selectedBranch) || null
  const current = row.current
  const configured = row.target.configured
  const enabled = row.target.enabled
  const isRemote = row.target.kind === 'remote'
  const currentCandidate = selected?.latestArtifact?.id === current?.artifactId
  const stagedCandidate = selected?.latestArtifact?.id === staged?.id
  const stagedOfficial = Boolean(staged && staged.id === null)
  const disabledReason = !configured ? '尚未配置 Git 仓库' : '项目已停用，可在管理后台重新启用'

  return (
    <article className={`target-row ${enabled && configured ? '' : 'disabled-target'}`}>
      <div className="target-identity">
        <div className="target-name">
          <PackageCheck size={17} />
          <strong>{row.target.name}</strong>
        </div>
        <span className={`target-state ${enabled && configured ? 'available' : ''}`}>
          {enabled && configured ? '可用' : '不可用'}
        </span>
      </div>

      {enabled && configured ? (
        <>
          <div className="current-version">
            <span>当前</span>
            <strong title={current?.branch || ''}>
              {current?.branch || (isRemote ? '官方热更' : '未发布')}
            </strong>
          </div>
          <label className="branch-control">
            <span>候选分支</span>
            <BranchPicker
              targetId={row.target.id}
              targetName={row.target.name}
              items={branchState.items}
              queueItems={queueItems}
              selectedBranch={selectedBranch}
              fallbackBranch={row.target.defaultBranch}
              officialLabel={isRemote ? '官方热更（不覆盖）' : undefined}
              onChange={onBranchChange}
            />
          </label>
          <div className="artifact-meta">
            <span>上次打包</span>
            <strong>{formatTime(selected?.latestArtifact?.builtAt)}</strong>
            {!branchState.remoteAvailable ? (
              <small>远端分支查询失败，仍可使用已有产物</small>
            ) : null}
          </div>
          <div className="row-actions">
            <button
              className="secondary-button"
              onClick={onBuild}
              disabled={busy || !selectedBranch}
            >
              {busy ? <LoaderCircle className="spin" size={16} /> : <Hammer size={16} />}
              {busy ? '提交中' : '打最新包'}
            </button>
            <button
              className="primary-button"
              onClick={() => {
                if (isRemote && !selectedBranch) {
                  onStage({
                    id: null,
                    targetId: row.target.id,
                    targetName: row.target.name,
                    branch: '官方热更',
                    builtAt: '',
                  })
                  return
                }
                if (selected?.latestArtifact) {
                  onStage({
                    ...selected.latestArtifact,
                    targetId: row.target.id,
                    targetName: row.target.name,
                  })
                }
              }}
              disabled={
                isRemote && !selectedBranch
                  ? stagedOfficial || (!current && !staged)
                  : !selected?.latestArtifact || currentCandidate || stagedCandidate
              }
            >
              <Check size={16} />
              {isRemote && !selectedBranch
                ? stagedOfficial
                  ? '待发布'
                  : !current && !staged
                    ? '当前使用中'
                    : '使用官方'
                : !selected?.latestArtifact
                  ? '暂无产物'
                  : currentCandidate
                    ? '当前使用中'
                    : stagedCandidate
                      ? '待发布'
                      : '使用此包'}
            </button>
          </div>
        </>
      ) : (
        <div className="disabled-reason">{disabledReason}</div>
      )}
    </article>
  )
}

export function App() {
  const [actorName, setActorNameState] = useState(getActorName)
  const [mainView, setMainView] = useState<MainView>('environment')
  const [matrix, setMatrix] = useState<EnvironmentMatrix | null>(null)
  const [branches, setBranches] = useState<Record<string, BranchState>>({})
  const [selectedBranches, setSelectedBranches] = useState<Record<string, string>>({})
  const [queue, setQueue] = useState<BuildQueueSnapshot>(emptyQueue)
  const [staged, setStaged] = useState<Record<string, StagedArtifact>>({})
  const [submittingTarget, setSubmittingTarget] = useState<string | null>(null)
  const [publishing, setPublishing] = useState(false)
  const [managementOpen, setManagementOpen] = useState(false)
  const [mobileEnvironmentUrl, setMobileEnvironmentUrl] = useState('http://localhost:9872')
  const [previewBaseDomain, setPreviewBaseDomain] = useState(DEFAULT_PREVIEW_BASE_DOMAIN)
  const [status, setStatus] = useState<StatusState>({ tone: 'idle', text: '正在连接公共环境' })
  const [historyJobs, setHistoryJobs] = useState<BuildJob[]>([])
  const [historyLoading, setHistoryLoading] = useState(false)
  const [historyError, setHistoryError] = useState('')
  const [historyTargetId, setHistoryTargetId] = useState('')
  const [historyStatus, setHistoryStatus] = useState<BuildJobStatus | ''>('')
  const [historyQuery, setHistoryQuery] = useState('')
  const [historyNextCursor, setHistoryNextCursor] = useState<string | null>(null)
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null)
  const [jobDetail, setJobDetail] = useState<BuildJobDetail | null>(null)
  const [jobLog, setJobLog] = useState<BuildJobLogView | null>(null)
  const [jobDetailLoading, setJobDetailLoading] = useState(false)
  const [jobDetailError, setJobDetailError] = useState('')
  const [jobDetailTab, setJobDetailTab] = useState<JobDetailTab>('overview')
  const [logCopied, setLogCopied] = useState(false)
  const [cancelingJobId, setCancelingJobId] = useState<string | null>(null)
  const historyRequestId = useRef(0)
  const logRef = useRef<HTMLPreElement>(null)
  const queueSignaturesRef = useRef<Map<string, string>>(new Map())
  const dirtyBranchTargetsRef = useRef<Set<string>>(new Set())

  const refreshCore = useCallback(async (quiet = false) => {
    try {
      const [nextMatrix, nextQueue, runtime] = await Promise.all([
        getMatrix(),
        getBuildQueue(),
        getPublicRuntimeSettings(),
      ])
      setMobileEnvironmentUrl(runtime.mobileEnvironmentUrl)
      setPreviewBaseDomain(runtime.previewBaseDomain || DEFAULT_PREVIEW_BASE_DOMAIN)
      setMatrix(nextMatrix)
      setQueue(nextQueue)
      setSelectedBranches((current) => {
        const next = { ...current }
        for (const row of nextMatrix.rows) {
          if (!Object.prototype.hasOwnProperty.call(next, row.target.id)) {
            next[row.target.id] = row.current?.branch || row.target.defaultBranch
          }
        }
        return next
      })
      if (!quiet) setStatus({ tone: 'idle', text: '环境信息已刷新' })
      return { matrix: nextMatrix, queue: nextQueue }
    } catch (error) {
      setStatus({ tone: 'warning', text: errorMessage(error) })
      return null
    }
  }, [])

  const refreshBranches = useCallback(
    async (nextMatrix: EnvironmentMatrix, targetIds?: ReadonlySet<string>) => {
      const rows = targetIds
        ? nextMatrix.rows.filter((row) => targetIds.has(row.target.id))
        : nextMatrix.rows
      const catalogs = await Promise.all(
        rows.map(async (row) => {
          if (!row.target.enabled || !row.target.configured) {
            return {
              targetId: row.target.id,
              catalog: { items: [], remoteAvailable: false } as BranchState,
              failed: false,
            }
          }
          try {
            return {
              targetId: row.target.id,
              catalog: await getBranches(row.target.id),
              failed: false,
            }
          } catch {
            return { targetId: row.target.id, catalog: null, failed: true }
          }
        })
      )
      const successful = catalogs.filter(
        (result): result is typeof result & { catalog: BranchState; failed: false } =>
          !result.failed && result.catalog !== null
      )
      const refreshedBranches = Object.fromEntries(
        successful.map((result) => [result.targetId, result.catalog])
      ) as Record<string, BranchState>
      setBranches((current) => {
        if (targetIds) return { ...current, ...refreshedBranches }
        const visibleTargets = new Set(nextMatrix.rows.map((row) => row.target.id))
        const preserved = Object.fromEntries(
          Object.entries(current).filter(([targetId]) => visibleTargets.has(targetId))
        )
        return { ...preserved, ...refreshedBranches }
      })
      setSelectedBranches((current) => {
        const next = { ...current }
        for (const row of rows.filter((candidate) => candidate.target.id in refreshedBranches)) {
          const catalog = refreshedBranches[row.target.id]?.items || []
          const selectedBranch = next[row.target.id]
          if (selectedBranch === '' && row.target.kind === 'remote') continue
          if (
            selectedBranch === undefined ||
            !catalog.some((item) => item.branch === selectedBranch)
          ) {
            next[row.target.id] =
              row.current?.branch || catalog[0]?.branch || row.target.defaultBranch
          }
        }
        return next
      })
      return new Set(catalogs.filter((result) => result.failed).map((result) => result.targetId))
    },
    []
  )

  const refreshAll = useCallback(
    async (quiet = false) => {
      const next = await refreshCore(quiet)
      if (next) {
        dirtyBranchTargetsRef.current = await refreshBranches(next.matrix)
        queueSignaturesRef.current = queueTargetSignatures(next.queue)
      }
    },
    [refreshBranches, refreshCore]
  )

  const refreshQueueAware = useCallback(
    async (quiet = true) => {
      const next = await refreshCore(quiet)
      if (!next) return
      const currentSignatures = queueTargetSignatures(next.queue)
      const affectedTargets = completedQueueTargets(queueSignaturesRef.current, currentSignatures)
      queueSignaturesRef.current = currentSignatures
      for (const targetId of affectedTargets) dirtyBranchTargetsRef.current.add(targetId)
      if (dirtyBranchTargetsRef.current.size) {
        const attempted = new Set(dirtyBranchTargetsRef.current)
        const failed = await refreshBranches(next.matrix, attempted)
        for (const targetId of attempted) dirtyBranchTargetsRef.current.delete(targetId)
        for (const targetId of failed) dirtyBranchTargetsRef.current.add(targetId)
      }
    },
    [refreshBranches, refreshCore]
  )

  useEffect(() => {
    let stopped = false
    let timer: number | undefined
    const poll = async () => {
      await refreshQueueAware(true)
      if (!stopped) timer = window.setTimeout(() => void poll(), 3000)
    }
    void refreshAll().finally(() => {
      if (!stopped) timer = window.setTimeout(() => void poll(), 3000)
    })
    return () => {
      stopped = true
      if (timer !== undefined) window.clearTimeout(timer)
    }
  }, [refreshAll, refreshQueueAware])

  const loadHistory = useCallback(
    async ({
      before,
      append = false,
      quiet = false,
    }: { before?: string; append?: boolean; quiet?: boolean } = {}) => {
      const requestId = ++historyRequestId.current
      if (!quiet) setHistoryLoading(true)
      setHistoryError('')
      try {
        const result = await getBuildHistory({
          targetId: historyTargetId,
          status: historyStatus,
          query: historyQuery.trim(),
          before,
          limit: 50,
        })
        if (requestId !== historyRequestId.current) return
        setHistoryJobs((current) => (append ? [...current, ...result.items] : result.items))
        setHistoryNextCursor(result.nextCursor)
      } catch (error) {
        if (requestId === historyRequestId.current) setHistoryError(errorMessage(error))
      } finally {
        if (requestId === historyRequestId.current) setHistoryLoading(false)
      }
    },
    [historyQuery, historyStatus, historyTargetId]
  )

  useEffect(() => {
    if (mainView !== 'history') return
    const initialTimer = window.setTimeout(() => void loadHistory(), historyQuery.trim() ? 220 : 0)
    const pollTimer = window.setInterval(() => void loadHistory({ quiet: true }), 5000)
    return () => {
      window.clearTimeout(initialTimer)
      window.clearInterval(pollTimer)
    }
  }, [historyQuery, loadHistory, mainView])

  useEffect(() => {
    if (!selectedJobId) return
    let stopped = false
    let timer: number | undefined

    setJobDetail(null)
    setJobLog(null)
    setJobDetailError('')
    setJobDetailLoading(true)

    const poll = async () => {
      try {
        const [nextDetail, nextLog] = await Promise.all([
          getBuildJobDetail(selectedJobId),
          getBuildJobLog(selectedJobId),
        ])
        if (stopped) return
        setJobDetail(nextDetail)
        setJobLog(nextLog)
        setJobDetailError('')
        setJobDetailLoading(false)
        if (!terminalBuildStatuses.has(nextDetail.job.status)) {
          timer = window.setTimeout(() => void poll(), 1500)
        }
      } catch (error) {
        if (stopped) return
        setJobDetailError(errorMessage(error))
        setJobDetailLoading(false)
        timer = window.setTimeout(() => void poll(), 3000)
      }
    }

    void poll()
    return () => {
      stopped = true
      if (timer !== undefined) window.clearTimeout(timer)
    }
  }, [selectedJobId])

  useEffect(() => {
    if (!selectedJobId) return
    const previousOverflow = document.body.style.overflow
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setSelectedJobId(null)
    }
    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', closeOnEscape)
    return () => {
      document.body.style.overflow = previousOverflow
      window.removeEventListener('keydown', closeOnEscape)
    }
  }, [selectedJobId])

  useEffect(() => {
    if (jobDetailTab === 'console' && logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight
    }
  }, [jobDetailTab, jobLog?.content])

  const queueItems = [...queue.running, ...queue.queued]
  const myRunning = queue.running.filter((item) => item.isMine)
  const myQueued = queue.queued.filter((item) => item.isMine)
  const queueSummary = myRunning.length
    ? `我的请求构建中${myRunning.length > 1 ? ` · ${myRunning.length} 个` : ''}`
    : myQueued.length
      ? `我的请求第 ${myQueued[0]?.queuePosition} 位${myQueued.length > 1 ? ` · 共 ${myQueued.length} 个` : ''}`
      : queue.running.length
        ? `忙碌 · ${queue.queued.length} 个等待`
        : queue.queued.length
          ? `${queue.queued.length} 个等待`
          : '空闲'

  const targetNames = useMemo(
    () => new Map(matrix?.rows.map((row) => [row.target.id, row.target.name]) || []),
    [matrix]
  )
  const historyTargets = useMemo(
    () => matrix?.rows.map((row) => ({ id: row.target.id, name: row.target.name })) || [],
    [matrix]
  )
  const changes = Object.values(staged).filter((item) => {
    const current = matrix?.rows.find((row) => row.target.id === item.targetId)?.current
    return isRevisionSelectionChanged(current?.artifactId, item.id)
  })

  async function handleBuild(targetId: string) {
    const branch = selectedBranches[targetId]
    if (!branch) return
    setSubmittingTarget(targetId)
    setStatus({ tone: 'busy', text: `${targetNames.get(targetId) || targetId} · 正在提交打包任务` })
    try {
      await createBuild(targetId, branch)
      await refreshQueueAware(true)
      setStatus({ tone: 'busy', text: `${branch} · 已加入全局队列` })
    } catch (error) {
      setStatus({ tone: 'warning', text: errorMessage(error) })
    } finally {
      setSubmittingTarget(null)
    }
  }

  async function handlePublish() {
    if (!matrix || changes.length === 0) return
    const selections = matrix.rows
      .filter((row) => row.target.enabled)
      .map((row) => {
        const candidate = staged[row.target.id]
        const artifactId = revisionArtifactId(row.current?.artifactId, candidate?.id)
        return artifactId ? { targetId: row.target.id, artifactId } : null
      })
      .filter((selection): selection is { targetId: string; artifactId: string } =>
        Boolean(selection)
      )
    const missingRequired = matrix.rows.find(
      (row) =>
        row.target.enabled &&
        row.target.required &&
        !selections.some((item) => item.targetId === row.target.id)
    )
    if (missingRequired) {
      setStatus({
        tone: 'warning',
        text: `${missingRequired.target.name} 没有可发布的产物，请先打包并选择`,
      })
      return
    }
    setPublishing(true)
    setStatus({ tone: 'busy', text: `正在发布 ${changes.length} 个项目变更` })
    try {
      await publishRevision({
        baseRevisionId: matrix.environment.currentRevisionId,
        selections,
        message: changes.map((item) => `${item.targetName} → ${item.branch}`).join('；'),
      })
      setStaged({})
      await refreshQueueAware(true)
      setStatus({ tone: 'success', text: '公共环境已更新' })
    } catch (error) {
      setStatus({ tone: 'warning', text: errorMessage(error) })
      await refreshQueueAware(true)
    } finally {
      setPublishing(false)
    }
  }

  async function handleCopyLog() {
    if (!jobLog?.content) return
    try {
      await navigator.clipboard.writeText(jobLog.content)
      setLogCopied(true)
      window.setTimeout(() => setLogCopied(false), 1600)
    } catch {
      setJobDetailError('浏览器没有允许复制日志，请使用下载按钮')
    }
  }

  async function handleCancelJob() {
    const job = jobDetail?.job
    if (!job || terminalBuildStatuses.has(job.status) || job.status === 'CANCELING') return
    setCancelingJobId(job.id)
    setJobDetailError('')
    try {
      const canceled = await cancelBuildJob(job.id)
      setJobDetail((current) => (current ? { ...current, job: canceled } : current))
      setStatus({
        tone: canceled.status === 'CANCELED' ? 'success' : 'busy',
        text: canceled.status === 'CANCELED' ? '构建已取消' : '已提交中断请求',
      })
      await Promise.all([refreshQueueAware(true), loadHistory({ quiet: true })])
    } catch (error) {
      setJobDetailError(errorMessage(error))
    } finally {
      setCancelingJobId(null)
    }
  }

  function openJob(jobId: string) {
    setJobDetailTab('overview')
    setLogCopied(false)
    setSelectedJobId(jobId)
  }

  function closeJob() {
    setSelectedJobId(null)
    setJobDetail(null)
    setJobLog(null)
    setJobDetailError('')
  }

  return (
    <main className="app-page">
      <section className="console-surface">
        <header className="toolbar">
          <div className="environment-title">
            <h1>{matrix?.environment.name || '公共调试环境'}</h1>
            <span className="environment-meta">
              {matrix?.revision ? `Revision ${matrix.revision.revisionNo}` : '尚未发布'} ·{' '}
              <label className="actor-control" title="操作人名称仅用于队列和审计记录">
                <UserRound size={12} />
                <span className="sr-only">操作人名称</span>
                <input
                  value={actorName}
                  onChange={(event) => setActorNameState(event.target.value)}
                  onBlur={() => setActorNameState(setActorName(actorName))}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter') event.currentTarget.blur()
                  }}
                  maxLength={40}
                  aria-label="操作人名称"
                />
              </label>
            </span>
          </div>
          <div className="toolbar-actions">
            <a
              className="icon-button"
              href={mobileEnvironmentUrl}
              target="_blank"
              rel="noreferrer"
              title="打开移动站"
            >
              <ExternalLink size={17} />
            </a>
            <button className="icon-button" onClick={() => void refreshAll()} title="刷新环境">
              <RefreshCw size={17} />
            </button>
            <button
              className="icon-button"
              onClick={() => setManagementOpen(true)}
              title="环境与项目设置"
            >
              <Settings size={17} />
            </button>
          </div>
        </header>

        <nav className="main-view-tabs" aria-label="控制台视图">
          <button
            type="button"
            className={mainView === 'environment' ? 'active' : ''}
            onClick={() => setMainView('environment')}
          >
            <Network size={15} />
            环境版本
          </button>
          <button
            type="button"
            className={mainView === 'history' ? 'active' : ''}
            onClick={() => setMainView('history')}
          >
            <History size={15} />
            构建记录
          </button>
        </nav>

        {mainView === 'environment' ? (
          <>
            <section className="build-queue" aria-label="打包机队列">
              <div className="queue-heading">
                <div className="queue-title">
                  <ListOrdered size={16} />
                  <strong>打包机队列</strong>
                </div>
                <span
                  className={
                    myRunning.length || myQueued.length
                      ? 'queue-summary mine-summary'
                      : 'queue-summary'
                  }
                >
                  {queueSummary}
                </span>
              </div>
              {queueItems.length ? (
                <div className="queue-list">
                  {queueItems.map((item) => (
                    <QueueRow
                      item={item}
                      targetName={targetNames.get(item.targetId) || item.targetId}
                      key={item.id}
                      onOpen={() => openJob(item.id)}
                    />
                  ))}
                </div>
              ) : (
                <div className="queue-empty">
                  <Clock3 size={14} />
                  当前没有打包任务
                </div>
              )}
            </section>

            <section className="target-list" aria-label="项目版本">
              {matrix?.rows.map((row) => (
                <TargetRow
                  key={row.target.id}
                  row={row}
                  branchState={branches[row.target.id] || { items: [], remoteAvailable: false }}
                  queueItems={queueItems.filter((item) => item.targetId === row.target.id)}
                  selectedBranch={selectedBranches[row.target.id] ?? row.target.defaultBranch}
                  staged={staged[row.target.id] || null}
                  busy={submittingTarget === row.target.id}
                  onBranchChange={(branch) =>
                    setSelectedBranches((current) => ({ ...current, [row.target.id]: branch }))
                  }
                  onBuild={() => void handleBuild(row.target.id)}
                  onStage={(artifact) => {
                    setStaged((current) => {
                      const next = { ...current }
                      if (artifact.id === null && !row.current) delete next[row.target.id]
                      else next[row.target.id] = artifact
                      return next
                    })
                    setStatus({
                      tone: 'success',
                      text:
                        artifact.id === null && !row.current
                          ? `${artifact.targetName} · 已恢复当前官方选择`
                          : `${artifact.targetName} · ${artifact.branch} 已加入待发布`,
                    })
                  }}
                />
              ))}
            </section>

            <section className={`publish-bar ${changes.length ? 'has-change' : ''}`}>
              <div className="publish-copy">
                <span>待发布</span>
                <strong>
                  {changes.length
                    ? changes.map((item) => `${item.targetName} → ${item.branch}`).join('；')
                    : '没有变更'}
                </strong>
              </div>
              <button
                className="publish-button"
                onClick={() => void handlePublish()}
                disabled={!changes.length || publishing}
              >
                {publishing ? <LoaderCircle className="spin" size={17} /> : <Rocket size={17} />}
                发布
              </button>
            </section>
          </>
        ) : (
          <BuildHistoryView
            jobs={historyJobs}
            loading={historyLoading}
            error={historyError}
            targetId={historyTargetId}
            status={historyStatus}
            query={historyQuery}
            targets={historyTargets}
            nextCursor={historyNextCursor}
            onTargetChange={setHistoryTargetId}
            onStatusChange={setHistoryStatus}
            onQueryChange={setHistoryQuery}
            onRefresh={() => void loadHistory()}
            onLoadMore={() =>
              historyNextCursor && void loadHistory({ before: historyNextCursor, append: true })
            }
            onOpen={openJob}
          />
        )}

        <div className={`status-bar status-${status.tone}`} role="status">
          <div className="status-message">
            {status.tone === 'busy' ? (
              <LoaderCircle className="spin" size={14} />
            ) : status.tone === 'warning' ? (
              <CircleAlert size={14} />
            ) : status.tone === 'success' ? (
              <Check size={14} />
            ) : (
              <ShieldCheck size={14} />
            )}
            <span>{status.text}</span>
          </div>
          <span className="cakedesign-credit" aria-hidden="true">
            Proudly Crafted With CakeDesign.
          </span>
        </div>
      </section>
      {managementOpen ? (
        <ManagementPanel
          onClose={() => setManagementOpen(false)}
          onProjectsChanged={() => void refreshAll(true)}
          previewBaseDomain={previewBaseDomain}
        />
      ) : null}
      {selectedJobId ? (
        <JobDetailPanel
          detail={jobDetail}
          log={jobLog}
          loading={jobDetailLoading}
          error={jobDetailError}
          tab={jobDetailTab}
          copied={logCopied}
          logRef={logRef}
          targetName={
            jobDetail ? targetNames.get(jobDetail.job.targetId) || jobDetail.job.targetId : ''
          }
          canceling={cancelingJobId === selectedJobId}
          onTabChange={setJobDetailTab}
          onCancel={() => void handleCancelJob()}
          onCopy={() => void handleCopyLog()}
          onClose={closeJob}
        />
      ) : null}
    </main>
  )
}
