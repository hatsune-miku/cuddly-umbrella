import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import test from 'node:test'
import vm from 'node:vm'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const mainSource = await readFile(path.join(root, 'in-place-hot-module-main.js'), 'utf8')
const bridgeSource = await readFile(path.join(root, 'in-place-hot-module-bridge.js'), 'utf8')

const remote = {
  moduleKey: 'base',
  name: 'cuddly_base_feature',
  entry:
    'https://main.bifrost.vanillacake.cn/__cuddly/preview-artifacts/00000000-0000-4000-8000-000000000001/cuddly_base_feature/remoteEntry.js',
  version: 'cuddly_base_feature',
  restartRequired: true,
}

function mainHarness(fetchImpl, origin = 'https://www.kookapp.cn') {
  const listeners = new Map()
  const window = {
    location: new URL(`${origin}/channels/1`),
    fetch: fetchImpl,
    setTimeout,
    addEventListener(type, listener) {
      listeners.set(type, listener)
    },
    removeEventListener(type, listener) {
      if (listeners.get(type) === listener) listeners.delete(type)
    },
  }
  const context = vm.createContext({
    Headers,
    Object,
    Promise,
    Reflect,
    Request,
    Response,
    URL,
    window,
  })
  new vm.Script(mainSource, { filename: 'in-place-hot-module-main.js' }).runInContext(context)
  return {
    window,
    configure(modules) {
      listeners.get('message')?.({
        source: window,
        origin,
        data: {
          channel: 'bifrost:in-place-hot-module:v1',
          type: 'configuration',
          modules,
        },
      })
    },
  }
}

test('keeps the official request unchanged and overlays only selected object modules', async () => {
  const requests = []
  const official = {
    code: 0,
    traceId: 'official-trace',
    data: {
      cursor: 42,
      modules: {
        base: {
          name: 'official_base',
          entry: 'https://static.kookapp.cn/base/remoteEntry.js',
          version: 'official',
          restartRequired: false,
          officialField: 'preserved',
        },
        discover: { name: 'official_discover', enabled: true },
      },
    },
  }
  const nativeResponse = new Response(JSON.stringify(official), {
    status: 200,
    headers: { 'content-type': 'application/json', 'x-official': 'preserved' },
  })
  const harness = mainHarness(async (...args) => {
    requests.push(args)
    return nativeResponse
  })
  harness.configure([remote])

  const init = {
    headers: { authorization: 'Bearer official', 'x-signature': 'official-signature' },
  }
  const response = await harness.window.fetch(
    '/api/v3/version/hot-module?app=1.2.3&cursor=42',
    init
  )

  assert.deepEqual(requests, [['/api/v3/version/hot-module?app=1.2.3&cursor=42', init]])
  assert.equal(requests[0][1], init)
  assert.equal(requests[0][1].headers, init.headers)
  assert.notEqual(response, nativeResponse)
  assert.equal(response.headers.get('x-official'), 'preserved')
  assert.deepEqual(await response.json(), {
    code: 0,
    traceId: 'official-trace',
    data: {
      cursor: 42,
      modules: {
        base: {
          name: remote.name,
          entry: remote.entry,
          version: remote.version,
          restartRequired: true,
          officialField: 'preserved',
        },
        discover: { name: 'official_discover', enabled: true },
      },
    },
  })
})

test('supports the array protocol shape and preserves unselected module fields', async () => {
  const harness = mainHarness(async () =>
    Response.json({
      code: 0,
      data: {
        modules: [
          { key: 'discover', name: 'official_discover' },
          { key: 'base', name: 'official_base', retained: 1 },
        ],
      },
    })
  )
  harness.configure([remote])

  const body = await harness.window
    .fetch('https://www.kookapp.cn/v3/version/hot-module')
    .then((response) => response.json())
  assert.deepEqual(body.data.modules, [
    { key: 'discover', name: 'official_discover' },
    {
      key: 'base',
      name: remote.name,
      entry: remote.entry,
      version: remote.version,
      restartRequired: true,
      retained: 1,
    },
  ])
})

test('fails open for non-target, failed, malformed, and business-error responses', async () => {
  for (const scenario of [
    {
      url: '/api/v3/users/me',
      response: Response.json({ code: 0, data: { modules: {} } }),
    },
    {
      url: 'https://other.example.test/api/v3/version/hot-module',
      response: Response.json({ code: 0, data: { modules: {} } }),
    },
    {
      url: '/api/v3/version/hot-module',
      response: new Response('unauthorized', { status: 401 }),
    },
    {
      url: '/api/v3/version/hot-module',
      response: new Response('not-json', { status: 200 }),
    },
    {
      url: '/api/v3/version/hot-module',
      response: Response.json({ code: 401, data: { modules: {} } }),
    },
    {
      url: '/api/v3/version/hot-module',
      response: Response.json({ code: 0, data: { modules: null } }),
    },
  ]) {
    const harness = mainHarness(async () => scenario.response)
    harness.configure([remote])
    assert.equal(await harness.window.fetch(scenario.url), scenario.response)
  }

  const postResponse = Response.json({ code: 0, data: { modules: {} } })
  const postHarness = mainHarness(async () => postResponse)
  postHarness.configure([remote])
  assert.equal(
    await postHarness.window.fetch('/api/v3/version/hot-module', { method: 'POST' }),
    postResponse
  )
})

test('waits for a cold bridge and leaves the response untouched when configuration is empty', async () => {
  const officialBody = {
    code: 0,
    data: { modules: { base: { name: 'official', retained: true } } },
  }
  const coldRequests = []
  const coldHarness = mainHarness(async (...args) => {
    coldRequests.push(args)
    return Response.json(officialBody)
  })
  const pending = coldHarness.window
    .fetch('/api/v3/version/hot-module')
    .then((response) => response.json())
  setTimeout(() => coldHarness.configure([remote]), 10)
  assert.equal((await pending).data.modules.base.name, remote.name)
  assert.deepEqual(coldRequests, [['/api/v3/version/hot-module']])

  const nativeResponse = Response.json(officialBody)
  const emptyHarness = mainHarness(async () => nativeResponse)
  emptyHarness.configure([])
  assert.equal(await emptyHarness.window.fetch('/api/v3/version/hot-module'), nativeResponse)
})

test('isolated bridge publishes only the public module overlay fields', async () => {
  let postedResolve
  const posted = new Promise((resolve) => {
    postedResolve = resolve
  })
  const window = {
    location: new URL('https://www.kookapp.cn/channels/1'),
    postMessage(message, targetOrigin) {
      postedResolve({ message, targetOrigin })
    },
  }
  const chrome = {
    runtime: {
      sendMessage: async (message) => {
        assert.equal(message.type, 'read-in-place-hot-module-config')
        return {
          ok: true,
          config: [
            { ...remote, token: 'must-not-cross-worlds', csrfToken: 'must-not-cross-worlds' },
          ],
        }
      },
    },
  }
  new vm.Script(bridgeSource, { filename: 'in-place-hot-module-bridge.js' }).runInContext(
    vm.createContext({ chrome, window })
  )

  assert.deepEqual(JSON.parse(JSON.stringify(await posted)), {
    targetOrigin: 'https://www.kookapp.cn',
    message: {
      channel: 'bifrost:in-place-hot-module:v1',
      type: 'configuration',
      modules: [remote],
    },
  })
})
