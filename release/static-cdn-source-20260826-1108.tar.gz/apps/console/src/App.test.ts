import { describe, expect, it } from 'vitest'
import { createElement } from 'react'
import { renderToStaticMarkup } from 'react-dom/server'
import type { BranchCatalogItem, MatrixRow, SiteBinding } from '@cuddly/contracts'

import {
  DEFAULT_RESOURCE_PROXY_PREFIXES,
  projectSiteSummary,
  selectedEnvironmentOrFirst,
  siteHostnameForId,
  TargetRow,
} from './App'

function siteBinding(id: string, targetId: string): SiteBinding {
  return {
    id,
    name: id,
    hostname: `${id}.bifrost.vanillacake.cn`,
    targetId,
    environmentSlug: 'shared',
    fallbackOrigin: 'https://www.kookapp.cn',
    upstreamOrigin: 'https://www.kookapp.cn',
    officialOrigin: `https://${id}.kookapp.cn`,
    enabled: true,
    remoteTargetIds: [],
    resourceProxyPrefixes: ['https://img.kookapp.cn/'],
  }
}

describe('site hostname generation', () => {
  it('proxies the complete KOOK protected resource origins by default', () => {
    expect(DEFAULT_RESOURCE_PROXY_PREFIXES).toEqual([
      'https://img.kookapp.cn/',
      'https://static.kookapp.cn/',
    ])
  })

  it('uses the deployed preview base domain by default', () => {
    expect(siteHostnameForId('main')).toBe('main.bifrost.vanillacake.cn')
    expect(siteHostnameForId('main-preview')).toBe('main-preview.bifrost.vanillacake.cn')
  })

  it('uses a runtime-provided preview base domain', () => {
    expect(siteHostnameForId('main', 'preview.example.test')).toBe('main.preview.example.test')
    expect(siteHostnameForId('mobile', '.QA.EXAMPLE.TEST.')).toBe('mobile.qa.example.test')
  })

  it('rejects invalid DNS-label site ids', () => {
    expect(siteHostnameForId('main_preview')).toBe('')
    expect(siteHostnameForId('main-')).toBe('')
    expect(siteHostnameForId('a'.repeat(64))).toBe('')
  })
})

describe('project site summary', () => {
  it('keeps remote projects distinct from page projects', () => {
    expect(projectSiteSummary({ id: 'base', kind: 'remote' }, [])).toBe('Remote')
    expect(projectSiteSummary({ id: 'webapp', kind: 'webapp' }, [])).toBe('未配置站点')
  })

  it('shows the hostname for one site and a count for multiple sites', () => {
    const main = siteBinding('main', 'webapp')
    const staging = siteBinding('staging', 'webapp')
    const mobile = siteBinding('mobile', 'online-h5')

    expect(projectSiteSummary({ id: 'webapp', kind: 'webapp' }, [main, mobile])).toBe(main.hostname)
    expect(projectSiteSummary({ id: 'webapp', kind: 'webapp' }, [main, staging, mobile])).toBe(
      '2 个站点'
    )
  })
})

describe('build-only project row', () => {
  it('keeps branch builds available without exposing public publication actions', () => {
    const builtAt = '2026-08-26T00:00:00.000Z'
    const row: MatrixRow = {
      target: {
        id: 'webapp',
        name: '网页端',
        kind: 'webapp',
        defaultBranch: 'master',
        enabled: true,
        required: false,
        configured: true,
      },
      config: {
        targetId: 'webapp',
        environmentId: '00000000-0000-4000-8000-000000000001',
        enabled: true,
        required: false,
        installCommand: 'pnpm install',
        buildCommand: 'pnpm build',
        outputDirectory: 'dist',
      },
      current: null,
      latestArtifact: { id: '00000000-0000-4000-8000-000000000002', branch: 'master', builtAt },
      activeJob: null,
    }
    const branch: BranchCatalogItem = {
      branch: 'master',
      buildStatus: 'IDLE',
      latestArtifact: row.latestArtifact,
      latestJob: null,
    }
    const markup = renderToStaticMarkup(
      createElement(TargetRow, {
        row,
        branchState: { items: [branch], remoteAvailable: true },
        queueItems: [],
        selectedBranch: 'master',
        busy: false,
        environmentStatus: 'ACTIVE',
        onBranchChange() {},
        onBuild() {},
      })
    )

    expect(markup).toContain('打包分支')
    expect(markup).toContain('打最新包')
    expect(markup).not.toContain('发布')
    expect(markup).not.toContain('使用此包')
    expect(markup).not.toContain('当前使用中')
  })
})

describe('environment settings selection', () => {
  const environments = [{ slug: 'shared' }, { slug: 'qa-local' }]

  it('opens the environment that is selected in the main console', () => {
    expect(selectedEnvironmentOrFirst(environments, 'qa-local')).toEqual({ slug: 'qa-local' })
  })

  it('falls back to the first environment when the current selection is unavailable', () => {
    expect(selectedEnvironmentOrFirst(environments, 'missing')).toEqual({ slug: 'shared' })
    expect(selectedEnvironmentOrFirst([], 'missing')).toBeNull()
  })
})
