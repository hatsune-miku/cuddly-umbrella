# Cuddly Umbrella

Cuddly 将 Bifrost、在线 H5 构建、不可变 Artifact 和 QA 环境选择收敛到一个工作区。

首个切片支持：

- 在线 H5 分支构建任务。
- 本地磁盘不可变 Artifact。
- `shared` 环境的完整 Revision 发布与回滚基础。
- 移动站前端走所选 Artifact，后端请求代理 `m.kookapp.cn`。
- 无登录门槛的 QA 控制台；客户端操作标识仅用于队列展示和弱审计，不参与鉴权。
- Compose 内置 Mihomo，支持通过受保护的管理面配置 Clash/Trojan 订阅。
- Host 驱动的站点绑定：页面 Artifact 走独立预览域名，接口请求代理对应官网。
- 按标签页预览：页面与 Remote 都在对应站点的隔离预览域名生效；每个 Preview Token 固定保存
  精确 Artifact 选择，不影响其它标签页或公共环境。

详细设计见 [CUDDLY_WEB_ARTIFACT_SYSTEM_DESIGN.md](./CUDDLY_WEB_ARTIFACT_SYSTEM_DESIGN.md)。

## 本地开发

```bash
pnpm install
pnpm typecheck
pnpm test
```

本地以非 production 模式启动 Control API 和 Gateway 时使用内存 Store，适合 UI 和路由开发；
Docker Compose 与正式部署使用 PostgreSQL。

## Docker Compose

```bash
docker compose up --build
```

持久化数据统一位于仓库的 `data/docker`。控制台监听宿主机 `9888`，站点 Gateway 监听
`9872`；自动 SSL 的 HTTP-01 challenge 服务只监听回环地址 `127.0.0.1:19873`。正式环境的
HTTPS 反向代理指向 Console 与 Gateway，预览域名在管理后台“项目”页面的“预览站点”区域配置。

`vanillacake.cn` 服务器部署使用生产覆盖文件，让容器只监听回环地址：

```bash
docker compose -p cuddly -f docker-compose.yml -f docker-compose.production.yml up -d --build
```

生产覆盖将 Console 映射到 `127.0.0.1:9888`、Gateway 映射到
`127.0.0.1:9872`，再由 `deploy/nginx` 中的站点配置接入 HTTPS。

### 预览域名与自动 SSL

自动 SSL 默认关闭。宿主 Nginx 只需执行一次通用预览入口安装；之后新增或停用站点绑定不需要
逐域名修改 Nginx：

```bash
sudo CUDDLY_PREVIEW_BASE_DOMAIN=bifrost.vanillacake.cn \
  ./deploy/nginx/install-preview-wildcard.sh
```

DNS 必须让每个最终站点名解析到部署服务器。部分 DNS 服务商的 `*.vanillacake.cn` 泛解析可以
覆盖 `main.bifrost.vanillacake.cn`，另一些服务商则需要额外配置
`*.bifrost.vanillacake.cn`；部署前应直接查询最终站点名确认。也可以为每个站点配置等价的精确
DNS 记录。

安装器会读取 Nginx `user` 配置并探测 worker UID，必要时安装系统 `acl` 包，然后把 UID 保存到
`/etc/letsencrypt/.cuddly-nginx-worker-uid`。安装器只授予证书根目录的遍历权限；Cert-manager
每次签发或续期成功后，仅为对应域名的 `live/<hostname>` 与 `archive/<hostname>` lineage 设置
读取 ACL，因此不会向 Nginx worker 暴露同机其它站点的私钥。无法自动识别时可显式传入
`CUDDLY_NGINX_WORKER_UID=<uid>`。

生产 Compose 把宿主 `/etc/letsencrypt` 挂载到 Cert-manager。使用基础 Compose 的自包含磁盘目录
时，安装器还需指向同一个宿主绝对路径，例如：

```bash
sudo CUDDLY_LETSENCRYPT_DIR=/srv/cuddly/data/docker/letsencrypt \
  ./deploy/nginx/install-preview-wildcard.sh
```

管理后台打开自动 SSL 后，Cert-manager 才会为每个已启用站点执行 Certbot；联系邮箱可留空，
此时使用 Certbot 的无邮箱注册模式。关闭时只轮询配置，不启动 Certbot，也不修改现有证书。

Runner 在自己的 Node 24 容器内执行一次性 clone、`pnpm install --frozen-lockfile` 和
`pnpm run build`，不依赖 Docker Socket。私有仓库使用干净的 HTTPS
项目仓库地址与 Git HTTP 认证头都在管理后台的“项目”页面配置。认证头加密保存且不会回显；
不要把 Token 放进仓库 URL 或提交到仓库文件。

Runner 会在 `/srv/cuddly/git-cache/v1` 按“仓库地址 + 凭据作用域”维护持久的 shallow bare
对象缓存。每个任务仍先向远端 fetch 所选分支的最新 tip，再通过本机 Git 传输生成完全独立的
depth-1 工作目录；不共享 checkout、`node_modules`、alternates 或构建输出。仓库锁只覆盖 fetch
和对象复制，随后 checkout、Git LFS、依赖安装和构建都在各自 Job 中运行，所以不同项目仍可并行，
同一仓库的任务也只在很短的源码物化阶段排队。fetch 会同步刷新当前分支可达的 tag，并在成功解析
本次 commit 后才允许构建，绝不会拿旧 tip 继续运行。

只有缓存自身明确不可用时，Runner 才会清理未完成目录并执行原来的远端浅 clone；网络、鉴权、分支
和未知 I/O 错误不会触发第二次下载。HTTP(S) 仓库 URL 不允许携带用户信息、query 或 fragment，
认证只能使用加密保存的 Authorization Header；SSH 缓存按实际私钥指纹隔离，无法安全读取指纹时
使用受磁盘水位保护的直接 clone。缓存采用 14 天 LRU 和 1 GiB 目标软上限，并在磁盘剩余 4 GiB
时开始清理、2 GiB 时拒绝继续扩张；对象复制和直接 clone 共用容量预留。当前部署保持单 Runner
实例，以便进程内并发控制与文件锁共同生效。

Mihomo 只在 Docker 内部暴露混合代理端口和控制端口，不映射到宿主机公网。Control API
与 Runner 的 Git/依赖网络使用该代理；代理关闭时 Mihomo 运行在 DIRECT 模式。订阅链接只在
管理后台配置，使用自动生成并持久化的设置密钥加密，API 只返回掩码。

构建任务成功后先登记新的 READY Artifact；QA 仍需在控制台点击“使用此包”，再点击“发布”，
公共环境 Revision 才会变化。登记完成后，Worker 会清理同一项目、同一分支中被新包取代且未被
当前 Revision 或有效 Preview 使用的旧包。当前仍在服役的旧包会继续保留，因此“服役旧包 + 最新
候选包”允许暂时并存；切换 Revision 或 Preview 到期后，启动时及每分钟执行的 sweep 会再次回收。
磁盘删除采用 `DELETING -> 原子移入回收区 -> 删除目录 -> DELETED` 两阶段流程；超时、断网或
Runner 5xx 时保持 DELETING 并幂等重试，绝不恢复成可能指向残缺目录的 READY。发布失败会清掉
staging，后台还会在安全宽限期后收敛没有数据库记录的 orphan 目录。轻量 DELETED 元数据继续
保留构建历史，但不再属于可用 Artifact。

Remote 项目是独立的打包目标，项目标识必须与 KOOK 的 Remote key 一致，例如 `base`、
`discover`、`voice_runtime`。它们使用 `kook-remote-v1` 适配器。Remote 构建完成后同样只会产生
候选 Artifact；创建浏览器预览不会改动 `shared` 环境，也不会自动发布到官网。
Runner 会在临时 clone 的 Remote `scripts/get_config.js` 中让 `CUDDLY_ASSET_PREFIX` 优先于原有
`PUB_PATH`，因此可以继续使用现有 `build:ttt`/`build:prod` 命令而不会把动态 chunk 指回官网 OSS；
该适配不会写回或 push 业务仓库。对尚未接入 `.remote-version` 的历史分支，Runner 还会在临时
clone 中让 `VERSION` 优先决定 Module Federation provider；产物适配器必须在 `remoteEntry.js` 中
核对到该精确 provider 声明后才接受产物，避免把名字不匹配、实际无法加载的 Remote 发给 QA。
内置 Remote 模板使用 pnpm 的目录依赖闭包过滤器，只安装 `apps/<module>` 及其 workspace 依赖，
不会因为同仓库内无关项目的安装脚本拖慢或阻断打包；目录不存在时会直接失败，不回退成全仓安装。
若该 Remote 的生产构建配置启用了 Sentry Webpack 插件，Runner 只在临时 clone 中为 Cuddly 构建
关闭 release/sourcemap 上传，避免候选 Artifact 写入正式 Sentry；应用运行时代码和业务仓库不变。

## 站点绑定

站点绑定把一个合法 DNS label 形式的站点 ID（例如 `main`）映射到预览域名
`main.bifrost.vanillacake.cn`，并关联页面项目、`shared` 环境、接口上游、对应官网、资源代理路径
白名单和允许使用的 Remote 项目。页面项目必须已启用，并使用 `kook-online-h5-v1` 或
`generic-static-v1`；Remote
项目使用 `kook-remote-v1`。

Gateway 按请求 Host 读取站点绑定。页面与静态资源来自该站点当前环境选择的 Artifact，接口和
非页面请求代理到绑定的上游。创建带页面 Artifact 的 Preview Token 时，只影响该标签页并跳转到
预览域名；只选择 Remote 时，预览域代理官网页面。两种模式都不会覆盖公共环境或修改官网部署。

对 `/api/v3/version/hot-module` 和 `/v3/version/hot-module`，Gateway 保留原请求的
`app`/`addon`/`id` 查询参数及 KOOK 登录态，取得官方完整响应后只覆盖当前 Revision 或 Preview
明确选择的 Remote。未选择模块、官方批次 `id`/`version` 和未知字段原样保留；异常响应按原状态
和内容放行。首期覆盖项统一标记 `restartRequired: true`，保证刷新后加载选定产物，不尝试在已运行
页面内强制热切换。该专用改写最多缓冲 256 KiB JSON，不扩大其它代理请求的缓冲范围。

页面中写死的跨域资源 URL 可加入资源代理路径白名单。默认使用
`https://img.kookapp.cn/`，该来源下的图片、字体、样式、脚本、Remote、媒体与 JSON 数据都会
改写为预览站点的同源代理地址，并通过 `GET`/`HEAD` 只读转发。Gateway 会同时处理首屏 HTML、
Artifact 文本资源、动态 DOM 属性以及 `fetch`/XHR 等浏览器 API；Cookie、Authorization、预览
Token 和上游 `Set-Cookie` 均不会穿过这条链路。应用自身 JS/CSS 不应借此回退到官网应用 CDN，
仍必须存在于当前 Artifact 中。

## 浏览器扩展

在 Chromium 的扩展管理页面启用开发者模式，选择“加载已解压的扩展程序”，目录为
`apps/browser-extension`。扩展默认连接 `https://bifrost.vanillacake.cn`，可在弹窗右上角的覆盖式
连接设置中切换其它服务地址；本地开发时使用 `http://localhost:9888`。扩展会为每个浏览器生成
稳定的匿名队列标识，操作人显示名仅作为高级设置中的可选覆盖，不参与鉴权。正式使用时还需在
管理后台把“预览资源地址”配置为浏览器可访问的 HTTPS Gateway 地址。

升级或修改已解压扩展后，必须在 `chrome://extensions` 对 Cuddly KOOK Preview 点击一次“重新
加载”，使 popup 与常驻 Service Worker 使用同一协议版本；否则扩展会明确提示重载，不会先创建
一个无法应用的 Preview。

扩展始终把选中的页面/Remote 组合应用到对应站点的隔离预览域名，并只为目标标签页附加短期
Preview Token；不会把官网热更接口重定向到一份缺失模块的响应，也不会影响其它标签页。只选择
Remote 时，页面选择保持“官网页面”，由 Gateway 在预览域代理官网并合并官方热更响应。关闭
标签页、离开预览域、替换组合或在扩展中停用时，会话规则会被清理，服务端 Token 也会被幂等
撤销；Gateway 的 30 秒正缓存另有 35 秒 Artifact 回收保护窗。扩展可以从 `kookapp.cn` 当前路径
发起预览，但实际页面会导航到 `*.bifrost.vanillacake.cn`，不会在保持官网地址的同时替换响应。旧版
`/__cuddly/previews/<token>/v3/version/hot-module` 直连接口固定返回 `410`，避免旧扩展继续使用不完整
模块表；无效、过期或跨站点的 Preview Token 会明确返回 `404`，不会静默退回共享环境。

Preview 选中的 Remote 优先于公共环境；未选 Remote 始终保留官方接口返回值，不继承公共环境。
Remote Artifact 在被有效 Preview 或当前 Revision 引用时可通过
`/__cuddly/preview-artifacts/<artifactId>/...` 读取。已退出当前 Revision 且没有有效 Preview 的旧包
会按每分支一个最新候选的规则回收，因此历史 Revision 记录不等于可回滚的文件备份。
公共环境中的 Remote 也可以在分支下拉框中选择“官方热更（不覆盖）”并发布，从 Revision 中移除
该模块覆盖，不需要用另一个分支包反向覆盖。

构建队列默认允许 3 个不同项目并行执行，可在管理后台的“系统”页面调整。同一项目的任务
始终串行，后续任务会留在全局队列中，直到该项目的当前任务结束。

## 项目配置

管理后台可以配置每个打包项目的显示名称、Git 仓库地址、默认分支、安装命令、打包命令、产物目录、站点适配器、启用状态和发布必选状态。页面项目的预览域名、官网、接口上游、资源代理路径白名单及关联 Remote 也在同一个项目编辑区维护；一个页面项目仍可拥有多个站点绑定。

项目由内置模板或管理后台创建。Git 仓库、默认分支、构建命令与凭证只保存在数据库；恢复模板
会清空仓库和凭证。任务进入队列时会保存项目配置快照，后续修改不会改变已经排队或执行中的任务。

默认声明 `online-h5`、`webapp`、`biz` 以及 KOOK 当前 13 个 Remote 项目模板，均需在管理后台
补齐仓库后显式启用。Remote 模板默认从同一 Monorepo 中只安装对应 `apps/<module>` 的 workspace
依赖闭包，并构建 `apps/<module>/dist`。普通 QA 接口只返回名称、状态和默认分支；仓库地址与构建
命令只通过已解锁的管理接口读取。

## 管理口令

首次打开管理后台时，页面会要求设置第一个管理口令；不需要准备 `.env`。口令只以 Hash 形式
保存在数据库中，后续可在管理后台修改。普通 QA 功能不做鉴权；该口令只保护项目仓库、构建
命令、网关与代理等敏感配置。控制台提交的操作人名称仅用于队列展示和审计记录，不代表经过
认证的真实身份。

## 配置边界

日常配置全部由管理后台维护：

- 项目：仓库、分支、命令、产物目录、适配器、凭证与启用状态，以及页面项目下的预览域名、环境、官网、接口上游、资源代理路径白名单与关联 Remote 项目。
- 系统：公共服务地址、Cookie 域、并行度、超时、自动 SSL 与管理口令。
- 代理：启用状态、订阅链接和自动刷新周期。

Compose 中的数据库账号、服务地址、端口和磁盘路径属于单机部署内部连线，不是可变业务配置。
日常运行无需 `.env`；只有换用其它预览根域名时，Compose 与宿主 Nginx 安装器需要同时覆写
`CUDDLY_PREVIEW_BASE_DOMAIN`，它属于 DNS/Nginx 部署边界，不是管理后台中的业务配置。
