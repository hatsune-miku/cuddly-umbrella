import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto'
import { open, stat } from 'node:fs/promises'
import { isIP } from 'node:net'
import path from 'node:path'

import {
  adminUnlockSchema,
  adminSetupSchema,
  createBuildJobSchema,
  createPreviewSchema,
  publishRevisionSchema,
  resetProxySettingsSchema,
  saveBuildTargetSchema,
  saveSiteBindingSchema,
  siteBuildAdapters,
  updateSystemSettingsSchema,
  updateProxySettingsSchema,
  CHINA_NPM_REGISTRY,
  type BranchCatalogItem,
  type BuildCommandStep,
  type BuildJob,
  type BuildJobDetail,
  type BuildJobLogView,
  type BuildJobStatus,
  type BuildQueueItem,
  type BuildTarget,
  type BuildTargetSettingsView,
  type PreviewSession,
  type PreviewSessionView,
  type PreviewSelection,
  type SiteBinding,
} from '@cuddly/contracts'
import {
  type CuddlyStore,
  InvalidSelectionError,
  RevisionConflictError,
  resolveSystemSettings,
  SYSTEM_SETTING_KEYS,
  type RuntimeSettingChange,
} from '@cuddly/db'
import {
  createSessionToken,
  decryptSetting,
  encryptSetting,
  hashPassword,
  listRemoteBranches,
  readCookie,
  verifyPassword,
  verifySessionToken,
} from '@cuddly/domain'
import express, { type NextFunction, type Request, type Response } from 'express'

import type { ProxySettingsService } from './proxy-settings'

const ADMIN_COOKIE = 'cuddly_admin'
const ACTOR_HEADER = 'x-cuddly-actor'
const DEFAULT_PREVIEW_BASE_DOMAIN = 'bifrost.vanillacake.cn'

export interface ControlAppOptions {
  store: CuddlyStore
  adminSessionSecret: string
  internalApiToken: string
  proxySettings?: ProxySettingsService
  developmentAdminPassword?: string
  projectTemplates?: BuildTarget[]
  settingsSecret: string
  logDirectory?: string
  previewBaseDomain?: string
}

function publicTarget(target: BuildTarget) {
  return {
    id: target.id,
    name: target.name,
    kind: target.kind,
    defaultBranch: target.defaultBranch,
    enabled: target.enabled,
    required: target.required,
    configured: Boolean(target.repositoryUrl),
  }
}

function publicBuildJob(job: BuildJob): BuildJob {
  const targetSnapshot = job.targetSnapshot
    ? (({ gitAuthorization: _credential, ...snapshot }) => ({
        ...snapshot,
        repositoryUrl: '<repository>',
        installCommand: redactSensitiveText(snapshot.installCommand),
        buildCommand: redactSensitiveText(snapshot.buildCommand),
      }))(job.targetSnapshot)
    : null
  return {
    ...job,
    failureMessage: job.failureMessage ? redactSensitiveText(job.failureMessage) : null,
    logPath: job.logPath ? `/api/v1/build-jobs/${job.id}/log` : null,
    targetSnapshot,
  }
}

const terminalBuildStatuses = new Set<BuildJobStatus>(['SUCCEEDED', 'FAILED', 'CANCELED'])
const LOG_VIEW_MAX_BYTES = 1024 * 1024
const LOG_DOWNLOAD_MAX_BYTES = 8 * 1024 * 1024

function shellQuote(value: string): string {
  return `'${value.replaceAll("'", "'\\''")}'`
}

function redactSensitiveText(value: string): string {
  return value
    .replace(
      /-----BEGIN [^-\r\n]*PRIVATE KEY-----[\s\S]*?-----END [^-\r\n]*PRIVATE KEY-----/gi,
      '<redacted-private-key>'
    )
    .replace(/(authorization\s*[:=]\s*)(?:basic|bearer)\s+[^\s'"`]+/gi, '$1<redacted>')
    .replace(/(https?:\/\/)([^/\s:@]+):([^@\s/]+)@/gi, '$1<redacted>@')
    .replace(
      /\b([A-Z0-9_]*(?:TOKEN|PASSWORD|PASSWD|SECRET|PRIVATE_KEY|AUTHORIZATION|API_KEY|ACCESS_KEY|COOKIE)[A-Z0-9_]*)=([^\s]+)/gi,
      '$1=<redacted>'
    )
    .replace(/(--(?:token|password|secret|api-key|access-key)(?:=|\s+))[^\s'"`]+/gi, '$1<redacted>')
    .replace(/([?&](?:token|password|secret|key|authorization)=)[^&\s]+/gi, '$1<redacted>')
}

function buildCommandPlan(job: BuildJob): BuildCommandStep[] {
  if (!job.targetSnapshot) return []
  const registryEnvironment =
    job.targetSnapshot.useChinaRegistry === false
      ? ''
      : `npm_config_registry=${shellQuote(CHINA_NPM_REGISTRY)} COREPACK_NPM_REGISTRY=${shellQuote(CHINA_NPM_REGISTRY)} `
  const pnpmBuildEnvironment =
    /(?:^|[;&|()]\s*)(?:(?:[A-Za-z_][A-Za-z0-9_]*=\S+)\s+)*(?:corepack\s+)?pnpm(?:@[\w.-]+)?(?=$|\s|[;&|()])/i.test(
      job.targetSnapshot.installCommand
    )
      ? 'npm_config_dangerously_allow_all_builds=true pnpm_config_dangerously_allow_all_builds=true '
      : ''
  return [
    {
      stage: 'CHECKOUT',
      label: '拉取代码',
      command: `git clone --depth 1 --single-branch --branch ${shellQuote(job.branch)} <repository> source`,
    },
    {
      stage: 'INSTALLING',
      label: '安装依赖',
      command: `${registryEnvironment}${pnpmBuildEnvironment}${redactSensitiveText(job.targetSnapshot.installCommand)}`,
    },
    {
      stage: 'BUILDING',
      label: '执行构建',
      command: `${registryEnvironment}${redactSensitiveText(job.targetSnapshot.buildCommand)}`,
    },
    {
      stage: 'VALIDATING',
      label: '校验产物',
      command: `validate ${shellQuote(job.targetSnapshot.outputDirectory)}`,
    },
    {
      stage: 'UPLOADING',
      label: '保存产物',
      command: 'publish Artifact',
    },
  ]
}

async function readBuildLog(
  options: ControlAppOptions,
  job: BuildJob,
  maxBytes: number
): Promise<BuildJobLogView> {
  const logDirectory = options.logDirectory || path.resolve('data/logs')
  const logFile = path.join(logDirectory, `${job.id}.log`)
  try {
    const info = await stat(logFile)
    const start = Math.max(0, info.size - maxBytes)
    const length = info.size - start
    const buffer = Buffer.alloc(length)
    const handle = await open(logFile, 'r')
    try {
      await handle.read(buffer, 0, length, start)
    } finally {
      await handle.close()
    }
    let content = buffer.toString('utf8')
    if (start > 0) {
      const firstLine = content.indexOf('\n')
      if (firstLine >= 0) content = content.slice(firstLine + 1)
      content = `[日志过长，仅显示最后 ${Math.round(maxBytes / 1024)} KiB]\n${content}`
    }
    return {
      content: redactSensitiveText(content),
      size: info.size,
      complete: terminalBuildStatuses.has(job.status),
      truncated: start > 0,
      updatedAt: info.mtime.toISOString(),
    }
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
    return {
      content: '',
      size: 0,
      complete: terminalBuildStatuses.has(job.status),
      truncated: false,
      updatedAt: null,
    }
  }
}

function adminCookie(token: string, req: Request): string {
  const secure = req.secure || req.get('x-forwarded-proto') === 'https'
  return [
    `${ADMIN_COOKIE}=${encodeURIComponent(token)}`,
    'Path=/api/v1/admin',
    'HttpOnly',
    'SameSite=Strict',
    secure ? 'Secure' : '',
    'Max-Age=1800',
  ]
    .filter(Boolean)
    .join('; ')
}

async function checkAdminPassword(password: string, options: ControlAppOptions): Promise<boolean> {
  const stored = await options.store.getRuntimeSettings([SYSTEM_SETTING_KEYS.adminPasswordHash])
  const passwordHash = stored[0]?.value as string | undefined
  if (passwordHash) return verifyPassword(password, passwordHash)
  return Boolean(options.developmentAdminPassword && password === options.developmentAdminPassword)
}

async function adminPasswordConfigured(options: ControlAppOptions): Promise<boolean> {
  const stored = await options.store.getRuntimeSettings([SYSTEM_SETTING_KEYS.adminPasswordHash])
  return Boolean(stored[0]?.value || options.developmentAdminPassword)
}

function projectAuthorizationKey(targetId: string): string {
  return `project.${targetId}.git_authorization`
}

async function getProjectAuthorization(
  options: ControlAppOptions,
  targetId: string
): Promise<{ configured: boolean; encrypted?: ReturnType<typeof encryptSetting> }> {
  const record = (await options.store.getRuntimeSettings([projectAuthorizationKey(targetId)]))[0]
  if (!record) return { configured: false }
  return { configured: true, encrypted: record.value as ReturnType<typeof encryptSetting> }
}

function requestActor(req: Request): string {
  const value = req.get(ACTOR_HEADER)?.trim().replace(/\s+/g, ' ')
  return value ? value.slice(0, 40) : 'QA Operator'
}

function previewToken(): string {
  return randomBytes(24).toString('base64url')
}

function remoteVersion(providerName: string, branch: string): string {
  return providerName || branch
}

async function previewSessionView(
  options: ControlAppOptions,
  preview: PreviewSession
): Promise<PreviewSessionView> {
  const siteArtifact = preview.siteArtifactId
    ? await options.store.getArtifact(preview.siteArtifactId)
    : null
  return {
    ...preview,
    ...(siteArtifact
      ? {
          siteSelection: {
            targetId: siteArtifact.targetId,
            artifactId: siteArtifact.id,
            branch: siteArtifact.branch,
            builtAt: siteArtifact.builtAt,
          },
        }
      : {}),
  }
}

function requireAdmin(options: ControlAppOptions) {
  return (req: Request, res: Response, next: NextFunction) => {
    const token = readCookie(req.headers.cookie, ADMIN_COOKIE)
    const identity = token ? verifySessionToken(token, `${options.adminSessionSecret}:admin`) : null
    if (!identity) {
      res.status(403).json({ code: 'ADMIN_REQUIRED', message: '需要管理口令' })
      return
    }
    next()
  }
}

function requireInternalApi(options: ControlAppOptions) {
  const expectedDigest = createHash('sha256').update(options.internalApiToken).digest()
  return (req: Request, res: Response, next: NextFunction) => {
    const authorization = req.get('authorization')
    const match = authorization?.match(/^Bearer ([^\s]+)$/i)
    const actualDigest = createHash('sha256')
      .update(match?.[1] || '')
      .digest()
    if (!match || !timingSafeEqual(actualDigest, expectedDigest)) {
      res.setHeader('WWW-Authenticate', 'Bearer realm="cuddly-internal"')
      res.status(401).json({ code: 'INTERNAL_API_UNAUTHORIZED' })
      return
    }
    next()
  }
}

function mergeBranches(
  catalog: BranchCatalogItem[],
  remoteBranches: string[],
  query: string
): BranchCatalogItem[] {
  const byBranch = new Map(catalog.map((item) => [item.branch, item]))
  for (const branch of remoteBranches) {
    if (!byBranch.has(branch)) {
      byBranch.set(branch, {
        branch,
        buildStatus: 'IDLE',
        latestArtifact: null,
        latestJob: null,
      })
    }
  }
  const normalizedQuery = query.trim().toLowerCase()
  return [...byBranch.values()]
    .filter((item) => !normalizedQuery || item.branch.toLowerCase().includes(normalizedQuery))
    .sort((a, b) => {
      const aHasArtifact = a.latestArtifact ? 1 : 0
      const bHasArtifact = b.latestArtifact ? 1 : 0
      return bHasArtifact - aHasArtifact || a.branch.localeCompare(b.branch)
    })
}

function normalizeRequestHostname(value: string): string {
  const trimmed = value.trim()
  try {
    return new URL(`http://${trimmed}`).hostname.toLowerCase().replace(/\.$/, '')
  } catch {
    return trimmed.toLowerCase().replace(/\.$/, '').replace(/:\d+$/, '')
  }
}

function normalizeRequestOrigin(value: string): string | null {
  try {
    const url = new URL(value.trim())
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return null
    return url.origin
  } catch {
    return null
  }
}

function normalizePreviewBaseDomain(value: string | undefined): string {
  const baseDomain = (value || DEFAULT_PREVIEW_BASE_DOMAIN).trim().toLowerCase().replace(/\.$/, '')
  const labels = baseDomain.split('.')
  if (
    baseDomain.length > 253 ||
    labels.length < 2 ||
    isIP(baseDomain) !== 0 ||
    !labels.every((label) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label))
  ) {
    throw new Error(`Preview base domain is invalid: ${value || ''}`)
  }
  return baseDomain
}

function isDirectPreviewSubdomain(hostname: string, previewBaseDomain: string): boolean {
  const suffix = `.${previewBaseDomain}`
  if (!hostname.endsWith(suffix)) return false
  const siteLabel = hostname.slice(0, -suffix.length)
  return siteLabel.length > 0 && !siteLabel.includes('.')
}

async function validateSiteBinding(
  options: ControlAppOptions,
  binding: SiteBinding,
  previewBaseDomain: string
): Promise<{ code: string; message: string } | null> {
  if (!isDirectPreviewSubdomain(binding.hostname, previewBaseDomain)) {
    return {
      code: 'SITE_BINDING_HOSTNAME_OUTSIDE_PREVIEW_DOMAIN',
      message: `预览域名必须是 ${previewBaseDomain} 的直接一级子域名，例如 main.${previewBaseDomain}`,
    }
  }
  const [target, environment, bindings] = await Promise.all([
    options.store.getBuildTarget(binding.targetId),
    options.store.getEnvironment(binding.environmentSlug),
    options.store.listSiteBindings(true),
  ])
  const remoteTargets = await Promise.all(
    binding.remoteTargetIds.map((targetId) => options.store.getBuildTarget(targetId))
  )

  if (
    !target ||
    target.kind === 'remote' ||
    !target.enabled ||
    !siteBuildAdapters.includes(target.siteAdapter as (typeof siteBuildAdapters)[number])
  ) {
    return {
      code: 'SITE_BINDING_TARGET_INVALID',
      message: '站点壳项目必须已启用，并使用受支持的站点适配器',
    }
  }
  if (!environment || (binding.enabled && environment.status !== 'ACTIVE')) {
    return {
      code: 'SITE_BINDING_ENVIRONMENT_INVALID',
      message: '站点环境不存在，或不是可用的活动环境',
    }
  }
  for (let index = 0; index < remoteTargets.length; index += 1) {
    const remote = remoteTargets[index]
    if (
      !remote ||
      remote.kind !== 'remote' ||
      remote.siteAdapter !== 'kook-remote-v1' ||
      (binding.enabled && !remote.enabled)
    ) {
      return {
        code: 'SITE_BINDING_REMOTE_TARGET_INVALID',
        message: `${binding.remoteTargetIds[index]} 不是可用的 Remote 项目`,
      }
    }
  }
  const hostnameConflict = bindings.find(
    (candidate) => candidate.id !== binding.id && candidate.hostname === binding.hostname
  )
  if (hostnameConflict) {
    return {
      code: 'SITE_BINDING_HOSTNAME_CONFLICT',
      message: `预览域名已由 ${hostnameConflict.name} 使用`,
    }
  }
  const officialOriginConflict = bindings.find(
    (candidate) =>
      candidate.id !== binding.id && candidate.officialOrigin === binding.officialOrigin
  )
  if (officialOriginConflict) {
    return {
      code: 'SITE_BINDING_OFFICIAL_ORIGIN_CONFLICT',
      message: `官方站点已由 ${officialOriginConflict.name} 绑定`,
    }
  }
  return null
}

export function createControlApp(options: ControlAppOptions) {
  const app = express()
  const previewBaseDomain = normalizePreviewBaseDomain(options.previewBaseDomain)
  const remoteBranchCache = new Map<
    string,
    {
      branches: string[]
      expiresAt: number
      pending?: Promise<string[]>
    }
  >()

  async function cachedRemoteBranches(
    targetId: string,
    repositoryUrl: string,
    authorizationHeader?: string
  ): Promise<string[]> {
    const source = createHash('sha256')
      .update(repositoryUrl)
      .update('\0')
      .update(authorizationHeader || '')
      .digest('hex')
    const cached = remoteBranchCache.get(source)
    if (cached && cached.expiresAt > Date.now()) return cached.branches
    if (cached?.pending) return cached.pending

    const previous = cached?.branches || []
    let pending: Promise<string[]>
    pending = listRemoteBranches(repositoryUrl, authorizationHeader)
      .then((branches) => {
        if (remoteBranchCache.get(source)?.pending === pending) {
          remoteBranchCache.set(source, {
            branches,
            expiresAt: Date.now() + 60_000,
          })
        }
        return branches
      })
      .catch((error) => {
        console.warn(
          `[control-api] failed to list remote branches for ${targetId}:`,
          error instanceof Error ? error.message : error
        )
        if (remoteBranchCache.get(source)?.pending === pending) {
          remoteBranchCache.set(source, {
            branches: previous,
            expiresAt: Date.now() + 15_000,
          })
        }
        return previous
      })
    remoteBranchCache.set(source, {
      branches: previous,
      expiresAt: 0,
      pending,
    })
    return pending
  }

  app.disable('x-powered-by')
  app.set('trust proxy', true)
  app.use('/api/v1/internal', requireInternalApi(options))
  app.use((req, res, next) => {
    const origin = req.get('origin')
    if (origin?.startsWith('chrome-extension://')) {
      res.setHeader('Access-Control-Allow-Origin', origin)
      res.setHeader('Vary', 'Origin')
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS')
      res.setHeader('Access-Control-Allow-Headers', 'content-type, idempotency-key, x-cuddly-actor')
      if (req.method === 'OPTIONS') {
        res.status(204).end()
        return
      }
    }
    next()
  })
  app.use(express.json({ limit: '1mb' }))

  app.get('/health/live', (_req, res) => res.json({ ok: true }))
  app.get('/health/ready', async (_req, res) => {
    await options.store.listBuildTargets()
    res.json({ ok: true })
  })

  app.get('/api/v1/admin/setup-status', async (_req, res) => {
    res.json({ setupRequired: !(await adminPasswordConfigured(options)) })
  })

  app.post('/api/v1/admin/setup', async (req, res) => {
    if (await adminPasswordConfigured(options)) {
      res.status(409).json({ code: 'ADMIN_ALREADY_CONFIGURED' })
      return
    }
    const parsed = adminSetupSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_REQUEST', issues: parsed.error.issues })
      return
    }
    await options.store.updateRuntimeSettings(
      [
        {
          key: SYSTEM_SETTING_KEYS.adminPasswordHash,
          value: await hashPassword(parsed.data.password),
        },
      ],
      requestActor(req)
    )
    const token = createSessionToken('admin', `${options.adminSessionSecret}:admin`, 30 * 60)
    res.setHeader('Set-Cookie', adminCookie(token, req))
    res.status(201).json({ configured: true })
  })

  app.post('/api/v1/admin/unlock', async (req, res) => {
    const parsed = adminUnlockSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_REQUEST', issues: parsed.error.issues })
      return
    }
    if (!(await checkAdminPassword(parsed.data.password, options))) {
      res.status(403).json({ code: 'INVALID_ADMIN_CREDENTIALS', message: '管理口令不正确' })
      return
    }
    const token = createSessionToken('admin', `${options.adminSessionSecret}:admin`, 30 * 60)
    res.setHeader('Set-Cookie', adminCookie(token, req))
    res.json({ unlocked: true })
  })

  app.use('/api/v1/admin', requireAdmin(options))

  app.get('/api/v1/admin/proxy-settings', async (_req, res) => {
    if (!options.proxySettings) {
      res.status(503).json({ code: 'PROXY_SETTINGS_UNAVAILABLE' })
      return
    }
    res.json(await options.proxySettings.getView())
  })

  app.patch('/api/v1/admin/proxy-settings', async (req, res) => {
    if (!options.proxySettings) {
      res.status(503).json({ code: 'PROXY_SETTINGS_UNAVAILABLE' })
      return
    }
    const parsed = updateProxySettingsSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_REQUEST', issues: parsed.error.issues })
      return
    }
    try {
      res.json(await options.proxySettings.update(parsed.data, requestActor(req)))
    } catch (error) {
      res.status(400).json({
        code: 'PROXY_APPLY_FAILED',
        message: error instanceof Error ? error.message : '代理配置应用失败',
      })
    }
  })

  app.post('/api/v1/admin/proxy-settings/reset', async (req, res) => {
    if (!options.proxySettings) {
      res.status(503).json({ code: 'PROXY_SETTINGS_UNAVAILABLE' })
      return
    }
    const parsed = resetProxySettingsSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_REQUEST', issues: parsed.error.issues })
      return
    }
    try {
      res.json(await options.proxySettings.reset(parsed.data.keys, requestActor(req)))
    } catch (error) {
      res.status(400).json({
        code: 'PROXY_APPLY_FAILED',
        message: error instanceof Error ? error.message : '代理配置应用失败',
      })
    }
  })

  app.post('/api/v1/admin/proxy-settings/refresh', async (_req, res) => {
    if (!options.proxySettings) {
      res.status(503).json({ code: 'PROXY_SETTINGS_UNAVAILABLE' })
      return
    }
    try {
      res.json(await options.proxySettings.refresh())
    } catch (error) {
      res.status(400).json({
        code: 'PROXY_APPLY_FAILED',
        message: error instanceof Error ? error.message : '代理配置刷新失败',
      })
    }
  })

  app.get('/api/v1/admin/build-targets', async (_req, res) => {
    const defaults = new Set((options.projectTemplates || []).map((target) => target.id))
    const items: BuildTargetSettingsView[] = await Promise.all(
      (await options.store.listBuildTargets(true)).map(async (target) => ({
        ...target,
        canReset: defaults.has(target.id),
        gitAuthorizationConfigured: (await getProjectAuthorization(options, target.id)).configured,
      }))
    )
    res.json({ items })
  })

  app.put('/api/v1/admin/build-targets/:targetId', async (req, res) => {
    const parsed = saveBuildTargetSchema.safeParse({ ...req.body, id: req.params.targetId })
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_PROJECT', issues: parsed.error.issues })
      return
    }
    const input = parsed.data
    const { gitAuthorizationHeader, clearGitAuthorizationHeader, ...projectInput } = input
    const authorizationKey = projectAuthorizationKey(input.id)
    if (clearGitAuthorizationHeader) {
      await options.store.updateRuntimeSettings(
        [{ key: authorizationKey, value: null }],
        requestActor(req)
      )
    } else if (gitAuthorizationHeader) {
      await options.store.updateRuntimeSettings(
        [
          {
            key: authorizationKey,
            value: encryptSetting(gitAuthorizationHeader, options.settingsSecret),
          },
        ],
        requestActor(req)
      )
    }
    const saved = await options.store.saveBuildTarget(
      {
        ...projectInput,
        repositoryUrl: projectInput.repositoryUrl || null,
        configurationSource: 'database',
      },
      requestActor(req)
    )
    remoteBranchCache.delete(saved.id)
    res.json({
      ...saved,
      canReset: (options.projectTemplates || []).some((item) => item.id === saved.id),
      gitAuthorizationConfigured: (await getProjectAuthorization(options, saved.id)).configured,
    })
  })

  app.post('/api/v1/admin/build-targets/:targetId/reset', async (req, res) => {
    const target = (options.projectTemplates || []).find((item) => item.id === req.params.targetId)
    if (!target) {
      res.status(404).json({ code: 'PROJECT_DEFAULT_NOT_FOUND', message: '这个项目没有内置模板' })
      return
    }
    await options.store.updateRuntimeSettings(
      [{ key: projectAuthorizationKey(target.id), value: null }],
      requestActor(req)
    )
    const saved = await options.store.saveBuildTarget(target, requestActor(req))
    remoteBranchCache.delete(saved.id)
    res.json({ ...saved, canReset: true, gitAuthorizationConfigured: false })
  })

  app.get('/api/v1/admin/site-bindings', async (_req, res) => {
    res.json({ items: await options.store.listSiteBindings(true) })
  })

  app.get('/api/v1/admin/site-bindings/:siteBindingId', async (req, res) => {
    const binding = await options.store.getSiteBinding(req.params.siteBindingId)
    if (!binding) {
      res.status(404).json({ code: 'SITE_BINDING_NOT_FOUND' })
      return
    }
    res.json(binding)
  })

  app.put('/api/v1/admin/site-bindings/:siteBindingId', async (req, res) => {
    const parsed = saveSiteBindingSchema.safeParse({
      ...req.body,
      id: req.params.siteBindingId,
    })
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_SITE_BINDING', issues: parsed.error.issues })
      return
    }
    const validationError = await validateSiteBinding(options, parsed.data, previewBaseDomain)
    if (validationError) {
      res.status(validationError.code.endsWith('_CONFLICT') ? 409 : 400).json(validationError)
      return
    }
    res.json(await options.store.saveSiteBinding(parsed.data, requestActor(req)))
  })

  app.delete('/api/v1/admin/site-bindings/:siteBindingId', async (req, res) => {
    const deleted = await options.store.deleteSiteBinding(
      req.params.siteBindingId,
      requestActor(req)
    )
    if (!deleted) {
      res.status(404).json({ code: 'SITE_BINDING_NOT_FOUND' })
      return
    }
    res.status(204).end()
  })

  app.get('/api/v1/admin/system-settings', async (_req, res) => {
    res.json(await resolveSystemSettings(options.store))
  })

  app.patch('/api/v1/admin/system-settings', async (req, res) => {
    const parsed = updateSystemSettingsSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_SETTINGS', issues: parsed.error.issues })
      return
    }
    const input = parsed.data
    const changes: RuntimeSettingChange[] = []
    if (input.mobileUpstream !== undefined) {
      changes.push({ key: SYSTEM_SETTING_KEYS.mobileUpstream, value: input.mobileUpstream })
    }
    if (input.publicMobileOrigin !== undefined) {
      changes.push({ key: SYSTEM_SETTING_KEYS.publicMobileOrigin, value: input.publicMobileOrigin })
    }
    if (input.webappUpstream !== undefined) {
      changes.push({ key: SYSTEM_SETTING_KEYS.webappUpstream, value: input.webappUpstream })
    }
    if (input.publicPreviewOrigin !== undefined) {
      changes.push({
        key: SYSTEM_SETTING_KEYS.publicPreviewOrigin,
        value: input.publicPreviewOrigin,
      })
    }
    if (input.mobileHostnames !== undefined) {
      changes.push({ key: SYSTEM_SETTING_KEYS.mobileHostnames, value: input.mobileHostnames })
    }
    if (input.cookieDomain !== undefined) {
      changes.push({ key: SYSTEM_SETTING_KEYS.cookieDomain, value: input.cookieDomain })
    }
    if (input.buildMaxConcurrency !== undefined) {
      changes.push({
        key: SYSTEM_SETTING_KEYS.buildMaxConcurrency,
        value: input.buildMaxConcurrency,
      })
    }
    if (input.runnerRequestTimeoutMinutes !== undefined) {
      changes.push({
        key: SYSTEM_SETTING_KEYS.runnerRequestTimeoutMinutes,
        value: input.runnerRequestTimeoutMinutes,
      })
    }
    if (input.useChinaRegistry !== undefined) {
      changes.push({
        key: SYSTEM_SETTING_KEYS.useChinaRegistry,
        value: input.useChinaRegistry,
      })
    }
    if (input.proxyRewriteMaxMegabytes !== undefined) {
      changes.push({
        key: SYSTEM_SETTING_KEYS.proxyRewriteMaxMegabytes,
        value: input.proxyRewriteMaxMegabytes,
      })
    }
    if (input.autoSslEnabled !== undefined) {
      changes.push({
        key: SYSTEM_SETTING_KEYS.autoSslEnabled,
        value: input.autoSslEnabled,
      })
    }
    if (input.autoSslEmail !== undefined) {
      changes.push({
        key: SYSTEM_SETTING_KEYS.autoSslEmail,
        value: input.autoSslEmail,
      })
    }
    if (input.newAdminPassword !== undefined) {
      changes.push({
        key: SYSTEM_SETTING_KEYS.adminPasswordHash,
        value: await hashPassword(input.newAdminPassword),
      })
    }
    await options.store.updateRuntimeSettings(changes, requestActor(req))
    res.json(await resolveSystemSettings(options.store))
  })

  app.get('/api/v1/internal/auto-ssl-config', async (_req, res) => {
    const [settings, bindings] = await Promise.all([
      resolveSystemSettings(options.store),
      options.store.listSiteBindings(),
    ])
    res.setHeader('Cache-Control', 'no-store')
    res.json({
      autoSslEnabled: settings.autoSslEnabled,
      autoSslEmail: settings.autoSslEmail,
      hostnames: bindings.map((binding) => binding.hostname),
    })
  })

  app.get('/api/v1/build-targets', async (_req, res) => {
    res.json({ items: (await options.store.listBuildTargets(true)).map(publicTarget) })
  })

  app.get('/api/v1/build-targets/:targetId/branches', async (req, res) => {
    const target = await options.store.getBuildTarget(req.params.targetId)
    if (!target) {
      res.status(404).json({ code: 'TARGET_NOT_FOUND' })
      return
    }
    const catalog = await options.store.listBranchCatalog(target.id)
    let remoteBranches: string[] = []
    const repositoryUrl = target.repositoryUrl
    if (repositoryUrl) {
      const authorization = await getProjectAuthorization(options, target.id)
      remoteBranches = await cachedRemoteBranches(
        target.id,
        repositoryUrl,
        authorization.encrypted
          ? decryptSetting(authorization.encrypted, options.settingsSecret)
          : undefined
      )
    }
    res.json({
      items: mergeBranches(catalog, remoteBranches, String(req.query.query || '')),
      remoteAvailable: remoteBranches.length > 0,
    })
  })

  app.post('/api/v1/build-jobs', async (req, res) => {
    const parsed = createBuildJobSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_REQUEST', issues: parsed.error.issues })
      return
    }
    const target = await options.store.getBuildTarget(parsed.data.targetId)
    if (!target?.enabled) {
      res.status(404).json({ code: 'TARGET_NOT_FOUND' })
      return
    }
    if (!target.repositoryUrl) {
      res.status(409).json({ code: 'TARGET_NOT_CONFIGURED', message: '项目没有配置 Git 仓库地址' })
      return
    }
    const idempotencyKey = req.headers['idempotency-key']
    const systemSettings = await resolveSystemSettings(options.store)
    const job = await options.store.createBuildJob({
      id: randomUUID(),
      targetId: parsed.data.targetId,
      branch: parsed.data.branch,
      profile: parsed.data.profile,
      requestedBy: requestActor(req),
      idempotencyKey: typeof idempotencyKey === 'string' ? idempotencyKey : null,
      targetSnapshot: {
        id: target.id,
        kind: target.kind,
        repositoryUrl: target.repositoryUrl,
        installCommand: target.installCommand,
        buildCommand: target.buildCommand,
        outputDirectory: target.outputDirectory,
        siteAdapter: target.siteAdapter,
        useChinaRegistry: systemSettings.useChinaRegistry,
        gitAuthorization: (await getProjectAuthorization(options, target.id)).encrypted,
      },
    })
    res.status(202).json(publicBuildJob(job))
  })

  app.get('/api/v1/build-jobs', async (req, res) => {
    const targetId = typeof req.query.targetId === 'string' ? req.query.targetId : undefined
    const status = typeof req.query.status === 'string' ? req.query.status : ''
    const query = typeof req.query.query === 'string' ? req.query.query.trim().toLowerCase() : ''
    const before = typeof req.query.before === 'string' ? req.query.before : ''
    const requestedLimit = Number(req.query.limit || 50)
    const limit = Number.isFinite(requestedLimit)
      ? Math.min(100, Math.max(1, Math.floor(requestedLimit)))
      : 50
    const jobs = (await options.store.listBuildJobs(targetId))
      .filter((job) => !status || job.status === status)
      .filter((job) => !before || job.createdAt < before)
      .filter(
        (job) =>
          !query ||
          job.id.toLowerCase().includes(query) ||
          job.branch.toLowerCase().includes(query) ||
          job.requestedBy.toLowerCase().includes(query)
      )
      .slice(0, limit)
    res.json({
      items: jobs.map(publicBuildJob),
      nextCursor: jobs.length === limit ? jobs.at(-1)?.createdAt || null : null,
    })
  })

  app.get('/api/v1/build-queue', async (req, res) => {
    const jobs = await options.store.listBuildQueue()
    let queuePosition = 0
    const items: BuildQueueItem[] = jobs.map((job) => {
      const queued = job.status === 'QUEUED'
      if (queued) queuePosition += 1
      return {
        id: job.id,
        targetId: job.targetId,
        branch: job.branch,
        status: job.status,
        requestedBy: job.requestedBy,
        createdAt: job.createdAt,
        startedAt: job.startedAt,
        queuePosition: queued ? queuePosition : null,
        isMine: job.requestedBy === requestActor(req),
      }
    })
    res.json({
      running: items.filter((item) => item.status !== 'QUEUED'),
      queued: items.filter((item) => item.status === 'QUEUED'),
      generatedAt: new Date().toISOString(),
    })
  })

  app.get('/api/v1/build-jobs/:jobId', async (req, res) => {
    const job = await options.store.getBuildJob(req.params.jobId)
    if (!job) {
      res.status(404).json({ code: 'JOB_NOT_FOUND' })
      return
    }
    res.json(publicBuildJob(job))
  })

  app.get('/api/v1/build-jobs/:jobId/detail', async (req, res) => {
    const job = await options.store.getBuildJob(req.params.jobId)
    if (!job) {
      res.status(404).json({ code: 'JOB_NOT_FOUND' })
      return
    }
    const [events, artifact] = await Promise.all([
      options.store.listBuildJobEvents(job.id),
      options.store.getArtifactByBuildJobId(job.id),
    ])
    const detail: BuildJobDetail = {
      job: publicBuildJob(job),
      commands: buildCommandPlan(job),
      events,
      artifact: artifact
        ? {
            id: artifact.id,
            status: artifact.status,
            builtAt: artifact.builtAt,
            fileCount: artifact.manifest.files.length,
            entrypoints: artifact.manifest.serve.entrypoints,
            publicBase: redactSensitiveText(artifact.manifest.serve.publicBase),
          }
        : null,
    }
    res.setHeader('Cache-Control', 'no-store')
    res.json(detail)
  })

  app.get('/api/v1/build-jobs/:jobId/log', async (req, res) => {
    const job = await options.store.getBuildJob(req.params.jobId)
    if (!job) {
      res.status(404).json({ code: 'JOB_NOT_FOUND' })
      return
    }
    const download = req.query.download === '1'
    const log = await readBuildLog(
      options,
      job,
      download ? LOG_DOWNLOAD_MAX_BYTES : LOG_VIEW_MAX_BYTES
    )
    res.setHeader('Cache-Control', 'no-store')
    if (download) {
      res.setHeader('Content-Disposition', `attachment; filename="${job.id}.sanitized.log"`)
      res.type('text/plain').send(log.content)
      return
    }
    res.json(log)
  })

  app.get('/api/v1/artifacts', async (req, res) => {
    const targetId = String(req.query.targetId || '')
    if (!targetId) {
      res.status(400).json({ code: 'TARGET_REQUIRED' })
      return
    }
    const branch = typeof req.query.branch === 'string' ? req.query.branch : undefined
    res.json({ items: await options.store.listArtifacts(targetId, branch) })
  })

  app.get('/api/v1/environments/:environmentId/matrix', async (req, res) => {
    const environmentId = String(req.params.environmentId || '')
    const matrix = await options.store.getEnvironmentMatrix(environmentId)
    if (!matrix) {
      res.status(404).json({ code: 'ENVIRONMENT_NOT_FOUND' })
      return
    }
    res.json(matrix)
  })

  app.get('/api/v1/site-bindings/resolve', async (req, res) => {
    const hostname = typeof req.query.hostname === 'string' ? req.query.hostname.trim() : ''
    const officialOrigin =
      typeof req.query.officialOrigin === 'string' ? req.query.officialOrigin.trim() : ''
    if ((!hostname && !officialOrigin) || (hostname && officialOrigin)) {
      res.status(400).json({
        code: 'SITE_BINDING_LOOKUP_INVALID',
        message: '必须且只能提供 hostname 或 officialOrigin',
      })
      return
    }

    let binding: SiteBinding | null
    if (hostname) {
      binding = await options.store.getSiteBindingByHostname(normalizeRequestHostname(hostname))
    } else {
      const normalizedOrigin = normalizeRequestOrigin(officialOrigin)
      if (!normalizedOrigin) {
        res.status(400).json({ code: 'SITE_BINDING_ORIGIN_INVALID' })
        return
      }
      binding = await options.store.getSiteBindingByOfficialOrigin(normalizedOrigin)
    }
    if (!binding) {
      res.status(404).json({ code: 'SITE_BINDING_NOT_FOUND' })
      return
    }
    res.json(binding)
  })

  app.get('/api/v1/runtime', async (_req, res) => {
    const settings = await resolveSystemSettings(options.store)
    res.json({
      mobileEnvironmentUrl: settings.publicMobileOrigin,
      previewOrigin: settings.publicPreviewOrigin,
      previewBaseDomain,
      webappOrigin: settings.webappUpstream,
    })
  })

  app.get('/api/v1/previews/:token', async (req, res) => {
    const preview = await options.store.getPreviewSession(req.params.token)
    if (!preview) {
      res.status(404).json({ code: 'PREVIEW_NOT_FOUND' })
      return
    }
    res.setHeader('Cache-Control', 'no-store')
    res.json(await previewSessionView(options, preview))
  })

  app.delete('/api/v1/previews/:token', async (req, res) => {
    await options.store.revokePreviewSession(req.params.token)
    res.status(204).end()
  })

  app.post('/api/v1/previews', async (req, res) => {
    const parsed = createPreviewSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_REQUEST', issues: parsed.error.issues })
      return
    }

    const siteBinding = parsed.data.siteBindingId
      ? await options.store.getSiteBinding(parsed.data.siteBindingId)
      : null
    if (parsed.data.siteBindingId && !siteBinding?.enabled) {
      res.status(400).json({
        code: 'PREVIEW_SITE_BINDING_INVALID',
        message: '所选站点绑定不存在或已停用',
      })
      return
    }

    if (parsed.data.siteArtifactId) {
      const [siteTarget, siteArtifact] = await Promise.all([
        options.store.getBuildTarget(siteBinding!.targetId),
        options.store.getArtifact(parsed.data.siteArtifactId),
      ])
      if (
        !siteTarget?.enabled ||
        siteTarget.kind === 'remote' ||
        !siteBuildAdapters.includes(siteTarget.siteAdapter as (typeof siteBuildAdapters)[number])
      ) {
        res.status(400).json({
          code: 'PREVIEW_SITE_TARGET_INVALID',
          message: '站点绑定的壳项目不可用',
        })
        return
      }
      if (
        !siteArtifact ||
        siteArtifact.status !== 'READY' ||
        siteArtifact.targetId !== siteBinding!.targetId ||
        siteArtifact.manifest.serve.siteAdapter !== siteTarget.siteAdapter ||
        siteArtifact.manifest.serve.remote
      ) {
        res.status(400).json({
          code: 'PREVIEW_SITE_ARTIFACT_INVALID',
          message: '所选产物不是这个站点可用的壳 Artifact',
        })
        return
      }
    }

    const seenTargets = new Set<string>()
    const selections: PreviewSelection[] = []
    for (const requested of parsed.data.selections) {
      if (seenTargets.has(requested.targetId)) {
        res.status(400).json({
          code: 'DUPLICATE_PREVIEW_TARGET',
          message: `预览中重复选择了 ${requested.targetId}`,
        })
        return
      }
      seenTargets.add(requested.targetId)

      if (siteBinding && !siteBinding.remoteTargetIds.includes(requested.targetId)) {
        res.status(400).json({
          code: 'PREVIEW_REMOTE_NOT_ALLOWED',
          message: `${requested.targetId} 不属于 ${siteBinding.name} 的热更项目`,
        })
        return
      }

      const [target, artifact] = await Promise.all([
        options.store.getBuildTarget(requested.targetId),
        options.store.getArtifact(requested.artifactId),
      ])
      if (!target?.enabled || target.kind !== 'remote') {
        res.status(400).json({
          code: 'PREVIEW_TARGET_NOT_REMOTE',
          message: `${requested.targetId} 不是已启用的 Remote 项目`,
        })
        return
      }
      if (
        !artifact ||
        artifact.status !== 'READY' ||
        artifact.targetId !== target.id ||
        artifact.manifest.serve.siteAdapter !== 'kook-remote-v1' ||
        !artifact.manifest.serve.remote
      ) {
        res.status(400).json({
          code: 'PREVIEW_ARTIFACT_INVALID',
          message: `${target.name} 所选产物不是可用的 Remote Artifact`,
        })
        return
      }
      const remote = artifact.manifest.serve.remote
      if (remote.moduleKey !== target.id) {
        res.status(400).json({
          code: 'PREVIEW_MODULE_MISMATCH',
          message: `${target.name} 的 Artifact 模块标识与项目不一致`,
        })
        return
      }
      selections.push({
        moduleKey: remote.moduleKey,
        targetId: target.id,
        artifactId: artifact.id,
        branch: artifact.branch,
        builtAt: artifact.builtAt,
        providerName: remote.providerName,
        version: remoteVersion(remote.providerName, artifact.branch),
        entryPath: remote.entryPath,
      })
    }

    const token = previewToken()
    let created: PreviewSession
    try {
      created = await options.store.createPreviewSession({
        token,
        createdBy: requestActor(req),
        expiresAt: new Date(Date.now() + parsed.data.ttlMinutes * 60_000).toISOString(),
        siteBindingId: siteBinding?.id,
        siteArtifactId: parsed.data.siteArtifactId,
        selections,
      })
    } catch (error) {
      if (error instanceof InvalidSelectionError) {
        res.status(409).json({
          code: 'PREVIEW_ARTIFACT_CHANGED',
          message: '所选产物已被更新，请刷新后重新选择',
        })
        return
      }
      throw error
    }
    res.status(201).json(await previewSessionView(options, created))
  })

  app.post('/api/v1/environments/:environmentId/revisions', async (req, res) => {
    const environmentId = String(req.params.environmentId || '')
    const parsed = publishRevisionSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_REQUEST', issues: parsed.error.issues })
      return
    }
    try {
      const revision = await options.store.publishRevision({
        environmentId,
        baseRevisionId: parsed.data.baseRevisionId,
        message: parsed.data.message,
        createdBy: requestActor(req),
        selections: parsed.data.selections,
      })
      res.status(201).json(revision)
    } catch (error) {
      if (error instanceof RevisionConflictError) {
        res.status(409).json({
          code: 'REVISION_CONFLICT',
          currentRevisionId: error.currentRevisionId,
          matrix: await options.store.getEnvironmentMatrix(environmentId),
        })
        return
      }
      if (error instanceof InvalidSelectionError) {
        res.status(400).json({ code: 'INVALID_SELECTION', message: error.message })
        return
      }
      throw error
    }
  })

  app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
    console.error('[control-api] request failed', error)
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: error instanceof Error ? error.message : '服务器处理失败',
    })
  })

  return app
}
