import { randomUUID } from 'node:crypto'

import type { Artifact, BuildJob, RunnerArtifactInventoryItem } from '@cuddly/contracts'
import { MemoryStore } from '@cuddly/db'
import { describe, expect, it, vi } from 'vitest'

import {
  BuildWorker,
  cleanupSupersededArtifacts,
  maintainArtifacts,
  reconcileOrphanArtifacts,
} from './worker'

function artifact(input: { targetId: string; branch: string; builtAt: string }): Artifact {
  const id = randomUUID()
  return {
    id,
    buildJobId: randomUUID(),
    targetId: input.targetId,
    branch: input.branch,
    status: 'READY',
    storageKey: `ready/${input.targetId}/${id}`,
    builtAt: input.builtAt,
    createdBy: 'gz',
    manifest: {
      schemaVersion: 1,
      artifactId: id,
      target: input.targetId,
      branch: input.branch,
      builtAt: input.builtAt,
      serve: {
        siteAdapter: 'generic-static-v1',
        entrypoints: ['index.html'],
        publicBase: `/__cuddly/artifacts/${id}/`,
      },
      files: [
        {
          path: 'index.html',
          size: 1,
          contentType: 'text/html',
          digest: 'sha256:test',
          cacheClass: 'html',
        },
      ],
    },
  }
}

function inventoryResponse(artifacts: RunnerArtifactInventoryItem[]): Response {
  return new Response(JSON.stringify({ artifacts }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })
}

describe('BuildWorker concurrency', () => {
  it('fills execution slots with jobs from different projects', async () => {
    const store = new MemoryStore()
    await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/mobile',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    await store.createBuildJob({
      id: randomUUID(),
      targetId: 'webapp',
      branch: 'feature/web',
      profile: 'qa-web',
      requestedBy: 'qa-two',
      idempotencyKey: null,
      targetSnapshot: null,
    })

    const started = new Set<string>()
    const releases = new Map<string, () => void>()
    let resolveBothStarted: () => void = () => undefined
    const bothStarted = new Promise<void>((resolve) => {
      resolveBothStarted = resolve
    })
    const processJob = async (job: BuildJob) => {
      started.add(job.targetId)
      if (started.size === 2) resolveBothStarted()
      await new Promise<void>((resolve) => releases.set(job.id, resolve))
      return true
    }
    const worker = new BuildWorker(
      {
        store,
        runnerUrl: 'http://runner.test',
        runnerToken: 'test-token',
        workerId: 'worker-1',
        requestTimeoutMs: 1000,
        maxConcurrency: 2,
        fetchImpl: async () => inventoryResponse([]),
      },
      processJob
    )

    const run = worker.run(5)
    await Promise.race([
      bothStarted,
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('worker did not start both projects')), 1000)
      ),
    ])

    expect([...started].sort()).toEqual(['online-h5', 'webapp'])
    worker.stop()
    releases.forEach((release) => release())
    await run
  })

  it('does not count a single-flight maintenance sweep against build execution slots', async () => {
    const store = new MemoryStore()
    const first = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/first',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const second = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'webapp',
      branch: 'feature/second',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    let announceInventoryStarted: () => void = () => undefined
    const inventoryStarted = new Promise<void>((resolve) => {
      announceInventoryStarted = resolve
    })
    let releaseInventory: () => void = () => undefined
    const inventoryReleased = new Promise<void>((resolve) => {
      releaseInventory = resolve
    })
    let announceSecondStarted: () => void = () => undefined
    const secondStarted = new Promise<void>((resolve) => {
      announceSecondStarted = resolve
    })
    let releaseSecond: () => void = () => undefined
    const secondReleased = new Promise<void>((resolve) => {
      releaseSecond = resolve
    })
    const worker = new BuildWorker(
      {
        store,
        runnerUrl: 'http://runner.test',
        runnerToken: 'runner-token',
        workerId: 'worker-1',
        requestTimeoutMs: 1000,
        maxConcurrency: 1,
        fetchImpl: async (_input, init) => {
          expect(init?.method).toBe('GET')
          announceInventoryStarted()
          await inventoryReleased
          return inventoryResponse([])
        },
      },
      async (job) => {
        if (job.id === first.id) {
          await inventoryStarted
          return true
        }
        expect(job.id).toBe(second.id)
        announceSecondStarted()
        await secondReleased
        return false
      }
    )

    const run = worker.run(5)
    await Promise.race([
      secondStarted,
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('maintenance occupied the only build slot')), 1000)
      ),
    ])
    worker.stop()
    releaseSecond()
    releaseInventory()
    await run
  })
})

describe('Artifact cleanup', () => {
  it('deletes the physical package before committing the DELETED tombstone', async () => {
    const store = new MemoryStore()
    const old = artifact({
      targetId: 'webapp',
      branch: 'master',
      builtAt: '2026-08-25T01:00:00.000Z',
    })
    const latest = artifact({
      targetId: 'webapp',
      branch: 'master',
      builtAt: '2026-08-25T02:00:00.000Z',
    })
    await store.createArtifact(old)
    await store.createArtifact(latest)
    const requests: Array<{ url: string; body: unknown }> = []

    const completed = await cleanupSupersededArtifacts({
      store,
      runnerUrl: 'http://runner.test/',
      runnerToken: 'runner-token',
      workerId: 'worker-1',
      requestTimeoutMs: 1000,
      maxConcurrency: 1,
      fetchImpl: async (input, init) => {
        requests.push({ url: String(input), body: JSON.parse(String(init?.body)) })
        expect((await store.getArtifact(old.id))?.status).toBe('DELETING')
        return new Response(null, { status: 204 })
      },
    })

    expect(completed).toBe(1)
    expect(requests).toEqual([
      {
        url: 'http://runner.test/internal/artifacts/delete',
        body: { artifactId: old.id, storageKey: old.storageKey },
      },
    ])
    expect((await store.getArtifact(old.id))?.status).toBe('DELETED')
    expect((await store.getArtifact(latest.id))?.status).toBe('READY')
  })

  it('keeps DELETING when the delete result is uncertain so READY never points at partial files', async () => {
    const store = new MemoryStore()
    const old = artifact({
      targetId: 'online-h5',
      branch: 'master',
      builtAt: '2026-08-25T01:00:00.000Z',
    })
    const latest = artifact({
      targetId: 'online-h5',
      branch: 'master',
      builtAt: '2026-08-25T02:00:00.000Z',
    })
    await store.createArtifact(old)
    await store.createArtifact(latest)

    const error = vi.spyOn(console, 'error').mockImplementation(() => undefined)
    try {
      await cleanupSupersededArtifacts({
        store,
        runnerUrl: 'http://runner.test',
        runnerToken: 'runner-token',
        workerId: 'worker-1',
        requestTimeoutMs: 1000,
        maxConcurrency: 1,
        fetchImpl: async () => new Response('disk busy', { status: 500 }),
      })
    } finally {
      error.mockRestore()
    }

    expect((await store.getArtifact(old.id))?.status).toBe('DELETING')
  })

  it('runs a sweep when the worker starts even when there are no build jobs', async () => {
    const store = new MemoryStore()
    const old = artifact({
      targetId: 'webapp',
      branch: 'existing-branch',
      builtAt: '2026-08-25T01:00:00.000Z',
    })
    const latest = artifact({
      targetId: 'webapp',
      branch: 'existing-branch',
      builtAt: '2026-08-25T02:00:00.000Z',
    })
    await store.createArtifact(old)
    await store.createArtifact(latest)
    let announceDeleted: () => void = () => undefined
    const deleted = new Promise<void>((resolve) => {
      announceDeleted = resolve
    })
    const worker = new BuildWorker({
      store,
      runnerUrl: 'http://runner.test',
      runnerToken: 'runner-token',
      workerId: 'worker-1',
      requestTimeoutMs: 1000,
      maxConcurrency: 1,
      artifactCleanupIntervalMs: 60_000,
      fetchImpl: async (_input, init) => {
        if (init?.method === 'GET') return inventoryResponse([])
        announceDeleted()
        return new Response(null, { status: 204 })
      },
    })

    const run = worker.run(5)
    await Promise.race([
      deleted,
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('startup Artifact sweep did not run')), 1000)
      ),
    ])
    worker.stop()
    await run

    expect((await store.getArtifact(old.id))?.status).toBe('DELETED')
  })

  it('reconciles only old untracked READY and safe DELETING directories with one DB batch', async () => {
    const store = new MemoryStore()
    const trackedReady = artifact({
      targetId: 'webapp',
      branch: 'tracked',
      builtAt: '2026-08-25T01:00:00.000Z',
    })
    const deleted = artifact({
      targetId: 'online-h5',
      branch: 'deleted',
      builtAt: '2026-08-25T01:00:00.000Z',
    })
    deleted.status = 'DELETED'
    await store.createArtifact(trackedReady)
    await store.createArtifact(deleted)
    const oldReadyId = randomUUID()
    const freshReadyId = randomUUID()
    const missingDeletingId = randomUUID()
    const trackedDeletingId = trackedReady.id
    const inventory: RunnerArtifactInventoryItem[] = [
      {
        artifactId: oldReadyId,
        targetId: 'webapp',
        storageKey: `ready/webapp/${oldReadyId}`,
        state: 'READY',
        modifiedAt: '2020-01-01T00:00:00.000Z',
      },
      {
        artifactId: freshReadyId,
        targetId: 'webapp',
        storageKey: `ready/webapp/${freshReadyId}`,
        state: 'READY',
        modifiedAt: new Date().toISOString(),
      },
      {
        artifactId: trackedReady.id,
        targetId: trackedReady.targetId,
        storageKey: trackedReady.storageKey,
        state: 'READY',
        modifiedAt: '2020-01-01T00:00:00.000Z',
      },
      {
        artifactId: missingDeletingId,
        targetId: 'base',
        storageKey: `deleting/base/${missingDeletingId}`,
        state: 'DELETING',
        modifiedAt: new Date().toISOString(),
      },
      {
        artifactId: deleted.id,
        targetId: deleted.targetId,
        storageKey: `deleting/${deleted.targetId}/${deleted.id}`,
        state: 'DELETING',
        modifiedAt: new Date().toISOString(),
      },
      {
        artifactId: trackedDeletingId,
        targetId: trackedReady.targetId,
        storageKey: `deleting/${trackedReady.targetId}/${trackedDeletingId}`,
        state: 'DELETING',
        modifiedAt: '2020-01-01T00:00:00.000Z',
      },
    ]
    const lookup = vi.spyOn(store, 'getArtifactsByIds')
    const deletedRequests: unknown[] = []

    const completed = await reconcileOrphanArtifacts({
      store,
      runnerUrl: 'http://runner.test',
      runnerToken: 'runner-token',
      workerId: 'worker-1',
      requestTimeoutMs: 1000,
      maxConcurrency: 1,
      fetchImpl: async (_input, init) => {
        if (init?.method === 'GET') return inventoryResponse(inventory)
        deletedRequests.push(JSON.parse(String(init?.body)))
        return new Response(null, { status: 204 })
      },
    })

    expect(completed).toBe(3)
    expect(lookup).toHaveBeenCalledTimes(1)
    expect(deletedRequests).toEqual(
      expect.arrayContaining([
        { artifactId: oldReadyId, storageKey: `ready/webapp/${oldReadyId}` },
        {
          artifactId: missingDeletingId,
          storageKey: `deleting/base/${missingDeletingId}`,
        },
        {
          artifactId: deleted.id,
          storageKey: `deleting/${deleted.targetId}/${deleted.id}`,
        },
      ])
    )
  })

  it('shares one maintenance batch between regular retention and orphan reconciliation', async () => {
    const store = new MemoryStore()
    const old = artifact({
      targetId: 'webapp',
      branch: 'master',
      builtAt: '2026-08-25T01:00:00.000Z',
    })
    const latest = artifact({
      targetId: 'webapp',
      branch: 'master',
      builtAt: '2026-08-25T02:00:00.000Z',
    })
    await store.createArtifact(old)
    await store.createArtifact(latest)
    const requests: Array<{ method: string | undefined; body: unknown }> = []

    const completed = await maintainArtifacts({
      store,
      runnerUrl: 'http://runner.test',
      runnerToken: 'runner-token',
      workerId: 'worker-1',
      requestTimeoutMs: 1000,
      maxConcurrency: 1,
      artifactCleanupBatchSize: 1,
      fetchImpl: async (_input, init) => {
        requests.push({
          method: init?.method,
          body: init?.body ? JSON.parse(String(init.body)) : null,
        })
        return new Response(null, { status: 204 })
      },
    })

    expect(completed).toBe(1)
    expect(requests).toEqual([
      {
        method: 'POST',
        body: { artifactId: old.id, storageKey: old.storageKey },
      },
    ])
  })
})
