import { randomUUID } from 'node:crypto'

import {
  runnerArtifactDeleteSchema,
  runnerArtifactInventorySchema,
  runnerEventSchema,
  type BuildJob,
  type RunnerArtifactInventoryItem,
  type RunnerEvent,
  type RunnerStage,
} from '@cuddly/contracts'
import type { CuddlyStore } from '@cuddly/db'

class BuildFailure extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly logPath: string | null = null
  ) {
    super(message)
    this.name = 'BuildFailure'
  }
}

export interface BuildWorkerOptions {
  store: CuddlyStore
  runnerUrl: string
  runnerToken: string
  workerId: string
  requestTimeoutMs: number
  maxConcurrency: number
  artifactCleanupIntervalMs?: number
  artifactCleanupBatchSize?: number
  artifactOrphanGraceMs?: number
  fetchImpl?: typeof fetch
  resolveRuntimeSettings?: () => Promise<{
    maxConcurrency: number
    requestTimeoutMs: number
    artifactBaseUrl: string
  }>
}

export type BuildJobProcessor = (job: BuildJob, options: BuildWorkerOptions) => Promise<boolean>

type RunnerResult = Extract<RunnerEvent, { type: 'result' }>

const DEFAULT_ARTIFACT_CLEANUP_BATCH_SIZE = 50
const DEFAULT_ARTIFACT_ORPHAN_GRACE_MS = 10 * 60_000

interface ArtifactCleanupBatchResult {
  attempted: number
  completed: number
}

function cleanupBatchSize(options: BuildWorkerOptions): number {
  const configured = options.artifactCleanupBatchSize ?? DEFAULT_ARTIFACT_CLEANUP_BATCH_SIZE
  return Number.isFinite(configured) ? Math.max(0, Math.min(200, Math.floor(configured))) : 0
}

async function deleteRunnerArtifact(
  options: BuildWorkerOptions,
  artifact: { artifactId: string; storageKey: string }
): Promise<void> {
  const fetchImpl = options.fetchImpl ?? fetch
  const body = runnerArtifactDeleteSchema.parse(artifact)
  const response = await fetchImpl(
    `${options.runnerUrl.replace(/\/$/, '')}/internal/artifacts/delete`,
    {
      method: 'POST',
      headers: {
        authorization: `Bearer ${options.runnerToken}`,
        'content-type': 'application/json',
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(Math.min(options.requestTimeoutMs, 30_000)),
    }
  )
  if (!response.ok) {
    const responseBody = await response.text()
    throw new Error(`Runner returned HTTP ${response.status}: ${responseBody.slice(0, 500)}`)
  }
}

async function cleanupSupersededArtifactBatch(
  options: BuildWorkerOptions,
  limit: number
): Promise<ArtifactCleanupBatchResult> {
  const candidates = await options.store.claimArtifactCleanupCandidates(limit)
  let completed = 0
  for (const candidate of candidates) {
    try {
      await deleteRunnerArtifact(options, {
        artifactId: candidate.id,
        storageKey: candidate.storageKey,
      })
      await options.store.completeArtifactDeletion(candidate.id)
      completed += 1
    } catch (error) {
      console.error(`[build-worker] Artifact cleanup failed for ${candidate.id}`, error)
    }
  }
  return { attempted: candidates.length, completed }
}

export async function cleanupSupersededArtifacts(options: BuildWorkerOptions): Promise<number> {
  return (await cleanupSupersededArtifactBatch(options, cleanupBatchSize(options))).completed
}

async function readRunnerArtifactInventory(
  options: BuildWorkerOptions
): Promise<RunnerArtifactInventoryItem[]> {
  const fetchImpl = options.fetchImpl ?? fetch
  const response = await fetchImpl(
    `${options.runnerUrl.replace(/\/$/, '')}/internal/artifacts/inventory`,
    {
      method: 'GET',
      headers: { authorization: `Bearer ${options.runnerToken}` },
      signal: AbortSignal.timeout(Math.min(options.requestTimeoutMs, 30_000)),
    }
  )
  if (!response.ok) {
    const responseBody = await response.text()
    throw new Error(`Runner returned HTTP ${response.status}: ${responseBody.slice(0, 500)}`)
  }
  return runnerArtifactInventorySchema.parse(await response.json()).artifacts
}

export async function reconcileOrphanArtifacts(
  options: BuildWorkerOptions,
  limit = cleanupBatchSize(options)
): Promise<number> {
  const boundedLimit = Math.max(0, Math.floor(limit))
  if (boundedLimit === 0) return 0
  const inventory = await readRunnerArtifactInventory(options)
  if (inventory.length === 0) return 0

  const artifacts = await options.store.getArtifactsByIds([
    ...new Set(inventory.map((item) => item.artifactId)),
  ])
  const artifactsById = new Map(artifacts.map((artifact) => [artifact.id, artifact]))
  const configuredGrace = options.artifactOrphanGraceMs ?? DEFAULT_ARTIFACT_ORPHAN_GRACE_MS
  const graceMs = Number.isFinite(configuredGrace)
    ? Math.max(0, configuredGrace)
    : DEFAULT_ARTIFACT_ORPHAN_GRACE_MS
  const readyBefore = Date.now() - graceMs
  const eligible = inventory
    .filter((item) => {
      const artifact = artifactsById.get(item.artifactId)
      if (item.state === 'DELETING') return !artifact || artifact.status === 'DELETED'
      return !artifact && Date.parse(item.modifiedAt) <= readyBefore
    })
    .sort(
      (a, b) =>
        Number(a.state !== 'DELETING') - Number(b.state !== 'DELETING') ||
        a.modifiedAt.localeCompare(b.modifiedAt) ||
        a.storageKey.localeCompare(b.storageKey)
    )
    .slice(0, boundedLimit)

  let completed = 0
  for (const item of eligible) {
    try {
      await deleteRunnerArtifact(options, {
        artifactId: item.artifactId,
        storageKey: item.storageKey,
      })
      completed += 1
    } catch (error) {
      console.error(`[build-worker] orphan Artifact cleanup failed for ${item.storageKey}`, error)
    }
  }
  return completed
}

export async function maintainArtifacts(options: BuildWorkerOptions): Promise<number> {
  const limit = cleanupBatchSize(options)
  if (limit === 0) return 0
  const regular = await cleanupSupersededArtifactBatch(options, limit)
  const remaining = Math.max(0, limit - regular.attempted)
  const orphaned = remaining > 0 ? await reconcileOrphanArtifacts(options, remaining) : 0
  return regular.completed + orphaned
}

async function readRunnerEvents(
  response: Response,
  onStage: (stage: RunnerStage) => Promise<void>
): Promise<RunnerResult> {
  if (!response.body)
    throw new BuildFailure('RUNNER_EMPTY_RESPONSE', 'Runner returned no response body')
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffered = ''
  let result: RunnerResult | null = null

  const consumeLine = async (line: string) => {
    if (!line.trim()) return
    const parsed = runnerEventSchema.safeParse(JSON.parse(line))
    if (!parsed.success) {
      throw new BuildFailure('RUNNER_PROTOCOL_ERROR', 'Runner returned an invalid event')
    }
    const event = parsed.data
    if (event.type === 'stage') await onStage(event.stage)
    if (event.type === 'result') result = event
    if (event.type === 'error') throw new BuildFailure(event.code, event.message, event.logPath)
  }

  while (true) {
    const { value, done } = await reader.read()
    buffered += decoder.decode(value, { stream: !done })
    const lines = buffered.split('\n')
    buffered = lines.pop() || ''
    for (const line of lines) await consumeLine(line)
    if (done) break
  }
  await consumeLine(buffered)
  if (!result)
    throw new BuildFailure('RUNNER_NO_RESULT', 'Runner finished without an Artifact result')
  return result
}

async function invokeRunner(job: BuildJob, artifactId: string, options: BuildWorkerOptions) {
  if (!job.targetSnapshot) {
    throw new BuildFailure(
      'TARGET_SNAPSHOT_MISSING',
      'Build job has no project configuration snapshot'
    )
  }
  const runtime = options.resolveRuntimeSettings
    ? await options.resolveRuntimeSettings()
    : {
        maxConcurrency: options.maxConcurrency,
        requestTimeoutMs: options.requestTimeoutMs,
        artifactBaseUrl: 'http://localhost:9872',
      }
  const response = await fetch(`${options.runnerUrl.replace(/\/$/, '')}/internal/run`, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${options.runnerToken}`,
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      jobId: job.id,
      artifactId,
      targetId: job.targetId,
      branch: job.branch,
      requestedBy: job.requestedBy,
      artifactBaseUrl: runtime.artifactBaseUrl,
      project: job.targetSnapshot,
    }),
    signal: AbortSignal.timeout(runtime.requestTimeoutMs),
  })
  if (!response.ok) {
    const body = await response.text()
    throw new BuildFailure(
      'RUNNER_HTTP_ERROR',
      `Runner returned HTTP ${response.status}: ${body.slice(0, 500)}`
    )
  }
  return readRunnerEvents(response, async (stage) => {
    await options.store.updateBuildJob(job.id, { status: stage })
  })
}

export async function processBuildJob(
  job: BuildJob,
  options: BuildWorkerOptions
): Promise<boolean> {
  const artifactId = randomUUID()
  let succeeded = false
  try {
    const result = await invokeRunner(job, artifactId, options)
    await options.store.createArtifact({
      id: result.artifactId,
      buildJobId: job.id,
      targetId: job.targetId,
      branch: job.branch,
      status: 'READY',
      storageKey: result.storageKey,
      manifest: result.manifest,
      builtAt: result.builtAt,
      createdBy: job.requestedBy,
    })
    await options.store.updateBuildJob(job.id, {
      status: 'SUCCEEDED',
      finishedAt: new Date().toISOString(),
      failureCode: null,
      failureMessage: null,
      logPath: result.logPath,
    })
    succeeded = true
  } catch (error) {
    const failure =
      error instanceof BuildFailure
        ? error
        : new BuildFailure('WORKER_FAILED', error instanceof Error ? error.message : String(error))
    await options.store.updateBuildJob(job.id, {
      status: 'FAILED',
      finishedAt: new Date().toISOString(),
      failureCode: failure.code,
      failureMessage: failure.message.slice(0, 1000),
      logPath: failure.logPath,
    })
  }
  return succeeded
}

export class BuildWorker {
  private stopping = false
  private readonly activeJobs = new Set<Promise<void>>()
  private activeCleanup: Promise<void> | null = null
  private artifactCleanupRequested = false
  private nextArtifactCleanupAt = 0
  constructor(
    private readonly options: BuildWorkerOptions,
    private readonly processJob: BuildJobProcessor = processBuildJob
  ) {}

  stop(): void {
    this.stopping = true
  }

  private start(job: BuildJob): void {
    let succeeded = false
    let task: Promise<void>
    task = Promise.resolve()
      .then(() => this.processJob(job, this.options))
      .then((result) => {
        succeeded = result
      })
      .catch((error) => {
        console.error(`[build-worker] job ${job.id} stopped unexpectedly`, error)
      })
      .finally(() => {
        this.activeJobs.delete(task)
        if (succeeded) this.requestArtifactCleanup()
      })
    this.activeJobs.add(task)
  }

  private requestArtifactCleanup(): void {
    if (this.stopping) return
    this.artifactCleanupRequested = true
    this.startArtifactCleanupIfDue()
  }

  private startArtifactCleanupIfDue(): void {
    if (this.stopping || this.activeCleanup) return
    if (!this.artifactCleanupRequested && Date.now() < this.nextArtifactCleanupAt) return
    this.artifactCleanupRequested = false
    this.nextArtifactCleanupAt = Date.now() + (this.options.artifactCleanupIntervalMs ?? 60_000)
    let task: Promise<void>
    task = maintainArtifacts(this.options)
      .then(() => undefined)
      .catch((error) => {
        console.error('[build-worker] scheduled Artifact cleanup failed', error)
      })
      .finally(() => {
        if (this.activeCleanup === task) this.activeCleanup = null
        if (this.artifactCleanupRequested) this.startArtifactCleanupIfDue()
      })
    this.activeCleanup = task
  }

  async run(pollIntervalMs: number): Promise<void> {
    while (!this.stopping) {
      const runtime = this.options.resolveRuntimeSettings
        ? await this.options.resolveRuntimeSettings()
        : { maxConcurrency: this.options.maxConcurrency }
      const maxConcurrency = Number.isFinite(runtime.maxConcurrency)
        ? Math.max(1, Math.floor(runtime.maxConcurrency))
        : 1
      while (!this.stopping && this.activeJobs.size < maxConcurrency) {
        const job = await this.options.store.claimNextBuildJob(this.options.workerId)
        if (!job) break
        this.start(job)
      }

      if (!this.stopping) this.startArtifactCleanupIfDue()

      if (this.stopping) break
      const poll = new Promise<void>((resolve) => setTimeout(resolve, pollIntervalMs))
      await Promise.race([
        poll,
        ...this.activeJobs,
        ...(this.activeCleanup ? [this.activeCleanup] : []),
      ])
    }

    await Promise.allSettled([
      ...this.activeJobs,
      ...(this.activeCleanup ? [this.activeCleanup] : []),
    ])
  }
}
