import { randomUUID } from 'node:crypto'
import { createWriteStream } from 'node:fs'
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { FileArtifactStore } from '@cuddly/artifact-store'
import { runnerArtifactInventorySchema, type RunnerJobInput } from '@cuddly/contracts'
import { afterEach, describe, expect, it } from 'vitest'

import {
  buildPublicPath,
  checkoutRepository,
  commandUsesPnpm,
  createRunnerApp,
  packageManagerEnvironment,
  patchOnlineH5AssetPrefixSource,
  patchRemoteAssetPrefixSource,
  patchRemoteProviderVersionSource,
  patchRemoteSentryPluginSource,
  writeRunnerHeartbeat,
  type RunnerExecutor,
  type RunnerOptions,
} from './runner'
import {
  RepositoryCacheDiskPressureError,
  RepositoryCacheUnavailableError,
} from './repository-cache'

const roots: string[] = []

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })))
})

function runnerJob(targetId: string): RunnerJobInput {
  return {
    jobId: randomUUID(),
    artifactId: randomUUID(),
    targetId,
    branch: 'feature/test',
    requestedBy: 'gz',
    artifactBaseUrl: 'http://localhost:9872',
    project: {
      id: targetId,
      kind: targetId === 'webapp' ? 'webapp' : 'h5-site',
      repositoryUrl: 'https://git.example.test/project.git',
      installCommand: 'pnpm install',
      buildCommand: 'pnpm build',
      outputDirectory: 'dist',
      siteAdapter: 'generic-static-v1',
    },
  }
}

async function checkoutHarness(input: {
  repositoryCache?: NonNullable<RunnerOptions['repositoryCache']>
  repositoryUrl?: string
  branch?: string
  availableDiskBytes?: (directory: string) => Promise<number>
  readGitSshIdentity?: () => Promise<Buffer>
  runCommand?: (request: {
    command: string
    args: string[]
    cwd: string
    displayCommand?: string
  }) => Promise<string>
}): Promise<{ root: string; logPath: string }> {
  const root = await mkdtemp(path.join(tmpdir(), 'cuddly-runner-checkout-'))
  roots.push(root)
  const logPath = path.join(root, 'checkout.log')
  const log = createWriteStream(logPath)
  const job = runnerJob('base')
  job.project.repositoryUrl = input.repositoryUrl || 'https://git.example.test/kook/kook.git'
  if (input.branch) job.branch = input.branch
  try {
    await checkoutRepository({
      job,
      options: {
        internalToken: 'runner-token',
        runnerRoot: root,
        artifactStore: new FileArtifactStore(path.join(root, 'artifacts')),
        keepWorkspace: false,
        settingsSecret: 'test-secret',
        repositoryCache: input.repositoryCache,
        availableDiskBytes: input.availableDiskBytes || (async () => 5 * 1024 ** 3),
        readGitSshIdentity: input.readGitSshIdentity,
      },
      jobDirectory: root,
      sourceDirectory: path.join(root, 'source'),
      log,
      runCommand: input.runCommand ? (request) => input.runCommand!(request) : undefined,
    })
    return { root, logPath }
  } finally {
    await new Promise<void>((resolve, reject) => {
      log.on('error', reject)
      log.end(resolve)
    })
  }
}

describe('site build public path', () => {
  it('gives webapp builds an Artifact-specific /app/ prefix', () => {
    const job = runnerJob('webapp')

    expect(buildPublicPath(job, 'https://preview.example.test/remote/')).toBe(
      `/__cuddly/artifacts/${job.artifactId}/app/`
    )
  })

  it('keeps the webapp id fallback for queued snapshots created before kind was recorded', () => {
    const job = runnerJob('webapp')
    delete job.project.kind

    expect(buildPublicPath(job, 'https://preview.example.test/remote/')).toBe(
      `/__cuddly/artifacts/${job.artifactId}/app/`
    )
  })

  it('does not apply the webapp prefix to other generic static sites', () => {
    const job = runnerJob('biz')
    job.project.kind = 'spa-site'

    expect(buildPublicPath(job, 'https://preview.example.test/remote/')).toBeUndefined()
  })

  it('preserves the absolute preview prefix for Remote builds', () => {
    const job = runnerJob('base')
    job.project.kind = 'remote'
    job.project.siteAdapter = 'kook-remote-v1'

    expect(buildPublicPath(job, 'https://preview.example.test/remote/')).toBe(
      'https://preview.example.test/remote/'
    )
  })
})

describe('runner repository cache integration', () => {
  it('passes the repository checkout to the shared cache without invoking direct clone', async () => {
    let cachedBranch = ''
    let commandCount = 0
    await checkoutHarness({
      repositoryCache: {
        checkout: async (input) => {
          cachedBranch = input.branch
          return { cacheHit: true, cacheKey: 'a'.repeat(64), commit: 'b'.repeat(40) }
        },
      },
      runCommand: async () => {
        commandCount += 1
        return ''
      },
    })

    expect(cachedBranch).toBe('feature/test')
    expect(commandCount).toBe(0)
  })

  it('falls back to the original shallow clone when cache infrastructure is unavailable', async () => {
    const commands: Array<{ args: string[]; displayCommand?: string }> = []
    await checkoutHarness({
      repositoryCache: {
        checkout: async () => {
          throw new RepositoryCacheUnavailableError('cache filesystem unavailable')
        },
      },
      runCommand: async (request) => {
        commands.push(request)
        return ''
      },
    })

    expect(commands).toHaveLength(2)
    expect(commands[0]?.args).toEqual(['check-ref-format', '--branch', 'feature/test'])
    expect(commands[1]?.args).toEqual(
      expect.arrayContaining(['clone', '--depth', '1', '--single-branch', '--branch'])
    )
    expect(commands[1]?.displayCommand).toContain('<repository>')
  })

  it('does not retry a direct clone for an unknown cache or remote fetch failure', async () => {
    let commandCount = 0
    await expect(
      checkoutHarness({
        repositoryCache: {
          checkout: async () => {
            throw new Error('origin fetch failed')
          },
        },
        runCommand: async () => {
          commandCount += 1
          return ''
        },
      })
    ).rejects.toThrow('origin fetch failed')
    expect(commandCount).toBe(0)
  })

  it('does not bypass the hard disk watermark with a direct clone', async () => {
    let commandCount = 0
    await expect(
      checkoutHarness({
        repositoryCache: {
          checkout: async () => {
            throw new RepositoryCacheDiskPressureError(1024)
          },
        },
        runCommand: async () => {
          commandCount += 1
          return ''
        },
      })
    ).rejects.toMatchObject({ code: 'RUNNER_DISK_PRESSURE' })
    expect(commandCount).toBe(0)
  })

  it.each([
    'https://user:secret@git.example.test/kook.git',
    'https://@git.example.test/kook.git',
    'https://git.example.test/kook.git?access_token=secret',
    'https://git.example.test/kook.git?',
    'https://git.example.test/kook.git#credential',
    'https://git.example.test/kook.git#',
  ])('rejects an unsafe HTTP repository URL before invoking Git: %s', async (repositoryUrl) => {
    let cacheCount = 0
    let commandCount = 0
    await expect(
      checkoutHarness({
        repositoryUrl,
        repositoryCache: {
          checkout: async () => {
            cacheCount += 1
            return { cacheHit: false, cacheKey: 'a'.repeat(64), commit: 'b'.repeat(40) }
          },
        },
        runCommand: async () => {
          commandCount += 1
          return ''
        },
      })
    ).rejects.toMatchObject({ code: 'UNSAFE_REPOSITORY_URL' })
    expect(cacheCount).toBe(0)
    expect(commandCount).toBe(0)
  })

  it('uses the guarded direct path when an SSH identity cannot be fingerprinted', async () => {
    let cacheCount = 0
    const commands: string[][] = []
    await checkoutHarness({
      repositoryUrl: 'ssh://git@git.example.test/kook.git',
      repositoryCache: {
        checkout: async () => {
          cacheCount += 1
          return { cacheHit: false, cacheKey: 'a'.repeat(64), commit: 'b'.repeat(40) }
        },
      },
      readGitSshIdentity: async () => {
        throw new Error('identity is unavailable')
      },
      runCommand: async (request) => {
        commands.push(request.args)
        return ''
      },
    })

    expect(cacheCount).toBe(0)
    expect(commands[0]).toEqual(['check-ref-format', '--branch', 'feature/test'])
    expect(commands[1]?.[0]).toBe('clone')
  })

  it('separates SSH cache scopes when the fixed identity changes', async () => {
    const credentialScopes: string[] = []
    const checkoutWithIdentity = (identity: string) =>
      checkoutHarness({
        repositoryUrl: 'ssh://git@git.example.test/kook.git',
        readGitSshIdentity: async () => Buffer.from(identity),
        repositoryCache: {
          checkout: async (input) => {
            credentialScopes.push(input.credentialScope)
            return { cacheHit: true, cacheKey: 'a'.repeat(64), commit: 'b'.repeat(40) }
          },
        },
      })

    await checkoutWithIdentity('fixed-identity-one')
    await checkoutWithIdentity('fixed-identity-two')

    expect(credentialScopes).toHaveLength(2)
    expect(credentialScopes[0]).not.toBe(credentialScopes[1])
    expect(credentialScopes[0]).toMatch(/^ssh-key:[a-f0-9]{64}$/)
    expect(credentialScopes.join('\n')).not.toContain('fixed-identity')
  })

  it('removes a direct checkout and fails when the post-clone reject watermark is crossed', async () => {
    let diskCheck = 0
    let cloneCount = 0
    await expect(
      checkoutHarness({
        repositoryCache: {
          checkout: async () => {
            throw new RepositoryCacheUnavailableError('cache filesystem unavailable')
          },
        },
        availableDiskBytes: async () => {
          diskCheck += 1
          return diskCheck === 1 ? 5 * 1024 ** 3 : 1024
        },
        runCommand: async (request) => {
          if (request.args[0] === 'clone') cloneCount += 1
          return ''
        },
      })
    ).rejects.toMatchObject({ code: 'RUNNER_DISK_PRESSURE' })
    expect(cloneCount).toBe(1)
  })

  it('rejects a direct checkout below the cleanup watermark before clone starts', async () => {
    let cloneCount = 0
    await expect(
      checkoutHarness({
        repositoryCache: {
          checkout: async () => {
            throw new RepositoryCacheUnavailableError('cache filesystem unavailable')
          },
        },
        availableDiskBytes: async () => 3 * 1024 ** 3,
        runCommand: async (request) => {
          if (request.args[0] === 'clone') cloneCount += 1
          return ''
        },
      })
    ).rejects.toMatchObject({ code: 'RUNNER_DISK_PRESSURE' })
    expect(cloneCount).toBe(0)
  })

  it('serializes direct clones before taking their disk-space snapshots', async () => {
    let activeClones = 0
    let maximumActiveClones = 0
    let releaseFirst!: () => void
    let announceFirst!: () => void
    const firstStarted = new Promise<void>((resolve) => {
      announceFirst = resolve
    })
    const firstRelease = new Promise<void>((resolve) => {
      releaseFirst = resolve
    })
    const runDirect = () =>
      checkoutHarness({
        repositoryCache: {
          checkout: async () => {
            throw new RepositoryCacheUnavailableError('cache filesystem unavailable')
          },
        },
        availableDiskBytes: async () => 5 * 1024 ** 3,
        runCommand: async (request) => {
          if (request.args[0] !== 'clone') return ''
          activeClones += 1
          maximumActiveClones = Math.max(maximumActiveClones, activeClones)
          if (maximumActiveClones === 1) {
            announceFirst()
            await firstRelease
          }
          activeClones -= 1
          return ''
        },
      })

    const first = runDirect()
    await firstStarted
    const second = runDirect()
    await new Promise((resolve) => setTimeout(resolve, 25))
    expect(maximumActiveClones).toBe(1)
    releaseFirst()
    await Promise.all([first, second])
    expect(maximumActiveClones).toBe(1)
  })
})

describe('runner project concurrency', () => {
  it('allows different projects and rejects a second build for the same project', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'cuddly-runner-'))
    roots.push(root)
    const releases = new Map<string, () => void>()
    const execute: RunnerExecutor = async (job) => {
      await new Promise<void>((resolve) => releases.set(job.targetId, resolve))
    }
    const app = createRunnerApp(
      {
        internalToken: 'runner-token',
        runnerRoot: root,
        artifactStore: new FileArtifactStore(path.join(root, 'artifacts')),
        keepWorkspace: false,
        settingsSecret: 'test-secret',
      },
      execute
    )
    const server = app.listen(0, '127.0.0.1')
    await new Promise<void>((resolve) => server.once('listening', resolve))
    const address = server.address()
    if (!address || typeof address === 'string') throw new Error('runner test server has no port')
    const url = `http://127.0.0.1:${address.port}`
    const request = (job: RunnerJobInput) =>
      fetch(`${url}/internal/run`, {
        method: 'POST',
        headers: {
          authorization: 'Bearer runner-token',
          'content-type': 'application/json',
        },
        body: JSON.stringify(job),
      })

    try {
      const onlineResponse = await request(runnerJob('online-h5'))
      expect(onlineResponse.status).toBe(200)

      const duplicateResponse = await request(runnerJob('online-h5'))
      expect(duplicateResponse.status).toBe(409)
      expect(await duplicateResponse.json()).toMatchObject({ code: 'RUNNER_TARGET_BUSY' })

      const webappResponse = await request(runnerJob('webapp'))
      expect(webappResponse.status).toBe(200)

      const health = await fetch(`${url}/health/ready`).then((response) => response.json())
      expect(health).toMatchObject({
        ok: true,
        busy: true,
        activeCount: 2,
        activeTargets: ['online-h5', 'webapp'],
      })

      releases.forEach((release) => release())
      await Promise.all([onlineResponse.text(), webappResponse.text()])
    } finally {
      releases.forEach((release) => release())
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve()))
      )
    }
  })
})

describe('runner Artifact cleanup endpoint', () => {
  it('requires the internal token and removes the exact Artifact directory', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'cuddly-runner-cleanup-'))
    roots.push(root)
    const artifactStore = new FileArtifactStore(path.join(root, 'artifacts'))
    await artifactStore.initialize()
    const artifactId = randomUUID()
    const storageKey = `ready/webapp/${artifactId}`
    const artifactDirectory = artifactStore.resolveStorageDirectory(storageKey)
    await mkdir(artifactDirectory, { recursive: true })
    await writeFile(path.join(artifactDirectory, 'index.html'), 'ready', 'utf8')
    const app = createRunnerApp({
      internalToken: 'runner-token',
      runnerRoot: root,
      artifactStore,
      keepWorkspace: false,
      settingsSecret: 'test-secret',
    })
    const server = app.listen(0, '127.0.0.1')
    await new Promise<void>((resolve) => server.once('listening', resolve))
    const address = server.address()
    if (!address || typeof address === 'string') throw new Error('runner test server has no port')
    const origin = `http://127.0.0.1:${address.port}`
    const url = `${origin}/internal/artifacts/delete`
    const inventoryUrl = `${origin}/internal/artifacts/inventory`
    const body = JSON.stringify({ artifactId, storageKey })

    try {
      const unauthorizedInventory = await fetch(inventoryUrl)
      expect(unauthorizedInventory.status).toBe(401)
      const inventoryResponse = await fetch(inventoryUrl, {
        headers: { authorization: 'Bearer runner-token' },
      })
      expect(inventoryResponse.status).toBe(200)
      expect(runnerArtifactInventorySchema.parse(await inventoryResponse.json()).artifacts).toEqual(
        [
          expect.objectContaining({
            artifactId,
            targetId: 'webapp',
            storageKey,
            state: 'READY',
          }),
        ]
      )

      const unauthorized = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body,
      })
      expect(unauthorized.status).toBe(401)
      await expect(artifactStore.readText(storageKey, 'index.html')).resolves.toBe('ready')

      const deleted = await fetch(url, {
        method: 'POST',
        headers: {
          authorization: 'Bearer runner-token',
          'content-type': 'application/json',
        },
        body,
      })
      expect(deleted.status).toBe(204)
      await expect(artifactStore.readText(storageKey, 'index.html')).resolves.toBeNull()
    } finally {
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve()))
      )
    }
  })
})

describe('Online H5 asset public path patch', () => {
  it('supports the current CDN config while preserving upstream fallbacks', () => {
    const source = `"use strict";

module.exports = {
  test: "/",
  online: "https://static-m.kookapp.cn/",
  dev: "https://static-m.dev.chuanyuapp.com/",
};
`

    expect(patchOnlineH5AssetPrefixSource(source)).toBe(`"use strict";

module.exports = {
  test: process.env.CUDDLY_ASSET_PREFIX || "/",
  online: process.env.CUDDLY_ASSET_PREFIX || "https://static-m.kookapp.cn/",
  dev: "https://static-m.dev.chuanyuapp.com/",
};
`)
  })

  it('supports quoted properties and is idempotent', () => {
    const source = `module.exports = {
  'test': process.env.CUDDLY_ASSET_PREFIX || '/',
  "online": process.env.CUDDLY_ASSET_PREFIX || '/',
}
`
    expect(patchOnlineH5AssetPrefixSource(source)).toBe(source)
  })

  it('rejects an incompatible CDN config with a dedicated failure', () => {
    expect(() => patchOnlineH5AssetPrefixSource('module.exports = { dev: "/" }\n')).toThrow(
      'Online H5 CDN config does not expose the expected test property'
    )
  })
})

describe('Remote build public path patch', () => {
  it('keeps existing build commands but gives the Artifact prefix priority', () => {
    const source = 'const publicPath = `${process.env.PUB_PATH}${templateName}/`\n'
    expect(patchRemoteAssetPrefixSource(source)).toBe(
      'const publicPath = process.env.CUDDLY_ASSET_PREFIX || `${process.env.PUB_PATH}${templateName}/`\n'
    )
  })

  it('is idempotent', () => {
    const source =
      'const publicPath = process.env.CUDDLY_ASSET_PREFIX || `${process.env.PUB_PATH}${remoteName}/`\n'
    expect(patchRemoteAssetPrefixSource(source)).toBe(source)
  })

  it('gives Cuddly VERSION priority on historical Remote configs', () => {
    const source = "const templateName = require('../package.json').templateName || 'base_v0'\n"
    expect(patchRemoteProviderVersionSource(source)).toBe(
      "const templateName = process.env.VERSION || require('../package.json').templateName || 'base_v0'\n"
    )
  })

  it('preserves configs that already resolve an explicit build version', () => {
    const source = `const remoteName = resolve_build_remote_version({
  app_root_dir: __dirname,
})
`
    expect(patchRemoteProviderVersionSource(source)).toBe(source)
  })

  it('disables only the Sentry build plugin for isolated Remote artifacts', () => {
    const source = `plugins: [\n  sentryWebpackPlugin({\n    org: 'kook',\n    telemetry: false\n  }),\n  new ModuleFederationPlugin()\n]`

    expect(patchRemoteSentryPluginSource(source)).toBe(
      `plugins: [\n  sentryWebpackPlugin({\n    disable: process.env.CUDDLY_DISABLE_SENTRY_UPLOAD === '1',\n    org: 'kook',\n    telemetry: false\n  }),\n  new ModuleFederationPlugin()\n]`
    )
  })

  it('leaves Remote configs without a Sentry build plugin unchanged', () => {
    const source = `plugins: [new ModuleFederationPlugin()]`
    expect(patchRemoteSentryPluginSource(source)).toBe(source)
  })

  it('keeps an already patched Sentry build plugin unchanged', () => {
    const source = `sentryWebpackPlugin({\n  disable: process.env.CUDDLY_DISABLE_SENTRY_UPLOAD === '1'\n})`
    expect(patchRemoteSentryPluginSource(source)).toBe(source)
  })
})

describe('package manager registry environment', () => {
  it('uses npmmirror for npm, pnpm, and Corepack when enabled', () => {
    const environment = packageManagerEnvironment(
      {
        PATH: '/usr/bin',
        npm_config_registry: 'https://registry.example.test',
        COREPACK_NPM_REGISTRY: 'https://registry.example.test',
      },
      true
    )

    expect(environment).toMatchObject({
      PATH: '/usr/bin',
      npm_config_registry: 'https://registry.npmmirror.com',
      COREPACK_NPM_REGISTRY: 'https://registry.npmmirror.com',
    })
  })

  it('leaves registry selection to the project when disabled', () => {
    const environment = packageManagerEnvironment(
      {
        PATH: '/usr/bin',
        npm_config_registry: 'https://registry.example.test',
        NPM_CONFIG_REGISTRY: 'https://registry.example.test',
        COREPACK_NPM_REGISTRY: 'https://registry.example.test',
      },
      false
    )

    expect(environment).toEqual({ PATH: '/usr/bin' })
  })

  it('enables dependency build scripts for both pnpm 10 and pnpm 11', () => {
    const environment = packageManagerEnvironment({ PATH: '/usr/bin' }, true, true)

    expect(environment).toMatchObject({
      npm_config_dangerously_allow_all_builds: 'true',
      pnpm_config_dangerously_allow_all_builds: 'true',
    })
  })

  it('removes dependency build overrides outside the install command', () => {
    const environment = packageManagerEnvironment(
      {
        PATH: '/usr/bin',
        npm_config_dangerously_allow_all_builds: 'true',
        pnpm_config_dangerously_allow_all_builds: 'true',
      },
      true
    )

    expect(environment).not.toHaveProperty('npm_config_dangerously_allow_all_builds')
    expect(environment).not.toHaveProperty('pnpm_config_dangerously_allow_all_builds')
  })
})

describe('pnpm command detection', () => {
  it.each([
    'pnpm install',
    'corepack pnpm install',
    'pnpm@11.22.0 install',
    'CI=true pnpm install',
    'cd app && pnpm install',
  ])('%s', (command) => {
    expect(commandUsesPnpm(command)).toBe(true)
  })

  it.each(['npm install', 'yarn install', 'echo pnpm'])('%s', (command) => {
    expect(commandUsesPnpm(command)).toBe(false)
  })
})

describe('runner response heartbeat', () => {
  it('writes a blank NDJSON line while the response remains open', () => {
    const chunks: string[] = []
    const written = writeRunnerHeartbeat({
      destroyed: false,
      writableEnded: false,
      write: (chunk: string) => {
        chunks.push(chunk)
        return true
      },
    })

    expect(written).toBe(true)
    expect(chunks).toEqual(['\n'])
  })

  it('does not write after the response closes', () => {
    const written = writeRunnerHeartbeat({
      destroyed: true,
      writableEnded: false,
      write: () => {
        throw new Error('should not write')
      },
    })

    expect(written).toBe(false)
  })
})
