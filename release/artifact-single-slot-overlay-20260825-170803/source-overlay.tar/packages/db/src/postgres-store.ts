import { randomUUID } from 'node:crypto'

import type {
  Artifact,
  ArtifactManifest,
  BranchCatalogItem,
  BuildJob,
  BuildJobEvent,
  BuildTarget,
  EnvironmentMatrix,
  EnvironmentRecord,
  EnvironmentRevision,
  PreviewSession,
  SiteBinding,
} from '@cuddly/contracts'
import { Pool, type PoolClient, type QueryResultRow } from 'pg'

import { schemaSql } from './schema'
import { PROJECT_TEMPLATES } from './project-templates'
import {
  type BuildJobUpdate,
  type CreateBuildJobRecord,
  type CreatePreviewSessionRecord,
  type CuddlyStore,
  InvalidSelectionError,
  PREVIEW_REVOKE_GRACE_MS,
  type PublishRevisionRecord,
  RevisionConflictError,
  type RuntimeSettingChange,
  type RuntimeSettingRecord,
} from './store'

function iso(value: Date | string | null): string | null {
  if (value === null) return null
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString()
}

function mapTarget(row: QueryResultRow): BuildTarget {
  return {
    id: row.id,
    name: row.name,
    kind: row.kind,
    repositoryUrl: row.repository_url,
    defaultBranch: row.default_branch,
    installCommand: row.install_command,
    buildCommand: row.build_command,
    outputDirectory: row.output_directory,
    siteAdapter: row.site_adapter,
    enabled: row.enabled,
    required: row.required,
    configurationSource: row.configuration_source,
  }
}

function mapJob(row: QueryResultRow): BuildJob {
  return {
    id: row.id,
    targetId: row.target_id,
    branch: row.branch,
    profile: row.profile,
    status: row.status,
    requestedBy: row.requested_by,
    createdAt: iso(row.created_at)!,
    startedAt: iso(row.started_at),
    finishedAt: iso(row.finished_at),
    failureCode: row.failure_code,
    failureMessage: row.failure_message,
    logPath: row.log_path,
    targetSnapshot: row.target_snapshot ?? null,
  }
}

function mapJobEvent(row: QueryResultRow): BuildJobEvent {
  return {
    id: String(row.id),
    jobId: row.job_id,
    status: row.status,
    createdAt: iso(row.created_at)!,
  }
}

function mapArtifact(row: QueryResultRow): Artifact {
  return {
    id: row.id,
    buildJobId: row.build_job_id,
    targetId: row.target_id,
    branch: row.branch,
    status: row.status,
    storageKey: row.storage_key,
    manifest: row.manifest as ArtifactManifest,
    builtAt: iso(row.built_at)!,
    createdBy: row.created_by,
  }
}

function mapEnvironment(row: QueryResultRow): EnvironmentRecord {
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    status: row.status,
    currentRevisionId: row.current_revision_id,
  }
}

function mapPreviewSession(row: QueryResultRow): PreviewSession {
  return {
    token: row.token,
    createdBy: row.created_by,
    createdAt: iso(row.created_at)!,
    expiresAt: iso(row.expires_at)!,
    siteBindingId: row.site_binding_id ?? undefined,
    siteArtifactId: row.site_artifact_id ?? undefined,
    selections: row.selections as PreviewSession['selections'],
  }
}

function mapSiteBinding(row: QueryResultRow): SiteBinding {
  return {
    id: row.id,
    name: row.name,
    hostname: row.hostname,
    targetId: row.target_id,
    environmentSlug: row.environment_slug,
    upstreamOrigin: row.upstream_origin,
    officialOrigin: row.official_origin,
    enabled: row.enabled,
    remoteTargetIds: [...(row.remote_target_ids as string[])],
    resourceProxyPrefixes: [...(row.resource_proxy_prefixes as string[])],
  }
}

function normalizeHostname(value: string): string {
  return value.trim().toLowerCase().replace(/\.$/, '').replace(/:\d+$/, '')
}

function normalizeOrigin(value: string): string {
  try {
    return new URL(value).origin
  } catch {
    return value.trim().replace(/\/$/, '')
  }
}

export class PostgresStore implements CuddlyStore {
  readonly pool: Pool

  constructor(connectionString: string) {
    this.pool = new Pool({ connectionString })
  }

  async initialize(): Promise<void> {
    const client = await this.pool.connect()
    try {
      await client.query("SELECT pg_advisory_lock(hashtext('cuddly-schema-v1'))")
      await client.query(schemaSql)
      for (const target of PROJECT_TEMPLATES) {
        await client.query(
          `INSERT INTO build_targets
            (id, name, kind, repository_url, default_branch, install_command, build_command,
             output_directory, site_adapter, enabled, required, configuration_source)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
           ON CONFLICT (id) DO NOTHING`,
          [
            target.id,
            target.name,
            target.kind,
            target.repositoryUrl,
            target.defaultBranch,
            target.installCommand,
            target.buildCommand,
            target.outputDirectory,
            target.siteAdapter,
            target.enabled,
            target.required,
            target.configurationSource,
          ]
        )
      }
    } finally {
      await client.query("SELECT pg_advisory_unlock(hashtext('cuddly-schema-v1'))")
      client.release()
    }
  }

  async close(): Promise<void> {
    await this.pool.end()
  }

  async listBuildTargets(includeDisabled = false): Promise<BuildTarget[]> {
    const result = await this.pool.query(
      `SELECT * FROM build_targets
       ${includeDisabled ? '' : 'WHERE enabled = true'}
       ORDER BY created_at, id`
    )
    return result.rows.map(mapTarget)
  }

  async getBuildTarget(id: string): Promise<BuildTarget | null> {
    const result = await this.pool.query('SELECT * FROM build_targets WHERE id = $1', [id])
    return result.rows[0] ? mapTarget(result.rows[0]) : null
  }

  async saveBuildTarget(target: BuildTarget, actor: string): Promise<BuildTarget> {
    const client = await this.pool.connect()
    try {
      await client.query('BEGIN')
      const result = await client.query(
        `INSERT INTO build_targets
          (id, name, kind, repository_url, default_branch, install_command, build_command,
           output_directory, site_adapter, enabled, required, configuration_source, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, now())
         ON CONFLICT (id) DO UPDATE SET
           name = EXCLUDED.name,
           kind = EXCLUDED.kind,
           repository_url = EXCLUDED.repository_url,
           default_branch = EXCLUDED.default_branch,
           install_command = EXCLUDED.install_command,
           build_command = EXCLUDED.build_command,
           output_directory = EXCLUDED.output_directory,
           site_adapter = EXCLUDED.site_adapter,
           enabled = EXCLUDED.enabled,
           required = EXCLUDED.required,
           configuration_source = EXCLUDED.configuration_source,
           updated_at = now()
         RETURNING *`,
        [
          target.id,
          target.name,
          target.kind,
          target.repositoryUrl,
          target.defaultBranch,
          target.installCommand,
          target.buildCommand,
          target.outputDirectory,
          target.siteAdapter,
          target.enabled,
          target.required,
          target.configurationSource,
        ]
      )
      await client.query(
        `INSERT INTO audit_events (id, actor, action, subject_type, subject_id, payload)
         VALUES ($1, $2, 'build-target.save', 'build-target', $3, $4::jsonb)`,
        [
          randomUUID(),
          actor,
          target.id,
          JSON.stringify({
            source: target.configurationSource,
            enabled: target.enabled,
            required: target.required,
          }),
        ]
      )
      await client.query('COMMIT')
      return mapTarget(result.rows[0]!)
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }

  async createBuildJob(record: CreateBuildJobRecord): Promise<BuildJob> {
    if (record.idempotencyKey) {
      const existing = await this.pool.query(
        'SELECT * FROM build_jobs WHERE idempotency_key = $1',
        [record.idempotencyKey]
      )
      if (existing.rows[0]) return mapJob(existing.rows[0])
    }
    const client = await this.pool.connect()
    try {
      await client.query('BEGIN')
      const result = await client.query(
        `INSERT INTO build_jobs
          (id, target_id, branch, profile, status, requested_by, idempotency_key, target_snapshot)
         VALUES ($1, $2, $3, $4, 'QUEUED', $5, $6, $7::jsonb)
         RETURNING *`,
        [
          record.id,
          record.targetId,
          record.branch,
          record.profile,
          record.requestedBy,
          record.idempotencyKey,
          JSON.stringify(record.targetSnapshot),
        ]
      )
      await client.query(
        'INSERT INTO build_job_events (job_id, status, created_at) VALUES ($1, $2, $3)',
        [record.id, 'QUEUED', result.rows[0]!.created_at]
      )
      await client.query('COMMIT')
      return mapJob(result.rows[0]!)
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }

  async getBuildJob(id: string): Promise<BuildJob | null> {
    const result = await this.pool.query('SELECT * FROM build_jobs WHERE id = $1', [id])
    return result.rows[0] ? mapJob(result.rows[0]) : null
  }

  async listBuildJobs(targetId?: string): Promise<BuildJob[]> {
    const result = targetId
      ? await this.pool.query(
          'SELECT * FROM build_jobs WHERE target_id = $1 ORDER BY created_at DESC LIMIT 200',
          [targetId]
        )
      : await this.pool.query('SELECT * FROM build_jobs ORDER BY created_at DESC LIMIT 200')
    return result.rows.map(mapJob)
  }

  async listBuildQueue(): Promise<BuildJob[]> {
    const result = await this.pool.query(
      `SELECT * FROM build_jobs
       WHERE status IN ('QUEUED', 'LEASED', 'CHECKOUT', 'INSTALLING', 'BUILDING', 'VALIDATING', 'UPLOADING')
       ORDER BY
         CASE WHEN status = 'QUEUED' THEN 1 ELSE 0 END,
         COALESCE(started_at, created_at),
         created_at,
         id`
    )
    return result.rows.map(mapJob)
  }

  async claimNextBuildJob(workerId: string): Promise<BuildJob | null> {
    const client = await this.pool.connect()
    try {
      await client.query('BEGIN')
      const result = await client.query(
        `WITH candidate AS (
         SELECT queued.id
         FROM build_jobs AS queued
         WHERE queued.status = 'QUEUED'
           AND NOT EXISTS (
             SELECT 1
             FROM build_jobs AS active
             WHERE active.target_id = queued.target_id
               AND active.status IN (
                 'LEASED', 'CHECKOUT', 'INSTALLING', 'BUILDING', 'VALIDATING', 'UPLOADING'
               )
           )
         ORDER BY queued.created_at, queued.id
         FOR UPDATE OF queued SKIP LOCKED
         LIMIT 1
       )
       UPDATE build_jobs AS job
       SET status = 'LEASED', worker_id = $1, started_at = now()
       FROM candidate
       WHERE job.id = candidate.id
         RETURNING job.*`,
        [workerId]
      )
      if (result.rows[0]) {
        await client.query(
          'INSERT INTO build_job_events (job_id, status, created_at) VALUES ($1, $2, $3)',
          [result.rows[0].id, result.rows[0].status, result.rows[0].started_at]
        )
      }
      await client.query('COMMIT')
      return result.rows[0] ? mapJob(result.rows[0]) : null
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }

  async updateBuildJob(id: string, update: BuildJobUpdate): Promise<BuildJob> {
    const client = await this.pool.connect()
    try {
      await client.query('BEGIN')
      const previous = await client.query(
        'SELECT status FROM build_jobs WHERE id = $1 FOR UPDATE',
        [id]
      )
      if (!previous.rows[0]) throw new Error(`Build job not found: ${id}`)
      const result = await client.query(
        `UPDATE build_jobs
       SET status = $2,
           started_at = COALESCE($3::timestamptz, started_at),
           finished_at = COALESCE($4::timestamptz, finished_at),
           failure_code = $5,
           failure_message = $6,
           log_path = COALESCE($7, log_path)
       WHERE id = $1
         RETURNING *`,
        [
          id,
          update.status,
          update.startedAt ?? null,
          update.finishedAt ?? null,
          update.failureCode ?? null,
          update.failureMessage ?? null,
          update.logPath ?? null,
        ]
      )
      if (previous.rows[0].status !== update.status) {
        await client.query(
          'INSERT INTO build_job_events (job_id, status, created_at) VALUES ($1, $2, $3)',
          [id, update.status, update.finishedAt ?? new Date().toISOString()]
        )
      }
      await client.query('COMMIT')
      return mapJob(result.rows[0]!)
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }

  async listBuildJobEvents(jobId: string): Promise<BuildJobEvent[]> {
    const result = await this.pool.query(
      'SELECT * FROM build_job_events WHERE job_id = $1 ORDER BY created_at, id',
      [jobId]
    )
    return result.rows.map(mapJobEvent)
  }

  async createArtifact(artifact: Artifact): Promise<Artifact> {
    const result = await this.pool.query(
      `INSERT INTO artifacts
        (id, build_job_id, target_id, branch, status, storage_key, manifest, built_at, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8, $9)
       RETURNING *`,
      [
        artifact.id,
        artifact.buildJobId,
        artifact.targetId,
        artifact.branch,
        artifact.status,
        artifact.storageKey,
        JSON.stringify(artifact.manifest),
        artifact.builtAt,
        artifact.createdBy,
      ]
    )
    return mapArtifact(result.rows[0]!)
  }

  async getArtifact(id: string): Promise<Artifact | null> {
    const result = await this.pool.query('SELECT * FROM artifacts WHERE id = $1', [id])
    return result.rows[0] ? mapArtifact(result.rows[0]) : null
  }

  async getArtifactsByIds(ids: string[]): Promise<Artifact[]> {
    const uniqueIds = [...new Set(ids)]
    if (uniqueIds.length === 0) return []
    const result = await this.pool.query(
      `SELECT *
       FROM artifacts
       WHERE id = ANY($1::uuid[])
       ORDER BY array_position($1::uuid[], id)`,
      [uniqueIds]
    )
    return result.rows.map(mapArtifact)
  }

  async getArtifactByBuildJobId(buildJobId: string): Promise<Artifact | null> {
    const result = await this.pool.query('SELECT * FROM artifacts WHERE build_job_id = $1', [
      buildJobId,
    ])
    return result.rows[0] ? mapArtifact(result.rows[0]) : null
  }

  async listArtifacts(targetId: string, branch?: string): Promise<Artifact[]> {
    const result = branch
      ? await this.pool.query(
          `SELECT * FROM artifacts
           WHERE target_id = $1 AND branch = $2 AND status = 'READY'
           ORDER BY built_at DESC`,
          [targetId, branch]
        )
      : await this.pool.query(
          `SELECT * FROM artifacts
           WHERE target_id = $1 AND status = 'READY'
           ORDER BY built_at DESC`,
          [targetId]
        )
    return result.rows.map(mapArtifact)
  }

  async listBranchCatalog(targetId: string): Promise<BranchCatalogItem[]> {
    const [target, jobs, artifacts] = await Promise.all([
      this.getBuildTarget(targetId),
      this.listBuildJobs(targetId),
      this.listArtifacts(targetId),
    ])
    const branches = new Set<string>(target ? [target.defaultBranch] : [])
    jobs.forEach((job) => branches.add(job.branch))
    artifacts.forEach((artifact) => branches.add(artifact.branch))
    return [...branches].sort().map((branch) => {
      const branchJobs = jobs.filter((job) => job.branch === branch)
      const branchArtifacts = artifacts.filter((artifact) => artifact.branch === branch)
      const active = branchJobs.find(
        (job) => !['SUCCEEDED', 'FAILED', 'CANCELED'].includes(job.status)
      )
      const latestJob = branchJobs[0] ?? null
      const latestArtifact = branchArtifacts[0] ?? null
      return {
        branch,
        buildStatus: active ? 'BUILDING' : latestJob?.status === 'FAILED' ? 'FAILED' : 'IDLE',
        latestArtifact: latestArtifact
          ? {
              id: latestArtifact.id,
              branch: latestArtifact.branch,
              builtAt: latestArtifact.builtAt,
            }
          : null,
        latestJob: latestJob
          ? {
              id: latestJob.id,
              status: latestJob.status,
              createdAt: latestJob.createdAt,
              failureMessage: latestJob.failureMessage,
            }
          : null,
      }
    })
  }

  async claimArtifactCleanupCandidates(limit: number) {
    const boundedLimit = Math.max(0, Math.min(200, Math.floor(limit)))
    if (boundedLimit === 0) return []
    const client = await this.pool.connect()
    try {
      await client.query('BEGIN')
      await client.query(
        "SELECT pg_advisory_xact_lock(hashtext('cuddly-artifact-reference-lifecycle-v1'))"
      )
      const result = await client.query(
        `WITH ranked_ready AS (
           SELECT id,
                  row_number() OVER (
                    PARTITION BY target_id, branch
                    ORDER BY built_at DESC, id DESC
                  ) AS branch_rank
           FROM artifacts
           WHERE status = 'READY'
         ), eligible AS (
           SELECT artifact.id
           FROM artifacts AS artifact
           LEFT JOIN ranked_ready AS ranked ON ranked.id = artifact.id
           WHERE (
               (artifact.status = 'READY' AND ranked.branch_rank > 1)
               OR (
                 artifact.status = 'DELETING'
                 AND COALESCE(artifact.deletion_started_at, artifact.created_at)
                   < now() - interval '5 minutes'
               )
             )
             AND NOT EXISTS (
               SELECT 1
               FROM environments AS environment
               JOIN environment_revision_items AS item
                 ON item.revision_id = environment.current_revision_id
               WHERE item.artifact_id = artifact.id
             )
             AND NOT EXISTS (
               SELECT 1
               FROM preview_sessions AS preview
               WHERE preview.expires_at > now()
                 AND (
                   preview.revoked_at IS NULL
                   OR preview.revoked_at > now() - ($2 * interval '1 millisecond')
                 )
                 AND (
                   preview.site_artifact_id = artifact.id
                   OR preview.selections @> jsonb_build_array(
                     jsonb_build_object('artifactId', artifact.id)
                   )
                 )
             )
           ORDER BY artifact.built_at, artifact.id
           LIMIT $1
         )
         UPDATE artifacts AS artifact
         SET status = 'DELETING', deletion_started_at = now()
         FROM eligible
         WHERE artifact.id = eligible.id
         RETURNING artifact.id, artifact.target_id, artifact.branch, artifact.storage_key`,
        [boundedLimit, PREVIEW_REVOKE_GRACE_MS]
      )
      await client.query('COMMIT')
      return result.rows.map((row) => ({
        id: row.id as string,
        targetId: row.target_id as string,
        branch: row.branch as string,
        storageKey: row.storage_key as string,
      }))
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }

  async completeArtifactDeletion(id: string): Promise<void> {
    await this.pool.query(
      `UPDATE artifacts
       SET status = 'DELETED', deletion_started_at = NULL
       WHERE id = $1 AND status = 'DELETING'`,
      [id]
    )
  }

  async restoreArtifactDeletion(id: string): Promise<void> {
    await this.pool.query(
      `UPDATE artifacts
       SET status = 'READY', deletion_started_at = NULL
       WHERE id = $1 AND status = 'DELETING'`,
      [id]
    )
  }

  async getRuntimeSettings(keys: string[]): Promise<RuntimeSettingRecord[]> {
    if (keys.length === 0) return []
    const result = await this.pool.query(
      'SELECT * FROM runtime_settings WHERE key = ANY($1::text[]) ORDER BY key',
      [keys]
    )
    return result.rows.map((row) => ({
      key: row.key,
      value: row.value,
      updatedBy: row.updated_by,
      updatedAt: iso(row.updated_at)!,
    }))
  }

  async updateRuntimeSettings(changes: RuntimeSettingChange[], actor: string): Promise<void> {
    const client = await this.pool.connect()
    try {
      await client.query('BEGIN')
      for (const change of changes) {
        if (change.value === null) {
          await client.query('DELETE FROM runtime_settings WHERE key = $1', [change.key])
          continue
        }
        await client.query(
          `INSERT INTO runtime_settings (key, value, updated_by, updated_at)
           VALUES ($1, $2::jsonb, $3, now())
           ON CONFLICT (key) DO UPDATE
           SET value = EXCLUDED.value, updated_by = EXCLUDED.updated_by, updated_at = now()`,
          [change.key, JSON.stringify(change.value), actor]
        )
      }
      await client.query(
        `INSERT INTO audit_events (id, actor, action, subject_type, subject_id, payload)
         VALUES ($1, $2, 'runtime_settings.update', 'settings', 'runtime', $3::jsonb)`,
        [
          randomUUID(),
          actor,
          JSON.stringify({
            keys: changes.map((change) => change.key),
            reset: changes.filter((change) => change.value === null).map((change) => change.key),
          }),
        ]
      )
      await client.query('COMMIT')
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }

  async listSiteBindings(includeDisabled = false): Promise<SiteBinding[]> {
    const result = await this.pool.query(
      `SELECT * FROM site_bindings
       ${includeDisabled ? '' : 'WHERE enabled = true'}
       ORDER BY hostname, id`
    )
    return result.rows.map(mapSiteBinding)
  }

  async getSiteBinding(id: string): Promise<SiteBinding | null> {
    const result = await this.pool.query('SELECT * FROM site_bindings WHERE id = $1', [id])
    return result.rows[0] ? mapSiteBinding(result.rows[0]) : null
  }

  async getSiteBindingByHostname(hostname: string): Promise<SiteBinding | null> {
    const result = await this.pool.query(
      'SELECT * FROM site_bindings WHERE hostname = $1 AND enabled = true',
      [normalizeHostname(hostname)]
    )
    return result.rows[0] ? mapSiteBinding(result.rows[0]) : null
  }

  async getSiteBindingByOfficialOrigin(officialOrigin: string): Promise<SiteBinding | null> {
    const result = await this.pool.query(
      'SELECT * FROM site_bindings WHERE official_origin = $1 AND enabled = true',
      [normalizeOrigin(officialOrigin)]
    )
    return result.rows[0] ? mapSiteBinding(result.rows[0]) : null
  }

  async saveSiteBinding(binding: SiteBinding, actor: string): Promise<SiteBinding> {
    const normalized: SiteBinding = {
      ...binding,
      hostname: normalizeHostname(binding.hostname),
      upstreamOrigin: normalizeOrigin(binding.upstreamOrigin),
      officialOrigin: normalizeOrigin(binding.officialOrigin),
      remoteTargetIds: [...binding.remoteTargetIds],
      resourceProxyPrefixes: [...binding.resourceProxyPrefixes],
    }
    const client = await this.pool.connect()
    try {
      await client.query('BEGIN')
      const result = await client.query(
        `INSERT INTO site_bindings
          (id, name, hostname, target_id, environment_slug, upstream_origin, official_origin,
           enabled, remote_target_ids, resource_proxy_prefixes, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9::jsonb, $10::jsonb, now())
         ON CONFLICT (id) DO UPDATE SET
           name = EXCLUDED.name,
           hostname = EXCLUDED.hostname,
           target_id = EXCLUDED.target_id,
           environment_slug = EXCLUDED.environment_slug,
           upstream_origin = EXCLUDED.upstream_origin,
           official_origin = EXCLUDED.official_origin,
           enabled = EXCLUDED.enabled,
           remote_target_ids = EXCLUDED.remote_target_ids,
           resource_proxy_prefixes = EXCLUDED.resource_proxy_prefixes,
           updated_at = now()
         RETURNING *`,
        [
          normalized.id,
          normalized.name,
          normalized.hostname,
          normalized.targetId,
          normalized.environmentSlug,
          normalized.upstreamOrigin,
          normalized.officialOrigin,
          normalized.enabled,
          JSON.stringify(normalized.remoteTargetIds),
          JSON.stringify(normalized.resourceProxyPrefixes),
        ]
      )
      await client.query(
        `INSERT INTO audit_events (id, actor, action, subject_type, subject_id, payload)
         VALUES ($1, $2, 'site-binding.save', 'site-binding', $3, $4::jsonb)`,
        [
          randomUUID(),
          actor,
          normalized.id,
          JSON.stringify({
            hostname: normalized.hostname,
            targetId: normalized.targetId,
            enabled: normalized.enabled,
            resourceProxyPrefixes: normalized.resourceProxyPrefixes,
          }),
        ]
      )
      await client.query('COMMIT')
      return mapSiteBinding(result.rows[0]!)
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }

  async deleteSiteBinding(id: string, actor: string): Promise<boolean> {
    const client = await this.pool.connect()
    try {
      await client.query('BEGIN')
      const result = await client.query('DELETE FROM site_bindings WHERE id = $1 RETURNING id', [
        id,
      ])
      if (!result.rows[0]) {
        await client.query('ROLLBACK')
        return false
      }
      await client.query(
        `INSERT INTO audit_events (id, actor, action, subject_type, subject_id)
         VALUES ($1, $2, 'site-binding.delete', 'site-binding', $3)`,
        [randomUUID(), actor, id]
      )
      await client.query('COMMIT')
      return true
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }

  async createPreviewSession(record: CreatePreviewSessionRecord): Promise<PreviewSession> {
    const client = await this.pool.connect()
    try {
      await client.query('BEGIN')
      await client.query(
        "SELECT pg_advisory_xact_lock(hashtext('cuddly-artifact-reference-lifecycle-v1'))"
      )
      const artifactIds = [
        record.siteArtifactId,
        ...record.selections.map((selection) => selection.artifactId),
      ].filter((id): id is string => Boolean(id))
      for (const artifactId of new Set(artifactIds)) {
        const artifact = await client.query(
          'SELECT status FROM artifacts WHERE id = $1 FOR SHARE',
          [artifactId]
        )
        if (artifact.rows[0]?.status !== 'READY') {
          throw new InvalidSelectionError(`Artifact is not ready: ${artifactId}`)
        }
      }
      const result = await client.query(
        `INSERT INTO preview_sessions
          (token, created_by, site_binding_id, site_artifact_id, selections, expires_at)
         VALUES ($1, $2, $3, $4, $5::jsonb, $6)
         RETURNING *`,
        [
          record.token,
          record.createdBy,
          record.siteBindingId ?? null,
          record.siteArtifactId ?? null,
          JSON.stringify(record.selections),
          record.expiresAt,
        ]
      )
      await client.query('COMMIT')
      return mapPreviewSession(result.rows[0]!)
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }

  async getPreviewSession(token: string): Promise<PreviewSession | null> {
    const result = await this.pool.query(
      `SELECT *
       FROM preview_sessions
       WHERE token = $1 AND expires_at > now() AND revoked_at IS NULL`,
      [token]
    )
    return result.rows[0] ? mapPreviewSession(result.rows[0]) : null
  }

  async revokePreviewSession(token: string): Promise<boolean> {
    const result = await this.pool.query(
      `UPDATE preview_sessions
       SET revoked_at = COALESCE(revoked_at, now())
       WHERE token = $1 AND revoked_at IS NULL`,
      [token]
    )
    return (result.rowCount ?? 0) > 0
  }

  async isArtifactReferencedByActivePreview(artifactId: string): Promise<boolean> {
    const result = await this.pool.query(
      `SELECT 1
       FROM preview_sessions
       WHERE expires_at > now()
         AND (revoked_at IS NULL OR revoked_at > now() - ($3 * interval '1 millisecond'))
         AND (site_artifact_id = $1 OR selections @> $2::jsonb)
       LIMIT 1`,
      [artifactId, JSON.stringify([{ artifactId }]), PREVIEW_REVOKE_GRACE_MS]
    )
    return Boolean(result.rows[0])
  }

  async isRemoteArtifactReferenced(artifactId: string): Promise<boolean> {
    const result = await this.pool.query(
      `SELECT EXISTS (
         SELECT 1
         FROM preview_sessions
         WHERE expires_at > now()
           AND (revoked_at IS NULL OR revoked_at > now() - ($3 * interval '1 millisecond'))
           AND (site_artifact_id = $1 OR selections @> $2::jsonb)
         UNION ALL
         SELECT 1
         FROM environment_artifact_refs
         WHERE artifact_id = $1
       ) AS referenced`,
      [artifactId, JSON.stringify([{ artifactId }]), PREVIEW_REVOKE_GRACE_MS]
    )
    return result.rows[0]?.referenced === true
  }

  async getEnvironment(idOrSlug: string): Promise<EnvironmentRecord | null> {
    const result = await this.pool.query(
      'SELECT * FROM environments WHERE id::text = $1 OR slug = $1',
      [idOrSlug]
    )
    return result.rows[0] ? mapEnvironment(result.rows[0]) : null
  }

  private async getRevision(
    client: Pool | PoolClient,
    revisionId: string
  ): Promise<EnvironmentRevision | null> {
    const result = await client.query('SELECT * FROM environment_revisions WHERE id = $1', [
      revisionId,
    ])
    if (!result.rows[0]) return null
    const items = await client.query(
      'SELECT * FROM environment_revision_items WHERE revision_id = $1 ORDER BY target_id',
      [revisionId]
    )
    const row = result.rows[0]
    return {
      id: row.id,
      environmentId: row.environment_id,
      revisionNo: row.revision_no,
      message: row.message,
      createdBy: row.created_by,
      createdAt: iso(row.created_at)!,
      selections: items.rows.map((item) => ({
        targetId: item.target_id,
        artifactId: item.artifact_id,
        branch: item.branch,
        builtAt: iso(item.built_at)!,
      })),
    }
  }

  async getEnvironmentMatrix(idOrSlug: string): Promise<EnvironmentMatrix | null> {
    const environment = await this.getEnvironment(idOrSlug)
    if (!environment) return null
    const revision = environment.currentRevisionId
      ? await this.getRevision(this.pool, environment.currentRevisionId)
      : null
    const targets = await this.listBuildTargets(true)
    const jobs = await this.listBuildJobs()
    return {
      environment,
      revision,
      rows: await Promise.all(
        targets.map(async (target) => {
          const artifacts = await this.listArtifacts(target.id)
          const activeJob = jobs.find(
            (job) =>
              job.targetId === target.id &&
              !['SUCCEEDED', 'FAILED', 'CANCELED'].includes(job.status)
          )
          const current =
            revision?.selections.find((selection) => selection.targetId === target.id) ?? null
          return {
            target: {
              id: target.id,
              name: target.name,
              kind: target.kind,
              defaultBranch: target.defaultBranch,
              enabled: target.enabled,
              required: target.required,
              configured: Boolean(target.repositoryUrl),
            },
            current,
            latestArtifact: artifacts[0]
              ? { id: artifacts[0].id, branch: artifacts[0].branch, builtAt: artifacts[0].builtAt }
              : null,
            activeJob: activeJob
              ? {
                  id: activeJob.id,
                  branch: activeJob.branch,
                  status: activeJob.status,
                  createdAt: activeJob.createdAt,
                }
              : null,
          }
        })
      ),
    }
  }

  async publishRevision(record: PublishRevisionRecord): Promise<EnvironmentRevision> {
    const client = await this.pool.connect()
    try {
      await client.query('BEGIN')
      await client.query(
        "SELECT pg_advisory_xact_lock(hashtext('cuddly-artifact-reference-lifecycle-v1'))"
      )
      const environmentResult = await client.query(
        'SELECT * FROM environments WHERE id::text = $1 OR slug = $1 FOR UPDATE',
        [record.environmentId]
      )
      if (!environmentResult.rows[0])
        throw new Error(`Environment not found: ${record.environmentId}`)
      const environment = mapEnvironment(environmentResult.rows[0])
      if (environment.currentRevisionId !== record.baseRevisionId) {
        throw new RevisionConflictError(environment.currentRevisionId)
      }

      const selectedTargets = new Set<string>()
      const artifacts: Artifact[] = []
      for (const selection of record.selections) {
        if (selectedTargets.has(selection.targetId)) {
          throw new InvalidSelectionError(`Duplicate target selection: ${selection.targetId}`)
        }
        selectedTargets.add(selection.targetId)
        const artifactResult = await client.query(
          'SELECT * FROM artifacts WHERE id = $1 FOR SHARE',
          [selection.artifactId]
        )
        if (!artifactResult.rows[0])
          throw new InvalidSelectionError(`Artifact not found: ${selection.artifactId}`)
        const artifact = mapArtifact(artifactResult.rows[0])
        if (artifact.status !== 'READY') {
          throw new InvalidSelectionError(`Artifact is not ready: ${artifact.id}`)
        }
        if (artifact.targetId !== selection.targetId) {
          throw new InvalidSelectionError(`Artifact target mismatch: ${artifact.id}`)
        }
        artifacts.push(artifact)
      }

      const requiredTargets = await client.query(
        'SELECT id FROM build_targets WHERE enabled = true AND required = true'
      )
      for (const target of requiredTargets.rows) {
        if (!selectedTargets.has(target.id)) {
          throw new InvalidSelectionError(`Required target is missing: ${target.id}`)
        }
      }

      const revisionId = randomUUID()
      const nextRevision = await client.query(
        'SELECT COALESCE(MAX(revision_no), 0) + 1 AS revision_no FROM environment_revisions WHERE environment_id = $1',
        [environment.id]
      )
      const revisionNo = Number(nextRevision.rows[0]!.revision_no)
      await client.query(
        `INSERT INTO environment_revisions
          (id, environment_id, revision_no, message, created_by)
         VALUES ($1, $2, $3, $4, $5)`,
        [revisionId, environment.id, revisionNo, record.message, record.createdBy]
      )

      for (const artifact of artifacts) {
        await client.query(
          `INSERT INTO environment_revision_items
            (revision_id, target_id, artifact_id, branch, built_at)
           VALUES ($1, $2, $3, $4, $5)`,
          [revisionId, artifact.targetId, artifact.id, artifact.branch, artifact.builtAt]
        )
        await client.query(
          `INSERT INTO environment_artifact_refs
            (environment_id, artifact_id, first_revision_id, last_revision_id, last_referenced_at)
           VALUES ($1, $2, $3, $3, now())
           ON CONFLICT (environment_id, artifact_id)
           DO UPDATE SET last_revision_id = EXCLUDED.last_revision_id, last_referenced_at = now()`,
          [environment.id, artifact.id, revisionId]
        )
      }

      await client.query('UPDATE environments SET current_revision_id = $2 WHERE id = $1', [
        environment.id,
        revisionId,
      ])
      await client.query(
        `INSERT INTO audit_events (id, actor, action, subject_type, subject_id, payload)
         VALUES ($1, $2, 'environment.revision.publish', 'environment', $3, $4::jsonb)`,
        [randomUUID(), record.createdBy, environment.id, JSON.stringify({ revisionId, revisionNo })]
      )
      await client.query('COMMIT')
      return (await this.getRevision(this.pool, revisionId))!
    } catch (error) {
      await client.query('ROLLBACK')
      throw error
    } finally {
      client.release()
    }
  }

  async resolveCurrentArtifact(
    environmentSlug: string,
    targetId: string
  ): Promise<Artifact | null> {
    const result = await this.pool.query(
      `SELECT artifact.*
       FROM environments environment
       JOIN environment_revision_items item ON item.revision_id = environment.current_revision_id
       JOIN artifacts artifact ON artifact.id = item.artifact_id
       WHERE environment.slug = $1 AND item.target_id = $2`,
      [environmentSlug, targetId]
    )
    return result.rows[0] ? mapArtifact(result.rows[0]) : null
  }

  async resolveCurrentRemoteArtifacts(
    environmentSlug: string,
    targetIds: string[]
  ): Promise<Artifact[]> {
    if (targetIds.length === 0) return []
    const result = await this.pool.query(
      `SELECT artifact.*
       FROM environments environment
       JOIN environment_revision_items item ON item.revision_id = environment.current_revision_id
       JOIN artifacts artifact ON artifact.id = item.artifact_id
       JOIN build_targets target ON target.id = item.target_id
       WHERE environment.slug = $1
         AND item.target_id = ANY($2::text[])
         AND target.enabled = true
         AND target.kind = 'remote'
         AND target.site_adapter = 'kook-remote-v1'
       ORDER BY item.target_id`,
      [environmentSlug, targetIds]
    )
    return result.rows.map(mapArtifact)
  }

  async isArtifactReferenced(environmentId: string, artifactId: string): Promise<boolean> {
    const result = await this.pool.query(
      'SELECT 1 FROM environment_artifact_refs WHERE environment_id = $1 AND artifact_id = $2',
      [environmentId, artifactId]
    )
    return result.rowCount === 1
  }
}
