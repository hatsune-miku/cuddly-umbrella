import { randomUUID } from 'node:crypto'

import type {
  Artifact,
  BranchCatalogItem,
  BuildJob,
  BuildJobEvent,
  BuildTarget,
  EnvironmentMatrix,
  EnvironmentRecord,
  EnvironmentRevision,
  PreviewSession,
  SiteBinding,
} from '@cuddly/contracts'

import {
  type BuildJobUpdate,
  type CreateBuildJobRecord,
  type CreatePreviewSessionRecord,
  type CuddlyStore,
  InvalidSelectionError,
  PREVIEW_REVOKE_GRACE_MS,
  type PublishRevisionRecord,
  RevisionConflictError,
  type RuntimeSettingChange,
  type RuntimeSettingRecord,
} from './store'
import { PROJECT_TEMPLATES } from './project-templates'

function compareTimeDesc(a: string, b: string): number {
  return b.localeCompare(a)
}

function normalizeHostname(value: string): string {
  return value.trim().toLowerCase().replace(/\.$/, '').replace(/:\d+$/, '')
}

function normalizeOrigin(value: string): string {
  try {
    return new URL(value).origin
  } catch {
    return value.trim().replace(/\/$/, '')
  }
}

export class MemoryStore implements CuddlyStore {
  private readonly targets = new Map<string, BuildTarget>()
  private readonly jobs = new Map<string, BuildJob>()
  private readonly jobEvents = new Map<string, BuildJobEvent[]>()
  private readonly artifacts = new Map<string, Artifact>()
  private readonly environments = new Map<string, EnvironmentRecord>()
  private readonly revisions = new Map<string, EnvironmentRevision>()
  private readonly artifactReferences = new Set<string>()
  private readonly runtimeSettings = new Map<string, RuntimeSettingRecord>()
  private readonly siteBindings = new Map<string, SiteBinding>()
  private readonly previewSessions = new Map<string, PreviewSession>()
  private readonly previewRevokedAt = new Map<string, number>()
  private readonly artifactDeletionStartedAt = new Map<string, number>()

  constructor(private readonly now: () => number = Date.now) {
    for (const target of PROJECT_TEMPLATES) this.targets.set(target.id, { ...target })

    const environment: EnvironmentRecord = {
      id: '00000000-0000-4000-8000-000000000001',
      slug: 'shared',
      name: '公共调试环境',
      status: 'ACTIVE',
      currentRevisionId: null,
    }
    this.environments.set(environment.id, environment)
    this.environments.set(environment.slug, environment)
  }

  async initialize(): Promise<void> {}
  async close(): Promise<void> {}

  async listBuildTargets(includeDisabled = false): Promise<BuildTarget[]> {
    return [...this.targets.values()].filter((target) => includeDisabled || target.enabled)
  }

  async getBuildTarget(id: string): Promise<BuildTarget | null> {
    return this.targets.get(id) ?? null
  }

  async saveBuildTarget(target: BuildTarget, _actor: string): Promise<BuildTarget> {
    this.targets.set(target.id, { ...target })
    return target
  }

  async createBuildJob(record: CreateBuildJobRecord): Promise<BuildJob> {
    if (record.idempotencyKey) {
      const existing = [...this.jobs.values()].find(
        (job) =>
          (job as BuildJob & { idempotencyKey?: string }).idempotencyKey === record.idempotencyKey
      )
      if (existing) return existing
    }

    const job: BuildJob & { idempotencyKey?: string | null; workerId?: string } = {
      id: record.id,
      targetId: record.targetId,
      branch: record.branch,
      profile: record.profile,
      status: 'QUEUED',
      requestedBy: record.requestedBy,
      createdAt: new Date().toISOString(),
      startedAt: null,
      finishedAt: null,
      failureCode: null,
      failureMessage: null,
      logPath: null,
      targetSnapshot: record.targetSnapshot,
      idempotencyKey: record.idempotencyKey,
    }
    this.jobs.set(job.id, job)
    this.appendJobEvent(job.id, job.status, job.createdAt)
    return job
  }

  async getBuildJob(id: string): Promise<BuildJob | null> {
    return this.jobs.get(id) ?? null
  }

  async listBuildJobs(targetId?: string): Promise<BuildJob[]> {
    return [...this.jobs.values()]
      .filter((job) => !targetId || job.targetId === targetId)
      .sort((a, b) => compareTimeDesc(a.createdAt, b.createdAt))
  }

  async listBuildQueue(): Promise<BuildJob[]> {
    const activeStatuses = new Set([
      'QUEUED',
      'LEASED',
      'CHECKOUT',
      'INSTALLING',
      'BUILDING',
      'VALIDATING',
      'UPLOADING',
    ])
    return [...this.jobs.values()]
      .filter((job) => activeStatuses.has(job.status))
      .sort((a, b) => {
        const aQueued = a.status === 'QUEUED' ? 1 : 0
        const bQueued = b.status === 'QUEUED' ? 1 : 0
        return (
          aQueued - bQueued ||
          (a.startedAt || a.createdAt).localeCompare(b.startedAt || b.createdAt) ||
          a.createdAt.localeCompare(b.createdAt) ||
          a.id.localeCompare(b.id)
        )
      })
  }

  async claimNextBuildJob(workerId: string): Promise<BuildJob | null> {
    const activeStatuses = new Set([
      'LEASED',
      'CHECKOUT',
      'INSTALLING',
      'BUILDING',
      'VALIDATING',
      'UPLOADING',
    ])
    const activeTargets = new Set(
      [...this.jobs.values()]
        .filter((candidate) => activeStatuses.has(candidate.status))
        .map((candidate) => candidate.targetId)
    )
    const job = [...this.jobs.values()]
      .filter(
        (candidate) => candidate.status === 'QUEUED' && !activeTargets.has(candidate.targetId)
      )
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id))[0]
    if (!job) return null
    const claimed = job as BuildJob & { workerId?: string }
    claimed.status = 'LEASED'
    claimed.startedAt = new Date().toISOString()
    claimed.workerId = workerId
    this.appendJobEvent(claimed.id, claimed.status, claimed.startedAt)
    return claimed
  }

  async updateBuildJob(id: string, update: BuildJobUpdate): Promise<BuildJob> {
    const job = this.jobs.get(id)
    if (!job) throw new Error(`Build job not found: ${id}`)
    const previousStatus = job.status
    Object.assign(job, update)
    if (job.status !== previousStatus) {
      this.appendJobEvent(job.id, job.status, job.finishedAt || new Date().toISOString())
    }
    return job
  }

  async listBuildJobEvents(jobId: string): Promise<BuildJobEvent[]> {
    return [...(this.jobEvents.get(jobId) || [])]
  }

  async createArtifact(artifact: Artifact): Promise<Artifact> {
    if (this.artifacts.has(artifact.id)) throw new Error(`Artifact already exists: ${artifact.id}`)
    this.artifacts.set(artifact.id, artifact)
    return artifact
  }

  async getArtifact(id: string): Promise<Artifact | null> {
    return this.artifacts.get(id) ?? null
  }

  async getArtifactsByIds(ids: string[]): Promise<Artifact[]> {
    return [...new Set(ids)]
      .map((id) => this.artifacts.get(id))
      .filter((artifact): artifact is Artifact => Boolean(artifact))
  }

  async getArtifactByBuildJobId(buildJobId: string): Promise<Artifact | null> {
    return (
      [...this.artifacts.values()].find((artifact) => artifact.buildJobId === buildJobId) ?? null
    )
  }

  async listArtifacts(targetId: string, branch?: string): Promise<Artifact[]> {
    return [...this.artifacts.values()]
      .filter(
        (artifact) =>
          artifact.targetId === targetId &&
          artifact.status === 'READY' &&
          (!branch || artifact.branch === branch)
      )
      .sort((a, b) => compareTimeDesc(a.builtAt, b.builtAt))
  }

  async listBranchCatalog(targetId: string): Promise<BranchCatalogItem[]> {
    const branches = new Set<string>()
    for (const artifact of this.artifacts.values()) {
      if (artifact.targetId === targetId) branches.add(artifact.branch)
    }
    for (const job of this.jobs.values()) {
      if (job.targetId === targetId) branches.add(job.branch)
    }
    const target = this.targets.get(targetId)
    if (target) branches.add(target.defaultBranch)

    return [...branches].sort().map((branch) => {
      const artifacts = [...this.artifacts.values()]
        .filter(
          (artifact) =>
            artifact.targetId === targetId &&
            artifact.branch === branch &&
            artifact.status === 'READY'
        )
        .sort((a, b) => compareTimeDesc(a.builtAt, b.builtAt))
      const jobs = [...this.jobs.values()]
        .filter((job) => job.targetId === targetId && job.branch === branch)
        .sort((a, b) => compareTimeDesc(a.createdAt, b.createdAt))
      const active = jobs.find((job) => !['SUCCEEDED', 'FAILED', 'CANCELED'].includes(job.status))
      const latestJob = jobs[0] ?? null
      return {
        branch,
        buildStatus: active ? 'BUILDING' : latestJob?.status === 'FAILED' ? 'FAILED' : 'IDLE',
        latestArtifact: artifacts[0]
          ? {
              id: artifacts[0].id,
              branch: artifacts[0].branch,
              builtAt: artifacts[0].builtAt,
            }
          : null,
        latestJob: latestJob
          ? {
              id: latestJob.id,
              status: latestJob.status,
              createdAt: latestJob.createdAt,
              failureMessage: latestJob.failureMessage,
            }
          : null,
      }
    })
  }

  async claimArtifactCleanupCandidates(limit: number) {
    const boundedLimit = Math.max(0, Math.floor(limit))
    if (boundedLimit === 0) return []

    const newestReady = new Map<string, string>()
    const readyArtifacts = [...this.artifacts.values()]
      .filter((artifact) => artifact.status === 'READY')
      .sort((a, b) => compareTimeDesc(a.builtAt, b.builtAt) || b.id.localeCompare(a.id))
    for (const artifact of readyArtifacts) {
      const key = `${artifact.targetId}\0${artifact.branch}`
      if (!newestReady.has(key)) newestReady.set(key, artifact.id)
    }

    const now = this.now()
    const retryBefore = now - 5 * 60_000
    const candidates: Artifact[] = []
    for (const artifact of this.artifacts.values()) {
      const key = `${artifact.targetId}\0${artifact.branch}`
      const retryable =
        artifact.status === 'DELETING' &&
        (this.artifactDeletionStartedAt.get(artifact.id) ?? 0) <= retryBefore
      const superseded = artifact.status === 'READY' && newestReady.get(key) !== artifact.id
      if (!retryable && !superseded) continue
      if (this.isArtifactInCurrentRevision(artifact.id)) continue
      if (this.isArtifactReferencedByActivePreviewSync(artifact.id)) continue
      candidates.push(artifact)
    }

    candidates.sort((a, b) => a.builtAt.localeCompare(b.builtAt) || a.id.localeCompare(b.id))
    return candidates.slice(0, boundedLimit).map((artifact) => {
      artifact.status = 'DELETING'
      this.artifactDeletionStartedAt.set(artifact.id, now)
      return {
        id: artifact.id,
        targetId: artifact.targetId,
        branch: artifact.branch,
        storageKey: artifact.storageKey,
      }
    })
  }

  async completeArtifactDeletion(id: string): Promise<void> {
    const artifact = this.artifacts.get(id)
    if (artifact?.status === 'DELETING') artifact.status = 'DELETED'
    this.artifactDeletionStartedAt.delete(id)
  }

  async restoreArtifactDeletion(id: string): Promise<void> {
    const artifact = this.artifacts.get(id)
    if (artifact?.status === 'DELETING') artifact.status = 'READY'
    this.artifactDeletionStartedAt.delete(id)
  }

  private appendJobEvent(jobId: string, status: BuildJob['status'], createdAt: string): void {
    const events = this.jobEvents.get(jobId) || []
    events.push({ id: String(events.length + 1), jobId, status, createdAt })
    this.jobEvents.set(jobId, events)
  }

  async getRuntimeSettings(keys: string[]): Promise<RuntimeSettingRecord[]> {
    return keys
      .map((key) => this.runtimeSettings.get(key))
      .filter((setting): setting is RuntimeSettingRecord => Boolean(setting))
  }

  async updateRuntimeSettings(changes: RuntimeSettingChange[], actor: string): Promise<void> {
    const updatedAt = new Date().toISOString()
    for (const change of changes) {
      if (change.value === null) {
        this.runtimeSettings.delete(change.key)
        continue
      }
      this.runtimeSettings.set(change.key, {
        key: change.key,
        value: change.value,
        updatedBy: actor,
        updatedAt,
      })
    }
  }

  async listSiteBindings(includeDisabled = false): Promise<SiteBinding[]> {
    return [...this.siteBindings.values()]
      .filter((binding) => includeDisabled || binding.enabled)
      .sort((a, b) => a.hostname.localeCompare(b.hostname))
      .map((binding) => ({
        ...binding,
        remoteTargetIds: [...binding.remoteTargetIds],
        resourceProxyPrefixes: [...binding.resourceProxyPrefixes],
      }))
  }

  async getSiteBinding(id: string): Promise<SiteBinding | null> {
    const binding = this.siteBindings.get(id)
    return binding
      ? {
          ...binding,
          remoteTargetIds: [...binding.remoteTargetIds],
          resourceProxyPrefixes: [...binding.resourceProxyPrefixes],
        }
      : null
  }

  async getSiteBindingByHostname(hostname: string): Promise<SiteBinding | null> {
    const normalized = normalizeHostname(hostname)
    const binding = [...this.siteBindings.values()].find(
      (candidate) => candidate.enabled && candidate.hostname === normalized
    )
    return binding
      ? {
          ...binding,
          remoteTargetIds: [...binding.remoteTargetIds],
          resourceProxyPrefixes: [...binding.resourceProxyPrefixes],
        }
      : null
  }

  async getSiteBindingByOfficialOrigin(officialOrigin: string): Promise<SiteBinding | null> {
    const normalized = normalizeOrigin(officialOrigin)
    const binding = [...this.siteBindings.values()].find(
      (candidate) => candidate.enabled && candidate.officialOrigin === normalized
    )
    return binding
      ? {
          ...binding,
          remoteTargetIds: [...binding.remoteTargetIds],
          resourceProxyPrefixes: [...binding.resourceProxyPrefixes],
        }
      : null
  }

  async saveSiteBinding(binding: SiteBinding, _actor: string): Promise<SiteBinding> {
    const saved: SiteBinding = {
      ...binding,
      hostname: normalizeHostname(binding.hostname),
      upstreamOrigin: normalizeOrigin(binding.upstreamOrigin),
      officialOrigin: normalizeOrigin(binding.officialOrigin),
      remoteTargetIds: [...binding.remoteTargetIds],
      resourceProxyPrefixes: [...binding.resourceProxyPrefixes],
    }
    this.siteBindings.set(saved.id, saved)
    return {
      ...saved,
      remoteTargetIds: [...saved.remoteTargetIds],
      resourceProxyPrefixes: [...saved.resourceProxyPrefixes],
    }
  }

  async deleteSiteBinding(id: string, _actor: string): Promise<boolean> {
    return this.siteBindings.delete(id)
  }

  async createPreviewSession(record: CreatePreviewSessionRecord): Promise<PreviewSession> {
    const artifactIds = [
      record.siteArtifactId,
      ...record.selections.map((item) => item.artifactId),
    ].filter((id): id is string => Boolean(id))
    for (const artifactId of new Set(artifactIds)) {
      const artifact = this.artifacts.get(artifactId)
      if (!artifact || artifact.status !== 'READY') {
        throw new InvalidSelectionError(`Artifact is not ready: ${artifactId}`)
      }
    }
    const preview: PreviewSession = {
      ...record,
      createdAt: new Date(this.now()).toISOString(),
      selections: record.selections.map((selection) => ({ ...selection })),
    }
    this.previewRevokedAt.delete(preview.token)
    this.previewSessions.set(preview.token, preview)
    return preview
  }

  async getPreviewSession(token: string): Promise<PreviewSession | null> {
    const preview = this.previewSessions.get(token)
    if (!preview) return null
    if (new Date(preview.expiresAt).getTime() <= this.now()) {
      this.previewSessions.delete(token)
      this.previewRevokedAt.delete(token)
      return null
    }
    if (this.previewRevokedAt.has(token)) return null
    return preview
  }

  async revokePreviewSession(token: string): Promise<boolean> {
    if (!this.previewSessions.has(token)) return false
    if (this.previewRevokedAt.has(token)) return false
    this.previewRevokedAt.set(token, this.now())
    return true
  }

  async isArtifactReferencedByActivePreview(artifactId: string): Promise<boolean> {
    return this.isArtifactReferencedByActivePreviewSync(artifactId)
  }

  private isArtifactReferencedByActivePreviewSync(artifactId: string): boolean {
    const now = this.now()
    for (const [token, preview] of this.previewSessions) {
      if (new Date(preview.expiresAt).getTime() <= now) {
        this.previewSessions.delete(token)
        this.previewRevokedAt.delete(token)
        continue
      }
      const revokedAt = this.previewRevokedAt.get(token)
      if (revokedAt !== undefined && now - revokedAt >= PREVIEW_REVOKE_GRACE_MS) continue
      if (preview.siteArtifactId === artifactId) return true
      if (preview.selections.some((selection) => selection.artifactId === artifactId)) return true
    }
    return false
  }

  async isRemoteArtifactReferenced(artifactId: string): Promise<boolean> {
    if (await this.isArtifactReferencedByActivePreview(artifactId)) return true
    return [...this.artifactReferences].some((reference) => reference.endsWith(`:${artifactId}`))
  }

  async getEnvironment(idOrSlug: string): Promise<EnvironmentRecord | null> {
    return this.environments.get(idOrSlug) ?? null
  }

  async getEnvironmentMatrix(idOrSlug: string): Promise<EnvironmentMatrix | null> {
    const environment = await this.getEnvironment(idOrSlug)
    if (!environment) return null
    const revision = environment.currentRevisionId
      ? (this.revisions.get(environment.currentRevisionId) ?? null)
      : null
    const targets = await this.listBuildTargets(true)
    const jobs = await this.listBuildJobs()

    return {
      environment,
      revision,
      rows: await Promise.all(
        targets.map(async (target) => {
          const current =
            revision?.selections.find((selection) => selection.targetId === target.id) ?? null
          const artifacts = await this.listArtifacts(target.id)
          const activeJob = jobs.find(
            (job) =>
              job.targetId === target.id &&
              !['SUCCEEDED', 'FAILED', 'CANCELED'].includes(job.status)
          )
          return {
            target: {
              id: target.id,
              name: target.name,
              kind: target.kind,
              defaultBranch: target.defaultBranch,
              enabled: target.enabled,
              required: target.required,
              configured: Boolean(target.repositoryUrl),
            },
            current,
            latestArtifact: artifacts[0]
              ? {
                  id: artifacts[0].id,
                  branch: artifacts[0].branch,
                  builtAt: artifacts[0].builtAt,
                }
              : null,
            activeJob: activeJob
              ? {
                  id: activeJob.id,
                  branch: activeJob.branch,
                  status: activeJob.status,
                  createdAt: activeJob.createdAt,
                }
              : null,
          }
        })
      ),
    }
  }

  async publishRevision(record: PublishRevisionRecord): Promise<EnvironmentRevision> {
    const environment = await this.getEnvironment(record.environmentId)
    if (!environment) throw new Error(`Environment not found: ${record.environmentId}`)
    if (environment.currentRevisionId !== record.baseRevisionId) {
      throw new RevisionConflictError(environment.currentRevisionId)
    }

    const selections = []
    const selectedTargets = new Set<string>()
    for (const selection of record.selections) {
      if (selectedTargets.has(selection.targetId)) {
        throw new InvalidSelectionError(`Duplicate target selection: ${selection.targetId}`)
      }
      selectedTargets.add(selection.targetId)
      const artifact = this.artifacts.get(selection.artifactId)
      if (!artifact || artifact.status !== 'READY') {
        throw new InvalidSelectionError(`Artifact is not ready: ${selection.artifactId}`)
      }
      if (artifact.targetId !== selection.targetId) {
        throw new InvalidSelectionError(`Artifact target mismatch: ${selection.artifactId}`)
      }
      selections.push({
        targetId: selection.targetId,
        artifactId: artifact.id,
        branch: artifact.branch,
        builtAt: artifact.builtAt,
      })
    }

    for (const target of this.targets.values()) {
      if (target.enabled && target.required && !selectedTargets.has(target.id)) {
        throw new InvalidSelectionError(`Required target is missing: ${target.id}`)
      }
    }

    const previousRevision = environment.currentRevisionId
      ? this.revisions.get(environment.currentRevisionId)
      : null
    const revision: EnvironmentRevision = {
      id: randomUUID(),
      environmentId: environment.id,
      revisionNo: (previousRevision?.revisionNo ?? 0) + 1,
      message: record.message,
      createdBy: record.createdBy,
      createdAt: new Date().toISOString(),
      selections,
    }
    this.revisions.set(revision.id, revision)
    environment.currentRevisionId = revision.id
    for (const selection of selections) {
      this.artifactReferences.add(`${environment.id}:${selection.artifactId}`)
    }
    return revision
  }

  async resolveCurrentArtifact(
    environmentSlug: string,
    targetId: string
  ): Promise<Artifact | null> {
    const environment = await this.getEnvironment(environmentSlug)
    if (!environment?.currentRevisionId) return null
    const revision = this.revisions.get(environment.currentRevisionId)
    const selection = revision?.selections.find((item) => item.targetId === targetId)
    return selection ? (this.artifacts.get(selection.artifactId) ?? null) : null
  }

  async resolveCurrentRemoteArtifacts(
    environmentSlug: string,
    targetIds: string[]
  ): Promise<Artifact[]> {
    const environment = await this.getEnvironment(environmentSlug)
    if (!environment?.currentRevisionId || targetIds.length === 0) return []
    const revision = this.revisions.get(environment.currentRevisionId)
    const allowedTargetIds = new Set(targetIds)
    return (revision?.selections || [])
      .filter((selection) => {
        const target = this.targets.get(selection.targetId)
        return (
          allowedTargetIds.has(selection.targetId) &&
          target?.enabled &&
          target.kind === 'remote' &&
          target.siteAdapter === 'kook-remote-v1'
        )
      })
      .map((selection) => this.artifacts.get(selection.artifactId))
      .filter((artifact): artifact is Artifact => Boolean(artifact))
  }

  async isArtifactReferenced(environmentId: string, artifactId: string): Promise<boolean> {
    return this.artifactReferences.has(`${environmentId}:${artifactId}`)
  }

  private isArtifactInCurrentRevision(artifactId: string): boolean {
    const seenEnvironments = new Set<string>()
    for (const environment of this.environments.values()) {
      if (seenEnvironments.has(environment.id)) continue
      seenEnvironments.add(environment.id)
      if (!environment.currentRevisionId) continue
      const revision = this.revisions.get(environment.currentRevisionId)
      if (revision?.selections.some((selection) => selection.artifactId === artifactId)) {
        return true
      }
    }
    return false
  }
}
