import type {
  Artifact,
  BranchCatalogItem,
  BuildJob,
  BuildJobEvent,
  BuildJobStatus,
  BuildTarget,
  EnvironmentMatrix,
  EnvironmentRecord,
  EnvironmentRevision,
  PreviewSession,
  SiteBinding,
} from '@cuddly/contracts'

export const PREVIEW_REVOKE_GRACE_MS = 35_000

export interface CreateBuildJobRecord {
  id: string
  targetId: string
  branch: string
  profile: string
  requestedBy: string
  idempotencyKey: string | null
  targetSnapshot: BuildJob['targetSnapshot']
}

export interface BuildJobUpdate {
  status: BuildJobStatus
  startedAt?: string | null
  finishedAt?: string | null
  failureCode?: string | null
  failureMessage?: string | null
  logPath?: string | null
}

export interface PublishRevisionRecord {
  environmentId: string
  baseRevisionId: string | null
  message: string
  createdBy: string
  selections: Array<{ targetId: string; artifactId: string }>
}

export interface RuntimeSettingRecord {
  key: string
  value: unknown
  updatedBy: string
  updatedAt: string
}

export interface RuntimeSettingChange {
  key: string
  value: unknown | null
}

export interface CreatePreviewSessionRecord {
  token: string
  createdBy: string
  expiresAt: string
  siteBindingId?: string
  siteArtifactId?: string
  selections: PreviewSession['selections']
}

export type ArtifactCleanupCandidate = Pick<Artifact, 'id' | 'targetId' | 'branch' | 'storageKey'>

export interface CuddlyStore {
  initialize(): Promise<void>
  close(): Promise<void>

  listBuildTargets(includeDisabled?: boolean): Promise<BuildTarget[]>
  getBuildTarget(id: string): Promise<BuildTarget | null>
  saveBuildTarget(target: BuildTarget, actor: string): Promise<BuildTarget>

  createBuildJob(record: CreateBuildJobRecord): Promise<BuildJob>
  getBuildJob(id: string): Promise<BuildJob | null>
  listBuildJobs(targetId?: string): Promise<BuildJob[]>
  listBuildQueue(): Promise<BuildJob[]>
  claimNextBuildJob(workerId: string): Promise<BuildJob | null>
  updateBuildJob(id: string, update: BuildJobUpdate): Promise<BuildJob>
  listBuildJobEvents(jobId: string): Promise<BuildJobEvent[]>

  createArtifact(artifact: Artifact): Promise<Artifact>
  getArtifact(id: string): Promise<Artifact | null>
  getArtifactsByIds(ids: string[]): Promise<Artifact[]>
  getArtifactByBuildJobId(buildJobId: string): Promise<Artifact | null>
  listArtifacts(targetId: string, branch?: string): Promise<Artifact[]>
  listBranchCatalog(targetId: string): Promise<BranchCatalogItem[]>
  claimArtifactCleanupCandidates(limit: number): Promise<ArtifactCleanupCandidate[]>
  completeArtifactDeletion(id: string): Promise<void>
  restoreArtifactDeletion(id: string): Promise<void>

  getRuntimeSettings(keys: string[]): Promise<RuntimeSettingRecord[]>
  updateRuntimeSettings(changes: RuntimeSettingChange[], actor: string): Promise<void>

  listSiteBindings(includeDisabled?: boolean): Promise<SiteBinding[]>
  getSiteBinding(id: string): Promise<SiteBinding | null>
  getSiteBindingByHostname(hostname: string): Promise<SiteBinding | null>
  getSiteBindingByOfficialOrigin(officialOrigin: string): Promise<SiteBinding | null>
  saveSiteBinding(binding: SiteBinding, actor: string): Promise<SiteBinding>
  deleteSiteBinding(id: string, actor: string): Promise<boolean>

  createPreviewSession(record: CreatePreviewSessionRecord): Promise<PreviewSession>
  getPreviewSession(token: string): Promise<PreviewSession | null>
  revokePreviewSession(token: string): Promise<boolean>
  isArtifactReferencedByActivePreview(artifactId: string): Promise<boolean>
  isRemoteArtifactReferenced(artifactId: string): Promise<boolean>

  getEnvironment(idOrSlug: string): Promise<EnvironmentRecord | null>
  getEnvironmentMatrix(idOrSlug: string): Promise<EnvironmentMatrix | null>
  publishRevision(record: PublishRevisionRecord): Promise<EnvironmentRevision>
  resolveCurrentArtifact(environmentSlug: string, targetId: string): Promise<Artifact | null>
  resolveCurrentRemoteArtifacts(environmentSlug: string, targetIds: string[]): Promise<Artifact[]>
  isArtifactReferenced(environmentId: string, artifactId: string): Promise<boolean>
}

export class RevisionConflictError extends Error {
  constructor(public readonly currentRevisionId: string | null) {
    super('Environment revision changed')
    this.name = 'RevisionConflictError'
  }
}

export class InvalidSelectionError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'InvalidSelectionError'
  }
}
