export const schemaSql = String.raw`
CREATE TABLE IF NOT EXISTS build_targets (
  id text PRIMARY KEY,
  name text NOT NULL,
  kind text NOT NULL,
  repository_url text,
  default_branch text NOT NULL,
  install_command text NOT NULL DEFAULT 'corepack pnpm install --frozen-lockfile',
  build_command text NOT NULL DEFAULT 'corepack pnpm run build',
  output_directory text NOT NULL DEFAULT 'build',
  site_adapter text NOT NULL DEFAULT 'kook-online-h5-v1',
  enabled boolean NOT NULL DEFAULT true,
  required boolean NOT NULL DEFAULT false,
  configuration_source text NOT NULL DEFAULT 'template',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE build_targets ADD COLUMN IF NOT EXISTS install_command text NOT NULL DEFAULT 'corepack pnpm install --frozen-lockfile';
ALTER TABLE build_targets ADD COLUMN IF NOT EXISTS build_command text NOT NULL DEFAULT 'corepack pnpm run build';
ALTER TABLE build_targets ADD COLUMN IF NOT EXISTS output_directory text NOT NULL DEFAULT 'build';
ALTER TABLE build_targets ADD COLUMN IF NOT EXISTS site_adapter text NOT NULL DEFAULT 'kook-online-h5-v1';
ALTER TABLE build_targets ADD COLUMN IF NOT EXISTS configuration_source text NOT NULL DEFAULT 'template';
ALTER TABLE build_targets ALTER COLUMN configuration_source SET DEFAULT 'template';
UPDATE build_targets
SET configuration_source = CASE WHEN repository_url IS NULL THEN 'template' ELSE 'database' END
WHERE configuration_source = 'environment';
ALTER TABLE build_targets ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE TABLE IF NOT EXISTS build_jobs (
  id uuid PRIMARY KEY,
  target_id text NOT NULL REFERENCES build_targets(id),
  branch text NOT NULL,
  profile text NOT NULL,
  status text NOT NULL,
  requested_by text NOT NULL,
  idempotency_key text UNIQUE,
  worker_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  started_at timestamptz,
  finished_at timestamptz,
  failure_code text,
  failure_message text,
  log_path text,
  target_snapshot jsonb
);

ALTER TABLE build_jobs ADD COLUMN IF NOT EXISTS target_snapshot jsonb;

CREATE INDEX IF NOT EXISTS build_jobs_queue_idx ON build_jobs(status, created_at);
CREATE INDEX IF NOT EXISTS build_jobs_target_branch_idx ON build_jobs(target_id, branch, created_at DESC);

CREATE TABLE IF NOT EXISTS build_job_events (
  id bigserial PRIMARY KEY,
  job_id uuid NOT NULL REFERENCES build_jobs(id) ON DELETE CASCADE,
  status text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS build_job_events_job_idx
  ON build_job_events(job_id, created_at, id);

INSERT INTO build_job_events (job_id, status, created_at)
SELECT id, status, COALESCE(finished_at, started_at, created_at)
FROM build_jobs AS job
WHERE NOT EXISTS (
  SELECT 1 FROM build_job_events AS event WHERE event.job_id = job.id
);

CREATE TABLE IF NOT EXISTS runtime_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  updated_by text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS artifacts (
  id uuid PRIMARY KEY,
  build_job_id uuid NOT NULL UNIQUE REFERENCES build_jobs(id),
  target_id text NOT NULL REFERENCES build_targets(id),
  branch text NOT NULL,
  status text NOT NULL,
  storage_key text NOT NULL UNIQUE,
  manifest jsonb NOT NULL,
  built_at timestamptz NOT NULL,
  created_by text NOT NULL,
  deletion_started_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE artifacts ADD COLUMN IF NOT EXISTS deletion_started_at timestamptz;

CREATE INDEX IF NOT EXISTS artifacts_catalog_idx ON artifacts(target_id, branch, built_at DESC)
  WHERE status = 'READY';

CREATE INDEX IF NOT EXISTS artifacts_deleting_idx ON artifacts(deletion_started_at)
  WHERE status = 'DELETING';

CREATE TABLE IF NOT EXISTS environments (
  id uuid PRIMARY KEY,
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  status text NOT NULL DEFAULT 'ACTIVE',
  current_revision_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS environment_revisions (
  id uuid PRIMARY KEY,
  environment_id uuid NOT NULL REFERENCES environments(id),
  revision_no integer NOT NULL,
  message text NOT NULL,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(environment_id, revision_no)
);

ALTER TABLE environments
  DROP CONSTRAINT IF EXISTS environments_current_revision_id_fkey;
ALTER TABLE environments
  ADD CONSTRAINT environments_current_revision_id_fkey
  FOREIGN KEY (current_revision_id) REFERENCES environment_revisions(id);

CREATE TABLE IF NOT EXISTS environment_revision_items (
  revision_id uuid NOT NULL REFERENCES environment_revisions(id),
  target_id text NOT NULL REFERENCES build_targets(id),
  artifact_id uuid NOT NULL REFERENCES artifacts(id),
  branch text NOT NULL,
  built_at timestamptz NOT NULL,
  PRIMARY KEY(revision_id, target_id)
);

CREATE TABLE IF NOT EXISTS environment_artifact_refs (
  environment_id uuid NOT NULL REFERENCES environments(id),
  artifact_id uuid NOT NULL REFERENCES artifacts(id),
  first_revision_id uuid NOT NULL REFERENCES environment_revisions(id),
  last_revision_id uuid NOT NULL REFERENCES environment_revisions(id),
  last_referenced_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(environment_id, artifact_id)
);

CREATE INDEX IF NOT EXISTS environment_artifact_refs_artifact_idx
  ON environment_artifact_refs(artifact_id);

CREATE TABLE IF NOT EXISTS site_bindings (
  id text PRIMARY KEY,
  name text NOT NULL,
  hostname text NOT NULL UNIQUE,
  target_id text NOT NULL REFERENCES build_targets(id),
  environment_slug text NOT NULL REFERENCES environments(slug),
  upstream_origin text NOT NULL,
  official_origin text NOT NULL UNIQUE,
  enabled boolean NOT NULL DEFAULT true,
  remote_target_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  resource_proxy_prefixes jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT site_bindings_remote_target_ids_array
    CHECK (jsonb_typeof(remote_target_ids) = 'array'),
  CONSTRAINT site_bindings_resource_proxy_prefixes_array
    CHECK (jsonb_typeof(resource_proxy_prefixes) = 'array')
);

ALTER TABLE site_bindings
  ADD COLUMN IF NOT EXISTS resource_proxy_prefixes jsonb NOT NULL DEFAULT '[]'::jsonb;

DO $migration$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'site_bindings_resource_proxy_prefixes_array'
      AND conrelid = 'site_bindings'::regclass
  ) THEN
    ALTER TABLE site_bindings
      ADD CONSTRAINT site_bindings_resource_proxy_prefixes_array
      CHECK (jsonb_typeof(resource_proxy_prefixes) = 'array');
  END IF;
END
$migration$;

CREATE INDEX IF NOT EXISTS site_bindings_enabled_hostname_idx
  ON site_bindings(hostname) WHERE enabled = true;

CREATE INDEX IF NOT EXISTS site_bindings_enabled_official_origin_idx
  ON site_bindings(official_origin) WHERE enabled = true;

CREATE TABLE IF NOT EXISTS preview_sessions (
  token text PRIMARY KEY,
  created_by text NOT NULL,
  site_binding_id text REFERENCES site_bindings(id) ON DELETE SET NULL,
  site_artifact_id uuid REFERENCES artifacts(id),
  selections jsonb NOT NULL,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE preview_sessions
  ADD COLUMN IF NOT EXISTS site_binding_id text REFERENCES site_bindings(id) ON DELETE SET NULL;
ALTER TABLE preview_sessions
  ADD COLUMN IF NOT EXISTS site_artifact_id uuid REFERENCES artifacts(id);
ALTER TABLE preview_sessions
  ADD COLUMN IF NOT EXISTS revoked_at timestamptz;

CREATE INDEX IF NOT EXISTS preview_sessions_expires_idx ON preview_sessions(expires_at);

CREATE INDEX IF NOT EXISTS preview_sessions_site_artifact_idx
  ON preview_sessions(site_artifact_id, expires_at);

CREATE INDEX IF NOT EXISTS preview_sessions_selections_gin_idx
  ON preview_sessions USING gin(selections jsonb_path_ops);

CREATE TABLE IF NOT EXISTS audit_events (
  id uuid PRIMARY KEY,
  actor text NOT NULL,
  action text NOT NULL,
  subject_type text NOT NULL,
  subject_id text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO build_targets
  (id, name, kind, repository_url, default_branch, install_command, build_command,
   output_directory, site_adapter, enabled, required, configuration_source)
VALUES
  ('online-h5', '在线 H5', 'h5-site', NULL, 'master',
   'corepack pnpm install --frozen-lockfile', 'corepack pnpm run build', 'build',
   'kook-online-h5-v1', false, false, 'template'),
  ('webapp', '网页端', 'webapp', NULL, 'master',
   'corepack pnpm install --frozen-lockfile', 'corepack pnpm run build', 'build',
   'generic-static-v1', false, false, 'template'),
  ('biz', '商户后台', 'spa-site', NULL, 'master',
   'corepack pnpm install --frozen-lockfile', 'corepack pnpm run build', 'dist',
   'generic-static-v1', false, false, 'template')
ON CONFLICT (id) DO NOTHING;

INSERT INTO environments (id, slug, name, status)
VALUES ('00000000-0000-4000-8000-000000000001', 'shared', '公共调试环境', 'ACTIVE')
ON CONFLICT (slug) DO NOTHING;
`
