import { readFileSync } from 'node:fs'
import vm from 'node:vm'

import { describe, expect, it } from 'vitest'

const source = readFileSync(new URL('./host-adapter.js', import.meta.url), 'utf8')
const tokenKey = 'bifrost.pc.auth-token.v1'

function harness(responses: Array<Record<string, unknown> | number>, token = '') {
  const storage = new Map(token ? [[tokenKey, token]] : [])
  const calls: Array<{ url: string; headers: Headers }> = []
  const channels: Array<{ callback?: (event: unknown) => void; name: string; closed?: boolean }> =
    []
  const opened: string[] = []
  const messageListeners = new Set<(event: unknown) => void>()
  const popup = {}
  let reloaded = false
  const window = {
    location: {
      origin: 'https://bifrost.vanillacake.cn',
      href: 'https://bifrost.vanillacake.cn/pc-plugin/',
      reload: () => {
        reloaded = true
      },
    },
    parent: { postMessage: () => undefined },
    addEventListener: (name: string, callback: (event: unknown) => void) => {
      if (name === 'message') messageListeners.add(callback)
    },
    removeEventListener: (name: string, callback: (event: unknown) => void) => {
      if (name === 'message') messageListeners.delete(callback)
    },
    setTimeout: () => 1,
    clearTimeout: () => undefined,
    open: (url: string) => {
      opened.push(url)
      return popup
    },
  }
  const context = vm.createContext({
    window,
    URL,
    Headers,
    Request,
    Response,
    crypto,
    btoa,
    console,
    localStorage: {
      getItem: (key: string) => storage.get(key) || null,
      setItem: (key: string, value: string) => storage.set(key, value),
      removeItem: (key: string) => storage.delete(key),
    },
    BroadcastChannel: class {
      item: (typeof channels)[number]
      constructor(name: string) {
        this.item = { name }
        channels.push(this.item)
      }
      addEventListener(_type: string, callback: (event: unknown) => void) {
        this.item.callback = callback
      }
      close() {
        this.item.closed = true
      }
    },
    fetch: async (url: string, init: RequestInit) => {
      calls.push({ url: String(url), headers: new Headers(init.headers) })
      const next = responses.shift()
      if (next === undefined) throw new Error('Unexpected request')
      return new Response(JSON.stringify(typeof next === 'number' ? {} : next), {
        status: typeof next === 'number' ? next : 200,
      })
    },
  })
  vm.runInContext(source, context)
  return {
    context,
    storage,
    calls,
    channels,
    opened,
    popup,
    messageListeners,
    reloaded: () => reloaded,
  }
}

describe('PC permission-system compatibility', () => {
  it('shows login for the new anonymous HTTP 200 response without creating Guest sessions', async () => {
    const h = harness([{ authenticated: false, permissionLevel: 0 }])
    const response = await h.context.fetch('/api/v1/auth/session')
    expect(response.status).toBe(401)
    expect(h.calls.map((call) => call.url)).toEqual(['/api/v1/auth/session'])
  })

  it('replaces a legacy Guest bearer with an existing Feishu cookie', async () => {
    const h = harness(
      [
        { authenticated: true, guest: true },
        { authenticated: true, permissionLevel: 2 },
      ],
      'g'.repeat(43)
    )
    const response = await h.context.fetch('/api/v1/auth/session', { credentials: 'include' })
    expect((await response.json()).permissionLevel).toBe(2)
    expect(h.storage.has(tokenKey)).toBe(false)
    expect(h.calls[0].headers.get('authorization')).toBe(`Bearer ${'g'.repeat(43)}`)
    expect(h.calls[1].headers.has('authorization')).toBe(false)
  })

  it('expires stale bearer sessions and offers login when no cookie is available', async () => {
    const h = harness([401, { authenticated: false }], 's'.repeat(43))
    expect((await h.context.fetch('/api/v1/auth/session')).status).toBe(401)
    expect(h.storage.has(tokenKey)).toBe(false)
    expect(h.calls).toHaveLength(2)
  })

  it('preserves user levels, roles and CSRF without leaking credentials to other origins', async () => {
    const h = harness(
      [{ authenticated: true, permissionLevel: 8, roles: ['owner'], csrfToken: 'csrf' }, {}],
      'u'.repeat(43)
    )
    const response = await h.context.fetch('/api/v1/auth/session')
    expect(await response.json()).toMatchObject({
      permissionLevel: 8,
      roles: ['owner'],
      csrfToken: 'csrf',
    })
    await h.context.fetch('https://other.example/api/v1/test')
    expect(h.calls[1].headers.has('authorization')).toBe(false)
  })

  it('keeps service failures visible instead of silently downgrading to Guest', async () => {
    const h = harness([503])
    expect((await h.context.fetch('/api/v1/auth/session')).status).toBe(503)
    expect(h.calls).toHaveLength(1)
  })

  it('hands Feishu login back to the panel over a nonce-scoped channel', async () => {
    const h = harness([])
    await h.context.chrome.tabs.create({
      url: 'https://bifrost.vanillacake.cn/api/v1/auth/feishu/start',
    })
    const returnTo = new URL(h.opened[0]).searchParams.get('return_to')!
    const nonce = new URL(returnTo, 'https://bifrost.vanillacake.cn').searchParams.get('nonce')
    expect(h.channels[0].name).toBe(`bifrost-pc-auth:${nonce}`)
    h.channels[0].callback!({ data: { token: 'f'.repeat(43) } })
    expect(h.storage.get(tokenKey)).toBe('f'.repeat(43))
    expect(h.reloaded()).toBe(true)
  })

  it('accepts a matching popup handoff and rejects foreign windows, origins and nonces', async () => {
    const h = harness([])
    await h.context.chrome.tabs.create({
      url: 'https://bifrost.vanillacake.cn/api/v1/auth/feishu/start',
    })
    const valid = {
      source: h.popup,
      origin: 'https://bifrost.vanillacake.cn',
      data: { channel: h.channels[0].name, token: 'p'.repeat(43) },
    }
    for (const bad of [
      { ...valid, source: {} },
      { ...valid, origin: 'https://other.example' },
      { ...valid, data: { ...valid.data, channel: 'wrong' } },
    ]) {
      for (const listener of h.messageListeners) listener(bad)
    }
    expect(h.storage.has(tokenKey)).toBe(false)
    for (const listener of h.messageListeners) listener(valid)
    expect(h.storage.get(tokenKey)).toBe('p'.repeat(43))
    expect(h.reloaded()).toBe(true)
  })
})

it('rejects a malformed expiry in the packaged PC plugin', () => {
  const context = vm.createContext({
    module: { exports: {} },
    URL,
    localStorage: {
      getItem: () => JSON.stringify({ preview: { expiresAt: 'invalid' } }),
      removeItem: () => undefined,
    },
  })
  vm.runInContext(readFileSync(new URL('./bifrost.js', import.meta.url), 'utf8'), context)
  const plugin = context.module.exports
  expect(plugin.readActive()).toBe(null)
  expect(() =>
    plugin.validateActive({ mode: 'remote', preview: { expiresAt: 'invalid', selections: [{}] } })
  ).toThrow()
})
