import assert from 'node:assert/strict'
import test from 'node:test'

import {
  chooseRestoredPopupState,
  operationMatchesContext,
  popupStateScopeKey,
  readScopedPopupState,
  removeScopedPopupStatesForTab,
  retainScopedPopupStatesForTabs,
  writeScopedPopupState,
} from '../popup-state.js'

test('keeps branch choices and submission locks isolated by tab and binding', () => {
  let store = writeScopedPopupState(null, {
    tabId: 7,
    bindingId: 'binding-online',
    selectedBranches: { webapp: 'feature/chat' },
    submittedBuildBranches: { webapp: 'feature/chat' },
    updatedAt: 1,
  })
  store = writeScopedPopupState(store, {
    tabId: 7,
    bindingId: 'binding-test',
    selectedBranches: { webapp: 'develop' },
    submittedBuildBranches: {},
    updatedAt: 2,
  })

  assert.equal(popupStateScopeKey(7, 'binding-online'), '7:binding-online')
  assert.deepEqual(readScopedPopupState(store, { tabId: 7, bindingId: 'binding-online' }), {
    selectedBranches: { webapp: 'feature/chat' },
    submittedBuildBranches: { webapp: 'feature/chat' },
    updatedAt: 1,
  })
  assert.deepEqual(readScopedPopupState(store, { tabId: 7, bindingId: 'binding-test' }), {
    selectedBranches: { webapp: 'develop' },
    submittedBuildBranches: {},
    updatedAt: 2,
  })
  assert.equal(readScopedPopupState(store, { tabId: 8, bindingId: 'binding-online' }), null)
})

test('sanitizes persisted popup state', () => {
  const stored = readScopedPopupState(
    {
      '3:binding': {
        selectedBranches: { webapp: 'main', invalid: 3 },
        submittedBuildBranches: ['not', 'a', 'record'],
        updatedAt: 'yesterday',
      },
    },
    { tabId: 3, bindingId: 'binding' }
  )
  assert.deepEqual(stored, {
    selectedBranches: { webapp: 'main' },
    submittedBuildBranches: {},
    updatedAt: 0,
  })
})

test('removes closed tabs and rejects stale or malformed local fallback scopes', () => {
  const store = {
    '3:main': { selectedBranches: { base: 'feature/a' }, updatedAt: 3 },
    '3:test': { selectedBranches: { base: 'feature/b' }, updatedAt: 2 },
    '4:main': { selectedBranches: { base: 'feature/c' }, updatedAt: 1 },
    malformed: { selectedBranches: { base: 'stale' }, updatedAt: 4 },
  }

  assert.deepEqual(removeScopedPopupStatesForTab(store, 3), {
    '4:main': store['4:main'],
    malformed: store.malformed,
  })
  assert.deepEqual(retainScopedPopupStatesForTabs(store, [3]), {
    '3:main': store['3:main'],
    '3:test': store['3:test'],
  })
})

test('keeps the current popup selection ahead of a stale persisted snapshot during refresh', () => {
  const current = {
    selectedBranches: { base: 'feature/current' },
    submittedBuildBranches: {},
  }
  const stale = {
    selectedBranches: { base: 'master' },
    submittedBuildBranches: {},
  }

  assert.equal(chooseRestoredPopupState(current, stale), current)
  assert.equal(chooseRestoredPopupState(null, stale), stale)
  assert.equal(chooseRestoredPopupState(null, null), null)
})

test('rejects stale async operations after environment or branch changes', () => {
  const operation = {
    tabId: 5,
    bindingId: 'online-binding',
    environmentSlug: 'online',
    targetId: 'webapp',
    branch: 'feature/chat',
    contextVersion: 4,
  }
  assert.equal(operationMatchesContext(operation, operation, { requireBranch: true }), true)
  assert.equal(
    operationMatchesContext(operation, { ...operation, bindingId: 'test-binding' }),
    false
  )
  assert.equal(operationMatchesContext(operation, { ...operation, environmentSlug: 'test' }), false)
  assert.equal(operationMatchesContext(operation, { ...operation, contextVersion: 5 }), false)
  assert.equal(
    operationMatchesContext(
      operation,
      { ...operation, branch: 'feature/voice' },
      { requireBranch: true }
    ),
    false
  )
})
