import assert from 'node:assert/strict'
import test from 'node:test'

import {
  createAnonymousActorId,
  normalizeActorName,
  resolveActorIdentity,
} from '../popup-identity.js'

test('creates a compact anonymous actor id from a UUID', () => {
  assert.equal(createAnonymousActorId('a7f2c9d0-1111-2222-3333-444444444444'), 'QA-A7F2C9')
})

test('keeps an existing browser id stable without a display-name override', () => {
  assert.deepEqual(resolveActorIdentity({ storedActorId: 'QA-A7F2C9', storedActorName: '' }), {
    actorId: 'QA-A7F2C9',
    actorOverride: '',
    actorName: 'QA-A7F2C9',
  })
})

test('preserves a meaningful legacy display name as an optional override', () => {
  assert.deepEqual(
    resolveActorIdentity({ storedActorId: 'QA-A7F2C9', storedActorName: '  QA   Alice  ' }),
    {
      actorId: 'QA-A7F2C9',
      actorOverride: 'QA Alice',
      actorName: 'QA Alice',
    }
  )
})

test('migrates the shared legacy default to the browser-specific id', () => {
  const identity = resolveActorIdentity({
    storedActorId: 'QA-A7F2C9',
    storedActorName: 'QA Operator',
  })
  assert.equal(identity.actorOverride, '')
  assert.equal(identity.actorName, 'QA-A7F2C9')
})

test('normalizes and limits optional display names', () => {
  assert.equal(normalizeActorName(`  ${'a'.repeat(45)}  `), 'a'.repeat(40))
})
