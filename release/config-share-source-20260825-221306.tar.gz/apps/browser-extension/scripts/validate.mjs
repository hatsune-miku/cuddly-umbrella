import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const manifest = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8'))
if (manifest.manifest_version !== 3) throw new Error('Browser extension must use Manifest V3')
if (!manifest.permissions?.includes('alarms')) {
  throw new Error('Browser extension must declare the alarms permission')
}
for (const file of [
  'popup.html',
  'popup.css',
  'popup.js',
  'popup-state.js',
  'branch-picker.js',
  'build-queue.js',
  'binding-selection.js',
  'popup-identity.js',
  'preview-routing.js',
  'extension-protocol.js',
  'service-worker.js',
]) {
  await readFile(path.join(root, file))
}

const popupHtml = await readFile(path.join(root, 'popup.html'), 'utf8')
for (const requiredId of [
  'module-list',
  'queue-list',
  'queue-summary',
  'job-detail-dialog',
  'job-detail-content',
  'job-detail-cancel',
  'apply-button-wrap',
]) {
  if (!popupHtml.includes(`id="${requiredId}"`)) {
    throw new Error(`Browser extension popup is missing #${requiredId}`)
  }
}
const popupJs = await readFile(path.join(root, 'popup.js'), 'utf8')
for (const match of popupJs.matchAll(/document\.querySelector\('#([^']+)'\)/g)) {
  if (!popupHtml.includes(`id="${match[1]}"`)) {
    throw new Error(`popup.js references missing element #${match[1]}`)
  }
}
const popupCss = await readFile(path.join(root, 'popup.css'), 'utf8')
if (!popupCss.includes('width: 560px;') || !popupCss.includes('height: 600px;')) {
  throw new Error('Browser extension popup must stay within the Chromium 800x600 limit')
}
console.log('[browser-extension] manifest and entry files are valid')
