import assert from 'node:assert/strict'
import test from 'node:test'

import {
  configurationGroupFingerprint,
  configurationGroupItems,
  configurationGroupShareUrl,
} from '../config-share.js'

test('configuration groups explicitly snapshot every project as branch or official', () => {
  const items = configurationGroupItems([{ id: 'webapp' }, { id: 'base' }, { id: 'discover' }], {
    webapp: 'feature/site',
    base: '',
    discover: ' feature/discover ',
  })
  assert.deepEqual(items, [
    { targetId: 'webapp', mode: 'branch', branch: 'feature/site' },
    { targetId: 'base', mode: 'official' },
    { targetId: 'discover', mode: 'branch', branch: 'feature/discover' },
  ])
})

test('configuration fingerprints change with environment or branch intent', () => {
  const base = {
    bindingId: 'main',
    environmentSlug: 'online',
    items: [{ targetId: 'base', mode: 'branch', branch: 'feature/a' }],
  }
  assert.equal(configurationGroupFingerprint(base), configurationGroupFingerprint({ ...base }))
  assert.notEqual(
    configurationGroupFingerprint(base),
    configurationGroupFingerprint({ ...base, environmentSlug: 'test' })
  )
  assert.notEqual(
    configurationGroupFingerprint(base),
    configurationGroupFingerprint({
      ...base,
      items: [{ targetId: 'base', mode: 'branch', branch: 'feature/b' }],
    })
  )
})

test('share URLs stay on the configured control origin and ignore an untrusted path', () => {
  const token = 'abcdefghijklmnopqrstuvwxyzABCDEF'
  assert.equal(
    configurationGroupShareUrl('https://bifrost.vanillacake.cn/settings', {
      token,
      sharePath: `/s/${token}`,
    }),
    `https://bifrost.vanillacake.cn/s/${token}`
  )
  assert.equal(
    configurationGroupShareUrl('https://bifrost.vanillacake.cn', {
      token,
      sharePath: 'https://attacker.example/s/leak',
    }),
    `https://bifrost.vanillacake.cn/s/${token}`
  )
  assert.throws(
    () => configurationGroupShareUrl('https://bifrost.vanillacake.cn', { token: 'short' }),
    /令牌无效/
  )
})
