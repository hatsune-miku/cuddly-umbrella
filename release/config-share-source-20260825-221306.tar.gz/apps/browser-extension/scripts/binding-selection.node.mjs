import assert from 'node:assert/strict'
import test from 'node:test'

import {
  bindingEnvironmentLabel,
  chooseBindingCandidate,
  normalizeBindingCandidates,
} from '../binding-selection.js'

const shared = {
  id: 'main',
  hostname: 'main.bifrost.example.test',
  environmentSlug: 'shared',
}
const qaA = {
  id: 'qa-a-main',
  hostname: 'qa-a-main.bifrost.example.test',
  environmentSlug: 'qa-a',
  environmentName: '需求 A',
  environmentStatus: 'FROZEN',
}

test('normalizes candidate envelopes and legacy single-binding responses', () => {
  assert.deepEqual(normalizeBindingCandidates({ items: [shared, shared, null] }), [shared])
  assert.deepEqual(normalizeBindingCandidates(qaA), [qaA])
  assert.deepEqual(normalizeBindingCandidates(null), [])
})

test('keeps an active tab binding ahead of a remembered official-origin preference', () => {
  assert.equal(
    chooseBindingCandidate({
      candidates: [shared, qaA],
      rememberedEnvironmentSlug: 'shared',
      activeSiteBindingId: qaA.id,
    }),
    qaA
  )
  assert.equal(
    chooseBindingCandidate({
      candidates: [shared, qaA],
      rememberedEnvironmentSlug: 'qa-a',
      activeSiteBindingId: null,
    }),
    qaA
  )
})

test('uses a compact environment label with a slug fallback', () => {
  assert.equal(bindingEnvironmentLabel(qaA), '需求 A · qa-a · 冻结')
  assert.equal(bindingEnvironmentLabel(shared), 'shared')
})
