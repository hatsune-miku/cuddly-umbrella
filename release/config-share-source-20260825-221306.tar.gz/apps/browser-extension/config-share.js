export function configurationGroupItems(targets, selectedBranches) {
  return (Array.isArray(targets) ? targets : []).map((target) => {
    const targetId = typeof target?.id === 'string' ? target.id : ''
    const branch =
      selectedBranches && typeof selectedBranches[targetId] === 'string'
        ? selectedBranches[targetId].trim()
        : ''
    return branch ? { targetId, mode: 'branch', branch } : { targetId, mode: 'official' }
  })
}

export function configurationGroupFingerprint({ bindingId, environmentSlug, items }) {
  return JSON.stringify({
    bindingId: typeof bindingId === 'string' ? bindingId : '',
    environmentSlug: typeof environmentSlug === 'string' ? environmentSlug : '',
    items: Array.isArray(items) ? items : [],
  })
}

export function configurationGroupShareUrl(controlOrigin, group) {
  const origin = new URL(controlOrigin).origin
  const token = typeof group?.token === 'string' ? group.token : ''
  if (!/^[A-Za-z0-9_-]{32}$/.test(token)) throw new Error('配置组令牌无效')
  const expectedPath = `/s/${token}`
  const path = group?.sharePath === expectedPath ? group.sharePath : expectedPath
  const url = new URL(path, `${origin}/`)
  if (url.origin !== origin || url.pathname !== expectedPath) {
    throw new Error('配置组链接无效')
  }
  url.search = ''
  url.hash = ''
  return url.href
}
