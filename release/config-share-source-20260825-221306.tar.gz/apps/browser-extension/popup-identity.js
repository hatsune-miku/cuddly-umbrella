const LEGACY_DEFAULT_ACTOR = 'QA Operator'
const GENERATED_ACTOR_PATTERN = /^QA-[A-Z0-9]{6}$/

export function normalizeActorName(value) {
  return String(value || '')
    .trim()
    .replace(/\s+/g, ' ')
    .slice(0, 40)
}

export function createAnonymousActorId(randomValue = crypto.randomUUID()) {
  const token = String(randomValue)
    .replace(/[^a-z0-9]/gi, '')
    .slice(0, 6)
    .toUpperCase()
    .padEnd(6, '0')
  return `QA-${token}`
}

export function resolveActorIdentity({ storedActorId, storedActorName }) {
  const actorId = GENERATED_ACTOR_PATTERN.test(String(storedActorId || ''))
    ? storedActorId
    : createAnonymousActorId()
  const normalizedName = normalizeActorName(storedActorName)
  const actorOverride =
    normalizedName && normalizedName !== LEGACY_DEFAULT_ACTOR && normalizedName !== actorId
      ? normalizedName
      : ''

  return {
    actorId,
    actorOverride,
    actorName: actorOverride || actorId,
  }
}
