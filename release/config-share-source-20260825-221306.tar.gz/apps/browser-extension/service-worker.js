const ACTIVE_KEY = 'cuddly.activePreviews'
const CONTROL_KEY = 'cuddly.controlOrigin'
const POPUP_SCOPED_STATE_KEY = 'cuddly.popupStateByTabBinding.v1'
const READ_POPUP_SCOPED_STATE_COMMAND = 'read-popup-scoped-state'
const WRITE_POPUP_SCOPED_STATE_COMMAND = 'write-popup-scoped-state'
const MAX_SCOPED_STATES = 100
const PREVIEW_ALARM_PREFIX = 'cuddly.previewExpiry.'
const EXTENSION_PROTOCOL_VERSION = 3
const EXTENSION_CAPABILITIES_COMMAND = 'get-extension-capabilities'
const APPLY_SITE_PREVIEW_TRANSACTION_COMMAND = 'apply-site-preview-transaction'
const REMOVE_PREVIEW_TRANSACTION_COMMAND = 'remove-preview-transaction'
const DEFAULT_CONTROL_ORIGIN = 'https://bifrost.vanillacake.cn'
const CONFIGURATION_GROUP_TOKEN_PATTERN = /^[A-Za-z0-9_-]{32}$/
const EXTENSION_RELOAD_REQUIRED =
  '扩展前后台版本不一致，请在 chrome://extensions 重新加载 Cuddly KOOK Preview'
const PREVIEW_REVOKE_TIMEOUT_MS = 3_000
let mutationQueue = Promise.resolve()
let popupScopedStorageArea = null

function serializeMutation(task) {
  const result = mutationQueue.then(task, task)
  mutationQueue = result.catch(() => undefined)
  return result
}

function normalizeHttpOrigin(value) {
  if (typeof value !== 'string' || !value.trim()) return null
  try {
    const url = new URL(value.trim())
    if (
      !['http:', 'https:'].includes(url.protocol) ||
      url.username ||
      url.password ||
      url.pathname !== '/' ||
      url.search ||
      url.hash
    ) {
      return null
    }
    return url.origin
  } catch {
    return null
  }
}

async function configuredControlOrigin() {
  const stored = await chrome.storage.local.get(CONTROL_KEY)
  return normalizeHttpOrigin(stored[CONTROL_KEY]) || DEFAULT_CONTROL_ORIGIN
}

function configurationShareUrl(value, controlOrigin) {
  try {
    const url = new URL(value)
    if (url.username || url.password || url.origin !== controlOrigin) return null
    const match = /^\/s\/([A-Za-z0-9_-]{32})$/.exec(url.pathname)
    if (!match || !CONFIGURATION_GROUP_TOKEN_PATTERN.test(match[1])) return null
    return {
      token: match[1],
      url: `${controlOrigin}/s/${match[1]}`,
    }
  } catch {
    return null
  }
}

function configurationGroupSelection(body, expectedToken) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new Error('Configuration group response is invalid')
  }
  if (body.mode !== 'preview' && body.mode !== 'official') {
    throw new Error('Configuration group response mode is invalid')
  }
  const group = body.configurationGroup
  if (!group || typeof group !== 'object' || Array.isArray(group)) {
    throw new Error('Configuration group is missing')
  }
  if (group.token !== expectedToken) throw new Error('Configuration group token does not match')
  const name = typeof group.name === 'string' ? group.name.trim() : ''
  const environmentSlug =
    typeof group.environmentSlug === 'string' ? group.environmentSlug.trim() : ''
  if (!name || name.length > 80 || !environmentSlug) {
    throw new Error('Configuration group identity is invalid')
  }
  const binding = group.siteBinding
  if (!binding || typeof binding !== 'object' || Array.isArray(binding)) {
    throw new Error('Configuration group site binding is missing')
  }
  const bindingId = typeof binding.id === 'string' ? binding.id.trim() : ''
  const hostname = typeof binding.hostname === 'string' ? binding.hostname.trim().toLowerCase() : ''
  const officialOrigin = normalizeHttpOrigin(binding.officialOrigin)
  if (!bindingId || !hostname || !officialOrigin) {
    throw new Error('Configuration group site binding is invalid')
  }
  if (!Array.isArray(group.items) || !group.items.length || group.items.length > 40) {
    throw new Error('Configuration group items are invalid')
  }
  const selectedBranches = {}
  for (const item of group.items) {
    const targetId = typeof item?.targetId === 'string' ? item.targetId.trim() : ''
    if (!targetId || targetId.length > 80 || Object.hasOwn(selectedBranches, targetId)) {
      throw new Error('Configuration group project is invalid')
    }
    if (item.mode === 'official') {
      selectedBranches[targetId] = ''
    } else if (
      item.mode === 'branch' &&
      typeof item.branch === 'string' &&
      item.branch.trim() &&
      item.branch.trim().length <= 240
    ) {
      selectedBranches[targetId] = item.branch.trim()
    } else {
      throw new Error('Configuration group branch selection is invalid')
    }
  }
  return {
    mode: body.mode,
    group,
    bindingId,
    hostname,
    officialOrigin,
    name,
    environmentSlug,
    selectedBranches,
  }
}

function validatedPreviewResponse(body, selection) {
  if (selection.mode !== 'preview') return null
  const preview = body.preview
  if (!preview || typeof preview !== 'object' || Array.isArray(preview)) {
    throw new Error('Configuration group preview is missing')
  }
  if (
    typeof preview.token !== 'string' ||
    !preview.token ||
    preview.siteBindingId !== selection.bindingId ||
    preview.environmentSlug !== selection.environmentSlug ||
    !Number.isFinite(Date.parse(preview.expiresAt || '')) ||
    Date.parse(preview.expiresAt) <= Date.now()
  ) {
    throw new Error('Configuration group preview is invalid')
  }
  const previewOrigin = normalizeHttpOrigin(body.previewOrigin)
  if (!previewOrigin || new URL(previewOrigin).hostname.toLowerCase() !== selection.hostname) {
    throw new Error('Configuration group preview origin does not match its site binding')
  }
  return { preview, previewOrigin }
}

function stringRecord(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {}
  return Object.fromEntries(
    Object.entries(value).filter(
      ([key, entry]) => typeof key === 'string' && typeof entry === 'string'
    )
  )
}

function popupStateScopeKey(tabId, bindingId) {
  if (!Number.isInteger(tabId) || tabId < 0 || typeof bindingId !== 'string' || !bindingId) {
    return ''
  }
  return `${tabId}:${bindingId}`
}

function readScopedPopupState(store, { tabId, bindingId }) {
  const key = popupStateScopeKey(tabId, bindingId)
  const entry = key && store && typeof store === 'object' ? store[key] : null
  if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return null
  return {
    selectedBranches: stringRecord(entry.selectedBranches),
    submittedBuildBranches: stringRecord(entry.submittedBuildBranches),
    updatedAt: Number.isFinite(entry.updatedAt) ? entry.updatedAt : 0,
  }
}

function writeScopedPopupState(
  store,
  { tabId, bindingId, selectedBranches, submittedBuildBranches, updatedAt = Date.now() }
) {
  const key = popupStateScopeKey(tabId, bindingId)
  if (!key) throw new Error('Popup state scope is invalid')
  const next = {
    ...(store && typeof store === 'object' && !Array.isArray(store) ? store : {}),
    [key]: {
      selectedBranches: stringRecord(selectedBranches),
      submittedBuildBranches: stringRecord(submittedBuildBranches),
      updatedAt,
    },
  }
  return Object.fromEntries(
    Object.entries(next)
      .sort(([, left], [, right]) => (right?.updatedAt || 0) - (left?.updatedAt || 0))
      .slice(0, MAX_SCOPED_STATES)
  )
}

function removeScopedPopupStatesForTab(store, tabId) {
  const prefix = `${tabId}:`
  return Object.fromEntries(
    Object.entries(store && typeof store === 'object' && !Array.isArray(store) ? store : {}).filter(
      ([key]) => !key.startsWith(prefix)
    )
  )
}

function retainScopedPopupStatesForTabs(store, tabIds) {
  const activeTabIds = new Set(tabIds)
  return Object.fromEntries(
    Object.entries(store && typeof store === 'object' && !Array.isArray(store) ? store : {}).filter(
      ([key]) => {
        const separator = key.indexOf(':')
        if (separator <= 0) return false
        const tabId = Number(key.slice(0, separator))
        return Number.isInteger(tabId) && activeTabIds.has(tabId)
      }
    )
  )
}

async function getPopupScopedStorageArea() {
  if (popupScopedStorageArea) return popupScopedStorageArea
  const session = chrome.storage?.session
  if (session?.get && session?.set) {
    try {
      await session.get(POPUP_SCOPED_STATE_KEY)
      popupScopedStorageArea = session
      return popupScopedStorageArea
    } catch {
      // Older Chromium builds can expose storage.session without making it usable here.
    }
  }
  popupScopedStorageArea = chrome.storage.local
  return popupScopedStorageArea
}

async function readPersistedPopupState(tabId, bindingId) {
  const area = await getPopupScopedStorageArea()
  const stored = await area.get(POPUP_SCOPED_STATE_KEY)
  return readScopedPopupState(stored[POPUP_SCOPED_STATE_KEY] || {}, { tabId, bindingId })
}

async function persistPopupState(message) {
  const area = await getPopupScopedStorageArea()
  const stored = await area.get(POPUP_SCOPED_STATE_KEY)
  const next = writeScopedPopupState(stored[POPUP_SCOPED_STATE_KEY] || {}, message)
  await area.set({ [POPUP_SCOPED_STATE_KEY]: next })
  return readScopedPopupState(next, message)
}

async function removePersistedPopupStatesForTab(tabId) {
  if (!Number.isInteger(tabId) || tabId < 0) return
  const area = await getPopupScopedStorageArea()
  const stored = await area.get(POPUP_SCOPED_STATE_KEY)
  const current = stored[POPUP_SCOPED_STATE_KEY] || {}
  const next = removeScopedPopupStatesForTab(current, tabId)
  if (Object.keys(next).length !== Object.keys(current).length) {
    await area.set({ [POPUP_SCOPED_STATE_KEY]: next })
  }
}

async function reconcilePersistedPopupStates() {
  const area = await getPopupScopedStorageArea()
  const [stored, tabs] = await Promise.all([
    area.get(POPUP_SCOPED_STATE_KEY),
    chrome.tabs.query({}),
  ])
  const current = stored[POPUP_SCOPED_STATE_KEY] || {}
  const next = retainScopedPopupStatesForTabs(
    current,
    tabs.flatMap((tab) => (Number.isInteger(tab.id) ? [tab.id] : []))
  )
  if (Object.keys(next).length !== Object.keys(current).length) {
    await area.set({ [POPUP_SCOPED_STATE_KEY]: next })
  }
}

async function readActivePreviews() {
  return (await chrome.storage.local.get(ACTIVE_KEY))[ACTIVE_KEY] || {}
}

async function writeActivePreviews(value) {
  await chrome.storage.local.set({ [ACTIVE_KEY]: value })
}

function previewAlarmName(tabId) {
  return `${PREVIEW_ALARM_PREFIX}${tabId}`
}

function previewAlarmTabId(name) {
  if (!name.startsWith(PREVIEW_ALARM_PREFIX)) return null
  const tabId = Number(name.slice(PREVIEW_ALARM_PREFIX.length))
  return Number.isInteger(tabId) && tabId >= 0 ? tabId : null
}

function previewExpiresAt(active) {
  return Date.parse(active?.preview?.expiresAt || '')
}

async function schedulePreviewExpiry(tabId, active) {
  const when = previewExpiresAt(active)
  if (!Number.isFinite(when) || when <= Date.now()) {
    throw new Error('Preview session has already expired')
  }
  await chrome.alarms.create(previewAlarmName(tabId), { when })
}

async function revokeActivePreview(active) {
  const token = active?.preview?.token
  if (typeof token !== 'string' || !token || !active?.controlOrigin) return false
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), PREVIEW_REVOKE_TIMEOUT_MS)
  try {
    const origin = new URL(active.controlOrigin).origin
    const response = await fetch(`${origin}/api/v1/previews/${encodeURIComponent(token)}`, {
      method: 'DELETE',
      cache: 'no-store',
      credentials: 'omit',
      keepalive: true,
      signal: controller.signal,
    })
    return response.ok || response.status === 404
  } catch {
    return false
  } finally {
    clearTimeout(timeout)
  }
}

async function clearPreviewState(tabId) {
  const active = await readActivePreviews()
  const current = active[String(tabId)] || null
  if (current?.ruleIds?.length) {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: current.ruleIds })
  }
  delete active[String(tabId)]
  await writeActivePreviews(active)
  await chrome.alarms.clear(previewAlarmName(tabId))
  return current
}

async function removePreview(tabId) {
  const current = await clearPreviewState(tabId)
  await revokeActivePreview(current)
  return current
}

async function nextRuleIds(count) {
  const rules = await chrome.declarativeNetRequest.getSessionRules()
  const first = rules.reduce((maximum, rule) => Math.max(maximum, rule.id), 1000) + 1
  return Array.from({ length: count }, (_value, index) => first + index)
}

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function sitePreviewRules({ tabId, previewOrigin, token, previewHeaderRuleId }) {
  const origin = new URL(previewOrigin).origin
  return [
    {
      id: previewHeaderRuleId,
      priority: 3,
      action: {
        type: 'modifyHeaders',
        requestHeaders: [
          {
            header: 'x-cuddly-preview-token',
            operation: 'set',
            value: token,
          },
        ],
      },
      condition: {
        regexFilter: `^${escapeRegex(origin)}(?:/|$)`,
        tabIds: [tabId],
      },
    },
  ]
}

function rulesForActivePreview(tabId, active) {
  try {
    if (
      active?.mode === 'site' &&
      active.ruleIds?.length === 1 &&
      typeof active.preview?.token === 'string'
    ) {
      return sitePreviewRules({
        tabId,
        previewOrigin: active.previewOrigin,
        token: active.preview.token,
        previewHeaderRuleId: active.ruleIds[0],
      })
    }
  } catch {
    return null
  }
  return null
}

function activePreviewMatchesTab(active, tab) {
  if (active?.mode !== 'site' || !active.previewOrigin || !tab?.url) return false
  try {
    return new URL(tab.url).origin === new URL(active.previewOrigin).origin
  } catch {
    return false
  }
}

function officialUrlForActivePreview(active, tab) {
  if (!activePreviewMatchesTab(active, tab) || !active?.officialOrigin) return null
  try {
    const destination = new URL(active.officialOrigin)
    const current = new URL(tab.url)
    destination.pathname = current.pathname
    destination.search = current.search
    destination.hash = current.hash
    return destination.href
  } catch {
    return null
  }
}

function shareUrlForActivePreview(active) {
  const controlOrigin = normalizeHttpOrigin(active?.controlOrigin)
  if (!controlOrigin || !CONFIGURATION_GROUP_TOKEN_PATTERN.test(active?.configGroupToken || '')) {
    return null
  }
  const share = configurationShareUrl(active?.shareUrl, controlOrigin)
  return share?.token === active.configGroupToken ? share.url : null
}

function recoveryUrlForActivePreview(active, tab) {
  return shareUrlForActivePreview(active) || officialUrlForActivePreview(active, tab)
}

async function storeActive(tabId, value) {
  const active = await readActivePreviews()
  active[String(tabId)] = value
  await writeActivePreviews(active)
  try {
    await schedulePreviewExpiry(tabId, value)
  } catch (error) {
    delete active[String(tabId)]
    await writeActivePreviews(active)
    await chrome.alarms.clear(previewAlarmName(tabId))
    throw error
  }
  return value
}

async function restoreActive(tabId, value) {
  if (!value) return null
  const rules = rulesForActivePreview(tabId, value)
  if (!rules?.length) throw new Error('Previous preview state cannot be restored')
  await chrome.declarativeNetRequest.updateSessionRules({ addRules: rules })
  try {
    return await storeActive(tabId, value)
  } catch (error) {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: rules.map((rule) => rule.id),
    })
    throw error
  }
}

async function discardPreviewState(tabId, value) {
  const ruleIds = Array.isArray(value?.ruleIds) ? value.ruleIds : []
  if (ruleIds.length) {
    await chrome.declarativeNetRequest
      .updateSessionRules({ removeRuleIds: ruleIds })
      .catch(() => undefined)
  }

  const active = await readActivePreviews().catch(() => null)
  const current = active?.[String(tabId)] || null
  if (active && current?.ruleIds?.some((ruleId) => ruleIds.includes(ruleId))) {
    delete active[String(tabId)]
    await writeActivePreviews(active).catch(() => undefined)
  }
  await chrome.alarms.clear(previewAlarmName(tabId)).catch(() => undefined)
}

async function reconcilePreviewLifecycles() {
  const active = await readActivePreviews()
  const tabs = await chrome.tabs.query({})
  const tabsById = new Map(tabs.flatMap((tab) => (tab.id === undefined ? [] : [[tab.id, tab]])))
  const expectedAlarms = new Set()
  const restoredRules = []
  const restoredPreviews = []
  const stalePreviews = []
  const redirects = []
  const usedRuleIds = new Set()

  for (const [tabKey, preview] of Object.entries(active)) {
    const tabId = Number(tabKey)
    const tab = tabsById.get(tabId)
    const expiresAt = previewExpiresAt(preview)
    const rules =
      Number.isInteger(tabId) && tabId >= 0 ? rulesForActivePreview(tabId, preview) : null
    const ruleIds = rules?.map((rule) => rule.id) || []
    const rulesAreUnique = ruleIds.every(
      (ruleId) => Number.isInteger(ruleId) && ruleId > 0 && !usedRuleIds.has(ruleId)
    )
    if (
      !tab ||
      !Number.isFinite(expiresAt) ||
      expiresAt <= Date.now() ||
      !rules?.length ||
      !rulesAreUnique ||
      !activePreviewMatchesTab(preview, tab)
    ) {
      delete active[tabKey]
      stalePreviews.push(preview)
      const recoveryUrl = recoveryUrlForActivePreview(preview, tab)
      if (recoveryUrl) redirects.push([tabId, recoveryUrl])
      if (Number.isInteger(tabId) && tabId >= 0) await chrome.alarms.clear(previewAlarmName(tabId))
      continue
    }
    for (const ruleId of ruleIds) usedRuleIds.add(ruleId)
    restoredRules.push(...rules)
    restoredPreviews.push([tabId, preview])
    expectedAlarms.add(previewAlarmName(tabId))
  }

  const currentRules = await chrome.declarativeNetRequest.getSessionRules()
  if (currentRules.length || restoredRules.length) {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: currentRules.map((rule) => rule.id),
      addRules: restoredRules,
    })
  }
  await writeActivePreviews(active)
  await Promise.all(stalePreviews.map((preview) => revokeActivePreview(preview)))
  for (const [tabId, preview] of restoredPreviews) {
    await schedulePreviewExpiry(tabId, preview)
  }

  const alarms = await chrome.alarms.getAll()
  await Promise.all(
    alarms
      .filter(
        (alarm) => alarm.name.startsWith(PREVIEW_ALARM_PREFIX) && !expectedAlarms.has(alarm.name)
      )
      .map((alarm) => chrome.alarms.clear(alarm.name))
  )
  await Promise.all(
    redirects.map(([tabId, url]) => chrome.tabs.update(tabId, { url }).catch(() => undefined))
  )
}

function transactionTargetUrl(message, previewOrigin) {
  const target = new URL(message.targetUrl)
  if (target.origin !== previewOrigin) {
    throw new Error('Preview target must use the configured preview origin')
  }
  return target.href
}

function configurationShareMetadata(message, controlOrigin) {
  const hasShareMetadata =
    message.shareUrl !== undefined ||
    message.configGroupToken !== undefined ||
    message.name !== undefined
  if (!hasShareMetadata) return {}
  const share = configurationShareUrl(message.shareUrl, controlOrigin)
  const name = typeof message.name === 'string' ? message.name.trim() : ''
  if (!share || share.token !== message.configGroupToken || !name || name.length > 80) {
    throw new Error('Configuration group preview metadata is invalid')
  }
  return {
    shareUrl: share.url,
    configGroupToken: share.token,
    name,
  }
}

async function applySitePreview(message, { navigate = false } = {}) {
  const tabId = message.tabId
  if (!Number.isInteger(tabId) || tabId < 0) throw new Error('Preview tab is invalid')
  const [previewHeaderRuleId] = await nextRuleIds(1)
  const origin = new URL(message.previewOrigin).origin
  const controlOrigin = new URL(message.controlOrigin).origin
  const officialOrigin = new URL(message.officialOrigin).origin
  const targetUrl = navigate ? transactionTargetUrl(message, origin) : message.targetUrl
  const shareMetadata = configurationShareMetadata(message, controlOrigin)
  const pending = {
    mode: 'site',
    ruleIds: [previewHeaderRuleId],
    preview: message.preview,
    previewOrigin: origin,
    controlOrigin,
    officialOrigin,
    originalUrl: message.originalUrl,
    targetUrl,
    appliedAt: new Date().toISOString(),
    ...shareMetadata,
  }
  const rules = sitePreviewRules({
    tabId,
    previewOrigin: origin,
    token: message.preview.token,
    previewHeaderRuleId,
  })
  const previous = await clearPreviewState(tabId)
  try {
    await chrome.declarativeNetRequest.updateSessionRules({ addRules: rules })
    const active = await storeActive(tabId, pending)
    if (navigate) await chrome.tabs.update(tabId, { url: targetUrl })
    await revokeActivePreview(previous)
    return active
  } catch (error) {
    await discardPreviewState(tabId, pending)
    try {
      await restoreActive(tabId, previous)
    } catch {
      await revokeActivePreview(previous)
    }
    await revokeActivePreview(pending)
    throw error
  }
}

async function removePreviewAndNavigate(tabId) {
  if (!Number.isInteger(tabId) || tabId < 0) throw new Error('Preview tab is invalid')
  const active = await readActivePreviews()
  const current = active[String(tabId)] || null
  if (!current) return null

  const tab = await chrome.tabs.get(tabId)
  const expired = previewExpiresAt(current) <= Date.now()
  const destinationUrl = expired
    ? recoveryUrlForActivePreview(current, tab)
    : officialUrlForActivePreview(current, tab)
  const previous = await clearPreviewState(tabId)
  try {
    if (destinationUrl) {
      await chrome.tabs.update(tabId, { url: destinationUrl })
    } else if (current.mode !== 'site') {
      await chrome.tabs.reload(tabId)
    }
  } catch (error) {
    try {
      await restoreActive(tabId, previous)
    } catch {
      await revokeActivePreview(previous)
    }
    throw error
  }
  await revokeActivePreview(previous)
  return previous
}

async function requestConfigurationGroupPreview(controlOrigin, token) {
  const response = await fetch(
    `${controlOrigin}/api/v1/config-groups/${encodeURIComponent(token)}/previews`,
    {
      method: 'POST',
      cache: 'no-store',
      credentials: 'omit',
    }
  )
  const body = await response.json().catch(() => null)
  if (!response.ok) {
    const message = typeof body?.message === 'string' ? body.message.trim() : ''
    throw new Error(message || `Configuration group preview returned HTTP ${response.status}`)
  }
  return body
}

async function applyConfigurationShare(tab) {
  if (!Number.isInteger(tab?.id) || !tab.url) return false
  const controlOrigin = await configuredControlOrigin()
  const expectedShare = configurationShareUrl(tab.url, controlOrigin)
  if (!expectedShare) return false

  // Multiple onUpdated events can carry the same stale landing URL. Re-read the tab only when the
  // queued task starts so a previous task's navigation prevents a duplicate Preview creation.
  const currentTab = await chrome.tabs.get(tab.id).catch(() => null)
  const currentShare = configurationShareUrl(currentTab?.url, controlOrigin)
  if (!currentShare || currentShare.token !== expectedShare.token) return false

  let previewToRevoke = null
  try {
    const body = await requestConfigurationGroupPreview(controlOrigin, currentShare.token)
    const selection = configurationGroupSelection(body, currentShare.token)
    const previewResponse = validatedPreviewResponse(body, selection)
    previewToRevoke = previewResponse?.preview || null

    // Persist the complete branch draft before any navigation. The popup can now close/reopen or
    // load on the destination without falling back to its previous branch selection.
    await persistPopupState({
      tabId: tab.id,
      bindingId: selection.bindingId,
      selectedBranches: selection.selectedBranches,
      submittedBuildBranches: {},
    })

    if (selection.mode === 'official') {
      await removePreview(tab.id)
      await chrome.tabs.update(tab.id, { url: new URL('/', selection.officialOrigin).href })
      return true
    }

    await applySitePreview(
      {
        tabId: tab.id,
        previewOrigin: previewResponse.previewOrigin,
        controlOrigin,
        officialOrigin: selection.officialOrigin,
        originalUrl: currentShare.url,
        targetUrl: new URL('/', previewResponse.previewOrigin).href,
        preview: previewResponse.preview,
        shareUrl: currentShare.url,
        configGroupToken: currentShare.token,
        name: selection.name,
      },
      { navigate: true }
    )
    previewToRevoke = null
    return true
  } catch {
    if (previewToRevoke) {
      await revokeActivePreview({ preview: previewToRevoke, controlOrigin })
    }
    return false
  }
}

async function scanConfigurationShareTabs() {
  const tabs = await chrome.tabs.query({})
  for (const tab of tabs) await applyConfigurationShare(tab)
}

function extensionCapabilities() {
  return {
    protocolVersion: EXTENSION_PROTOCOL_VERSION,
    commands: [
      'apply-site-preview',
      'remove-preview',
      APPLY_SITE_PREVIEW_TRANSACTION_COMMAND,
      REMOVE_PREVIEW_TRANSACTION_COMMAND,
    ],
  }
}

chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  const task = serializeMutation(() => {
    if (message?.type === EXTENSION_CAPABILITIES_COMMAND) return extensionCapabilities()
    if (message?.type === READ_POPUP_SCOPED_STATE_COMMAND) {
      return readPersistedPopupState(message.tabId, message.bindingId)
    }
    if (message?.type === WRITE_POPUP_SCOPED_STATE_COMMAND) return persistPopupState(message)
    if (message?.type === 'apply-site-preview') return applySitePreview(message)
    if (message?.type === 'remove-preview') return removePreview(message.tabId)
    if (message?.type === APPLY_SITE_PREVIEW_TRANSACTION_COMMAND) {
      return applySitePreview(message, { navigate: true })
    }
    if (message?.type === REMOVE_PREVIEW_TRANSACTION_COMMAND) {
      return removePreviewAndNavigate(message.tabId)
    }
    if (message?.type === 'apply-preview' || message?.type === 'apply-remote-preview') {
      return Promise.reject(new Error(EXTENSION_RELOAD_REQUIRED))
    }
    return Promise.reject(new Error('Unsupported extension command'))
  })

  task
    .then((result) =>
      respond(
        message?.type === EXTENSION_CAPABILITIES_COMMAND
          ? { ok: true, capabilities: result }
          : message?.type === READ_POPUP_SCOPED_STATE_COMMAND ||
              message?.type === WRITE_POPUP_SCOPED_STATE_COMMAND
            ? { ok: true, state: result }
            : { ok: true, active: result }
      )
    )
    .catch((error) => respond({ ok: false, message: error.message }))
  return true
})

chrome.tabs.onRemoved.addListener((tabId) => {
  void serializeMutation(async () => {
    try {
      await removePreview(tabId)
    } finally {
      await removePersistedPopupStatesForTab(tabId)
    }
  })
})

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!changeInfo.url) return
  void serializeMutation(async () => {
    const currentTab = await chrome.tabs.get(tabId).catch(() => tab)
    if (currentTab?.url !== changeInfo.url) return
    const active = await readActivePreviews()
    const current = active[String(tabId)] || null
    if (current && !activePreviewMatchesTab(current, currentTab)) await removePreview(tabId)
    await applyConfigurationShare(currentTab)
  })
})

chrome.alarms.onAlarm.addListener((alarm) => {
  const tabId = previewAlarmTabId(alarm.name)
  if (tabId === null) return
  void serializeMutation(async () => {
    const active = await readActivePreviews()
    const current = active[String(tabId)] || null
    if (!current) {
      await chrome.alarms.clear(alarm.name)
      return
    }
    if (previewExpiresAt(current) > Date.now()) {
      await schedulePreviewExpiry(tabId, current)
      return
    }
    const tab = await chrome.tabs.get(tabId).catch(() => null)
    const recoveryUrl = recoveryUrlForActivePreview(current, tab)
    await removePreview(tabId)
    if (recoveryUrl) await chrome.tabs.update(tabId, { url: recoveryUrl }).catch(() => undefined)
  })
})

async function reconcileExtensionLifecycles() {
  try {
    await reconcilePreviewLifecycles()
  } finally {
    await reconcilePersistedPopupStates()
  }
  await scanConfigurationShareTabs()
}

chrome.runtime.onStartup.addListener(() => {
  void serializeMutation(reconcileExtensionLifecycles)
})

chrome.runtime.onInstalled.addListener(() => {
  void serializeMutation(reconcileExtensionLifecycles)
})
