export function normalizeBindingCandidates(value) {
  const source = Array.isArray(value?.items) ? value.items : value?.id ? [value] : []
  const seen = new Set()
  return source.filter((binding) => {
    if (
      !binding ||
      typeof binding.id !== 'string' ||
      typeof binding.environmentSlug !== 'string' ||
      typeof binding.hostname !== 'string' ||
      seen.has(binding.id)
    ) {
      return false
    }
    seen.add(binding.id)
    return true
  })
}

export function chooseBindingCandidate({
  candidates,
  rememberedEnvironmentSlug,
  activeSiteBindingId,
}) {
  if (!candidates?.length) return null
  return (
    candidates.find((binding) => binding.id === activeSiteBindingId) ||
    candidates.find((binding) => binding.environmentSlug === rememberedEnvironmentSlug) ||
    candidates[0]
  )
}

export function bindingEnvironmentLabel(binding) {
  const name = typeof binding?.environmentName === 'string' ? binding.environmentName.trim() : ''
  const status =
    binding?.environmentStatus === 'FROZEN'
      ? ' · 冻结'
      : binding?.environmentStatus === 'ARCHIVED'
        ? ' · 归档'
        : ''
  const label = name ? `${name} · ${binding.environmentSlug}` : binding?.environmentSlug
  return `${label || '未命名环境'}${status}`
}
