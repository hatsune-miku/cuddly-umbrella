import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'

import { App } from './App'
import { ShareLanding, shareTokenFromPathname } from './ShareLanding'
import './styles.css'

const shareToken = shareTokenFromPathname(window.location.pathname)

createRoot(document.getElementById('root')!).render(
  <StrictMode>{shareToken ? <ShareLanding token={shareToken} /> : <App />}</StrictMode>
)
