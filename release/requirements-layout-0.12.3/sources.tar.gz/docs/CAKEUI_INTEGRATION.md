# CakeUI 界面维护

本次 UI 使用 [CakeUI 文档](https://gallery.vanillacake.cn/llms.txt) 对应的
`@a1knla/cakeui@0.1.0`，统一为 blue / light / compact。保留控制台最大宽度和双列项目区、
浏览器扩展单列紧凑布局、可搜索的分支下拉、构建队列和原有业务状态。

0.12.2 已撤回 0.12.1 的额外视觉设计，恢复 0.12.0 的经典 CakeUI 外观。

0.12.3 修复扩展/PC 插件的需求列表：内容左对齐，行间保留 6px 间距，
Grid 行按内容高度排布并在列表内滚动，避免多条需求被压缩裁切。
不要额外覆盖 CakeUI 的色板、字体、圆角或阴影；产品样式只负责必要布局。

## 实现边界

- 控制台直接使用 CakeUI React 组件。`apps/console/src/ui.tsx` 集中导出控件并定义操作按钮层级。
- 扩展不引入第二套 React 状态树：构建时从真实 CakeUI 组件生成原生节点描述，
  `cakeui-dom.js` 在既有节点上附加组件样式，不更换事件、输入值、禁用状态或业务属性。
- PC 插件由扩展源文件同步，不能单独改 `apps/console/public/pc-plugin/`。
- 帮助页与 OAuth 完成页也使用随包部署的 CakeUI 样式。运行时不访问组件 CDN。
- `packages/ui-theme/theme.css` 只定义兼容变量和共享布局，色板由 CakeUI 提供。
  原有样式放在 `bifrost-layout` 层，CakeUI 基础控件在其上；产品级布局在各自 `cake-layout.css`。
- 本次没有修改网关、DNR、hot-module 覆写、构建调度、权限或接口契约。

## 构建与检查

```powershell
pnpm --filter @cuddly/console build
pnpm --filter @cuddly/browser-extension test
pnpm test
node docs/scripts/capture_help_screens.mjs
node docs/scripts/test_help.mjs
```

`build:ui` 会复制库内 CSS、生成原生控件描述，并同步共享主题。生成文件不能手工改。
修改截图后再次构建控制台，才能将新图带入 `dist`。
浏览器扩展仍在原目录 `apps/browser-extension`，在扩展管理页重新加载即可。

扩展测试覆盖控件语义和业务回归；浏览器检查使用本地演示数据，覆盖分支搜索、标签切换、
环境/项目/代理/系统表单、分享表单、失败任务重试入口、运行任务中断入口、分页与移动布局。
这些检查不会创建生产构建或分享，不会访问真实业务后端。

## 发布

网站按原控制台部署流程更新；OAuth 页面样式引用在 control-api 中，需与 `/ui/` 静态资产一起上线。
只更新前端静态包不会更新 control-api 输出的 OAuth HTML。

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File ./kfc-pack.ps1 -Version 0.12.3
```

该命令只生成可安装 ZIP，不会自动发布 KFC。UI 版本变更不需要更改扩展业务协议。
