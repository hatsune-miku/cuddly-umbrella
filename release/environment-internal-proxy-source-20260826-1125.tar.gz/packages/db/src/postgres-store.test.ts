import { createHash } from 'node:crypto'

import type { Artifact, BuildJob, BuildTarget, EnvironmentRecord } from '@cuddly/contracts'
import { afterEach, describe, expect, it, vi } from 'vitest'

import { PostgresStore } from './postgres-store'
import { schemaSql } from './schema'

const environment: EnvironmentRecord = {
  id: '00000000-0000-4000-8000-000000000002',
  slug: 'staging',
  name: '测试环境',
  status: 'ACTIVE',
  backendOrigin: 'https://staging-api.example.test',
  useInternalProxy: true,
  currentRevisionId: null,
}

const target: BuildTarget = {
  id: 'webapp',
  name: '网页端',
  kind: 'webapp',
  repositoryUrl: 'https://git.example.test/webapp.git',
  defaultBranch: 'master',
  installCommand: 'pnpm install',
  buildCommand: 'pnpm build',
  outputDirectory: 'dist',
  siteAdapter: 'generic-static-v1',
  enabled: true,
  required: false,
  configurationSource: 'database',
}

const artifact: Artifact = {
  id: '00000000-0000-4000-8000-000000000010',
  buildJobId: '00000000-0000-4000-8000-000000000011',
  environmentId: environment.id,
  environmentSlug: environment.slug,
  targetId: target.id,
  branch: 'feature/latest',
  status: 'READY',
  storageKey: 'ready/webapp/latest',
  manifest: {
    schemaVersion: 1,
    artifactId: '00000000-0000-4000-8000-000000000010',
    target: target.id,
    branch: 'feature/latest',
    builtAt: '2026-08-25T08:00:00.000Z',
    serve: {
      siteAdapter: 'generic-static-v1',
      entrypoints: ['index.html'],
      publicBase: '/artifacts/latest/',
    },
    files: [],
  },
  builtAt: '2026-08-25T08:00:00.000Z',
  createdBy: 'gz',
}

const activeJob: BuildJob = {
  id: '00000000-0000-4000-8000-000000000012',
  environmentId: environment.id,
  environmentSlug: environment.slug,
  targetId: target.id,
  branch: 'feature/building',
  profile: 'qa-web',
  status: 'BUILDING',
  requestedBy: 'gz',
  createdAt: '2026-08-25T09:00:00.000Z',
  startedAt: '2026-08-25T09:00:01.000Z',
  finishedAt: null,
  failureCode: null,
  failureMessage: null,
  logPath: null,
  targetSnapshot: null,
}

function artifactRow(value: Artifact) {
  return {
    id: value.id,
    build_job_id: value.buildJobId,
    environment_id: value.environmentId,
    environment_slug: value.environmentSlug,
    target_id: value.targetId,
    branch: value.branch,
    status: value.status,
    storage_key: value.storageKey,
    manifest: value.manifest,
    built_at: value.builtAt,
    created_by: value.createdBy,
  }
}

function jobRow(value: BuildJob) {
  return {
    id: value.id,
    environment_id: value.environmentId,
    environment_slug: value.environmentSlug,
    target_id: value.targetId,
    branch: value.branch,
    profile: value.profile,
    status: value.status,
    requested_by: value.requestedBy,
    created_at: value.createdAt,
    started_at: value.startedAt,
    finished_at: value.finishedAt,
    failure_code: value.failureCode,
    failure_message: value.failureMessage,
    log_path: value.logPath,
    target_snapshot: value.targetSnapshot,
  }
}

describe('PostgresStore matrix queries', () => {
  const stores: PostgresStore[] = []

  afterEach(async () => {
    vi.restoreAllMocks()
    await Promise.all(stores.splice(0).map((store) => store.close()))
  })

  it('uses two environment-scoped latest-row queries instead of loading history per project', async () => {
    const store = new PostgresStore('postgres://unused:unused@127.0.0.1:1/unused')
    stores.push(store)
    vi.spyOn(store, 'getEnvironment').mockResolvedValue(environment)
    vi.spyOn(store, 'listBuildTargets').mockResolvedValue([target])
    vi.spyOn(store, 'listProjectEnvironmentConfigs').mockResolvedValue([
      {
        targetId: target.id,
        environmentId: environment.id,
        enabled: true,
        required: false,
        installCommand: 'pnpm install --staging',
        buildCommand: 'pnpm build --staging',
        outputDirectory: 'staging-dist',
      },
    ])
    const listArtifacts = vi.spyOn(store, 'listArtifacts')
    const listJobs = vi.spyOn(store, 'listBuildJobs')
    const queries: string[] = []
    vi.spyOn(store.pool, 'query').mockImplementation((async (query: unknown) => {
      const sql = String(query)
      queries.push(sql)
      if (sql.includes('FROM artifacts')) return { rows: [artifactRow(artifact)] }
      if (sql.includes('FROM build_jobs')) return { rows: [jobRow(activeJob)] }
      throw new Error(`Unexpected matrix query: ${sql}`)
    }) as typeof store.pool.query)

    const matrix = await store.getEnvironmentMatrix(environment.slug)

    expect(matrix?.rows).toEqual([
      expect.objectContaining({
        latestArtifact: { id: artifact.id, branch: artifact.branch, builtAt: artifact.builtAt },
        activeJob: expect.objectContaining({ id: activeJob.id, status: 'BUILDING' }),
      }),
    ])
    expect(listArtifacts).not.toHaveBeenCalled()
    expect(listJobs).not.toHaveBeenCalled()
    expect(queries).toHaveLength(2)
    expect(queries.every((sql) => sql.includes('DISTINCT ON (target_id)'))).toBe(true)
    expect(queries.every((sql) => sql.includes('environment_id = $1'))).toBe(true)
  })
})

describe('Postgres environment migration', () => {
  it('maps the per-environment internal proxy switch', async () => {
    const store = new PostgresStore('postgres://unused:unused@127.0.0.1:1/unused')
    vi.spyOn(store.pool, 'query').mockResolvedValue({
      rows: [
        {
          id: environment.id,
          slug: environment.slug,
          name: environment.name,
          status: environment.status,
          backend_origin: environment.backendOrigin,
          use_internal_proxy: true,
          current_revision_id: null,
        },
      ],
    } as never)

    try {
      await expect(store.getEnvironment(environment.slug)).resolves.toEqual(environment)
    } finally {
      await store.close()
    }
  })

  it('backfills without overwriting origins and enforces paired environment identity', () => {
    expect(schemaSql).toContain("setting.key = 'system.webapp_upstream'")
    expect(schemaSql).toContain('WHERE backend_origin IS NULL')
    expect(schemaSql).toContain(
      "ALTER TABLE environments ALTER COLUMN backend_origin SET DEFAULT 'https://www.kookapp.cn'"
    )
    expect(schemaSql).toContain(
      'ADD COLUMN IF NOT EXISTS use_internal_proxy boolean NOT NULL DEFAULT false'
    )
    expect(schemaSql).toMatch(
      /INSERT INTO environments \(id, slug, name, status, backend_origin\)[\s\S]+?'https:\/\/www\.kookapp\.cn'/
    )
    expect(
      schemaSql.indexOf('ALTER TABLE environments ADD COLUMN IF NOT EXISTS backend_origin text')
    ).toBeLessThan(
      schemaSql.indexOf('INSERT INTO environments (id, slug, name, status, backend_origin)')
    )
    expect(schemaSql).toContain('environments_id_slug_unique_idx')
    expect(schemaSql).toContain(
      'FOREIGN KEY (environment_id, environment_slug) REFERENCES environments(id, slug)'
    )
    expect(schemaSql).toContain('pg_get_constraintdef(constraint_row.oid)')
    expect(schemaSql).not.toContain(
      'ALTER TABLE build_jobs DROP CONSTRAINT IF EXISTS build_jobs_environment_identity_fkey'
    )
    expect(schemaSql).not.toContain(
      'ALTER TABLE artifacts DROP CONSTRAINT IF EXISTS artifacts_environment_identity_fkey'
    )
    expect(schemaSql).not.toContain(
      'ALTER TABLE preview_sessions DROP CONSTRAINT IF EXISTS preview_sessions_environment_identity_fkey'
    )
  })

  it('keeps old site origin writes synchronized and seeds only the shared environment', () => {
    expect(schemaSql).toContain('cuddly_sync_site_binding_origins')
    expect(schemaSql).toContain("WHERE environment.slug = 'shared'")
    expect(schemaSql).toContain('ON CONFLICT (environment_id, target_id) DO NOTHING')
    expect(schemaSql).toContain('site_bindings_official_environment_unique_idx')
  })

  it('indexes bounded matrix lookups and environment-scoped Artifact retention', () => {
    expect(schemaSql).toContain('build_jobs_environment_active_idx')
    expect(schemaSql).toContain('artifacts_environment_catalog_idx')
  })

  it('creates permanent immutable V1 configuration groups with structured JSON items', () => {
    expect(schemaSql).toContain('CREATE TABLE IF NOT EXISTS configuration_groups')
    expect(schemaSql).toContain('configuration_groups_schema_version_v1')
    expect(schemaSql).toContain("CHECK (jsonb_typeof(items) = 'array')")
    expect(schemaSql).toMatch(
      /configuration_groups_environment_identity_fkey\s+FOREIGN KEY \(environment_id, environment_slug\) REFERENCES environments\(id, slug\)/
    )
    expect(schemaSql).toContain('site_binding_id text NOT NULL REFERENCES site_bindings(id)')
  })
})

describe('PostgresStore configuration groups', () => {
  it('maps persisted JSON items without exposing the row array', async () => {
    const store = new PostgresStore('postgres://unused:unused@127.0.0.1:1/unused')
    const items = [
      { targetId: 'webapp', mode: 'official' as const },
      { targetId: 'base', mode: 'branch' as const, branch: 'feature/permissions' },
    ]
    const query = vi.spyOn(store.pool, 'query').mockResolvedValue({
      rows: [
        {
          token: 'share-token',
          name: '频道权限重构',
          environment_id: environment.id,
          environment_slug: environment.slug,
          site_binding_id: 'main',
          schema_version: 1,
          items,
          created_by: 'gz',
          created_at: '2026-08-25T12:34:56.000Z',
        },
      ],
    } as never)

    try {
      const group = await store.getConfigurationGroup('share-token')
      expect(query).toHaveBeenCalledWith('SELECT * FROM configuration_groups WHERE token = $1', [
        'share-token',
      ])
      expect(group).toEqual({
        token: 'share-token',
        name: '频道权限重构',
        environmentId: environment.id,
        environmentSlug: environment.slug,
        siteBindingId: 'main',
        schemaVersion: 1,
        items,
        createdBy: 'gz',
        createdAt: '2026-08-25T12:34:56.000Z',
      })
      group!.items.length = 0
      expect(items).toHaveLength(2)
    } finally {
      await store.close()
    }
  })
})

describe('PostgresStore Remote runtime authorization', () => {
  it('uses only active Preview sessions and ignores legacy Revision references', async () => {
    const store = new PostgresStore('postgres://unused:unused@127.0.0.1:1/unused')
    const query = vi.spyOn(store.pool, 'query').mockResolvedValue({
      rows: [{ referenced: false }],
    } as never)

    try {
      expect(await store.isRemoteArtifactReferenced(artifact.id)).toBe(false)
      const sql = String(query.mock.calls[0]?.[0])
      expect(sql).toContain('FROM preview_sessions')
      expect(sql).not.toContain('environment_artifact_refs')
    } finally {
      await store.close()
    }
  })
})

describe('PostgresStore auth sessions', () => {
  const token = 'opaque-session-token'
  const tokenHash = createHash('sha256').update(token, 'utf8').digest('hex')
  const row = {
    session_token_hash: tokenHash,
    tenant_key: 'tenant-1',
    open_id: 'open-1',
    union_id: '',
    name: '测试用户',
    avatar_url: '',
    csrf_token: 'csrf-token',
    created_at: '2026-08-25T12:00:00.000Z',
    expires_at: '2026-08-25T13:00:00.000Z',
  }

  it('persists and looks up only the SHA-256 token hash', async () => {
    const store = new PostgresStore('postgres://unused:unused@127.0.0.1:1/unused')
    const query = vi.spyOn(store.pool, 'query')
    query.mockResolvedValueOnce({ rows: [row], rowCount: 1 } as never)
    query.mockResolvedValueOnce({ rows: [row], rowCount: 1 } as never)
    query.mockResolvedValueOnce({ rows: [], rowCount: 1 } as never)

    try {
      const created = await store.createAuthSession({
        token,
        tenantKey: row.tenant_key,
        openId: row.open_id,
        unionId: row.union_id,
        name: row.name,
        avatarUrl: row.avatar_url,
        csrfToken: row.csrf_token,
        createdAt: row.created_at,
        expiresAt: row.expires_at,
      })
      expect(created).not.toHaveProperty('token')
      expect(created).not.toHaveProperty('tokenHash')
      expect(query.mock.calls[0]?.[1]).toEqual([
        tokenHash,
        row.tenant_key,
        row.open_id,
        row.union_id,
        row.name,
        row.avatar_url,
        row.csrf_token,
        row.created_at,
        row.expires_at,
      ])
      expect(query.mock.calls[0]?.[1]).not.toContain(token)

      await expect(store.getAuthSession(token)).resolves.toEqual({
        tenantKey: row.tenant_key,
        openId: row.open_id,
        unionId: row.union_id,
        name: row.name,
        avatarUrl: row.avatar_url,
        csrfToken: row.csrf_token,
        createdAt: row.created_at,
        expiresAt: row.expires_at,
      })
      expect(String(query.mock.calls[1]?.[0])).toContain('DELETE FROM auth_sessions')
      expect(String(query.mock.calls[1]?.[0])).toContain('expires_at <= now()')
      expect(String(query.mock.calls[1]?.[0])).toContain('expires_at > now()')
      expect(query.mock.calls[1]?.[1]).toEqual([tokenHash])

      await expect(store.deleteAuthSession(token)).resolves.toBe(true)
      expect(query.mock.calls[2]?.[1]).toEqual([tokenHash])
    } finally {
      await store.close()
    }
  })

  it('declares hashed session storage and expiry cleanup indexes', () => {
    const table = schemaSql.match(/CREATE TABLE IF NOT EXISTS auth_sessions \(([\s\S]*?)\n\);/)?.[1]
    expect(table).toContain('session_token_hash text PRIMARY KEY')
    expect(table).toContain("CHECK (session_token_hash ~ '^[0-9a-f]{64}$')")
    expect(table).not.toMatch(/^\s*(?:session_)?token\s/m)
    expect(schemaSql).toContain('auth_sessions_subject_idx')
    expect(schemaSql).toContain('auth_sessions_expires_idx')
  })
})
