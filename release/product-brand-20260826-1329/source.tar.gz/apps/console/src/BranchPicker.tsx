import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from 'react'
import { createPortal } from 'react-dom'
import type { BranchCatalogItem, BuildQueueItem } from '@cuddly/contracts'
import { PRODUCT_NAME } from '@cuddly/product'
import { Check, ChevronDown, GitBranch, Search, X } from 'lucide-react'

import {
  branchOptionStatus,
  createBranchPickerOptions,
  filterBranchPickerOptions,
  type BranchPickerOption,
} from './branch-picker'

function formatTime(value: string | null | undefined): string {
  if (!value) return '无可用产物'
  return new Intl.DateTimeFormat('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(new Date(value))
}

function connectedOptions(optionRefs: Array<HTMLButtonElement | null>): HTMLButtonElement[] {
  return optionRefs.filter((option): option is HTMLButtonElement => Boolean(option?.isConnected))
}

function focusOption(optionRefs: Array<HTMLButtonElement | null>, index: number): void {
  const options = connectedOptions(optionRefs)
  if (!options.length) return
  const normalized = (index + options.length) % options.length
  for (const option of options) option.tabIndex = -1
  const target = options[normalized]
  if (!target) return
  target.tabIndex = 0
  target.focus()
}

export function BranchPicker({
  targetId,
  targetName,
  items,
  queueItems,
  selectedBranch,
  fallbackBranch,
  officialLabel,
  onChange,
}: {
  targetId: string
  targetName: string
  items: BranchCatalogItem[]
  queueItems: BuildQueueItem[]
  selectedBranch: string
  fallbackBranch: string
  officialLabel?: string
  onChange: (branch: string) => void
}) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const searchRef = useRef<HTMLInputElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const dialogRef = useRef<HTMLElement>(null)
  const optionRefs = useRef<Array<HTMLButtonElement | null>>([])
  const options = useMemo(
    () =>
      createBranchPickerOptions({
        items,
        queueItems,
        targetId,
        selectedBranch,
        fallbackBranch,
      }),
    [fallbackBranch, items, queueItems, selectedBranch, targetId]
  )
  const filtered = useMemo(() => filterBranchPickerOptions(options, query), [options, query])
  const selected = options.find((item) => item.branch === selectedBranch) || null
  const selectedStatus = selected ? branchOptionStatus(selected) : null

  useEffect(() => {
    if (!open) return
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    window.requestAnimationFrame(() => searchRef.current?.focus())
    return () => {
      document.body.style.overflow = previousOverflow
    }
  }, [open])

  function close(): void {
    setOpen(false)
    setQuery('')
    window.requestAnimationFrame(() => triggerRef.current?.focus())
  }

  function choose(branch: string): void {
    onChange(branch)
    close()
  }

  function handleOptionKeyDown(event: KeyboardEvent<HTMLButtonElement>): void {
    const options = connectedOptions(optionRefs.current)
    const index = options.indexOf(event.currentTarget)
    if (event.key === 'Escape') {
      event.preventDefault()
      close()
    } else if (event.key === 'ArrowDown') {
      event.preventDefault()
      focusOption(optionRefs.current, index + 1)
    } else if (event.key === 'ArrowUp') {
      event.preventDefault()
      focusOption(optionRefs.current, index - 1)
    } else if (event.key === 'Home') {
      event.preventDefault()
      focusOption(optionRefs.current, 0)
    } else if (event.key === 'End') {
      event.preventDefault()
      focusOption(optionRefs.current, connectedOptions(optionRefs.current).length - 1)
    }
  }

  const renderedOptions: Array<BranchPickerOption | null> = [
    ...(officialLabel ? [null] : []),
    ...filtered.items,
  ]
  const selectedOptionIndex = Math.max(
    0,
    renderedOptions.findIndex((option) =>
      option ? option.branch === selectedBranch : selectedBranch === ''
    )
  )

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        className="branch-picker-trigger"
        aria-haspopup="dialog"
        aria-expanded={open}
        onClick={() => setOpen(true)}
      >
        <GitBranch size={14} />
        <span className="branch-picker-trigger-copy">
          <strong title={selectedBranch || officialLabel}>
            {selectedBranch || officialLabel || fallbackBranch}
          </strong>
          <small className={selectedStatus ? `tone-${selectedStatus.tone}` : ''}>
            {selectedStatus?.text || `不使用 ${PRODUCT_NAME} 产物`}
          </small>
        </span>
        <ChevronDown size={14} />
      </button>

      {open
        ? createPortal(
            <div
              className="branch-picker-scrim"
              role="presentation"
              onMouseDown={(event) => {
                if (event.target === event.currentTarget) close()
              }}
            >
              <section
                ref={dialogRef}
                className="branch-picker-dialog"
                role="dialog"
                aria-modal="true"
                aria-labelledby={`branch-picker-title-${targetId}`}
                onKeyDown={(event) => {
                  if (event.key === 'Escape') {
                    event.preventDefault()
                    close()
                  } else if (event.key === 'Tab') {
                    const focusable = [
                      ...(dialogRef.current?.querySelectorAll<HTMLElement>(
                        'button:not([disabled]):not([tabindex="-1"]), input:not([disabled])'
                      ) || []),
                    ].filter((element) => element.isConnected)
                    if (!focusable.length) return
                    const first = focusable[0]
                    const last = focusable[focusable.length - 1]
                    if (!first || !last) return
                    if (event.shiftKey && document.activeElement === first) {
                      event.preventDefault()
                      last.focus()
                    } else if (!event.shiftKey && document.activeElement === last) {
                      event.preventDefault()
                      first.focus()
                    }
                  }
                }}
              >
                <header className="branch-picker-heading">
                  <div>
                    <span>选择分支</span>
                    <h2 id={`branch-picker-title-${targetId}`}>{targetName}</h2>
                  </div>
                  <button
                    type="button"
                    className="icon-button"
                    onClick={close}
                    title="关闭分支选择"
                  >
                    <X size={17} />
                  </button>
                </header>

                <label className="branch-picker-search">
                  <Search size={15} />
                  <span className="sr-only">搜索分支</span>
                  <input
                    ref={searchRef}
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    onKeyDown={(event) => {
                      if (event.key === 'ArrowDown') {
                        event.preventDefault()
                        focusOption(optionRefs.current, 0)
                      }
                    }}
                    placeholder="搜索分支名称"
                    autoComplete="off"
                  />
                  {query ? (
                    <button type="button" onClick={() => setQuery('')} aria-label="清空搜索">
                      <X size={14} />
                    </button>
                  ) : null}
                </label>

                <div
                  className="branch-picker-options"
                  role="listbox"
                  aria-label={`${targetName} 分支`}
                >
                  {renderedOptions.map((option, index) => {
                    if (!option) {
                      const selectedOfficial = selectedBranch === ''
                      return (
                        <button
                          key="official"
                          ref={(element) => {
                            optionRefs.current[index] = element
                          }}
                          type="button"
                          role="option"
                          tabIndex={index === selectedOptionIndex ? 0 : -1}
                          aria-selected={selectedOfficial}
                          className={`branch-picker-option official-option ${selectedOfficial ? 'selected' : ''}`}
                          onClick={() => choose('')}
                          onKeyDown={handleOptionKeyDown}
                        >
                          <span className="branch-option-main">
                            <strong>{officialLabel}</strong>
                            <small>不使用 {PRODUCT_NAME} 打包产物</small>
                          </span>
                          <span className="branch-option-status tone-idle">官方版本</span>
                          {selectedOfficial ? <Check size={16} /> : null}
                        </button>
                      )
                    }
                    const status = branchOptionStatus(option)
                    const isSelected = option.branch === selectedBranch
                    return (
                      <button
                        key={option.branch}
                        ref={(element) => {
                          optionRefs.current[index] = element
                        }}
                        type="button"
                        role="option"
                        tabIndex={index === selectedOptionIndex ? 0 : -1}
                        aria-selected={isSelected}
                        className={`branch-picker-option ${isSelected ? 'selected' : ''}`}
                        onClick={() => choose(option.branch)}
                        onKeyDown={handleOptionKeyDown}
                      >
                        <span className="branch-option-main">
                          <strong title={option.branch}>{option.branch}</strong>
                          <small>上次产物 {formatTime(option.latestArtifact?.builtAt)}</small>
                        </span>
                        <span className={`branch-option-status tone-${status.tone}`}>
                          {status.text}
                        </span>
                        {isSelected ? <Check size={16} /> : null}
                      </button>
                    )
                  })}
                  {filtered.total === 0 ? (
                    <div className="branch-picker-empty">没有匹配“{query.trim()}”的分支</div>
                  ) : null}
                </div>

                <footer className="branch-picker-footer">
                  <span>共 {filtered.total} 个匹配分支</span>
                  {filtered.truncated ? (
                    <strong>仅显示前 100 条，请继续输入以缩小范围</strong>
                  ) : null}
                </footer>
              </section>
            </div>,
            document.body
          )
        : null}
    </>
  )
}
