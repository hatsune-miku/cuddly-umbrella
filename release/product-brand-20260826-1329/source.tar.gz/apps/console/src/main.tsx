import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { PRODUCT_DISPLAY_NAME } from '@cuddly/product'

import { App } from './App'
import { AuthGate } from './AuthGate'
import { ShareLanding, shareTokenFromPathname } from './ShareLanding'
import './styles.css'

const shareToken = shareTokenFromPathname(window.location.pathname)
document.title = PRODUCT_DISPLAY_NAME

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthGate>
      {(session, onLogout) =>
        shareToken ? (
          <ShareLanding token={shareToken} />
        ) : (
          <App identity={session.identity} onLogout={onLogout} />
        )
      }
    </AuthGate>
  </StrictMode>
)
