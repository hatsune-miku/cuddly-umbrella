import { readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const extensionRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const repositoryRoot = path.resolve(extensionRoot, '../..')
const productConfigPath = path.join(repositoryRoot, 'product.config.json')
const manifestPath = path.join(extensionRoot, 'manifest.json')

const productConfig = JSON.parse(await readFile(productConfigPath, 'utf8'))
const productName = typeof productConfig.name === 'string' ? productConfig.name.trim() : ''
if (!productName || productName !== productConfig.name || productName.length > 40) {
  throw new Error('product.config.json name must be a trimmed string between 1 and 40 characters')
}

const manifest = JSON.parse(await readFile(manifestPath, 'utf8'))
const expectedName = `${productName} QA`
if (manifest.name === expectedName && manifest.short_name === productName) process.exit(0)

manifest.name = expectedName
manifest.short_name = productName
await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8')
console.log(`[browser-extension] synchronized product name: ${expectedName}`)
