import { describe, expect, it } from 'vitest'

import { kookRemoteModuleKeys } from '@cuddly/contracts'

import {
  KOOK_PNPM_COMMAND,
  KOOK_REMOTE_PREBUILD_DIRECTORIES,
  PROJECT_TEMPLATES,
  kookRemoteBuildCommand,
  kookRemoteInstallCommand,
} from './project-templates.js'

describe('KOOK project command templates', () => {
  it('pins pnpm and installs only each Remote workspace dependency closure', () => {
    for (const id of kookRemoteModuleKeys) {
      expect(kookRemoteInstallCommand(id)).toBe(
        `${KOOK_PNPM_COMMAND} --filter '{./apps/${id}}...' --fail-if-no-match install --frozen-lockfile`
      )
    }
  })

  it('builds generated workspace entry points in dependency order before each Remote', () => {
    expect(KOOK_REMOTE_PREBUILD_DIRECTORIES.discover).toEqual([
      'packages/kjsbridge',
      'packages/utils',
    ])
    expect(KOOK_REMOTE_PREBUILD_DIRECTORIES.guild).toEqual([
      'packages/kjsbridge',
      'packages/utils',
      'packages/virtual-layout-engine',
      'packages/virtual-layout-engine-react',
    ])
    expect(KOOK_REMOTE_PREBUILD_DIRECTORIES.help_center).toEqual([])

    expect(kookRemoteBuildCommand('discover', 'ttt')).toBe(
      'corepack pnpm@9.15.9 --dir packages/kjsbridge run build && corepack pnpm@9.15.9 --dir packages/utils run build && corepack pnpm@9.15.9 --dir apps/discover run build:ttt'
    )
  })

  it('uses only build scripts and keeps every configured command within the API limit', () => {
    for (const id of kookRemoteModuleKeys) {
      for (const environment of ['prod', 'ttt'] as const) {
        const command = kookRemoteBuildCommand(id, environment)
        expect(command).not.toMatch(/(?:release|upload):/)
        expect(command.length).toBeLessThanOrEqual(1000)
        expect(command).toContain(`--dir apps/${id} run build:${environment}`)
      }
    }
  })

  it('matches the package managers and output directories used by standalone site repos', () => {
    expect(PROJECT_TEMPLATES.find(({ id }) => id === 'online-h5')).toMatchObject({
      installCommand: 'corepack pnpm@9.15.9 install --frozen-lockfile',
      buildCommand: 'corepack pnpm@9.15.9 run build',
      outputDirectory: 'build',
    })
    expect(PROJECT_TEMPLATES.find(({ id }) => id === 'webapp')).toMatchObject({
      installCommand: 'npm run i',
      buildCommand: 'npm run build_fast',
      outputDirectory: 'build',
    })
    expect(PROJECT_TEMPLATES.find(({ id }) => id === 'biz')).toMatchObject({
      installCommand: 'npm install --legacy-peer-deps --verbose',
      buildCommand: 'npm run build',
      outputDirectory: 'build',
    })
  })
})
