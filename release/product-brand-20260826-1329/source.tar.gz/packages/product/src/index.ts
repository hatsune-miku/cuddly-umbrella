import productConfig from '../../../product.config.json'

const configuredProductName = productConfig.name.trim()

if (!configuredProductName) {
  throw new Error('product.config.json name must not be empty')
}

/** The single product brand. Technical namespaces intentionally remain stable. */
export const PRODUCT_NAME = configuredProductName

/** The QA-facing Console and browser-extension title. */
export const PRODUCT_DISPLAY_NAME = `${PRODUCT_NAME} QA`

/** The extension is another surface of the same QA product, not a separate brand. */
export const EXTENSION_NAME = PRODUCT_DISPLAY_NAME
