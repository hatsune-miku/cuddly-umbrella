import { randomUUID } from 'node:crypto'

import type { Artifact, SiteBinding } from '@cuddly/contracts'
import { describe, expect, it } from 'vitest'

import { MemoryStore } from './memory-store'

describe('built-in project templates', () => {
  it('includes every KOOK Remote as an explicit disabled build target', async () => {
    const store = new MemoryStore()
    const targets = await store.listBuildTargets(true)
    const base = targets.find((target) => target.id === 'base')
    const voiceRuntime = targets.find((target) => target.id === 'voice_runtime')

    expect(base).toMatchObject({
      kind: 'remote',
      buildCommand: 'corepack pnpm --dir apps/base run build:prod',
      outputDirectory: 'apps/base/dist',
      siteAdapter: 'kook-remote-v1',
      enabled: false,
    })
    expect(voiceRuntime).toMatchObject({
      kind: 'remote',
      buildCommand: 'corepack pnpm --dir apps/voice_runtime run build:prod',
      outputDirectory: 'apps/voice_runtime/dist',
    })
  })
})

function artifact(jobId: string, branch: string): Artifact {
  const id = randomUUID()
  const builtAt = new Date().toISOString()
  return {
    id,
    buildJobId: jobId,
    targetId: 'online-h5',
    branch,
    status: 'READY',
    storageKey: `ready/online-h5/${id}`,
    builtAt,
    createdBy: 'gz',
    manifest: {
      schemaVersion: 1,
      artifactId: id,
      target: 'online-h5',
      branch,
      builtAt,
      serve: {
        siteAdapter: 'kook-online-h5-v1',
        entrypoints: ['index.htm'],
        publicBase: `/__cuddly/artifacts/${id}/`,
      },
      files: [
        {
          path: 'index.htm',
          size: 1,
          contentType: 'text/html; charset=utf-8',
          digest: 'sha256:test',
          cacheClass: 'html',
        },
      ],
    },
  }
}

function remoteArtifact(branch: string): Artifact {
  const id = randomUUID()
  const builtAt = new Date().toISOString()
  const providerName = `cuddly_base_${id.replaceAll('-', '').slice(0, 12)}`
  return {
    id,
    buildJobId: randomUUID(),
    targetId: 'base',
    branch,
    status: 'READY',
    storageKey: `ready/base/${id}`,
    builtAt,
    createdBy: 'gz',
    manifest: {
      schemaVersion: 1,
      artifactId: id,
      target: 'base',
      branch,
      builtAt,
      serve: {
        siteAdapter: 'kook-remote-v1',
        entrypoints: ['remoteEntry.js'],
        publicBase: `https://bifrost.example.test/__cuddly/preview-artifacts/${id}/${providerName}/`,
        remote: { moduleKey: 'base', providerName, entryPath: 'remoteEntry.js' },
      },
      files: [
        {
          path: 'remoteEntry.js',
          size: 1,
          contentType: 'text/javascript',
          digest: 'sha256:test',
          cacheClass: 'asset',
        },
      ],
    },
  }
}

describe('MemoryStore environment publication', () => {
  it('keeps a completed build separate from the active environment until publication', async () => {
    const store = new MemoryStore()
    const job = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/qa-panel',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const built = artifact(job.id, job.branch)
    await store.createArtifact(built)

    expect(await store.resolveCurrentArtifact('shared', 'online-h5')).toBeNull()

    const revision = await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: null,
      message: 'QA publish',
      createdBy: 'gz',
      selections: [{ targetId: 'online-h5', artifactId: built.id }],
    })

    expect((await store.resolveCurrentArtifact('shared', 'online-h5'))?.id).toBe(built.id)
    expect(await store.isArtifactReferenced(revision.environmentId, built.id)).toBe(true)
  })

  it('keeps artifacts from older revisions referenced after switching', async () => {
    const store = new MemoryStore()
    const first = artifact(randomUUID(), 'release/one')
    const second = artifact(randomUUID(), 'release/two')
    await store.createArtifact(first)
    await store.createArtifact(second)

    const revisionOne = await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: null,
      message: 'one',
      createdBy: 'gz',
      selections: [{ targetId: 'online-h5', artifactId: first.id }],
    })
    await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: revisionOne.id,
      message: 'two',
      createdBy: 'gz',
      selections: [{ targetId: 'online-h5', artifactId: second.id }],
    })

    const environment = await store.getEnvironment('shared')
    expect(environment).not.toBeNull()
    expect(await store.isArtifactReferenced(environment!.id, first.id)).toBe(true)
    expect((await store.resolveCurrentArtifact('shared', 'online-h5'))?.id).toBe(second.id)
  })

  it('resolves enabled Remote selections in one snapshot and retains old assets', async () => {
    const store = new MemoryStore()
    await store.saveBuildTarget(
      {
        ...(await store.getBuildTarget('base'))!,
        repositoryUrl: 'ssh://git.example.test/kook.git',
        enabled: true,
        configurationSource: 'database',
      },
      'gz'
    )
    const remote = remoteArtifact('feature/base')
    await store.createArtifact(remote)
    const first = await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: null,
      message: 'remote on',
      createdBy: 'gz',
      selections: [{ targetId: 'base', artifactId: remote.id }],
    })

    expect((await store.resolveCurrentRemoteArtifacts('shared', ['base']))[0]?.id).toBe(remote.id)
    expect(await store.isRemoteArtifactReferenced(remote.id)).toBe(true)

    await store.publishRevision({
      environmentId: 'shared',
      baseRevisionId: first.id,
      message: 'remote off',
      createdBy: 'gz',
      selections: [],
    })
    expect(await store.resolveCurrentRemoteArtifacts('shared', ['base'])).toEqual([])
    expect(await store.isRemoteArtifactReferenced(remote.id)).toBe(true)
  })
})

describe('MemoryStore build queue', () => {
  it('exposes running jobs before queued jobs and preserves queue order', async () => {
    const store = new MemoryStore()
    const first = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000001',
      targetId: 'online-h5',
      branch: 'feature/first',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const second = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000002',
      targetId: 'online-h5',
      branch: 'feature/second',
      profile: 'qa-web',
      requestedBy: 'qa-two',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const third = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000003',
      targetId: 'online-h5',
      branch: 'feature/third',
      profile: 'qa-web',
      requestedBy: 'qa-three',
      idempotencyKey: null,
      targetSnapshot: null,
    })

    expect((await store.claimNextBuildJob('worker-1'))?.id).toBe(first.id)

    const queue = await store.listBuildQueue()
    expect(queue.map((job) => job.id)).toEqual([first.id, second.id, third.id])

    await store.updateBuildJob(first.id, { status: 'SUCCEEDED' })
    expect((await store.listBuildQueue()).map((job) => job.id)).toEqual([second.id, third.id])
  })

  it('keeps the project execution snapshot on the queued job', async () => {
    const store = new MemoryStore()
    const snapshot = {
      id: 'online-h5',
      repositoryUrl: 'https://git.example.test/mobile.git',
      installCommand: 'pnpm install',
      buildCommand: 'pnpm build',
      outputDirectory: 'build',
      siteAdapter: 'kook-online-h5-v1',
    }
    const job = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'master',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: snapshot,
    })

    await store.saveBuildTarget(
      {
        ...(await store.getBuildTarget('online-h5'))!,
        buildCommand: 'pnpm build:changed',
        configurationSource: 'database',
      },
      'gz'
    )

    expect(job.targetSnapshot).toEqual(snapshot)
  })

  it('runs different projects in parallel while keeping each project serial', async () => {
    const store = new MemoryStore()
    const firstOnline = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000011',
      targetId: 'online-h5',
      branch: 'feature/online-first',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const secondOnline = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000012',
      targetId: 'online-h5',
      branch: 'feature/online-second',
      profile: 'qa-web',
      requestedBy: 'qa-two',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const webapp = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000013',
      targetId: 'webapp',
      branch: 'feature/webapp',
      profile: 'qa-web',
      requestedBy: 'qa-three',
      idempotencyKey: null,
      targetSnapshot: null,
    })

    expect((await store.claimNextBuildJob('worker-1'))?.id).toBe(firstOnline.id)
    expect((await store.claimNextBuildJob('worker-1'))?.id).toBe(webapp.id)
    expect(await store.claimNextBuildJob('worker-1')).toBeNull()

    await store.updateBuildJob(firstOnline.id, { status: 'SUCCEEDED' })
    expect((await store.claimNextBuildJob('worker-1'))?.id).toBe(secondOnline.id)
  })
})

describe('MemoryStore preview sessions', () => {
  it('expires preview tokens and stops retaining their artifacts', async () => {
    const store = new MemoryStore()
    const artifactId = randomUUID()
    await store.createPreviewSession({
      token: 'expired-preview',
      createdBy: 'gz',
      expiresAt: new Date(Date.now() - 1000).toISOString(),
      selections: [
        {
          moduleKey: 'base',
          targetId: 'base',
          artifactId,
          branch: 'feature/expired',
          builtAt: new Date().toISOString(),
          providerName: 'cuddly_base_expired',
          version: 'cuddly_base_expired',
          entryPath: 'remoteEntry.js',
        },
      ],
    })

    expect(await store.getPreviewSession('expired-preview')).toBeNull()
    expect(await store.isArtifactReferencedByActivePreview(artifactId)).toBe(false)
  })
})

describe('MemoryStore site bindings', () => {
  it('supports CRUD and enabled hostname/origin resolution', async () => {
    const store = new MemoryStore()
    const main: SiteBinding = {
      id: 'main',
      name: 'KOOK 网页端',
      hostname: 'MAIN.BIFROST.VANILLACAKE.CN.',
      targetId: 'webapp',
      environmentSlug: 'shared',
      upstreamOrigin: 'https://www.kookapp.cn/',
      officialOrigin: 'https://www.kookapp.cn/',
      enabled: true,
      remoteTargetIds: ['base'],
      resourceProxyPrefixes: [
        'https://static.kookapp.cn/static/',
        'https://img.kookapp.cn/assets/',
      ],
    }
    await store.saveSiteBinding(main, 'gz')
    main.resourceProxyPrefixes.push('https://unexpected.kookapp.cn/')
    await store.saveSiteBinding(
      {
        ...main,
        id: 'disabled',
        hostname: 'disabled.bifrost.vanillacake.cn',
        officialOrigin: 'https://disabled.kookapp.cn',
        enabled: false,
      },
      'gz'
    )

    expect((await store.listSiteBindings()).map((binding) => binding.id)).toEqual(['main'])
    expect(await store.getSiteBindingByHostname('MAIN.BIFROST.VANILLACAKE.CN:443')).toMatchObject({
      id: 'main',
      hostname: 'main.bifrost.vanillacake.cn',
      resourceProxyPrefixes: [
        'https://static.kookapp.cn/static/',
        'https://img.kookapp.cn/assets/',
      ],
    })
    expect(await store.getSiteBindingByOfficialOrigin('https://www.kookapp.cn/path')).toMatchObject(
      {
        id: 'main',
        officialOrigin: 'https://www.kookapp.cn',
      }
    )
    expect(await store.getSiteBindingByHostname('disabled.bifrost.vanillacake.cn')).toBeNull()

    const firstRead = await store.getSiteBinding('main')
    firstRead!.resourceProxyPrefixes.push('https://mutated.kookapp.cn/')
    expect((await store.getSiteBinding('main'))?.resourceProxyPrefixes).toEqual([
      'https://static.kookapp.cn/static/',
      'https://img.kookapp.cn/assets/',
    ])

    expect(await store.deleteSiteBinding('main', 'gz')).toBe(true)
    expect(await store.getSiteBinding('main')).toBeNull()
    expect(await store.deleteSiteBinding('main', 'gz')).toBe(false)
  })
})
