import { randomUUID } from 'node:crypto'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { FileArtifactStore } from '@cuddly/artifact-store'
import type { RunnerJobInput } from '@cuddly/contracts'
import { afterEach, describe, expect, it } from 'vitest'

import {
  buildPublicPath,
  commandUsesPnpm,
  createRunnerApp,
  packageManagerEnvironment,
  patchOnlineH5AssetPrefixSource,
  patchRemoteAssetPrefixSource,
  patchRemoteProviderVersionSource,
  writeRunnerHeartbeat,
  type RunnerExecutor,
} from './runner'

const roots: string[] = []

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })))
})

function runnerJob(targetId: string): RunnerJobInput {
  return {
    jobId: randomUUID(),
    artifactId: randomUUID(),
    targetId,
    branch: 'feature/test',
    requestedBy: 'gz',
    artifactBaseUrl: 'http://localhost:9872',
    project: {
      id: targetId,
      kind: targetId === 'webapp' ? 'webapp' : 'h5-site',
      repositoryUrl: 'https://git.example.test/project.git',
      installCommand: 'pnpm install',
      buildCommand: 'pnpm build',
      outputDirectory: 'dist',
      siteAdapter: 'generic-static-v1',
    },
  }
}

describe('site build public path', () => {
  it('gives webapp builds an Artifact-specific /app/ prefix', () => {
    const job = runnerJob('webapp')

    expect(buildPublicPath(job, 'https://preview.example.test/remote/')).toBe(
      `/__cuddly/artifacts/${job.artifactId}/app/`
    )
  })

  it('keeps the webapp id fallback for queued snapshots created before kind was recorded', () => {
    const job = runnerJob('webapp')
    delete job.project.kind

    expect(buildPublicPath(job, 'https://preview.example.test/remote/')).toBe(
      `/__cuddly/artifacts/${job.artifactId}/app/`
    )
  })

  it('does not apply the webapp prefix to other generic static sites', () => {
    const job = runnerJob('biz')
    job.project.kind = 'spa-site'

    expect(buildPublicPath(job, 'https://preview.example.test/remote/')).toBeUndefined()
  })

  it('preserves the absolute preview prefix for Remote builds', () => {
    const job = runnerJob('base')
    job.project.kind = 'remote'
    job.project.siteAdapter = 'kook-remote-v1'

    expect(buildPublicPath(job, 'https://preview.example.test/remote/')).toBe(
      'https://preview.example.test/remote/'
    )
  })
})

describe('runner project concurrency', () => {
  it('allows different projects and rejects a second build for the same project', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'cuddly-runner-'))
    roots.push(root)
    const releases = new Map<string, () => void>()
    const execute: RunnerExecutor = async (job) => {
      await new Promise<void>((resolve) => releases.set(job.targetId, resolve))
    }
    const app = createRunnerApp(
      {
        internalToken: 'runner-token',
        runnerRoot: root,
        artifactStore: new FileArtifactStore(path.join(root, 'artifacts')),
        keepWorkspace: false,
        settingsSecret: 'test-secret',
      },
      execute
    )
    const server = app.listen(0, '127.0.0.1')
    await new Promise<void>((resolve) => server.once('listening', resolve))
    const address = server.address()
    if (!address || typeof address === 'string') throw new Error('runner test server has no port')
    const url = `http://127.0.0.1:${address.port}`
    const request = (job: RunnerJobInput) =>
      fetch(`${url}/internal/run`, {
        method: 'POST',
        headers: {
          authorization: 'Bearer runner-token',
          'content-type': 'application/json',
        },
        body: JSON.stringify(job),
      })

    try {
      const onlineResponse = await request(runnerJob('online-h5'))
      expect(onlineResponse.status).toBe(200)

      const duplicateResponse = await request(runnerJob('online-h5'))
      expect(duplicateResponse.status).toBe(409)
      expect(await duplicateResponse.json()).toMatchObject({ code: 'RUNNER_TARGET_BUSY' })

      const webappResponse = await request(runnerJob('webapp'))
      expect(webappResponse.status).toBe(200)

      const health = await fetch(`${url}/health/ready`).then((response) => response.json())
      expect(health).toMatchObject({
        ok: true,
        busy: true,
        activeCount: 2,
        activeTargets: ['online-h5', 'webapp'],
      })

      releases.forEach((release) => release())
      await Promise.all([onlineResponse.text(), webappResponse.text()])
    } finally {
      releases.forEach((release) => release())
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve()))
      )
    }
  })
})

describe('Online H5 asset public path patch', () => {
  it('supports the current CDN config while preserving upstream fallbacks', () => {
    const source = `"use strict";

module.exports = {
  test: "/",
  online: "https://static-m.kookapp.cn/",
  dev: "https://static-m.dev.chuanyuapp.com/",
};
`

    expect(patchOnlineH5AssetPrefixSource(source)).toBe(`"use strict";

module.exports = {
  test: process.env.CUDDLY_ASSET_PREFIX || "/",
  online: process.env.CUDDLY_ASSET_PREFIX || "https://static-m.kookapp.cn/",
  dev: "https://static-m.dev.chuanyuapp.com/",
};
`)
  })

  it('supports quoted properties and is idempotent', () => {
    const source = `module.exports = {
  'test': process.env.CUDDLY_ASSET_PREFIX || '/',
  "online": process.env.CUDDLY_ASSET_PREFIX || '/',
}
`
    expect(patchOnlineH5AssetPrefixSource(source)).toBe(source)
  })

  it('rejects an incompatible CDN config with a dedicated failure', () => {
    expect(() => patchOnlineH5AssetPrefixSource('module.exports = { dev: "/" }\n')).toThrow(
      'Online H5 CDN config does not expose the expected test property'
    )
  })
})

describe('Remote build public path patch', () => {
  it('keeps existing build commands but gives the Artifact prefix priority', () => {
    const source = 'const publicPath = `${process.env.PUB_PATH}${templateName}/`\n'
    expect(patchRemoteAssetPrefixSource(source)).toBe(
      'const publicPath = process.env.CUDDLY_ASSET_PREFIX || `${process.env.PUB_PATH}${templateName}/`\n'
    )
  })

  it('is idempotent', () => {
    const source =
      'const publicPath = process.env.CUDDLY_ASSET_PREFIX || `${process.env.PUB_PATH}${remoteName}/`\n'
    expect(patchRemoteAssetPrefixSource(source)).toBe(source)
  })

  it('gives Cuddly VERSION priority on historical Remote configs', () => {
    const source = "const templateName = require('../package.json').templateName || 'base_v0'\n"
    expect(patchRemoteProviderVersionSource(source)).toBe(
      "const templateName = process.env.VERSION || require('../package.json').templateName || 'base_v0'\n"
    )
  })

  it('preserves configs that already resolve an explicit build version', () => {
    const source = `const remoteName = resolve_build_remote_version({
  app_root_dir: __dirname,
})
`
    expect(patchRemoteProviderVersionSource(source)).toBe(source)
  })
})

describe('package manager registry environment', () => {
  it('uses npmmirror for npm, pnpm, and Corepack when enabled', () => {
    const environment = packageManagerEnvironment(
      {
        PATH: '/usr/bin',
        npm_config_registry: 'https://registry.example.test',
        COREPACK_NPM_REGISTRY: 'https://registry.example.test',
      },
      true
    )

    expect(environment).toMatchObject({
      PATH: '/usr/bin',
      npm_config_registry: 'https://registry.npmmirror.com',
      COREPACK_NPM_REGISTRY: 'https://registry.npmmirror.com',
    })
  })

  it('leaves registry selection to the project when disabled', () => {
    const environment = packageManagerEnvironment(
      {
        PATH: '/usr/bin',
        npm_config_registry: 'https://registry.example.test',
        NPM_CONFIG_REGISTRY: 'https://registry.example.test',
        COREPACK_NPM_REGISTRY: 'https://registry.example.test',
      },
      false
    )

    expect(environment).toEqual({ PATH: '/usr/bin' })
  })

  it('enables dependency build scripts for both pnpm 10 and pnpm 11', () => {
    const environment = packageManagerEnvironment({ PATH: '/usr/bin' }, true, true)

    expect(environment).toMatchObject({
      npm_config_dangerously_allow_all_builds: 'true',
      pnpm_config_dangerously_allow_all_builds: 'true',
    })
  })

  it('removes dependency build overrides outside the install command', () => {
    const environment = packageManagerEnvironment(
      {
        PATH: '/usr/bin',
        npm_config_dangerously_allow_all_builds: 'true',
        pnpm_config_dangerously_allow_all_builds: 'true',
      },
      true
    )

    expect(environment).not.toHaveProperty('npm_config_dangerously_allow_all_builds')
    expect(environment).not.toHaveProperty('pnpm_config_dangerously_allow_all_builds')
  })
})

describe('pnpm command detection', () => {
  it.each([
    'pnpm install',
    'corepack pnpm install',
    'pnpm@11.22.0 install',
    'CI=true pnpm install',
    'cd app && pnpm install',
  ])('%s', (command) => {
    expect(commandUsesPnpm(command)).toBe(true)
  })

  it.each(['npm install', 'yarn install', 'echo pnpm'])('%s', (command) => {
    expect(commandUsesPnpm(command)).toBe(false)
  })
})

describe('runner response heartbeat', () => {
  it('writes a blank NDJSON line while the response remains open', () => {
    const chunks: string[] = []
    const written = writeRunnerHeartbeat({
      destroyed: false,
      writableEnded: false,
      write: (chunk: string) => {
        chunks.push(chunk)
        return true
      },
    })

    expect(written).toBe(true)
    expect(chunks).toEqual(['\n'])
  })

  it('does not write after the response closes', () => {
    const written = writeRunnerHeartbeat({
      destroyed: true,
      writableEnded: false,
      write: () => {
        throw new Error('should not write')
      },
    })

    expect(written).toBe(false)
  })
})
