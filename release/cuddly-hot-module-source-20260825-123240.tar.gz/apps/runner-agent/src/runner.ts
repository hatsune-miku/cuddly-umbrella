import { spawn } from 'node:child_process'
import { timingSafeEqual } from 'node:crypto'
import { createWriteStream, type WriteStream } from 'node:fs'
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'

import { createArtifactStore, type FileArtifactStore } from '@cuddly/artifact-store'
import {
  createOnlineH5Manifest,
  createRemoteManifest,
  createStaticManifest,
} from '@cuddly/build-adapters'
import {
  CHINA_NPM_REGISTRY,
  runnerJobSchema,
  type RunnerEvent,
  type RunnerJobInput,
  type RunnerStage,
} from '@cuddly/contracts'
import { decryptSetting, gitSshCommand, readOrCreateSecret } from '@cuddly/domain'
import express, { type Request, type Response } from 'express'

class RunnerFailure extends Error {
  constructor(
    readonly code: string,
    message: string
  ) {
    super(message)
    this.name = 'RunnerFailure'
  }
}

export interface RunnerOptions {
  internalToken: string
  runnerRoot: string
  artifactStore: FileArtifactStore
  keepWorkspace: boolean
  settingsSecret: string
}

function authorized(req: Request, token: string): boolean {
  const value = req.headers.authorization
  if (!value?.startsWith('Bearer ')) return false
  const supplied = Buffer.from(value.slice('Bearer '.length))
  const expected = Buffer.from(token)
  return supplied.length === expected.length && timingSafeEqual(supplied, expected)
}

function writeEvent(res: Response, event: RunnerEvent): void {
  res.write(`${JSON.stringify(event)}\n`)
}

export function writeRunnerHeartbeat(
  res: Pick<Response, 'destroyed' | 'writableEnded' | 'write'>
): boolean {
  if (res.destroyed || res.writableEnded) return false
  res.write('\n')
  return true
}

function writeLog(stream: WriteStream, value: string): void {
  stream.write(value.endsWith('\n') ? value : `${value}\n`)
}

async function runCommand(input: {
  command: string
  args: string[]
  cwd: string
  env?: NodeJS.ProcessEnv
  log: WriteStream
  displayCommand?: string
}): Promise<void> {
  writeLog(input.log, `\n$ ${input.displayCommand || `${input.command} ${input.args.join(' ')}`}`)
  await new Promise<void>((resolve, reject) => {
    const child = spawn(input.command, input.args, {
      cwd: input.cwd,
      env: input.env || process.env,
      shell: false,
      windowsHide: true,
    })
    child.stdout.on('data', (chunk: Buffer) => input.log.write(chunk))
    child.stderr.on('data', (chunk: Buffer) => input.log.write(chunk))
    child.on('error', (error) => reject(new RunnerFailure('COMMAND_START_FAILED', error.message)))
    child.on('close', (code, signal) => {
      if (code === 0) {
        resolve()
        return
      }
      reject(
        new RunnerFailure(
          'COMMAND_FAILED',
          `${input.command} exited with ${code ?? `signal ${signal || 'unknown'}`}`
        )
      )
    })
  })
}

function shellCommand(command: string): { command: string; args: string[] } {
  return { command: '/bin/sh', args: ['-lc', command] }
}

export function packageManagerEnvironment(
  baseEnvironment: NodeJS.ProcessEnv,
  useChinaRegistry: boolean,
  allowPnpmDependencyBuilds = false
): NodeJS.ProcessEnv {
  const environment = { ...baseEnvironment }
  delete environment.npm_config_registry
  delete environment.NPM_CONFIG_REGISTRY
  delete environment.COREPACK_NPM_REGISTRY
  delete environment.npm_config_dangerously_allow_all_builds
  delete environment.pnpm_config_dangerously_allow_all_builds
  if (useChinaRegistry) {
    environment.npm_config_registry = CHINA_NPM_REGISTRY
    environment.COREPACK_NPM_REGISTRY = CHINA_NPM_REGISTRY
  }
  if (allowPnpmDependencyBuilds) {
    // pnpm 10 reads the npm-prefixed key; pnpm 11 reads the pnpm-prefixed key.
    environment.npm_config_dangerously_allow_all_builds = 'true'
    environment.pnpm_config_dangerously_allow_all_builds = 'true'
  }
  return environment
}

export function commandUsesPnpm(command: string): boolean {
  return /(?:^|[;&|()]\s*)(?:(?:[A-Za-z_][A-Za-z0-9_]*=\S+)\s+)*(?:corepack\s+)?pnpm(?:@[\w.-]+)?(?=$|\s|[;&|()])/i.test(
    command
  )
}

function remoteProviderName(targetId: string, artifactId: string): string {
  const target = targetId.replace(/[^A-Za-z0-9_]/g, '_')
  return `cuddly_${target}_${artifactId.replaceAll('-', '').slice(0, 12)}`
}

export function buildPublicPath(
  job: Pick<RunnerJobInput, 'artifactId' | 'project'>,
  remotePublicBase: string
): string | undefined {
  if (job.project.siteAdapter === 'kook-remote-v1') return remotePublicBase
  if (job.project.kind === 'webapp' || (!job.project.kind && job.project.id === 'webapp')) {
    return `/__cuddly/artifacts/${job.artifactId}/app/`
  }
  return undefined
}

async function closeLog(log: WriteStream): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    log.on('error', reject)
    log.end(resolve)
  })
}

export function patchOnlineH5AssetPrefixSource(source: string): string {
  let patched = source
  for (const key of ['test', 'online']) {
    const propertyPattern = new RegExp(
      `(^\\s*(?:${key}|["']${key}["'])\\s*:\\s*)([^\\r\\n,]+?)(\\s*,)`,
      'm'
    )
    const match = propertyPattern.exec(patched)
    if (!match) {
      throw new RunnerFailure(
        'ONLINE_H5_ASSET_PREFIX_UNSUPPORTED',
        `Online H5 CDN config does not expose the expected ${key} property`
      )
    }
    if (match[2]?.includes('process.env.CUDDLY_ASSET_PREFIX')) continue
    patched = patched.replace(propertyPattern, '$1process.env.CUDDLY_ASSET_PREFIX || $2$3')
  }
  return patched
}

async function applyAssetPrefixPatch(sourceDirectory: string, log: WriteStream) {
  const targetPath = path.join(sourceDirectory, 'rsbuild-config', 'cdnPath.js')
  let current: string
  try {
    current = await readFile(targetPath, 'utf8')
  } catch (error) {
    throw new RunnerFailure(
      'ONLINE_H5_ASSET_PREFIX_CONFIG_MISSING',
      `Online H5 CDN config is unavailable: ${error instanceof Error ? error.message : String(error)}`
    )
  }
  const patched = patchOnlineH5AssetPrefixSource(current)
  if (patched === current) {
    writeLog(log, 'CUDDLY_ASSET_PREFIX support is already present; patch skipped')
    return
  }
  await writeFile(targetPath, patched, 'utf8')
  writeLog(
    log,
    `Applied CUDDLY_ASSET_PREFIX support to ${path.relative(sourceDirectory, targetPath)}`
  )
}

export function patchRemoteAssetPrefixSource(source: string): string {
  if (source.includes('process.env.CUDDLY_ASSET_PREFIX ||')) return source
  const pattern =
    /(const\s+publicPath\s*=\s*)(`\$\{process\.env\.PUB_PATH\}\$\{(?:templateName|remoteName)\}\/`)/
  if (!pattern.test(source)) {
    throw new RunnerFailure(
      'REMOTE_ASSET_PREFIX_UNSUPPORTED',
      'Remote build config does not expose the expected PUB_PATH publicPath expression'
    )
  }
  return source.replace(pattern, '$1process.env.CUDDLY_ASSET_PREFIX || $2')
}

export function patchRemoteProviderVersionSource(source: string): string {
  const versionAwareDeclaration =
    /^\s*(?:const|let)\s+(?:templateName|remoteName)\s*=\s*(?:process\.env\.(?:VERSION|npm_config_VERSION|npm_config_version)\b|resolve_build_remote_version\s*\()/m
  if (versionAwareDeclaration.test(source)) return source

  const declaration = /^(\s*(?:const|let)\s+(?:templateName|remoteName)\s*=\s*)([^\r\n]+)$/m
  if (!declaration.test(source)) {
    throw new RunnerFailure(
      'REMOTE_PROVIDER_VERSION_UNSUPPORTED',
      'Remote build config does not expose a supported templateName or remoteName declaration'
    )
  }
  return source.replace(declaration, '$1process.env.VERSION || $2')
}

async function applyRemoteAssetPrefixPatch(outputDirectory: string, log: WriteStream) {
  const projectDirectory = path.dirname(outputDirectory)
  const configPath = path.join(projectDirectory, 'scripts', 'get_config.js')
  let current: string
  try {
    current = await readFile(configPath, 'utf8')
  } catch (error) {
    throw new RunnerFailure(
      'REMOTE_ASSET_PREFIX_CONFIG_MISSING',
      `Remote build config is unavailable: ${error instanceof Error ? error.message : String(error)}`
    )
  }
  const patched = patchRemoteAssetPrefixSource(patchRemoteProviderVersionSource(current))
  if (patched === current) {
    writeLog(log, 'CUDDLY_ASSET_PREFIX support is already present; Remote patch skipped')
    return
  }
  await writeFile(configPath, patched, 'utf8')
  writeLog(
    log,
    `Applied CUDDLY_ASSET_PREFIX support to ${path.relative(projectDirectory, configPath)}`
  )
}

async function executeBuild(
  job: RunnerJobInput,
  options: RunnerOptions,
  res: Response
): Promise<void> {
  const jobDirectory = path.join(options.runnerRoot, 'runner-jobs', job.jobId)
  const sourceDirectory = path.join(jobDirectory, 'source')
  const outputDirectory = path.resolve(sourceDirectory, job.project.outputDirectory)
  const relativeOutput = path.relative(sourceDirectory, outputDirectory)
  if (!relativeOutput || relativeOutput.startsWith('..') || path.isAbsolute(relativeOutput)) {
    throw new RunnerFailure(
      'INVALID_OUTPUT_DIRECTORY',
      'Output directory must stay inside the repository'
    )
  }
  const logDirectory = path.join(options.runnerRoot, 'logs')
  const logPath = path.join(logDirectory, `${job.jobId}.log`)

  await mkdir(logDirectory, { recursive: true })
  await rm(jobDirectory, { recursive: true, force: true })
  await mkdir(jobDirectory, { recursive: true })
  const log = createWriteStream(logPath, { flags: 'a' })

  const stage = (value: RunnerStage) => {
    const at = new Date().toISOString()
    writeLog(log, `\n[${at}] ${value}`)
    writeEvent(res, { type: 'stage', stage: value, at })
  }

  try {
    stage('CHECKOUT')
    await runCommand({
      command: 'git',
      args: [
        'clone',
        '--depth',
        '1',
        '--single-branch',
        '--branch',
        job.branch,
        job.project.repositoryUrl,
        sourceDirectory,
      ],
      cwd: jobDirectory,
      env: {
        ...process.env,
        ...(job.project.gitAuthorization
          ? {
              GIT_CONFIG_COUNT: '1',
              GIT_CONFIG_KEY_0: 'http.extraHeader',
              GIT_CONFIG_VALUE_0: decryptSetting(
                job.project.gitAuthorization,
                options.settingsSecret
              ),
            }
          : {}),
        GIT_TERMINAL_PROMPT: '0',
        GIT_SSH_COMMAND: gitSshCommand(),
      },
      log,
      displayCommand: `git clone --depth 1 --single-branch --branch ${job.branch} <repository> ${sourceDirectory}`,
    })
    if (job.project.siteAdapter === 'kook-online-h5-v1') {
      await applyAssetPrefixPatch(sourceDirectory, log)
    } else if (job.project.siteAdapter === 'kook-remote-v1') {
      await applyRemoteAssetPrefixPatch(outputDirectory, log)
    }

    stage('INSTALLING')
    const install = shellCommand(job.project.installCommand)
    const useChinaRegistry = job.project.useChinaRegistry !== false
    const allowPnpmDependencyBuilds = commandUsesPnpm(job.project.installCommand)
    const installEnvironment = packageManagerEnvironment(
      process.env,
      useChinaRegistry,
      allowPnpmDependencyBuilds
    )
    writeLog(
      log,
      useChinaRegistry
        ? `Package registry: ${CHINA_NPM_REGISTRY}`
        : 'Package registry: project or package-manager default'
    )
    if (allowPnpmDependencyBuilds) {
      writeLog(log, 'pnpm dependency build scripts: enabled for trusted project build')
    }
    await runCommand({
      ...install,
      cwd: sourceDirectory,
      env: installEnvironment,
      log,
      displayCommand: job.project.installCommand,
    })

    stage('BUILDING')
    const build = shellCommand(job.project.buildCommand)
    const artifactPublicBase = `${job.artifactBaseUrl.replace(/\/$/, '')}/__cuddly/preview-artifacts/${job.artifactId}/`
    const providerName = remoteProviderName(job.targetId, job.artifactId)
    const remotePublicBase = `${artifactPublicBase}${providerName}/`
    const publicPath = buildPublicPath(job, artifactPublicBase)
    await runCommand({
      ...build,
      cwd: sourceDirectory,
      env: {
        ...packageManagerEnvironment(process.env, useChinaRegistry),
        NODE_ENV: 'production',
        PUB_PATH: publicPath,
        VERSION: job.project.siteAdapter === 'kook-remote-v1' ? providerName : undefined,
        npm_config_VERSION: job.project.siteAdapter === 'kook-remote-v1' ? providerName : undefined,
        CUDDLY_ASSET_PREFIX:
          job.project.siteAdapter === 'kook-remote-v1'
            ? remotePublicBase
            : publicPath || `/__cuddly/artifacts/${job.artifactId}/`,
      },
      log,
      displayCommand: job.project.buildCommand,
    })

    stage('VALIDATING')
    const builtAt = new Date().toISOString()
    const manifest =
      job.project.siteAdapter === 'kook-online-h5-v1'
        ? await createOnlineH5Manifest({
            outputDirectory,
            artifactId: job.artifactId,
            targetId: job.targetId,
            branch: job.branch,
            builtAt,
          })
        : job.project.siteAdapter === 'kook-remote-v1'
          ? await createRemoteManifest({
              outputDirectory,
              artifactId: job.artifactId,
              targetId: job.targetId,
              branch: job.branch,
              builtAt,
              publicBase: remotePublicBase,
              siteAdapter: job.project.siteAdapter,
              moduleKey: job.targetId,
              providerName,
            })
          : await createStaticManifest({
              outputDirectory,
              artifactId: job.artifactId,
              targetId: job.targetId,
              branch: job.branch,
              builtAt,
              siteAdapter: job.project.siteAdapter,
              publicBase: publicPath,
            })

    stage('UPLOADING')
    const storageKey = await options.artifactStore.publishDirectory({
      sourceDirectory: outputDirectory,
      targetId: job.targetId,
      artifactId: job.artifactId,
      manifest,
    })
    writeEvent(res, {
      type: 'result',
      artifactId: job.artifactId,
      storageKey,
      manifest,
      builtAt,
      logPath,
    })
  } catch (error) {
    const failure =
      error instanceof RunnerFailure ? error : new RunnerFailure('RUNNER_FAILED', String(error))
    writeLog(log, `\n[FAILED] ${failure.stack || failure.message}`)
    writeEvent(res, {
      type: 'error',
      code: failure.code,
      message: failure.message,
      logPath,
    })
  } finally {
    await closeLog(log)
    if (!options.keepWorkspace) await rm(jobDirectory, { recursive: true, force: true })
  }
}

export type RunnerExecutor = (
  job: RunnerJobInput,
  options: RunnerOptions,
  res: Response
) => Promise<void>

export function createRunnerApp(options: RunnerOptions, runBuild: RunnerExecutor = executeBuild) {
  const app = express()
  const activeTargets = new Map<string, string>()
  app.disable('x-powered-by')
  app.use(express.json({ limit: '64kb' }))

  app.get('/health/live', (_req, res) => res.json({ ok: true }))
  app.get('/health/ready', async (_req, res) => {
    await options.artifactStore.initialize()
    res.json({
      ok: true,
      busy: activeTargets.size > 0,
      activeCount: activeTargets.size,
      activeTargets: [...activeTargets.keys()],
    })
  })

  app.post('/internal/run', async (req, res) => {
    if (!authorized(req, options.internalToken)) {
      res.status(401).json({ code: 'UNAUTHENTICATED' })
      return
    }
    const parsed = runnerJobSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_REQUEST', issues: parsed.error.issues })
      return
    }
    const activeJobId = activeTargets.get(parsed.data.targetId)
    if (activeJobId) {
      res.status(409).json({
        code: 'RUNNER_TARGET_BUSY',
        targetId: parsed.data.targetId,
        activeJobId,
      })
      return
    }

    activeTargets.set(parsed.data.targetId, parsed.data.jobId)
    res.status(200)
    res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8')
    res.setHeader('Cache-Control', 'no-store')
    res.flushHeaders()
    const heartbeat = setInterval(() => writeRunnerHeartbeat(res), 15_000)
    heartbeat.unref()
    try {
      await runBuild(parsed.data, options, res)
    } finally {
      clearInterval(heartbeat)
      activeTargets.delete(parsed.data.targetId)
      res.end()
    }
  })

  return app
}

export async function createRunnerOptions(): Promise<RunnerOptions> {
  return {
    internalToken: 'cuddly-internal-runner-v1',
    runnerRoot: process.env.NODE_ENV === 'production' ? '/srv/cuddly' : path.resolve('data'),
    artifactStore: createArtifactStore(),
    keepWorkspace: false,
    settingsSecret: await readOrCreateSecret(
      process.env.NODE_ENV === 'production'
        ? '/srv/cuddly/secrets/settings.key'
        : path.resolve('data/secrets/settings.key')
    ),
  }
}
