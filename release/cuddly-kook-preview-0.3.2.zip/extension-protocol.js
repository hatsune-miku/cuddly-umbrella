export const EXTENSION_PROTOCOL_VERSION = 1
export const EXTENSION_CAPABILITIES_COMMAND = 'get-extension-capabilities'
export const EXTENSION_RELOAD_REQUIRED =
  '扩展后台仍在运行旧版本，请打开 chrome://extensions，重新加载 Cuddly KOOK Preview 后再试'

export async function requireExtensionCapabilities(sendMessage) {
  let response
  try {
    response = await sendMessage({ type: EXTENSION_CAPABILITIES_COMMAND })
  } catch {
    throw new Error(EXTENSION_RELOAD_REQUIRED)
  }

  const capabilities = response?.capabilities
  if (
    !response?.ok ||
    capabilities?.protocolVersion !== EXTENSION_PROTOCOL_VERSION ||
    !capabilities.commands?.includes('apply-site-preview')
  ) {
    throw new Error(EXTENSION_RELOAD_REQUIRED)
  }
  return capabilities
}
