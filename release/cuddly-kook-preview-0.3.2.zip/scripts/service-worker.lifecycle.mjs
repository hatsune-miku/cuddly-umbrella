import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import test from 'node:test'
import vm from 'node:vm'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const source = await readFile(path.join(root, 'service-worker.js'), 'utf8')
const activeKey = 'cuddly.activePreviews'
const alarmPrefix = 'cuddly.previewExpiry.'

function clone(value) {
  return value === undefined ? undefined : structuredClone(value)
}

function createHarness({ active = {}, rules = [], tabs = [] } = {}) {
  const storage = { [activeKey]: clone(active) }
  const sessionRules = clone(rules)
  const tabState = clone(tabs)
  const tabUpdates = []
  const alarms = new Map()
  const listeners = {}
  const event = (name) => ({ addListener: (listener) => (listeners[name] = listener) })
  const chrome = {
    alarms: {
      create: async (name, info) => void alarms.set(name, clone(info)),
      clear: async (name) => alarms.delete(name),
      getAll: async () => [...alarms].map(([name, info]) => ({ name, ...clone(info) })),
      onAlarm: event('alarm'),
    },
    declarativeNetRequest: {
      getSessionRules: async () => clone(sessionRules),
      updateSessionRules: async ({ addRules = [], removeRuleIds = [] }) => {
        for (const ruleId of removeRuleIds) {
          const index = sessionRules.findIndex((rule) => rule.id === ruleId)
          if (index >= 0) sessionRules.splice(index, 1)
        }
        sessionRules.push(...clone(addRules))
      },
    },
    runtime: {
      onInstalled: event('installed'),
      onMessage: event('message'),
      onStartup: event('startup'),
    },
    storage: {
      local: {
        get: async (key) => ({ [key]: clone(storage[key]) }),
        set: async (values) => Object.assign(storage, clone(values)),
      },
    },
    tabs: {
      onRemoved: event('removed'),
      onUpdated: event('updated'),
      get: async (tabId) => {
        const tab = tabState.find((candidate) => candidate.id === tabId)
        if (!tab) throw new Error('No tab with id')
        return clone(tab)
      },
      query: async () => clone(tabState),
      update: async (tabId, update) => {
        const tab = tabState.find((candidate) => candidate.id === tabId)
        if (!tab) throw new Error('No tab with id')
        Object.assign(tab, clone(update))
        tabUpdates.push({ tabId, ...clone(update) })
        return clone(tab)
      },
    },
  }
  const context = vm.createContext({ chrome, Date, Promise, URL })
  new vm.Script(source, { filename: 'service-worker.js' }).runInContext(context)
  return {
    alarms,
    sessionRules,
    listeners,
    storage,
    tabUpdates,
    flush: () => vm.runInContext('mutationQueue', context),
  }
}

async function sendMessage(harness, message) {
  return new Promise((resolve) => {
    assert.equal(harness.listeners.message(message, {}, resolve), true)
  })
}

test('creates and clears a one-time expiry alarm with a Remote-only site preview', async () => {
  const harness = createHarness({ tabs: [{ id: 7 }] })
  const expiresAt = new Date(Date.now() + 60_000).toISOString()
  const applied = await sendMessage(harness, {
    type: 'apply-site-preview',
    tabId: 7,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    officialOrigin: 'https://www.kookapp.cn',
    originalUrl: 'https://www.kookapp.cn/channels/7',
    targetUrl: 'https://main.bifrost.vanillacake.cn/channels/7',
    preview: {
      token: 'preview',
      expiresAt,
      selections: [{ moduleKey: 'base', artifactId: 'artifact-base' }],
    },
  })

  assert.equal(applied.ok, true)
  assert.equal(applied.active.mode, 'site')
  assert.equal(harness.sessionRules.length, 1)
  assert.ok(harness.sessionRules.every((rule) => rule.condition.tabIds?.[0] === 7))
  assert.equal(harness.alarms.get(`${alarmPrefix}7`).when, Date.parse(expiresAt))
  assert.equal(harness.storage[activeKey]['7'].preview.token, 'preview')

  const removed = await sendMessage(harness, { type: 'remove-preview', tabId: 7 })
  assert.equal(removed.ok, true)
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.alarms.has(`${alarmPrefix}7`), false)
  assert.equal(harness.storage[activeKey]['7'], undefined)
})

test('restores valid alarms and removes expired or closed-tab previews', async () => {
  const future = new Date(Date.now() + 60_000).toISOString()
  const past = new Date(Date.now() - 60_000).toISOString()
  const active = {
    1: {
      mode: 'site',
      ruleIds: [1001],
      preview: { token: 'valid', expiresAt: future },
      previewOrigin: 'https://main.bifrost.vanillacake.cn',
      officialOrigin: 'https://www.kookapp.cn',
    },
    2: {
      mode: 'remote',
      ruleIds: [1002, 1003],
      preview: { expiresAt: future },
      webappOrigin: 'https://www.kookapp.cn',
      hotModuleUrl: 'https://bifrost.vanillacake.cn/preview/legacy/hot-module',
    },
    3: {
      mode: 'site',
      ruleIds: [1004],
      preview: { token: 'closed', expiresAt: future },
      previewOrigin: 'https://main.bifrost.vanillacake.cn',
    },
    4: {
      mode: 'site',
      ruleIds: [1005],
      preview: { token: 'expired', expiresAt: past },
      previewOrigin: 'https://main.bifrost.vanillacake.cn',
      officialOrigin: 'https://www.kookapp.cn',
    },
  }
  const harness = createHarness({
    active,
    rules: [{ id: 1999 }],
    tabs: [
      { id: 1, url: 'https://main.bifrost.vanillacake.cn/channels/1' },
      { id: 2, url: 'https://www.kookapp.cn/channels/2' },
      { id: 4, url: 'https://main.bifrost.vanillacake.cn/channels/4' },
    ],
  })
  harness.alarms.set(`${alarmPrefix}99`, { when: Date.now() + 60_000 })

  harness.listeners.installed({ reason: 'update' })
  await harness.flush()

  assert.deepEqual(Object.keys(harness.storage[activeKey]), ['1'])
  assert.deepEqual(
    harness.sessionRules.map((rule) => rule.id),
    [1001]
  )
  assert.equal(harness.alarms.get(`${alarmPrefix}1`).when, Date.parse(future))
  assert.equal(harness.alarms.has(`${alarmPrefix}99`), false)
  assert.deepEqual(harness.tabUpdates, [{ tabId: 4, url: 'https://www.kookapp.cn/channels/4' }])

  harness.storage[activeKey]['1'].preview.expiresAt = past
  harness.listeners.alarm({ name: `${alarmPrefix}1` })
  await harness.flush()

  assert.equal(harness.storage[activeKey]['1'], undefined)
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.alarms.has(`${alarmPrefix}1`), false)
  assert.deepEqual(harness.tabUpdates.at(-1), {
    tabId: 1,
    url: 'https://www.kookapp.cn/channels/1',
  })
})

test('clears preview state when its tab leaves the preview origin', async () => {
  const future = new Date(Date.now() + 60_000).toISOString()
  const harness = createHarness({
    active: {
      8: {
        mode: 'site',
        ruleIds: [1008],
        preview: { token: 'preview-8', expiresAt: future },
        previewOrigin: 'https://main.bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
      },
    },
    rules: [{ id: 1008 }],
    tabs: [{ id: 8, url: 'https://main.bifrost.vanillacake.cn/channels/8' }],
  })

  harness.listeners.updated(
    8,
    { url: 'https://www.kookapp.cn/channels/8' },
    { id: 8, url: 'https://www.kookapp.cn/channels/8' }
  )
  await harness.flush()

  assert.equal(harness.storage[activeKey]['8'], undefined)
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.alarms.has(`${alarmPrefix}8`), false)
})

test('reports capabilities used to detect a stale service worker', async () => {
  const harness = createHarness()
  const result = await sendMessage(harness, { type: 'get-extension-capabilities' })

  assert.equal(result.ok, true)
  assert.equal(result.capabilities.protocolVersion, 1)
  assert.deepEqual([...result.capabilities.commands], ['apply-site-preview', 'remove-preview'])
  assert.equal(harness.sessionRules.length, 0)
  assert.deepEqual(harness.storage[activeKey], {})
})

test('rejects the legacy Remote redirect command with an actionable reload instruction', async () => {
  const harness = createHarness()
  const result = await sendMessage(harness, {
    type: 'apply-remote-preview',
    tabId: 9,
    webappOrigin: 'https://www.kookapp.cn',
    hotModuleUrl: 'https://bifrost.vanillacake.cn/preview/hot-module',
  })

  assert.equal(result.ok, false)
  assert.match(result.message, /chrome:\/\/extensions/)
  assert.match(result.message, /重新加载/)
  assert.equal(harness.sessionRules.length, 0)
  assert.deepEqual(harness.storage[activeKey], {})
})

test('applies a site preview with one tab-scoped session header rule', async () => {
  const harness = createHarness({
    tabs: [{ id: 11, url: 'https://main.bifrost.vanillacake.cn/channels/11' }],
  })
  const expiresAt = new Date(Date.now() + 60_000).toISOString()

  const applied = await sendMessage(harness, {
    type: 'apply-site-preview',
    tabId: 11,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    officialOrigin: 'https://www.kookapp.cn',
    originalUrl: 'https://www.kookapp.cn/channels/11',
    targetUrl: 'https://main.bifrost.vanillacake.cn/channels/11',
    preview: { token: 'site-preview', expiresAt, selections: [] },
  })

  assert.equal(applied.ok, true)
  assert.equal(harness.sessionRules.length, 1)
  assert.deepEqual(harness.sessionRules[0].condition.tabIds, [11])
  assert.deepEqual(harness.sessionRules[0].action.requestHeaders, [
    { header: 'x-cuddly-preview-token', operation: 'set', value: 'site-preview' },
  ])
})
