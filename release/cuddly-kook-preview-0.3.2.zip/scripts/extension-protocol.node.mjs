import assert from 'node:assert/strict'
import test from 'node:test'

import {
  EXTENSION_CAPABILITIES_COMMAND,
  EXTENSION_RELOAD_REQUIRED,
  requireExtensionCapabilities,
} from '../extension-protocol.js'

test('accepts a service worker that supports the current site-preview protocol', async () => {
  const capabilities = await requireExtensionCapabilities(async (message) => {
    assert.deepEqual(message, { type: EXTENSION_CAPABILITIES_COMMAND })
    return {
      ok: true,
      capabilities: {
        protocolVersion: 1,
        commands: ['apply-site-preview', 'remove-preview'],
      },
    }
  })

  assert.equal(capabilities.protocolVersion, 1)
})

test('turns the old worker unsupported-command response into a reload instruction', async () => {
  await assert.rejects(
    requireExtensionCapabilities(async () => ({
      ok: false,
      message: 'Unsupported extension command',
    })),
    new RegExp(EXTENSION_RELOAD_REQUIRED)
  )
})

test('turns a missing worker and incompatible protocol into a reload instruction', async () => {
  await assert.rejects(
    requireExtensionCapabilities(async () => {
      throw new Error('Could not establish connection. Receiving end does not exist.')
    }),
    new RegExp(EXTENSION_RELOAD_REQUIRED)
  )
  await assert.rejects(
    requireExtensionCapabilities(async () => ({
      ok: true,
      capabilities: { protocolVersion: 2, commands: ['apply-site-preview'] },
    })),
    new RegExp(EXTENSION_RELOAD_REQUIRED)
  )
})
