import {
  createPreviewRequest,
  mergeSelectedBranches,
  planPreviewApplication,
  previewDestinationUrl,
  SITE_BINDING_REQUIRED,
} from './preview-routing.js'
import { requireExtensionCapabilities } from './extension-protocol.js'
import { normalizeActorName, resolveActorIdentity } from './popup-identity.js'

const CONTROL_KEY = 'cuddly.controlOrigin'
const ACTOR_KEY = 'cuddly.actorName'
const ACTOR_ID_KEY = 'cuddly.actorId'
const ACTIVE_KEY = 'cuddly.activePreviews'
const DEFAULT_CONTROL_ORIGIN = 'https://bifrost.vanillacake.cn'

const state = {
  tab: null,
  controlOrigin: DEFAULT_CONTROL_ORIGIN,
  actorId: '',
  actorOverride: '',
  actorName: '',
  binding: null,
  targets: [],
  siteTargetId: null,
  currentSiteBranch: '',
  branches: {},
  selectedBranches: {},
  active: null,
  busyTargets: new Set(),
}

const elements = {
  pageTitle: document.querySelector('#page-title'),
  pageMeta: document.querySelector('#page-meta'),
  refreshButton: document.querySelector('#refresh-button'),
  settingsButton: document.querySelector('#settings-button'),
  settingsDialog: document.querySelector('#settings-dialog'),
  settingsForm: document.querySelector('#settings-form'),
  settingsCancel: document.querySelector('#settings-cancel'),
  settingsClose: document.querySelector('#settings-close'),
  controlOrigin: document.querySelector('#control-origin'),
  actorName: document.querySelector('#actor-name'),
  actorHint: document.querySelector('#actor-hint'),
  activePanel: document.querySelector('#active-panel'),
  activeSummary: document.querySelector('#active-summary'),
  removeButton: document.querySelector('#remove-button'),
  moduleList: document.querySelector('#module-list'),
  selectionSummary: document.querySelector('#selection-summary'),
  applyButton: document.querySelector('#apply-button'),
  statusBar: document.querySelector('#status-bar'),
  statusText: document.querySelector('#status-text'),
}

function setStatus(text, tone = '') {
  elements.statusText.textContent = text
  elements.statusBar.className = `status-bar ${tone}`.trim()
}

function formatTime(value) {
  if (!value) return '尚未打包'
  return new Intl.DateTimeFormat('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(new Date(value))
}

function errorText(error) {
  if (error?.body?.message) return error.body.message
  return error instanceof Error ? error.message : String(error)
}

async function api(pathname, init) {
  const response = await fetch(`${state.controlOrigin.replace(/\/$/, '')}${pathname}`, {
    ...init,
    headers: {
      'x-cuddly-actor': state.actorName,
      ...(init?.body ? { 'content-type': 'application/json' } : {}),
      ...init?.headers,
    },
  })
  const body = await response.json().catch(() => null)
  if (!response.ok) {
    const error = new Error(`Cuddly 返回 HTTP ${response.status}`)
    error.status = response.status
    error.body = body
    throw error
  }
  return body
}

async function optionalApi(pathname) {
  try {
    return await api(pathname)
  } catch (error) {
    if (error?.status === 404) return null
    throw error
  }
}

function latestArtifact(targetId, branch) {
  return (
    state.branches[targetId]?.items?.find((item) => item.branch === branch)?.latestArtifact || null
  )
}

function branchForArtifact(targetId, artifactId) {
  if (!artifactId) return ''
  return (
    state.branches[targetId]?.items?.find((item) => item.latestArtifact?.id === artifactId)
      ?.branch || ''
  )
}

function selectedArtifacts() {
  let siteArtifactId = null
  const selections = []
  for (const target of state.targets) {
    const branch = state.selectedBranches[target.id]
    const artifact = latestArtifact(target.id, branch)
    if (!artifact) continue
    if (target.id === state.siteTargetId) siteArtifactId = artifact.id
    else
      selections.push({
        targetId: target.id,
        artifactId: artifact.id,
        branch,
        builtAt: artifact.builtAt,
      })
  }
  return { siteArtifactId, selections }
}

function previewOrigin() {
  if (!state.binding) return null
  try {
    const current = new URL(state.tab?.url || '')
    const protocol = current.hostname === state.binding.hostname ? current.protocol : 'https:'
    return `${protocol}//${state.binding.hostname}`
  } catch {
    return `https://${state.binding.hostname}`
  }
}

function isPreviewHostname(tabUrl, binding) {
  try {
    return new URL(tabUrl).hostname === binding.hostname
  } catch {
    return false
  }
}

function activeSummary() {
  if (!state.active?.preview) return ''
  const labels = []
  if (state.active.preview.siteArtifactId && state.binding) {
    const branch =
      state.active.preview.siteSelection?.branch ||
      branchForArtifact(state.binding.targetId, state.active.preview.siteArtifactId)
    labels.push(`${state.binding.name} · ${branch || '页面产物'}`)
  }
  for (const selection of state.active.preview.selections || []) {
    labels.push(`${selection.moduleKey} · ${selection.branch}`)
  }
  return labels.join('；') || '已应用预览产物'
}

function renderActive() {
  elements.activePanel.hidden = !state.active
  if (!state.active) return
  elements.activeSummary.textContent = activeSummary()
}

function renderModules() {
  elements.moduleList.replaceChildren()
  if (!state.targets.length) {
    const empty = document.createElement('div')
    empty.className = 'empty-state'
    empty.innerHTML = state.binding
      ? '<strong>这个站点还没有可用项目</strong><span>检查页面项目、Remote 项目是否已启用并配置 Git 仓库。</span>'
      : '<strong>当前页面没有站点绑定</strong><span>在管理后台添加站点，并把它对应到当前官网地址。</span>'
    elements.moduleList.append(empty)
  }

  for (const target of state.targets) {
    const isSite = target.id === state.siteTargetId
    const catalog = state.branches[target.id] || { items: [], remoteAvailable: false }
    const branch = state.selectedBranches[target.id] || ''
    const branchItem = branch ? catalog.items.find((item) => item.branch === branch) : null
    const artifact = branchItem?.latestArtifact || null
    const row = document.createElement('article')
    row.className = `module-row ${isSite ? 'site-module' : 'remote-module'}`

    const heading = document.createElement('div')
    heading.className = 'module-heading'
    const name = document.createElement('strong')
    name.textContent = target.name
    const kind = document.createElement('span')
    kind.className = `module-kind ${isSite ? 'site-kind' : ''}`
    kind.textContent = isSite ? '页面' : '热更'
    heading.append(name, kind)

    const controls = document.createElement('div')
    controls.className = 'module-controls'
    const select = document.createElement('select')
    select.className = 'module-select'
    select.setAttribute('aria-label', `${target.name} 分支`)
    const officialOption = document.createElement('option')
    officialOption.value = ''
    officialOption.textContent = isSite ? '官网页面' : '官方热更'
    officialOption.selected = !branch
    select.append(officialOption)
    const items = catalog.items.length ? [...catalog.items] : [{ branch: target.defaultBranch }]
    if (branch && !items.some((item) => item.branch === branch)) items.unshift({ branch })
    for (const item of items) {
      const option = document.createElement('option')
      option.value = item.branch
      option.textContent = item.branch
      option.selected = item.branch === branch
      select.append(option)
    }
    select.addEventListener('change', () => {
      state.selectedBranches[target.id] = select.value
      renderModules()
    })
    const build = document.createElement('button')
    build.type = 'button'
    build.className = 'secondary-button build-button'
    build.textContent = state.busyTargets.has(target.id) ? '提交中' : '打最新包'
    build.disabled = state.busyTargets.has(target.id) || !branch
    build.addEventListener('click', () => void createBuild(target.id, select.value))
    controls.append(select, build)

    const meta = document.createElement('div')
    meta.className = 'module-meta'
    const builtAt = document.createElement('span')
    builtAt.textContent = !branch
      ? isSite
        ? `使用 ${state.binding?.officialOrigin || '官网页面'}`
        : '由 KOOK 官方热更响应决定'
      : artifact
        ? `上次打包 ${formatTime(artifact.builtAt)}`
        : '这个分支还没有可用产物'
    const buildState = document.createElement('span')
    if (!branch) {
      buildState.textContent = isSite ? '不替换页面' : '不覆盖'
    } else if (branchItem?.buildStatus === 'BUILDING') {
      buildState.className = 'working'
      buildState.textContent = '构建中'
    } else if (branchItem?.buildStatus === 'FAILED') {
      buildState.className = 'failed'
      buildState.textContent = '上次失败'
    } else if (isSite && state.active?.mode !== 'site' && branch === state.currentSiteBranch) {
      buildState.textContent = '当前环境'
    } else {
      buildState.textContent = catalog.remoteAvailable ? 'Git 已连接' : '使用本地分支记录'
    }
    meta.append(builtAt, buildState)
    row.append(heading, controls, meta)
    elements.moduleList.append(row)
  }

  const selected = selectedArtifacts()
  const plan = planPreviewApplication({
    binding: state.binding,
    previewOrigin: previewOrigin(),
    siteArtifactId: selected.siteArtifactId,
    selections: selected.selections,
  })
  const labels = []
  if (selected.siteArtifactId && state.binding) {
    labels.push(`${state.binding.name} · ${state.selectedBranches[state.binding.targetId]}`)
  }
  labels.push(
    ...selected.selections.map((item) => {
      const target = state.targets.find((candidate) => candidate.id === item.targetId)
      return `${target?.name || item.targetId} · ${item.branch}`
    })
  )
  elements.selectionSummary.textContent = labels.length ? labels.join('；') : '全部使用官网版本'
  elements.applyButton.disabled = !plan.canApply
}

async function resolveBinding(tabUrl) {
  if (!tabUrl) return null
  const url = new URL(tabUrl)
  const byOfficialOrigin = await optionalApi(
    `/api/v1/site-bindings/resolve?officialOrigin=${encodeURIComponent(url.origin)}`
  )
  if (byOfficialOrigin) return byOfficialOrigin
  return optionalApi(`/api/v1/site-bindings/resolve?hostname=${encodeURIComponent(url.hostname)}`)
}

async function loadActive() {
  const stored = (await chrome.storage.local.get(ACTIVE_KEY))[ACTIVE_KEY] || {}
  const active = stored[String(state.tab.id)] || null
  const expiresAt = Date.parse(active?.preview?.expiresAt || '')
  if (
    active &&
    (active.mode !== 'site' || !Number.isFinite(expiresAt) || expiresAt <= Date.now())
  ) {
    const result = await chrome.runtime.sendMessage({ type: 'remove-preview', tabId: state.tab.id })
    state.active = result?.ok ? null : active
  } else {
    state.active = active
  }
  renderActive()
}

async function load() {
  const previousBindingId = state.binding?.id || null
  const previousSelectedBranches = { ...state.selectedBranches }
  setStatus('正在读取站点、项目和分支', 'busy')
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  state.tab = tab
  const saved = await chrome.storage.local.get([CONTROL_KEY, ACTOR_KEY, ACTOR_ID_KEY])
  const identity = resolveActorIdentity({
    storedActorId: saved[ACTOR_ID_KEY],
    storedActorName: saved[ACTOR_KEY],
  })
  state.controlOrigin = saved[CONTROL_KEY] || DEFAULT_CONTROL_ORIGIN
  state.actorId = identity.actorId
  state.actorOverride = identity.actorOverride
  state.actorName = identity.actorName
  elements.controlOrigin.value = state.controlOrigin
  elements.actorName.value = state.actorOverride
  elements.actorName.placeholder = state.actorId
  elements.actorHint.textContent = `留空时使用本机标识 ${state.actorId}；仅用于队列和审计，不是登录身份。`
  if (
    saved[ACTOR_ID_KEY] !== state.actorId ||
    normalizeActorName(saved[ACTOR_KEY]) !== state.actorOverride
  ) {
    await chrome.storage.local.set({
      [ACTOR_ID_KEY]: state.actorId,
      [ACTOR_KEY]: state.actorOverride,
    })
  }
  elements.pageTitle.textContent = tab?.title || '当前标签页'
  elements.pageMeta.textContent = tab?.url || '无法读取页面地址'
  await loadActive()

  try {
    const [targetBody, binding] = await Promise.all([
      api('/api/v1/build-targets'),
      resolveBinding(tab?.url),
    ])
    state.binding = binding
    state.currentSiteBranch = ''
    const allTargets = targetBody.items || []
    if (binding) {
      const allowedIds = new Set([binding.targetId, ...(binding.remoteTargetIds || [])])
      state.targets = allTargets.filter(
        (target) => allowedIds.has(target.id) && target.enabled && target.configured
      )
      state.siteTargetId = state.targets.some((target) => target.id === binding.targetId)
        ? binding.targetId
        : null
      if (state.siteTargetId && isPreviewHostname(tab?.url, binding)) {
        const matrix = await api(
          `/api/v1/environments/${encodeURIComponent(binding.environmentSlug)}/matrix`
        )
        state.currentSiteBranch =
          matrix.rows?.find((row) => row.target.id === binding.targetId)?.current?.branch || ''
      }
      elements.pageTitle.textContent = binding.name
    } else {
      state.targets = []
      state.siteTargetId = null
    }

    const catalogs = await Promise.all(
      state.targets.map(async (target) => [
        target.id,
        await api(`/api/v1/build-targets/${encodeURIComponent(target.id)}/branches`),
      ])
    )
    state.branches = Object.fromEntries(catalogs)
    const defaultSelectedBranches = {}
    for (const target of state.targets) {
      if (target.id === state.siteTargetId) {
        const activeUsesOfficialPage =
          state.active?.mode === 'site' && !state.active.preview?.siteArtifactId
        defaultSelectedBranches[target.id] = activeUsesOfficialPage
          ? ''
          : state.active?.preview?.siteSelection?.branch ||
            branchForArtifact(target.id, state.active?.preview?.siteArtifactId) ||
            state.currentSiteBranch
        continue
      }
      const activeSelection = state.active?.preview?.selections?.find(
        (item) => item.targetId === target.id
      )
      defaultSelectedBranches[target.id] =
        activeSelection?.branch || branchForArtifact(target.id, activeSelection?.artifactId)
    }
    state.selectedBranches = mergeSelectedBranches({
      sameBinding: previousBindingId === (binding?.id || null),
      previous: previousSelectedBranches,
      defaults: defaultSelectedBranches,
    })
    renderActive()
    renderModules()
    setStatus(
      binding
        ? `已关联 ${binding.hostname}`
        : `${SITE_BINDING_REQUIRED}，Remote 热更不能单独应用到官网标签页`,
      binding ? '' : 'warning'
    )
  } catch (error) {
    state.binding = null
    state.targets = []
    state.siteTargetId = null
    state.currentSiteBranch = ''
    renderModules()
    setStatus(`连接失败：${errorText(error)}`, 'warning')
  }
}

async function createBuild(targetId, branch) {
  state.busyTargets.add(targetId)
  renderModules()
  setStatus(`${branch} 正在提交打包任务`, 'busy')
  try {
    await api('/api/v1/build-jobs', {
      method: 'POST',
      headers: { 'idempotency-key': crypto.randomUUID() },
      body: JSON.stringify({ targetId, branch, profile: 'qa-web' }),
    })
    setStatus(`${branch} 已加入全局队列`, 'success')
    window.setTimeout(() => void load(), 900)
  } catch (error) {
    setStatus(`提交失败：${errorText(error)}`, 'warning')
  } finally {
    state.busyTargets.delete(targetId)
    renderModules()
  }
}

async function applyPreview() {
  const selected = selectedArtifacts()
  const plan = planPreviewApplication({
    binding: state.binding,
    previewOrigin: previewOrigin(),
    siteArtifactId: selected.siteArtifactId,
    selections: selected.selections,
  })
  if (!state.tab?.id) return
  if (!plan.canApply) {
    setStatus(plan.reason, 'warning')
    return
  }
  elements.applyButton.disabled = true
  setStatus('正在创建标签页预览', 'busy')
  try {
    await requireExtensionCapabilities((message) => chrome.runtime.sendMessage(message))

    const granted = await chrome.permissions.request({ origins: [`${plan.requestedOrigin}/*`] })
    if (!granted) throw new Error(`没有获得 ${plan.requestedOrigin} 的预览访问权限`)

    const preview = await api('/api/v1/previews', {
      method: 'POST',
      body: JSON.stringify(
        createPreviewRequest({
          binding: state.binding,
          siteArtifactId: selected.siteArtifactId,
          selections: selected.selections,
        })
      ),
    })

    const origin = plan.requestedOrigin
    const targetUrl = previewDestinationUrl(origin, state.tab.url)
    const result = await chrome.runtime.sendMessage({
      type: 'apply-site-preview',
      tabId: state.tab.id,
      previewOrigin: origin,
      officialOrigin: state.binding.officialOrigin,
      originalUrl: state.tab.url,
      targetUrl,
      preview,
    })
    if (!result?.ok) throw new Error(result?.message || '扩展规则应用失败')
    state.active = result.active
    renderActive()
    setStatus(
      selected.siteArtifactId
        ? '页面与热更预览已应用，正在打开预览域名'
        : '热更预览已应用，正在打开隔离预览域名',
      'success'
    )
    await chrome.tabs.update(state.tab.id, { url: targetUrl })
  } catch (error) {
    setStatus(`应用失败：${errorText(error)}`, 'warning')
    renderModules()
  }
}

async function removePreview() {
  if (!state.tab?.id) return
  const active = state.active
  setStatus('正在停用当前标签页预览', 'busy')
  const result = await chrome.runtime.sendMessage({ type: 'remove-preview', tabId: state.tab.id })
  if (!result?.ok) {
    setStatus(`停用失败：${result?.message || '扩展规则移除失败'}`, 'warning')
    return
  }
  state.active = null
  renderActive()
  setStatus('预览已停用', 'success')
  if (active?.mode === 'site' && active.officialOrigin) {
    await chrome.tabs.update(state.tab.id, {
      url: previewDestinationUrl(active.officialOrigin, state.tab.url),
    })
  } else {
    await chrome.tabs.reload(state.tab.id)
  }
}

async function saveSettings(event) {
  event.preventDefault()
  const origin = new URL(elements.controlOrigin.value).origin
  const permission = `${origin}/*`
  const granted = await chrome.permissions.request({ origins: [permission] })
  if (!granted) {
    setStatus(`未获得 ${origin} 的访问权限，服务地址没有修改`, 'warning')
    return
  }
  state.controlOrigin = origin
  state.actorOverride = normalizeActorName(elements.actorName.value)
  state.actorName = state.actorOverride || state.actorId
  await chrome.storage.local.set({
    [CONTROL_KEY]: origin,
    [ACTOR_ID_KEY]: state.actorId,
    [ACTOR_KEY]: state.actorOverride,
  })
  elements.settingsDialog.close()
  await load()
}

elements.refreshButton.addEventListener('click', () => void load())
elements.settingsButton.addEventListener('click', () => {
  if (!elements.settingsDialog.open) elements.settingsDialog.showModal()
  elements.controlOrigin.focus()
})
elements.settingsCancel.addEventListener('click', () => elements.settingsDialog.close())
elements.settingsClose.addEventListener('click', () => elements.settingsDialog.close())
elements.settingsForm.addEventListener('submit', (event) => void saveSettings(event))
elements.applyButton.addEventListener('click', () => void applyPreview())
elements.removeButton.addEventListener('click', () => void removePreview())

void load()
