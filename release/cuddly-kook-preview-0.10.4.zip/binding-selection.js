export function normalizeBindingCandidates(value) {
  const source = Array.isArray(value?.items) ? value.items : value?.id ? [value] : []
  const seen = new Set()
  return source.filter((binding) => {
    if (
      !binding ||
      typeof binding.id !== 'string' ||
      typeof binding.hostname !== 'string' ||
      seen.has(binding.id)
    ) {
      return false
    }
    seen.add(binding.id)
    return true
  })
}

export function chooseBindingCandidate({ candidates, activeSiteBindingId }) {
  if (!candidates?.length) return null
  return candidates.find((binding) => binding.id === activeSiteBindingId) || candidates[0]
}
