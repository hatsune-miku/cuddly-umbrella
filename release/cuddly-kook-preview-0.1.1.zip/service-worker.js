const ACTIVE_KEY = 'cuddly.activePreviews'

async function readActivePreviews() {
  return (await chrome.storage.local.get(ACTIVE_KEY))[ACTIVE_KEY] || {}
}

async function writeActivePreviews(value) {
  await chrome.storage.local.set({ [ACTIVE_KEY]: value })
}

async function removePreview(tabId) {
  const active = await readActivePreviews()
  const current = active[String(tabId)]
  if (current?.ruleIds?.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: current.ruleIds })
  }
  delete active[String(tabId)]
  await writeActivePreviews(active)
}

async function nextRuleIds() {
  const rules = await chrome.declarativeNetRequest.getDynamicRules()
  const next = rules.reduce((maximum, rule) => Math.max(maximum, rule.id), 1000) + 1
  return [next, next + 1]
}

async function applyPreview(message) {
  const tabId = message.tabId
  await removePreview(tabId)
  const [redirectRuleId, privacyRuleId] = await nextRuleIds()
  const webappUrl = new URL(message.webappOrigin)
  const escapedWebappOrigin = webappUrl.origin.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const condition = {
    regexFilter: `^${escapedWebappOrigin}/(?:api/)?v3/version/hot-module(?:\\?.*)?$`,
    resourceTypes: ['xmlhttprequest'],
    tabIds: [tabId],
  }
  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [
      {
        id: redirectRuleId,
        priority: 1,
        action: { type: 'redirect', redirect: { url: message.hotModuleUrl } },
        condition,
      },
      {
        id: privacyRuleId,
        priority: 2,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'authorization', operation: 'remove' },
            { header: 'cookie', operation: 'remove' },
            { header: 'content-type', operation: 'remove' },
            { header: 'x-signature', operation: 'remove' },
            { header: 'x-nonce', operation: 'remove' },
            { header: 'x-timestamp', operation: 'remove' },
            { header: 'x-client-sessionid', operation: 'remove' },
            { header: 'x-client-version', operation: 'remove' },
            { header: 'x-client-addon-version', operation: 'remove' },
            { header: 'x-client-utm', operation: 'remove' },
          ],
        },
        condition: {
          regexFilter: `^${message.hotModuleUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?:\\?.*)?$`,
          resourceTypes: ['xmlhttprequest'],
          tabIds: [tabId],
        },
      },
    ],
  })
  const active = await readActivePreviews()
  active[String(tabId)] = {
    ruleIds: [privacyRuleId, redirectRuleId],
    preview: message.preview,
    hotModuleUrl: message.hotModuleUrl,
    appliedAt: new Date().toISOString(),
  }
  await writeActivePreviews(active)
}

chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  const task =
    message?.type === 'apply-preview'
      ? applyPreview(message)
      : message?.type === 'remove-preview'
        ? removePreview(message.tabId)
        : Promise.reject(new Error('Unsupported extension command'))
  task
    .then(() => respond({ ok: true }))
    .catch((error) => respond({ ok: false, message: error.message }))
  return true
})

chrome.tabs.onRemoved.addListener((tabId) => {
  void removePreview(tabId)
})

chrome.runtime.onStartup.addListener(async () => {
  const active = await readActivePreviews()
  const tabs = await chrome.tabs.query({})
  const openTabs = new Set(tabs.map((tab) => String(tab.id)))
  await Promise.all(
    Object.keys(active)
      .filter((tabId) => !openTabs.has(tabId))
      .map((tabId) => removePreview(Number(tabId)))
  )
})
