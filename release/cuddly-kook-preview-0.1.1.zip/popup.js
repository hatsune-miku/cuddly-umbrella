const CONTROL_KEY = 'cuddly.controlOrigin'
const ACTOR_KEY = 'cuddly.actorName'
const ACTIVE_KEY = 'cuddly.activePreviews'
const DEFAULT_CONTROL_ORIGIN = 'https://bifrost.vanillacake.cn'

const state = {
  tab: null,
  controlOrigin: DEFAULT_CONTROL_ORIGIN,
  actorName: 'QA Operator',
  runtime: null,
  targets: [],
  branches: {},
  selectedBranches: {},
  active: null,
  busyTargets: new Set(),
}

const elements = {
  pageTitle: document.querySelector('#page-title'),
  pageMeta: document.querySelector('#page-meta'),
  refreshButton: document.querySelector('#refresh-button'),
  settingsButton: document.querySelector('#settings-button'),
  settingsForm: document.querySelector('#settings-form'),
  settingsCancel: document.querySelector('#settings-cancel'),
  controlOrigin: document.querySelector('#control-origin'),
  actorName: document.querySelector('#actor-name'),
  activePanel: document.querySelector('#active-panel'),
  activeSummary: document.querySelector('#active-summary'),
  removeButton: document.querySelector('#remove-button'),
  moduleList: document.querySelector('#module-list'),
  selectionSummary: document.querySelector('#selection-summary'),
  applyButton: document.querySelector('#apply-button'),
  statusBar: document.querySelector('#status-bar'),
  statusText: document.querySelector('#status-text'),
}

function setStatus(text, tone = '') {
  elements.statusText.textContent = text
  elements.statusBar.className = `status-bar ${tone}`.trim()
}

function formatTime(value) {
  if (!value) return '尚未打包'
  return new Intl.DateTimeFormat('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(new Date(value))
}

function errorText(error) {
  if (error?.body?.message) return error.body.message
  return error instanceof Error ? error.message : String(error)
}

async function api(pathname, init) {
  const response = await fetch(`${state.controlOrigin.replace(/\/$/, '')}${pathname}`, {
    ...init,
    headers: {
      'x-cuddly-actor': state.actorName,
      ...(init?.body ? { 'content-type': 'application/json' } : {}),
      ...init?.headers,
    },
  })
  const body = await response.json().catch(() => null)
  if (!response.ok) {
    const error = new Error(`Cuddly 返回 HTTP ${response.status}`)
    error.body = body
    throw error
  }
  return body
}

function latestArtifact(targetId, branch) {
  return (
    state.branches[targetId]?.items?.find((item) => item.branch === branch)?.latestArtifact || null
  )
}

function currentSelections() {
  return state.targets.flatMap((target) => {
    const branch = state.selectedBranches[target.id]
    const artifact = latestArtifact(target.id, branch)
    return artifact
      ? [{ targetId: target.id, artifactId: artifact.id, branch, builtAt: artifact.builtAt }]
      : []
  })
}

function renderActive() {
  elements.activePanel.hidden = !state.active
  if (!state.active) return
  const selections = state.active.preview?.selections || []
  elements.activeSummary.textContent = selections
    .map((item) => `${item.moduleKey} · ${item.branch}`)
    .join('；')
}

function renderModules() {
  elements.moduleList.replaceChildren()
  if (!state.targets.length) {
    const empty = document.createElement('div')
    empty.className = 'empty-state'
    empty.innerHTML =
      '<strong>没有可用的 Remote 项目</strong><span>在管理后台启用 Remote 项目并配置 Git 仓库后会显示在这里。</span>'
    elements.moduleList.append(empty)
  }
  for (const target of state.targets) {
    const catalog = state.branches[target.id] || { items: [], remoteAvailable: false }
    const branch = state.selectedBranches[target.id] || target.defaultBranch
    const branchItem = branch ? catalog.items.find((item) => item.branch === branch) : null
    const artifact = branchItem?.latestArtifact || null
    const row = document.createElement('article')
    row.className = 'module-row'

    const heading = document.createElement('div')
    heading.className = 'module-heading'
    const name = document.createElement('strong')
    name.textContent = target.name
    const kind = document.createElement('span')
    kind.className = 'module-kind'
    kind.textContent = target.id
    heading.append(name, kind)

    const controls = document.createElement('div')
    controls.className = 'module-controls'
    const select = document.createElement('select')
    select.className = 'module-select'
    select.setAttribute('aria-label', `${target.name} 分支`)
    const officialOption = document.createElement('option')
    officialOption.value = ''
    officialOption.textContent = '官方版本'
    officialOption.selected = !branch
    select.append(officialOption)
    const items = catalog.items.length ? catalog.items : [{ branch: target.defaultBranch }]
    for (const item of items) {
      const option = document.createElement('option')
      option.value = item.branch
      option.textContent = item.branch
      option.selected = item.branch === branch
      select.append(option)
    }
    select.addEventListener('change', () => {
      state.selectedBranches[target.id] = select.value
      renderModules()
    })
    const build = document.createElement('button')
    build.type = 'button'
    build.className = 'secondary-button build-button'
    build.textContent = state.busyTargets.has(target.id) ? '提交中' : '打最新包'
    build.disabled = state.busyTargets.has(target.id) || !branch
    build.addEventListener('click', () => void createBuild(target.id, select.value))
    controls.append(select, build)

    const meta = document.createElement('div')
    meta.className = 'module-meta'
    const builtAt = document.createElement('span')
    builtAt.textContent = !branch
      ? '由 KOOK 官方热更响应决定'
      : artifact
        ? `上次打包 ${formatTime(artifact.builtAt)}`
        : '这个分支还没有可用产物'
    const buildState = document.createElement('span')
    if (!branch) {
      buildState.textContent = '不覆盖'
    } else if (branchItem?.buildStatus === 'BUILDING') {
      buildState.className = 'working'
      buildState.textContent = '构建中'
    } else if (branchItem?.buildStatus === 'FAILED') {
      buildState.className = 'failed'
      buildState.textContent = '上次失败'
    } else {
      buildState.textContent = catalog.remoteAvailable ? 'Git 已连接' : '使用本地分支记录'
    }
    meta.append(builtAt, buildState)
    row.append(heading, controls, meta)
    elements.moduleList.append(row)
  }

  const selections = currentSelections()
  elements.selectionSummary.textContent = selections.length
    ? selections.map((item) => `${item.targetId} · ${item.branch}`).join('；')
    : '尚未选择可用产物'
  elements.applyButton.disabled = !selections.length || !isKookTab()
}

function isKookTab() {
  if (!state.tab?.url || !state.runtime?.webappOrigin) return false
  try {
    return new URL(state.tab.url).hostname === new URL(state.runtime.webappOrigin).hostname
  } catch {
    return false
  }
}

async function loadActive() {
  const stored = (await chrome.storage.local.get(ACTIVE_KEY))[ACTIVE_KEY] || {}
  state.active = stored[String(state.tab.id)] || null
  renderActive()
}

async function load() {
  setStatus('正在读取项目和分支', 'busy')
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  state.tab = tab
  const saved = await chrome.storage.local.get([CONTROL_KEY, ACTOR_KEY])
  state.controlOrigin = saved[CONTROL_KEY] || DEFAULT_CONTROL_ORIGIN
  state.actorName = saved[ACTOR_KEY] || 'QA Operator'
  elements.controlOrigin.value = state.controlOrigin
  elements.actorName.value = state.actorName
  elements.pageTitle.textContent = tab?.title || '当前标签页'
  elements.pageMeta.textContent = tab?.url || '无法读取页面地址'
  await loadActive()

  try {
    const [runtime, targetBody] = await Promise.all([
      api('/api/v1/runtime'),
      api('/api/v1/build-targets'),
    ])
    state.runtime = runtime
    state.targets = targetBody.items.filter(
      (target) => target.kind === 'remote' && target.enabled && target.configured
    )
    const catalogs = await Promise.all(
      state.targets.map(async (target) => [
        target.id,
        await api(`/api/v1/build-targets/${encodeURIComponent(target.id)}/branches`),
      ])
    )
    state.branches = Object.fromEntries(catalogs)
    for (const target of state.targets) {
      const items = state.branches[target.id]?.items || []
      const activeBranch = state.active?.preview?.selections?.find(
        (item) => item.targetId === target.id
      )?.branch
      state.selectedBranches[target.id] =
        activeBranch && items.some((item) => item.branch === activeBranch) ? activeBranch : ''
    }
    renderModules()
    setStatus(
      isKookTab() ? '选择分支后应用到当前标签页' : '当前页面不是配置的 KOOK 主站，不能应用预览',
      isKookTab() ? '' : 'warning'
    )
  } catch (error) {
    state.targets = []
    renderModules()
    setStatus(`连接失败：${errorText(error)}`, 'warning')
  }
}

async function createBuild(targetId, branch) {
  state.busyTargets.add(targetId)
  renderModules()
  setStatus(`${branch} 正在提交打包任务`, 'busy')
  try {
    await api('/api/v1/build-jobs', {
      method: 'POST',
      headers: { 'idempotency-key': crypto.randomUUID() },
      body: JSON.stringify({ targetId, branch, profile: 'qa-web' }),
    })
    setStatus(`${branch} 已加入全局队列`, 'success')
    window.setTimeout(() => void load(), 900)
  } catch (error) {
    setStatus(`提交失败：${errorText(error)}`, 'warning')
  } finally {
    state.busyTargets.delete(targetId)
    renderModules()
  }
}

async function applyPreview() {
  const selections = currentSelections()
  if (!selections.length || !state.tab?.id) return
  elements.applyButton.disabled = true
  setStatus('正在创建标签页预览', 'busy')
  try {
    const preview = await api('/api/v1/previews', {
      method: 'POST',
      body: JSON.stringify({ ttlMinutes: 480, selections }),
    })
    const previewOrigin = new URL(preview.hotModuleUrl).origin
    const granted = await chrome.permissions.request({ origins: [`${previewOrigin}/*`] })
    if (!granted) throw new Error(`没有获得 ${previewOrigin} 的预览访问权限`)
    const result = await chrome.runtime.sendMessage({
      type: 'apply-preview',
      tabId: state.tab.id,
      hotModuleUrl: preview.hotModuleUrl,
      webappOrigin: state.runtime.webappOrigin,
      preview,
    })
    if (!result?.ok) throw new Error(result?.message || '扩展规则应用失败')
    state.active = { preview, hotModuleUrl: preview.hotModuleUrl }
    renderActive()
    setStatus('预览已应用，正在重新加载页面', 'success')
    await chrome.tabs.reload(state.tab.id)
  } catch (error) {
    setStatus(`应用失败：${errorText(error)}`, 'warning')
    renderModules()
  }
}

async function removePreview() {
  if (!state.tab?.id) return
  setStatus('正在停用当前标签页预览', 'busy')
  const result = await chrome.runtime.sendMessage({ type: 'remove-preview', tabId: state.tab.id })
  if (!result?.ok) {
    setStatus(`停用失败：${result?.message || '扩展规则移除失败'}`, 'warning')
    return
  }
  state.active = null
  renderActive()
  setStatus('预览已停用，正在重新加载页面', 'success')
  await chrome.tabs.reload(state.tab.id)
}

async function saveControlOrigin(event) {
  event.preventDefault()
  const origin = new URL(elements.controlOrigin.value).origin
  const permission = `${origin}/*`
  const granted = await chrome.permissions.request({ origins: [permission] })
  if (!granted) {
    setStatus(`未获得 ${origin} 的访问权限，服务地址没有修改`, 'warning')
    return
  }
  state.controlOrigin = origin
  state.actorName =
    elements.actorName.value.trim().replace(/\s+/g, ' ').slice(0, 40) || 'QA Operator'
  await chrome.storage.local.set({ [CONTROL_KEY]: origin, [ACTOR_KEY]: state.actorName })
  elements.settingsForm.hidden = true
  await load()
}

elements.refreshButton.addEventListener('click', () => void load())
elements.settingsButton.addEventListener('click', () => {
  elements.settingsForm.hidden = !elements.settingsForm.hidden
  if (!elements.settingsForm.hidden) elements.controlOrigin.focus()
})
elements.settingsCancel.addEventListener('click', () => {
  elements.settingsForm.hidden = true
})
elements.settingsForm.addEventListener('submit', (event) => void saveControlOrigin(event))
elements.applyButton.addEventListener('click', () => void applyPreview())
elements.removeButton.addEventListener('click', () => void removePreview())

void load()
