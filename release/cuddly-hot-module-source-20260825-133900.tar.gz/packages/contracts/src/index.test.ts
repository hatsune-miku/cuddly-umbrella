import { describe, expect, it } from 'vitest'

import { saveBuildTargetSchema, saveSiteBindingSchema } from './index'

const siteBinding = {
  id: 'main',
  name: 'KOOK 网页端',
  hostname: 'main.bifrost.vanillacake.cn',
  targetId: 'webapp',
  environmentSlug: 'shared',
  upstreamOrigin: 'https://www.kookapp.cn',
  officialOrigin: 'https://www.kookapp.cn',
  enabled: true,
  remoteTargetIds: ['base'],
  resourceProxyPrefixes: [],
}

const siteProject = {
  id: 'webapp',
  name: '网页端',
  kind: 'webapp' as const,
  repositoryUrl: 'https://git.example.test/webapp.git',
  defaultBranch: 'master',
  installCommand: 'pnpm install',
  buildCommand: 'pnpm build',
  outputDirectory: 'dist',
  siteAdapter: 'generic-static-v1',
  enabled: true,
  required: false,
}

describe('site binding contracts', () => {
  it('accepts DNS-label site ids and rejects underscores or invalid edges', () => {
    for (const id of ['main', 'main-preview', 'a', `${'a'.repeat(62)}z`]) {
      expect(saveSiteBindingSchema.safeParse({ ...siteBinding, id }).success).toBe(true)
    }
    for (const id of ['main_preview', '-main', 'main-', 'Main', 'a'.repeat(64)]) {
      expect(saveSiteBindingSchema.safeParse({ ...siteBinding, id }).success).toBe(false)
    }
  })

  it('normalizes and validates resource proxy URL prefixes', () => {
    const parsed = saveSiteBindingSchema.parse({
      ...siteBinding,
      resourceProxyPrefixes: [
        ' HTTPS://STATIC.KOOKAPP.CN:443/assets/../static/ ',
        'http://img.kookapp.cn:80/assets/',
      ],
    })
    expect(parsed.resourceProxyPrefixes).toEqual([
      'https://static.kookapp.cn/static/',
      'http://img.kookapp.cn/assets/',
    ])

    for (const prefix of [
      'ftp://static.kookapp.cn/static/',
      'https://user:secret@static.kookapp.cn/static/',
      'https://@static.kookapp.cn/static/',
      'https://static.kookapp.cn/static/?version=1',
      'https://static.kookapp.cn/static/?',
      'https://static.kookapp.cn/static/#entry',
      'https://static.kookapp.cn/static/#',
      'https://static.kookapp.cn/static',
    ]) {
      expect(
        saveSiteBindingSchema.safeParse({
          ...siteBinding,
          resourceProxyPrefixes: [prefix],
        }).success
      ).toBe(false)
    }
  })

  it('rejects localhost and non-public IPv4 resource proxy targets', () => {
    for (const prefix of [
      'http://localhost/assets/',
      'http://LOCALHOST./assets/',
      'http://api.localhost/assets/',
      'http://127.0.0.1/assets/',
      'http://2130706433/assets/',
      'http://0x7f000001/assets/',
      'http://0.0.0.0/assets/',
      'http://10.0.0.1/assets/',
      'http://100.100.100.200/assets/',
      'http://169.254.169.254/latest/',
      'http://172.16.0.1/assets/',
      'http://192.168.1.1/assets/',
      'http://198.18.0.1/assets/',
      'http://198.51.100.1/assets/',
      'http://224.0.0.1/assets/',
      'http://255.255.255.255/assets/',
    ]) {
      expect(
        saveSiteBindingSchema.safeParse({
          ...siteBinding,
          resourceProxyPrefixes: [prefix],
        }).success
      ).toBe(false)
    }

    for (const prefix of [
      'https://8.8.8.8/assets/',
      'https://1.1.1.1/assets/',
      'https://internal.example.test/assets/',
    ]) {
      expect(
        saveSiteBindingSchema.safeParse({
          ...siteBinding,
          resourceProxyPrefixes: [prefix],
        }).success
      ).toBe(true)
    }
  })

  it('rejects non-public IPv6 resource proxy targets', () => {
    for (const prefix of [
      'http://[::]/assets/',
      'http://[::1]/assets/',
      'http://[::ffff:127.0.0.1]/assets/',
      'http://[64:ff9b::a9fe:a9fe]/assets/',
      'http://[fc00::1]/assets/',
      'http://[fd12:3456::1]/assets/',
      'http://[fe80::1]/assets/',
      'http://[ff02::1]/assets/',
      'http://[2001:db8::1]/assets/',
      'http://[2002:7f00:1::]/assets/',
      'http://[3fff::1]/assets/',
    ]) {
      expect(
        saveSiteBindingSchema.safeParse({
          ...siteBinding,
          resourceProxyPrefixes: [prefix],
        }).success
      ).toBe(false)
    }

    for (const prefix of [
      'https://[2001:4860:4860::8888]/assets/',
      'https://[2606:4700:4700::1111]/assets/',
    ]) {
      expect(
        saveSiteBindingSchema.safeParse({
          ...siteBinding,
          resourceProxyPrefixes: [prefix],
        }).success
      ).toBe(true)
    }
  })

  it('requires at most 20 unique normalized resource proxy prefixes', () => {
    expect(
      saveSiteBindingSchema.safeParse({
        ...siteBinding,
        resourceProxyPrefixes: [
          'https://STATIC.kookapp.cn:443/static/',
          'https://static.kookapp.cn/static/',
        ],
      }).success
    ).toBe(false)
    expect(
      saveSiteBindingSchema.safeParse({
        ...siteBinding,
        resourceProxyPrefixes: Array.from(
          { length: 21 },
          (_, index) => `https://static-${index}.kookapp.cn/`
        ),
      }).success
    ).toBe(false)
    expect(saveSiteBindingSchema.safeParse(siteBinding).success).toBe(true)
    const { resourceProxyPrefixes: _prefixes, ...missingPrefixes } = siteBinding
    expect(saveSiteBindingSchema.safeParse(missingPrefixes).success).toBe(false)
  })

  it('limits non-Remote projects to implemented site adapters', () => {
    expect(saveBuildTargetSchema.safeParse(siteProject).success).toBe(true)
    expect(
      saveBuildTargetSchema.safeParse({ ...siteProject, siteAdapter: 'kook-online-h5-v1' }).success
    ).toBe(true)
    expect(
      saveBuildTargetSchema.safeParse({ ...siteProject, siteAdapter: 'kook-remote-v1' }).success
    ).toBe(false)
    expect(
      saveBuildTargetSchema.safeParse({ ...siteProject, siteAdapter: 'custom-static-v1' }).success
    ).toBe(false)
  })
})
