import { describe, expect, it } from 'vitest'

import { MemoryStore } from './memory-store'
import { resolveSystemSettings, SYSTEM_SETTING_KEYS } from './system-settings'

describe('system settings', () => {
  it('enables the China package registry by default and persists an override', async () => {
    const store = new MemoryStore()

    expect((await resolveSystemSettings(store)).useChinaRegistry).toBe(true)

    await store.updateRuntimeSettings(
      [{ key: SYSTEM_SETTING_KEYS.useChinaRegistry, value: false }],
      'gz'
    )

    expect((await resolveSystemSettings(store)).useChinaRegistry).toBe(false)
  })
})
