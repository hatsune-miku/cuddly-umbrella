import { createHmac, randomBytes, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto'
import { execFile } from 'node:child_process'
import { existsSync } from 'node:fs'
import { promisify } from 'node:util'

export * from './secure-settings'
export * from './secret-file'

const scrypt = promisify(scryptCallback)
const execFileAsync = promisify(execFile)
const gitSshIdentityPath = '/srv/cuddly/secrets/git_id_ed25519'
const gitSshKnownHostsPath = '/srv/cuddly/secrets/git_known_hosts'

function socks5ProxyAddress(env: NodeJS.ProcessEnv): string | null {
  const value = env.ALL_PROXY || env.all_proxy
  if (!value) return null
  try {
    const proxy = new URL(value)
    if (!['socks5:', 'socks5h:'].includes(proxy.protocol)) return null
    if (proxy.username || proxy.password || !/^[a-z0-9.-]+$/i.test(proxy.hostname)) return null
    const port = proxy.port || '1080'
    if (!/^\d{1,5}$/.test(port) || Number(port) > 65_535) return null
    return `${proxy.hostname}:${port}`
  } catch {
    return null
  }
}

export function gitSshCommand(
  env: NodeJS.ProcessEnv = process.env,
  identityAvailable = existsSync(gitSshIdentityPath)
): string {
  const options = [
    'ssh',
    '-o BatchMode=yes',
    '-o ConnectTimeout=7',
    '-o ConnectionAttempts=1',
    '-o StrictHostKeyChecking=accept-new',
    `-o UserKnownHostsFile=${gitSshKnownHostsPath}`,
  ]
  if (identityAvailable) {
    options.push(`-i ${gitSshIdentityPath}`, '-o IdentitiesOnly=yes')
  }
  const proxy = socks5ProxyAddress(env)
  if (proxy) options.push(`-o 'ProxyCommand=nc -X 5 -x ${proxy} %h %p'`)
  return options.join(' ')
}

export interface SessionIdentity {
  sessionId: string
  displayName: string
  expiresAt: number
}

function base64url(value: Buffer | string): string {
  return Buffer.from(value).toString('base64url')
}

function sign(value: string, secret: string): string {
  return createHmac('sha256', secret).update(value).digest('base64url')
}

export function createSessionToken(
  displayName: string,
  secret: string,
  ttlSeconds = 8 * 60 * 60
): string {
  const identity: SessionIdentity = {
    sessionId: randomBytes(16).toString('hex'),
    displayName,
    expiresAt: Math.floor(Date.now() / 1000) + ttlSeconds,
  }
  const payload = base64url(JSON.stringify(identity))
  return `${payload}.${sign(payload, secret)}`
}

export function verifySessionToken(token: string, secret: string): SessionIdentity | null {
  const [payload, signature] = token.split('.')
  if (!payload || !signature) return null
  const expected = sign(payload, secret)
  const actualBuffer = Buffer.from(signature)
  const expectedBuffer = Buffer.from(expected)
  if (
    actualBuffer.length !== expectedBuffer.length ||
    !timingSafeEqual(actualBuffer, expectedBuffer)
  )
    return null
  try {
    const identity = JSON.parse(
      Buffer.from(payload, 'base64url').toString('utf8')
    ) as SessionIdentity
    if (
      !identity.sessionId ||
      !identity.displayName ||
      identity.expiresAt <= Math.floor(Date.now() / 1000)
    ) {
      return null
    }
    return identity
  } catch {
    return null
  }
}

export function readCookie(cookieHeader: string | undefined, name: string): string | null {
  if (!cookieHeader) return null
  for (const pair of cookieHeader.split(';')) {
    const separator = pair.indexOf('=')
    if (separator === -1) continue
    const key = pair.slice(0, separator).trim()
    if (key !== name) continue
    return decodeURIComponent(pair.slice(separator + 1).trim())
  }
  return null
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16)
  const derived = (await scrypt(password, salt, 64)) as Buffer
  return `scrypt:${salt.toString('hex')}:${derived.toString('hex')}`
}

export async function verifyPassword(password: string, encoded: string): Promise<boolean> {
  const [algorithm, saltHex, hashHex] = encoded.split(encoded.includes(':') ? ':' : '$')
  if (algorithm !== 'scrypt' || !saltHex || !hashHex) return false
  const expected = Buffer.from(hashHex, 'hex')
  const derived = (await scrypt(password, Buffer.from(saltHex, 'hex'), expected.length)) as Buffer
  return derived.length === expected.length && timingSafeEqual(derived, expected)
}

export async function listRemoteBranches(
  repositoryUrl: string,
  authorizationHeader?: string
): Promise<string[]> {
  const authEnv = authorizationHeader
    ? {
        GIT_CONFIG_COUNT: '1',
        GIT_CONFIG_KEY_0: 'http.extraHeader',
        GIT_CONFIG_VALUE_0: authorizationHeader,
      }
    : {}
  const { stdout } = await execFileAsync('git', ['ls-remote', '--heads', repositoryUrl], {
    timeout: 12_000,
    windowsHide: true,
    env: {
      ...process.env,
      ...authEnv,
      GIT_TERMINAL_PROMPT: '0',
      GIT_SSH_COMMAND: gitSshCommand(),
    },
    maxBuffer: 4 * 1024 * 1024,
  })
  return stdout
    .split(/\r?\n/)
    .map((line) => line.trim().split(/\s+/)[1])
    .filter((ref): ref is string => Boolean(ref?.startsWith('refs/heads/')))
    .map((ref) => ref.slice('refs/heads/'.length))
    .sort((a, b) => a.localeCompare(b))
}
