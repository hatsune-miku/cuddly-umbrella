export interface HostRewrite {
  upstreamHost: string
  proxyHost: string
}

export function rewriteCookieDomain(cookie: string, domain: string): string {
  const stripped = cookie.replace(/;\s*Domain=[^;]*/i, '')
  return domain ? `${stripped}; Domain=${domain}` : stripped
}

export function rewriteSetCookieHeaders(
  header: string | string[] | undefined,
  domain: string
): string[] | undefined {
  if (!header) return undefined
  const cookies = Array.isArray(header) ? header : [header]
  return cookies.map((cookie) => rewriteCookieDomain(cookie, domain))
}

export function rewriteHosts(value: string, rewrites: HostRewrite[]): string {
  let result = value
  for (const rewrite of rewrites) {
    result = result.replaceAll(rewrite.upstreamHost, rewrite.proxyHost)
  }
  return result
}

export function rewriteLocationHeader(
  location: string | undefined,
  rewrites: HostRewrite[]
): string | undefined {
  return location ? rewriteHosts(location, rewrites) : undefined
}
