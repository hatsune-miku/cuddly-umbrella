import { createReadStream } from 'node:fs'
import { access, cp, mkdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises'
import path from 'node:path'

import type { ArtifactManifest } from '@cuddly/contracts'

export const ARTIFACT_METADATA_PATH = '.cuddly/manifest.json'

function assertSafeSegment(value: string, label: string): void {
  if (!/^[A-Za-z0-9._-]+$/.test(value) || value === '.' || value === '..') {
    throw new Error(`Unsafe ${label}: ${value}`)
  }
}

function normalizeRelativePath(value: string): string {
  const decoded = decodeURIComponent(value).replaceAll('\\', '/')
  const normalized = path.posix.normalize(decoded).replace(/^\/+/, '')
  if (
    !normalized ||
    normalized === '.' ||
    normalized.startsWith('../') ||
    normalized.includes('/../')
  ) {
    throw new Error(`Unsafe artifact path: ${value}`)
  }
  return normalized
}

export interface ArtifactFileHandle {
  absolutePath: string
  size: number
  createStream: (range?: { start: number; end: number }) => NodeJS.ReadableStream
}

export class FileArtifactStore {
  constructor(readonly root: string) {}

  async initialize(): Promise<void> {
    await Promise.all([
      mkdir(path.join(this.root, 'staging'), { recursive: true }),
      mkdir(path.join(this.root, 'ready'), { recursive: true }),
    ])
  }

  async publishDirectory(input: {
    sourceDirectory: string
    targetId: string
    artifactId: string
    manifest: ArtifactManifest
  }): Promise<string> {
    assertSafeSegment(input.targetId, 'target id')
    assertSafeSegment(input.artifactId, 'artifact id')
    const staging = path.join(this.root, 'staging', input.artifactId)
    const readyParent = path.join(this.root, 'ready', input.targetId)
    const ready = path.join(readyParent, input.artifactId)

    await rm(staging, { recursive: true, force: true })
    await mkdir(path.dirname(staging), { recursive: true })
    await cp(input.sourceDirectory, staging, { recursive: true, force: false })
    const metadataPath = path.join(staging, ...ARTIFACT_METADATA_PATH.split('/'))
    await mkdir(path.dirname(metadataPath), { recursive: true })
    await writeFile(metadataPath, JSON.stringify(input.manifest, null, 2), 'utf8')
    await mkdir(readyParent, { recursive: true })
    try {
      await access(ready)
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
      await rename(staging, ready)
      return path.posix.join('ready', input.targetId, input.artifactId)
    }
    throw new Error(`Artifact directory already exists: ${ready}`)
  }

  resolveStorageDirectory(storageKey: string): string {
    const normalized = normalizeRelativePath(storageKey)
    const resolved = path.resolve(this.root, normalized)
    const root = path.resolve(this.root)
    if (resolved !== root && !resolved.startsWith(`${root}${path.sep}`)) {
      throw new Error(`Storage key escapes artifact root: ${storageKey}`)
    }
    return resolved
  }

  resolveFilePath(storageKey: string, relativePath: string): string {
    const base = this.resolveStorageDirectory(storageKey)
    const normalized = normalizeRelativePath(relativePath)
    const resolved = path.resolve(base, ...normalized.split('/'))
    if (!resolved.startsWith(`${base}${path.sep}`)) {
      throw new Error(`Artifact path escapes storage directory: ${relativePath}`)
    }
    return resolved
  }

  async openFile(storageKey: string, relativePath: string): Promise<ArtifactFileHandle | null> {
    let absolutePath: string
    try {
      absolutePath = this.resolveFilePath(storageKey, relativePath)
      const fileStat = await stat(absolutePath)
      if (!fileStat.isFile()) return null
      return {
        absolutePath,
        size: fileStat.size,
        createStream: (range) => createReadStream(absolutePath, range),
      }
    } catch {
      return null
    }
  }

  async readText(storageKey: string, relativePath: string): Promise<string | null> {
    const file = await this.openFile(storageKey, relativePath)
    if (!file) return null
    return readFile(file.absolutePath, 'utf8')
  }
}

export function createArtifactStore(): FileArtifactStore {
  return new FileArtifactStore(
    process.env.NODE_ENV === 'production' ? '/srv/cuddly/artifacts' : path.resolve('data/artifacts')
  )
}
