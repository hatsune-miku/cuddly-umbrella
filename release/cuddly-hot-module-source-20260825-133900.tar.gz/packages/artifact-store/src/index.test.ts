import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'

import type { ArtifactManifest } from '@cuddly/contracts'
import { afterEach, describe, expect, it } from 'vitest'

import { ARTIFACT_METADATA_PATH, FileArtifactStore } from './index'

const cleanupDirectories: string[] = []

afterEach(async () => {
  await Promise.all(
    cleanupDirectories.splice(0).map((directory) => rm(directory, { recursive: true, force: true }))
  )
})

function artifactManifest(artifactId: string): ArtifactManifest {
  return {
    schemaVersion: 1,
    artifactId,
    target: 'webapp',
    branch: 'main',
    builtAt: '2026-08-24T00:00:00.000Z',
    serve: {
      siteAdapter: 'generic-static-v1',
      entrypoints: ['index.html'],
      publicBase: `/__cuddly/artifacts/${artifactId}/`,
    },
    files: [
      {
        path: 'index.html',
        size: 15,
        contentType: 'text/html; charset=utf-8',
        digest: 'sha256:test',
        cacheClass: 'html',
      },
    ],
  }
}

async function createStoreFixture(): Promise<{
  sourceDirectory: string
  store: FileArtifactStore
}> {
  const root = await mkdtemp(path.join(os.tmpdir(), 'cuddly-artifact-store-'))
  cleanupDirectories.push(root)
  const sourceDirectory = path.join(root, 'source')
  const store = new FileArtifactStore(path.join(root, 'artifacts'))
  await store.initialize()
  await mkdir(sourceDirectory, { recursive: true })
  await writeFile(path.join(sourceDirectory, 'index.html'), '<h1>Cuddly</h1>', 'utf8')
  return { sourceDirectory, store }
}

describe('FileArtifactStore.publishDirectory', () => {
  it('preserves a business manifest.json and writes Cuddly metadata separately', async () => {
    const { sourceDirectory, store } = await createStoreFixture()
    const artifactId = 'artifact-with-business-manifest'
    const manifest = artifactManifest(artifactId)
    const businessManifest = '{"name":"KOOK","start_url":"/"}\n'
    await writeFile(path.join(sourceDirectory, 'manifest.json'), businessManifest, 'utf8')

    const storageKey = await store.publishDirectory({
      sourceDirectory,
      targetId: 'webapp',
      artifactId,
      manifest,
    })

    await expect(store.readText(storageKey, 'manifest.json')).resolves.toBe(businessManifest)
    await expect(store.readText(storageKey, ARTIFACT_METADATA_PATH)).resolves.toBe(
      JSON.stringify(manifest, null, 2)
    )
  })

  it('does not create a public root manifest.json when the build has none', async () => {
    const { sourceDirectory, store } = await createStoreFixture()
    const artifactId = 'artifact-without-business-manifest'
    const manifest = artifactManifest(artifactId)

    const storageKey = await store.publishDirectory({
      sourceDirectory,
      targetId: 'webapp',
      artifactId,
      manifest,
    })

    await expect(store.readText(storageKey, 'manifest.json')).resolves.toBeNull()
    const metadata = await store.readText(storageKey, ARTIFACT_METADATA_PATH)
    expect(metadata && JSON.parse(metadata)).toEqual(manifest)
  })
})
