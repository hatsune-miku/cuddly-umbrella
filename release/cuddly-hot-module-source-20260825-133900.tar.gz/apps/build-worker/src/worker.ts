import { randomUUID } from 'node:crypto'

import {
  runnerEventSchema,
  type BuildJob,
  type RunnerEvent,
  type RunnerStage,
} from '@cuddly/contracts'
import type { CuddlyStore } from '@cuddly/db'

class BuildFailure extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly logPath: string | null = null
  ) {
    super(message)
    this.name = 'BuildFailure'
  }
}

export interface BuildWorkerOptions {
  store: CuddlyStore
  runnerUrl: string
  runnerToken: string
  workerId: string
  requestTimeoutMs: number
  maxConcurrency: number
  resolveRuntimeSettings?: () => Promise<{
    maxConcurrency: number
    requestTimeoutMs: number
    artifactBaseUrl: string
  }>
}

export type BuildJobProcessor = (job: BuildJob, options: BuildWorkerOptions) => Promise<void>

type RunnerResult = Extract<RunnerEvent, { type: 'result' }>

async function readRunnerEvents(
  response: Response,
  onStage: (stage: RunnerStage) => Promise<void>
): Promise<RunnerResult> {
  if (!response.body)
    throw new BuildFailure('RUNNER_EMPTY_RESPONSE', 'Runner returned no response body')
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffered = ''
  let result: RunnerResult | null = null

  const consumeLine = async (line: string) => {
    if (!line.trim()) return
    const parsed = runnerEventSchema.safeParse(JSON.parse(line))
    if (!parsed.success) {
      throw new BuildFailure('RUNNER_PROTOCOL_ERROR', 'Runner returned an invalid event')
    }
    const event = parsed.data
    if (event.type === 'stage') await onStage(event.stage)
    if (event.type === 'result') result = event
    if (event.type === 'error') throw new BuildFailure(event.code, event.message, event.logPath)
  }

  while (true) {
    const { value, done } = await reader.read()
    buffered += decoder.decode(value, { stream: !done })
    const lines = buffered.split('\n')
    buffered = lines.pop() || ''
    for (const line of lines) await consumeLine(line)
    if (done) break
  }
  await consumeLine(buffered)
  if (!result)
    throw new BuildFailure('RUNNER_NO_RESULT', 'Runner finished without an Artifact result')
  return result
}

async function invokeRunner(job: BuildJob, artifactId: string, options: BuildWorkerOptions) {
  if (!job.targetSnapshot) {
    throw new BuildFailure(
      'TARGET_SNAPSHOT_MISSING',
      'Build job has no project configuration snapshot'
    )
  }
  const runtime = options.resolveRuntimeSettings
    ? await options.resolveRuntimeSettings()
    : {
        maxConcurrency: options.maxConcurrency,
        requestTimeoutMs: options.requestTimeoutMs,
        artifactBaseUrl: 'http://localhost:9872',
      }
  const response = await fetch(`${options.runnerUrl.replace(/\/$/, '')}/internal/run`, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${options.runnerToken}`,
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      jobId: job.id,
      artifactId,
      targetId: job.targetId,
      branch: job.branch,
      requestedBy: job.requestedBy,
      artifactBaseUrl: runtime.artifactBaseUrl,
      project: job.targetSnapshot,
    }),
    signal: AbortSignal.timeout(runtime.requestTimeoutMs),
  })
  if (!response.ok) {
    const body = await response.text()
    throw new BuildFailure(
      'RUNNER_HTTP_ERROR',
      `Runner returned HTTP ${response.status}: ${body.slice(0, 500)}`
    )
  }
  return readRunnerEvents(response, async (stage) => {
    await options.store.updateBuildJob(job.id, { status: stage })
  })
}

export async function processBuildJob(job: BuildJob, options: BuildWorkerOptions): Promise<void> {
  const artifactId = randomUUID()
  try {
    const result = await invokeRunner(job, artifactId, options)
    await options.store.createArtifact({
      id: result.artifactId,
      buildJobId: job.id,
      targetId: job.targetId,
      branch: job.branch,
      status: 'READY',
      storageKey: result.storageKey,
      manifest: result.manifest,
      builtAt: result.builtAt,
      createdBy: job.requestedBy,
    })
    await options.store.updateBuildJob(job.id, {
      status: 'SUCCEEDED',
      finishedAt: new Date().toISOString(),
      failureCode: null,
      failureMessage: null,
      logPath: result.logPath,
    })
  } catch (error) {
    const failure =
      error instanceof BuildFailure
        ? error
        : new BuildFailure('WORKER_FAILED', error instanceof Error ? error.message : String(error))
    await options.store.updateBuildJob(job.id, {
      status: 'FAILED',
      finishedAt: new Date().toISOString(),
      failureCode: failure.code,
      failureMessage: failure.message.slice(0, 1000),
      logPath: failure.logPath,
    })
  }
}

export class BuildWorker {
  private stopping = false
  private readonly activeJobs = new Set<Promise<void>>()
  constructor(
    private readonly options: BuildWorkerOptions,
    private readonly processJob: BuildJobProcessor = processBuildJob
  ) {}

  stop(): void {
    this.stopping = true
  }

  private start(job: BuildJob): void {
    let task: Promise<void>
    task = Promise.resolve()
      .then(() => this.processJob(job, this.options))
      .catch((error) => {
        console.error(`[build-worker] job ${job.id} stopped unexpectedly`, error)
      })
      .finally(() => {
        this.activeJobs.delete(task)
      })
    this.activeJobs.add(task)
  }

  async run(pollIntervalMs: number): Promise<void> {
    while (!this.stopping) {
      const runtime = this.options.resolveRuntimeSettings
        ? await this.options.resolveRuntimeSettings()
        : { maxConcurrency: this.options.maxConcurrency }
      const maxConcurrency = Number.isFinite(runtime.maxConcurrency)
        ? Math.max(1, Math.floor(runtime.maxConcurrency))
        : 1
      while (!this.stopping && this.activeJobs.size < maxConcurrency) {
        const job = await this.options.store.claimNextBuildJob(this.options.workerId)
        if (!job) break
        this.start(job)
      }

      if (this.stopping) break
      const poll = new Promise<void>((resolve) => setTimeout(resolve, pollIntervalMs))
      await Promise.race([poll, ...this.activeJobs])
    }

    await Promise.allSettled(this.activeJobs)
  }
}
