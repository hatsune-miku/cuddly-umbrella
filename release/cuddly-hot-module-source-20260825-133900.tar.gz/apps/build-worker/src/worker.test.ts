import { randomUUID } from 'node:crypto'

import type { BuildJob } from '@cuddly/contracts'
import { MemoryStore } from '@cuddly/db'
import { describe, expect, it } from 'vitest'

import { BuildWorker } from './worker'

describe('BuildWorker concurrency', () => {
  it('fills execution slots with jobs from different projects', async () => {
    const store = new MemoryStore()
    await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/mobile',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    await store.createBuildJob({
      id: randomUUID(),
      targetId: 'webapp',
      branch: 'feature/web',
      profile: 'qa-web',
      requestedBy: 'qa-two',
      idempotencyKey: null,
      targetSnapshot: null,
    })

    const started = new Set<string>()
    const releases = new Map<string, () => void>()
    let resolveBothStarted: () => void = () => undefined
    const bothStarted = new Promise<void>((resolve) => {
      resolveBothStarted = resolve
    })
    const processJob = async (job: BuildJob) => {
      started.add(job.targetId)
      if (started.size === 2) resolveBothStarted()
      await new Promise<void>((resolve) => releases.set(job.id, resolve))
    }
    const worker = new BuildWorker(
      {
        store,
        runnerUrl: 'http://runner.test',
        runnerToken: 'test-token',
        workerId: 'worker-1',
        requestTimeoutMs: 1000,
        maxConcurrency: 2,
      },
      processJob
    )

    const run = worker.run(5)
    await Promise.race([
      bothStarted,
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('worker did not start both projects')), 1000)
      ),
    ])

    expect([...started].sort()).toEqual(['online-h5', 'webapp'])
    worker.stop()
    releases.forEach((release) => release())
    await run
  })
})
