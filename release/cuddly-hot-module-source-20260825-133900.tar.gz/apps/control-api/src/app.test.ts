import type { AddressInfo } from 'node:net'

import { randomUUID } from 'node:crypto'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import type { Artifact, BuildJob, BuildQueueSnapshot, PreviewSessionView } from '@cuddly/contracts'
import { MemoryStore } from '@cuddly/db'
import { describe, expect, it } from 'vitest'

import { createControlApp } from './app'

describe('control API build queue', () => {
  it('supports one-time admin setup without bootstrap environment variables', async () => {
    const store = new MemoryStore()
    const server = createControlApp({
      store,
      adminSessionSecret: 'test-secret',
      internalApiToken: 'internal-test-token',
      settingsSecret: 'test-secret',
    }).listen(0)

    try {
      const { port } = server.address() as AddressInfo
      const origin = `http://127.0.0.1:${port}`
      const status = await fetch(`${origin}/api/v1/admin/setup-status`)
      expect(await status.json()).toEqual({ setupRequired: true })

      const setup = await fetch(`${origin}/api/v1/admin/setup`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-cuddly-actor': 'gz' },
        body: JSON.stringify({ password: 'first-admin-password' }),
      })
      expect(setup.status).toBe(201)
      expect(setup.headers.get('set-cookie')).toContain('cuddly_admin=')

      const repeated = await fetch(`${origin}/api/v1/admin/setup`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ password: 'another-admin-password' }),
      })
      expect(repeated.status).toBe(409)

      const unlock = await fetch(`${origin}/api/v1/admin/unlock`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ password: 'first-admin-password' }),
      })
      expect(unlock.status).toBe(200)
    } finally {
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve()))
      )
    }
  })

  it('protects internal APIs with a Bearer token regardless of URL casing', async () => {
    const store = new MemoryStore()
    const server = createControlApp({
      store,
      adminSessionSecret: 'test-secret',
      internalApiToken: 'internal-test-token',
      settingsSecret: 'test-secret',
    }).listen(0)

    try {
      const { port } = server.address() as AddressInfo
      const origin = `http://127.0.0.1:${port}`
      const configUrl = `${origin}/api/v1/internal/auto-ssl-config`

      const missing = await fetch(configUrl)
      expect(missing.status).toBe(401)
      expect(missing.headers.get('www-authenticate')).toBe('Bearer realm="cuddly-internal"')

      const incorrect = await fetch(configUrl, {
        headers: { authorization: 'Bearer incorrect-token' },
      })
      expect(incorrect.status).toBe(401)

      const mixedCase = await fetch(`${origin}/api/v1/INTERNAL/auto-ssl-config`)
      expect(mixedCase.status).toBe(401)

      const authorized = await fetch(configUrl, {
        headers: { authorization: 'Bearer internal-test-token' },
      })
      expect(authorized.status).toBe(200)
      expect(await authorized.json()).toEqual({
        autoSslEnabled: false,
        autoSslEmail: '',
        hostnames: [],
      })
    } finally {
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve()))
      )
    }
  })

  it('keeps ordinary QA APIs open while protecting sensitive settings', async () => {
    const store = new MemoryStore()
    const first = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000001',
      targetId: 'online-h5',
      branch: 'feature/running',
      profile: 'qa-web',
      requestedBy: 'qa-one',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const second = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000002',
      targetId: 'online-h5',
      branch: 'feature/mine',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    const third = await store.createBuildJob({
      id: '00000000-0000-4000-8000-000000000003',
      targetId: 'online-h5',
      branch: 'feature/other',
      profile: 'qa-web',
      requestedBy: 'qa-two',
      idempotencyKey: null,
      targetSnapshot: null,
    })
    expect((await store.claimNextBuildJob('worker-1'))?.id).toBe(first.id)

    const server = createControlApp({
      store,
      adminSessionSecret: 'test-secret',
      internalApiToken: 'internal-test-token',
      developmentAdminPassword: 'admin-password',
      settingsSecret: 'test-secret',
    }).listen(0)

    try {
      const { port } = server.address() as AddressInfo
      const origin = `http://127.0.0.1:${port}`
      const response = await fetch(`${origin}/api/v1/build-queue`, {
        headers: { 'x-cuddly-actor': 'gz' },
      })
      expect(response.status).toBe(200)
      const queue = (await response.json()) as BuildQueueSnapshot

      expect(queue.running.map((item) => item.id)).toEqual([first.id])
      expect(queue.queued.map((item) => item.id)).toEqual([second.id, third.id])
      expect(queue.queued.map((item) => item.queuePosition)).toEqual([1, 2])
      expect(queue.queued.map((item) => item.isMine)).toEqual([true, false])

      const forbidden = await fetch(`${origin}/api/v1/admin/proxy-settings`, {
        headers: { 'x-cuddly-actor': 'gz' },
      })
      expect(forbidden.status).toBe(403)

      const unlock = await fetch(`${origin}/api/v1/admin/unlock`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-cuddly-actor': 'gz' },
        body: JSON.stringify({ password: 'admin-password' }),
      })
      expect(unlock.status).toBe(200)
      const adminCookie = unlock.headers.get('set-cookie')
      expect(adminCookie).toContain('cuddly_admin=')

      const projects = await fetch(`${origin}/api/v1/admin/build-targets`, {
        headers: { cookie: adminCookie!, 'x-cuddly-actor': 'gz' },
      })
      expect(projects.status).toBe(200)
      const projectBody = (await projects.json()) as { items: Array<{ id: string }> }
      expect(projectBody.items.map((item) => item.id)).toContain('online-h5')

      const saveProject = await fetch(`${origin}/api/v1/admin/build-targets/webapp`, {
        method: 'PUT',
        headers: {
          'content-type': 'application/json',
          cookie: adminCookie!,
          'x-cuddly-actor': 'gz',
        },
        body: JSON.stringify({
          id: 'ignored-by-path',
          name: '网页端',
          kind: 'webapp',
          repositoryUrl: 'https://git.example.test/webapp.git',
          defaultBranch: 'develop',
          installCommand: 'corepack pnpm install --frozen-lockfile',
          buildCommand: 'corepack pnpm run build',
          outputDirectory: 'dist',
          siteAdapter: 'generic-static-v1',
          enabled: true,
          required: false,
          gitAuthorizationHeader: 'Authorization: Basic hidden',
        }),
      })
      expect(saveProject.status).toBe(200)
      expect((await store.getBuildTarget('webapp'))?.configurationSource).toBe('database')
      expect((await saveProject.json()) as Record<string, unknown>).not.toHaveProperty(
        'gitAuthorizationHeader'
      )

      const publicProjects = await fetch(`${origin}/api/v1/build-targets`)
      const publicBody = (await publicProjects.json()) as { items: Array<Record<string, unknown>> }
      expect(publicBody.items.find((item) => item.id === 'webapp')).not.toHaveProperty(
        'repositoryUrl'
      )
      expect(publicBody.items.find((item) => item.id === 'webapp')).not.toHaveProperty(
        'buildCommand'
      )

      const build = await fetch(`${origin}/api/v1/build-jobs`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'idempotency-key': 'anonymous-build-test',
          'x-cuddly-actor': 'gz',
        },
        body: JSON.stringify({ targetId: 'webapp', branch: 'develop', profile: 'qa-web' }),
      })
      expect(build.status).toBe(202)
      const buildBody = (await build.json()) as BuildJob
      expect(buildBody).toMatchObject({ requestedBy: 'gz' })
      expect(buildBody.targetSnapshot).toMatchObject({
        kind: 'webapp',
        useChinaRegistry: true,
      })
      expect(buildBody.targetSnapshot).not.toHaveProperty('gitAuthorization')

      const systemSettings = await fetch(`${origin}/api/v1/admin/system-settings`, {
        method: 'PATCH',
        headers: {
          'content-type': 'application/json',
          cookie: adminCookie!,
          'x-cuddly-actor': 'gz',
        },
        body: JSON.stringify({
          buildMaxConcurrency: 4,
          useChinaRegistry: false,
          newAdminPassword: 'new-admin-password',
        }),
      })
      expect(systemSettings.status).toBe(200)
      expect(await systemSettings.json()).toMatchObject({
        buildMaxConcurrency: 4,
        useChinaRegistry: false,
      })

      const buildWithoutChinaRegistry = await fetch(`${origin}/api/v1/build-jobs`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'idempotency-key': 'default-registry-build-test',
          'x-cuddly-actor': 'gz',
        },
        body: JSON.stringify({ targetId: 'webapp', branch: 'master', profile: 'qa-web' }),
      })
      expect(buildWithoutChinaRegistry.status).toBe(202)
      expect(((await buildWithoutChinaRegistry.json()) as BuildJob).targetSnapshot).toMatchObject({
        useChinaRegistry: false,
      })

      const newUnlock = await fetch(`${origin}/api/v1/admin/unlock`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ password: 'new-admin-password' }),
      })
      expect(newUnlock.status).toBe(200)

      expect((await fetch(`${origin}/api/v1/session`)).status).toBe(404)
    } finally {
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve()))
      )
    }
  })

  it('serves build history, command snapshots, events, artifacts, and sanitized logs', async () => {
    const store = new MemoryStore()
    const job = await store.createBuildJob({
      id: randomUUID(),
      targetId: 'online-h5',
      branch: 'feature/ci-view',
      profile: 'qa-web',
      requestedBy: 'gz',
      idempotencyKey: null,
      targetSnapshot: {
        id: 'online-h5',
        repositoryUrl: 'https://user:password@git.example.test/html-h5.git',
        installCommand: 'AUTHORIZATION=Bearer-secret pnpm install',
        buildCommand: 'BUILD_TOKEN=hidden pnpm build',
        outputDirectory: 'build',
        siteAdapter: 'kook-online-h5-v1',
        useChinaRegistry: true,
      },
    })
    await store.claimNextBuildJob('worker-1')
    await store.updateBuildJob(job.id, { status: 'BUILDING' })
    const artifactId = randomUUID()
    const builtAt = new Date().toISOString()
    await store.createArtifact({
      id: artifactId,
      buildJobId: job.id,
      targetId: job.targetId,
      branch: job.branch,
      status: 'READY',
      storageKey: `ready/online-h5/${artifactId}`,
      builtAt,
      createdBy: 'gz',
      manifest: {
        schemaVersion: 1,
        artifactId,
        target: job.targetId,
        branch: job.branch,
        builtAt,
        serve: {
          siteAdapter: 'kook-online-h5-v1',
          entrypoints: ['index.html'],
          publicBase: `/__cuddly/artifacts/${artifactId}/`,
        },
        files: [
          {
            path: 'index.html',
            size: 1,
            contentType: 'text/html; charset=utf-8',
            digest: 'sha256:test',
            cacheClass: 'html',
          },
        ],
      },
    })
    await store.updateBuildJob(job.id, {
      status: 'SUCCEEDED',
      finishedAt: new Date().toISOString(),
      logPath: `/srv/cuddly/logs/${job.id}.log`,
    })

    const logDirectory = await mkdtemp(path.join(tmpdir(), 'cuddly-logs-'))
    await writeFile(
      path.join(logDirectory, `${job.id}.log`),
      [
        '$ AUTHORIZATION=Bearer-secret pnpm install',
        'BUILD_TOKEN=hidden pnpm build',
        'https://user:password@git.example.test/repository.git',
      ].join('\n')
    )
    const server = createControlApp({
      store,
      adminSessionSecret: 'test-secret',
      internalApiToken: 'internal-test-token',
      settingsSecret: 'test-secret',
      logDirectory,
    }).listen(0)

    try {
      const { port } = server.address() as AddressInfo
      const origin = `http://127.0.0.1:${port}`
      const history = await fetch(
        `${origin}/api/v1/build-jobs?status=SUCCEEDED&query=feature%2Fci-view`
      ).then((response) => response.json())
      expect(history.items).toHaveLength(1)
      expect(history.items[0].logPath).toBe(`/api/v1/build-jobs/${job.id}/log`)
      expect(history.items[0].targetSnapshot).not.toHaveProperty('gitAuthorization')
      expect(history.items[0].targetSnapshot).toMatchObject({
        repositoryUrl: '<repository>',
        installCommand: 'AUTHORIZATION=<redacted> pnpm install',
        buildCommand: 'BUILD_TOKEN=<redacted> pnpm build',
      })
      expect(JSON.stringify(history)).not.toContain('user:password')
      expect(JSON.stringify(history)).not.toContain('Bearer-secret')

      const detail = await fetch(`${origin}/api/v1/build-jobs/${job.id}/detail`).then((response) =>
        response.json()
      )
      expect(detail.commands.map((step: { command: string }) => step.command)).toEqual(
        expect.arrayContaining([
          expect.stringContaining('feature/ci-view'),
          expect.stringContaining('AUTHORIZATION=<redacted>'),
          expect.stringContaining('BUILD_TOKEN=<redacted>'),
        ])
      )
      expect(
        detail.commands.filter((step: { command: string }) =>
          step.command.includes('registry.npmmirror.com')
        )
      ).toHaveLength(2)
      expect(
        detail.commands.find((step: { stage: string }) => step.stage === 'INSTALLING').command
      ).toContain('pnpm_config_dangerously_allow_all_builds=true')
      expect(detail.events.map((event: { status: string }) => event.status)).toEqual([
        'QUEUED',
        'LEASED',
        'BUILDING',
        'SUCCEEDED',
      ])
      expect(detail.artifact).toMatchObject({ id: artifactId, fileCount: 1 })

      const log = await fetch(`${origin}/api/v1/build-jobs/${job.id}/log`).then((response) =>
        response.json()
      )
      expect(log.complete).toBe(true)
      expect(log.content).toContain('AUTHORIZATION=<redacted>')
      expect(log.content).toContain('BUILD_TOKEN=<redacted>')
      expect(log.content).toContain('https://<redacted>@git.example.test')
      expect(log.content).not.toContain('Bearer-secret')
      expect(log.content).not.toContain('password')
    } finally {
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve()))
      )
      await rm(logDirectory, { recursive: true, force: true })
    }
  })

  it('requires Remote previews to be bound to a site', async () => {
    const store = new MemoryStore()
    await store.saveBuildTarget(
      {
        id: 'base',
        name: 'Base',
        kind: 'remote',
        repositoryUrl: 'https://git.example.test/kook.git',
        defaultBranch: 'master',
        installCommand: 'pnpm install',
        buildCommand: 'pnpm --filter base build',
        outputDirectory: 'apps/base/dist',
        siteAdapter: 'kook-remote-v1',
        enabled: true,
        required: false,
        configurationSource: 'database',
      },
      'gz'
    )
    const artifactId = randomUUID()
    const builtAt = new Date().toISOString()
    const artifact: Artifact = {
      id: artifactId,
      buildJobId: randomUUID(),
      targetId: 'base',
      branch: 'feature/preview',
      status: 'READY',
      storageKey: `ready/base/${artifactId}`,
      builtAt,
      createdBy: 'gz',
      manifest: {
        schemaVersion: 1,
        artifactId,
        target: 'base',
        branch: 'feature/preview',
        builtAt,
        serve: {
          siteAdapter: 'kook-remote-v1',
          entrypoints: ['remoteEntry.js'],
          publicBase: `https://preview.example.test/__cuddly/preview-artifacts/${artifactId}/cuddly_base_test/`,
          remote: {
            moduleKey: 'base',
            providerName: 'cuddly_base_test',
            entryPath: 'remoteEntry.js',
          },
        },
        files: [
          {
            path: 'remoteEntry.js',
            size: 1,
            contentType: 'text/javascript; charset=utf-8',
            digest: 'sha256:test',
            cacheClass: 'asset',
          },
        ],
      },
    }
    await store.createArtifact(artifact)

    const server = createControlApp({
      store,
      adminSessionSecret: 'test-secret',
      internalApiToken: 'internal-test-token',
      settingsSecret: 'test-secret',
    }).listen(0)

    try {
      const { port } = server.address() as AddressInfo
      const origin = `http://127.0.0.1:${port}`
      const response = await fetch(`${origin}/api/v1/previews`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-cuddly-actor': 'gz' },
        body: JSON.stringify({ selections: [{ targetId: 'base', artifactId }] }),
      })
      expect(response.status).toBe(400)
      expect(await response.json()).toMatchObject({ code: 'INVALID_REQUEST' })

      const invalid = await fetch(`${origin}/api/v1/previews`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ selections: [{ targetId: 'online-h5', artifactId }] }),
      })
      expect(invalid.status).toBe(400)
      expect(await invalid.json()).toMatchObject({ code: 'INVALID_REQUEST' })
    } finally {
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve()))
      )
    }
  })

  it('manages site bindings, resolves official sites, and creates site-aware previews', async () => {
    const store = new MemoryStore()
    await store.saveBuildTarget(
      {
        id: 'webapp',
        name: '网页端',
        kind: 'webapp',
        repositoryUrl: 'https://git.example.test/webapp.git',
        defaultBranch: 'master',
        installCommand: 'pnpm install',
        buildCommand: 'pnpm build',
        outputDirectory: 'build',
        siteAdapter: 'generic-static-v1',
        enabled: true,
        required: false,
        configurationSource: 'database',
      },
      'gz'
    )
    await store.saveBuildTarget(
      {
        id: 'legacy-site',
        name: '旧站点项目',
        kind: 'webapp',
        repositoryUrl: 'https://git.example.test/legacy-site.git',
        defaultBranch: 'master',
        installCommand: 'pnpm install',
        buildCommand: 'pnpm build',
        outputDirectory: 'dist',
        siteAdapter: 'legacy-static-v0',
        enabled: true,
        required: false,
        configurationSource: 'database',
      },
      'gz'
    )
    await store.saveBuildTarget(
      {
        id: 'base',
        name: 'Base',
        kind: 'remote',
        repositoryUrl: 'https://git.example.test/kook.git',
        defaultBranch: 'master',
        installCommand: 'pnpm install',
        buildCommand: 'pnpm --filter base build',
        outputDirectory: 'apps/base/dist',
        siteAdapter: 'kook-remote-v1',
        enabled: true,
        required: false,
        configurationSource: 'database',
      },
      'gz'
    )

    await store.saveBuildTarget(
      {
        id: 'legacy-remote',
        name: '旧 Remote',
        kind: 'remote',
        repositoryUrl: 'https://git.example.test/legacy-remote.git',
        defaultBranch: 'master',
        installCommand: 'pnpm install',
        buildCommand: 'pnpm build',
        outputDirectory: 'dist',
        siteAdapter: 'legacy-remote-v0',
        enabled: true,
        required: false,
        configurationSource: 'database',
      },
      'gz'
    )

    const siteArtifactId = randomUUID()
    const mismatchedSiteArtifactId = randomUUID()
    const remoteArtifactId = randomUUID()
    const builtAt = new Date().toISOString()
    await store.createArtifact({
      id: siteArtifactId,
      buildJobId: randomUUID(),
      targetId: 'webapp',
      branch: 'feature/site-preview',
      status: 'READY',
      storageKey: `ready/webapp/${siteArtifactId}`,
      builtAt,
      createdBy: 'gz',
      manifest: {
        schemaVersion: 1,
        artifactId: siteArtifactId,
        target: 'webapp',
        branch: 'feature/site-preview',
        builtAt,
        serve: {
          siteAdapter: 'generic-static-v1',
          entrypoints: ['index.html'],
          publicBase: `/__cuddly/artifacts/${siteArtifactId}/`,
        },
        files: [
          {
            path: 'index.html',
            size: 1,
            contentType: 'text/html; charset=utf-8',
            digest: 'sha256:site',
            cacheClass: 'html',
          },
        ],
      },
    })
    await store.createArtifact({
      id: mismatchedSiteArtifactId,
      buildJobId: randomUUID(),
      targetId: 'webapp',
      branch: 'feature/wrong-adapter',
      status: 'READY',
      storageKey: `ready/webapp/${mismatchedSiteArtifactId}`,
      builtAt,
      createdBy: 'gz',
      manifest: {
        schemaVersion: 1,
        artifactId: mismatchedSiteArtifactId,
        target: 'webapp',
        branch: 'feature/wrong-adapter',
        builtAt,
        serve: {
          siteAdapter: 'kook-online-h5-v1',
          entrypoints: ['index.html'],
          publicBase: `/__cuddly/artifacts/${mismatchedSiteArtifactId}/`,
        },
        files: [
          {
            path: 'index.html',
            size: 1,
            contentType: 'text/html; charset=utf-8',
            digest: 'sha256:wrong-adapter',
            cacheClass: 'html',
          },
        ],
      },
    })
    await store.createArtifact({
      id: remoteArtifactId,
      buildJobId: randomUUID(),
      targetId: 'base',
      branch: 'feature/remote-preview',
      status: 'READY',
      storageKey: `ready/base/${remoteArtifactId}`,
      builtAt,
      createdBy: 'gz',
      manifest: {
        schemaVersion: 1,
        artifactId: remoteArtifactId,
        target: 'base',
        branch: 'feature/remote-preview',
        builtAt,
        serve: {
          siteAdapter: 'kook-remote-v1',
          entrypoints: ['remoteEntry.js'],
          publicBase: `/__cuddly/artifacts/${remoteArtifactId}/`,
          remote: {
            moduleKey: 'base',
            providerName: 'cuddly_base_site_preview',
            entryPath: 'remoteEntry.js',
          },
        },
        files: [
          {
            path: 'remoteEntry.js',
            size: 1,
            contentType: 'text/javascript; charset=utf-8',
            digest: 'sha256:remote',
            cacheClass: 'asset',
          },
        ],
      },
    })

    const server = createControlApp({
      store,
      adminSessionSecret: 'test-secret',
      internalApiToken: 'internal-test-token',
      developmentAdminPassword: 'admin-password',
      settingsSecret: 'test-secret',
      previewBaseDomain: 'Preview.Example.Test.',
    }).listen(0)

    try {
      const { port } = server.address() as AddressInfo
      const origin = `http://127.0.0.1:${port}`
      const runtime = await fetch(`${origin}/api/v1/runtime`)
      expect(runtime.status).toBe(200)
      expect(await runtime.json()).toMatchObject({
        previewBaseDomain: 'preview.example.test',
      })
      const unlock = await fetch(`${origin}/api/v1/admin/unlock`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ password: 'admin-password' }),
      })
      const adminCookie = unlock.headers.get('set-cookie')!

      const saved = await fetch(`${origin}/api/v1/admin/site-bindings/main`, {
        method: 'PUT',
        headers: {
          'content-type': 'application/json',
          cookie: adminCookie,
          'x-cuddly-actor': 'gz',
        },
        body: JSON.stringify({
          name: 'KOOK 网页端',
          hostname: 'Main.Preview.Example.Test.',
          targetId: 'webapp',
          environmentSlug: 'shared',
          upstreamOrigin: 'https://www.kookapp.cn/',
          officialOrigin: 'https://www.kookapp.cn/',
          enabled: true,
          remoteTargetIds: ['base'],
          resourceProxyPrefixes: [
            ' HTTPS://STATIC.KOOKAPP.CN:443/assets/../static/ ',
            'https://img.kookapp.cn/assets/',
          ],
        }),
      })
      expect(saved.status).toBe(200)
      expect(await saved.json()).toMatchObject({
        id: 'main',
        hostname: 'main.preview.example.test',
        officialOrigin: 'https://www.kookapp.cn',
        resourceProxyPrefixes: [
          'https://static.kookapp.cn/static/',
          'https://img.kookapp.cn/assets/',
        ],
      })

      const invalidResourceProxy = await fetch(
        `${origin}/api/v1/admin/site-bindings/invalid-resource-proxy`,
        {
          method: 'PUT',
          headers: { 'content-type': 'application/json', cookie: adminCookie },
          body: JSON.stringify({
            name: '非法资源代理',
            hostname: 'invalid-resource-proxy.preview.example.test',
            targetId: 'webapp',
            environmentSlug: 'shared',
            upstreamOrigin: 'https://invalid-resource-proxy.kookapp.cn',
            officialOrigin: 'https://invalid-resource-proxy.kookapp.cn',
            enabled: false,
            remoteTargetIds: [],
            resourceProxyPrefixes: ['https://static.kookapp.cn/static'],
          }),
        }
      )
      expect(invalidResourceProxy.status).toBe(400)
      expect(await invalidResourceProxy.json()).toMatchObject({ code: 'INVALID_SITE_BINDING' })

      const outsidePreviewDomain = await fetch(
        `${origin}/api/v1/admin/site-bindings/outside-domain`,
        {
          method: 'PUT',
          headers: { 'content-type': 'application/json', cookie: adminCookie },
          body: JSON.stringify({
            name: '越界站点',
            hostname: 'outside.bifrost.vanillacake.cn',
            targetId: 'webapp',
            environmentSlug: 'shared',
            upstreamOrigin: 'https://outside.kookapp.cn',
            officialOrigin: 'https://outside.kookapp.cn',
            enabled: false,
            remoteTargetIds: [],
            resourceProxyPrefixes: [],
          }),
        }
      )
      expect(outsidePreviewDomain.status).toBe(400)
      expect(await outsidePreviewDomain.json()).toEqual({
        code: 'SITE_BINDING_HOSTNAME_OUTSIDE_PREVIEW_DOMAIN',
        message:
          '预览域名必须是 preview.example.test 的直接一级子域名，例如 main.preview.example.test',
      })

      const nestedPreviewDomain = await fetch(
        `${origin}/api/v1/admin/site-bindings/nested-domain`,
        {
          method: 'PUT',
          headers: { 'content-type': 'application/json', cookie: adminCookie },
          body: JSON.stringify({
            name: '多级站点',
            hostname: 'nested.main.preview.example.test',
            targetId: 'webapp',
            environmentSlug: 'shared',
            upstreamOrigin: 'https://nested.kookapp.cn',
            officialOrigin: 'https://nested.kookapp.cn',
            enabled: false,
            remoteTargetIds: [],
            resourceProxyPrefixes: [],
          }),
        }
      )
      expect(nestedPreviewDomain.status).toBe(400)
      expect(await nestedPreviewDomain.json()).toMatchObject({
        code: 'SITE_BINDING_HOSTNAME_OUTSIDE_PREVIEW_DOMAIN',
      })

      const invalidId = await fetch(`${origin}/api/v1/admin/site-bindings/main_preview`, {
        method: 'PUT',
        headers: { 'content-type': 'application/json', cookie: adminCookie },
        body: JSON.stringify({
          name: '非法标识站点',
          hostname: 'invalid.bifrost.vanillacake.cn',
          targetId: 'webapp',
          environmentSlug: 'shared',
          upstreamOrigin: 'https://www.kookapp.cn',
          officialOrigin: 'https://invalid.kookapp.cn',
          enabled: false,
          remoteTargetIds: [],
          resourceProxyPrefixes: [],
        }),
      })
      expect(invalidId.status).toBe(400)
      expect(await invalidId.json()).toMatchObject({ code: 'INVALID_SITE_BINDING' })

      const disabledProject = await fetch(`${origin}/api/v1/admin/site-bindings/disabled-site`, {
        method: 'PUT',
        headers: { 'content-type': 'application/json', cookie: adminCookie },
        body: JSON.stringify({
          name: '停用站点',
          hostname: 'disabled.preview.example.test',
          targetId: 'biz',
          environmentSlug: 'shared',
          upstreamOrigin: 'https://biz.kookapp.cn',
          officialOrigin: 'https://biz.kookapp.cn',
          enabled: false,
          remoteTargetIds: [],
          resourceProxyPrefixes: [],
        }),
      })
      expect(disabledProject.status).toBe(400)
      expect(await disabledProject.json()).toMatchObject({
        code: 'SITE_BINDING_TARGET_INVALID',
      })

      const unsupportedAdapter = await fetch(`${origin}/api/v1/admin/site-bindings/legacy-site`, {
        method: 'PUT',
        headers: { 'content-type': 'application/json', cookie: adminCookie },
        body: JSON.stringify({
          name: '旧适配器站点',
          hostname: 'legacy.preview.example.test',
          targetId: 'legacy-site',
          environmentSlug: 'shared',
          upstreamOrigin: 'https://legacy.kookapp.cn',
          officialOrigin: 'https://legacy.kookapp.cn',
          enabled: false,
          remoteTargetIds: [],
          resourceProxyPrefixes: [],
        }),
      })
      expect(unsupportedAdapter.status).toBe(400)
      expect(await unsupportedAdapter.json()).toMatchObject({
        code: 'SITE_BINDING_TARGET_INVALID',
      })

      const unsupportedRemoteAdapter = await fetch(
        `${origin}/api/v1/admin/site-bindings/legacy-remote`,
        {
          method: 'PUT',
          headers: { 'content-type': 'application/json', cookie: adminCookie },
          body: JSON.stringify({
            name: '旧 Remote 站点',
            hostname: 'legacy-remote.preview.example.test',
            targetId: 'webapp',
            environmentSlug: 'shared',
            upstreamOrigin: 'https://legacy-remote.kookapp.cn',
            officialOrigin: 'https://legacy-remote.kookapp.cn',
            enabled: false,
            remoteTargetIds: ['legacy-remote'],
            resourceProxyPrefixes: [],
          }),
        }
      )
      expect(unsupportedRemoteAdapter.status).toBe(400)
      expect(await unsupportedRemoteAdapter.json()).toMatchObject({
        code: 'SITE_BINDING_REMOTE_TARGET_INVALID',
      })

      const byHostname = await fetch(
        `${origin}/api/v1/site-bindings/resolve?hostname=MAIN.PREVIEW.EXAMPLE.TEST%3A443`
      )
      expect(byHostname.status).toBe(200)
      expect(await byHostname.json()).toMatchObject({
        id: 'main',
        remoteTargetIds: ['base'],
        resourceProxyPrefixes: [
          'https://static.kookapp.cn/static/',
          'https://img.kookapp.cn/assets/',
        ],
      })

      const byOfficialOrigin = await fetch(
        `${origin}/api/v1/site-bindings/resolve?officialOrigin=${encodeURIComponent('https://www.kookapp.cn/')}`
      )
      expect(byOfficialOrigin.status).toBe(200)
      expect(await byOfficialOrigin.json()).toMatchObject({ id: 'main' })

      const sslSettings = await fetch(`${origin}/api/v1/admin/system-settings`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json', cookie: adminCookie },
        body: JSON.stringify({ autoSslEnabled: true }),
      })
      expect(sslSettings.status).toBe(200)
      expect(await sslSettings.json()).toMatchObject({
        autoSslEnabled: true,
        autoSslEmail: '',
      })

      const sslConfig = await fetch(`${origin}/api/v1/internal/auto-ssl-config`, {
        headers: { authorization: 'Bearer internal-test-token' },
      })
      expect(sslConfig.status).toBe(200)
      expect(await sslConfig.json()).toEqual({
        autoSslEnabled: true,
        autoSslEmail: '',
        hostnames: ['main.preview.example.test'],
      })

      const previewResponse = await fetch(`${origin}/api/v1/previews`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-cuddly-actor': 'gz' },
        body: JSON.stringify({
          siteBindingId: 'main',
          siteArtifactId,
          selections: [{ targetId: 'base', artifactId: remoteArtifactId }],
        }),
      })
      expect(previewResponse.status).toBe(201)
      const preview = (await previewResponse.json()) as PreviewSessionView
      expect(preview).not.toHaveProperty('hotModuleUrl')
      expect(preview).toMatchObject({
        siteBindingId: 'main',
        siteArtifactId,
        siteSelection: {
          targetId: 'webapp',
          artifactId: siteArtifactId,
          branch: 'feature/site-preview',
          builtAt,
        },
        selections: [expect.objectContaining({ targetId: 'base', artifactId: remoteArtifactId })],
      })
      expect(await store.isArtifactReferencedByActivePreview(siteArtifactId)).toBe(true)

      const mismatchedAdapter = await fetch(`${origin}/api/v1/previews`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          siteBindingId: 'main',
          siteArtifactId: mismatchedSiteArtifactId,
        }),
      })
      expect(mismatchedAdapter.status).toBe(400)
      expect(await mismatchedAdapter.json()).toMatchObject({
        code: 'PREVIEW_SITE_ARTIFACT_INVALID',
      })

      const storedPreviewResponse = await fetch(`${origin}/api/v1/previews/${preview.token}`)
      expect(storedPreviewResponse.status).toBe(200)
      expect(await storedPreviewResponse.json()).toMatchObject({
        token: preview.token,
        siteSelection: {
          targetId: 'webapp',
          artifactId: siteArtifactId,
          branch: 'feature/site-preview',
          builtAt,
        },
      })

      const disallowed = await fetch(`${origin}/api/v1/previews`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          siteBindingId: 'main',
          selections: [{ targetId: 'discover', artifactId: randomUUID() }],
        }),
      })
      expect(disallowed.status).toBe(400)
      expect(await disallowed.json()).toMatchObject({ code: 'PREVIEW_REMOTE_NOT_ALLOWED' })
    } finally {
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve()))
      )
    }
  })
})
