import { readFile } from 'node:fs/promises'

import { describe, expect, it } from 'vitest'

describe('console Nginx internal API isolation', () => {
  it('blocks the complete internal prefix without case sensitivity', async () => {
    const config = await readFile(new URL('./console.nginx.conf', import.meta.url), 'utf8')

    expect(config).toContain('location ~* ^/api/v1/internal(?:/|$) {')
    expect(config).not.toContain('location ^~ /api/v1/internal/')
  })
})
