export const SITE_BINDING_REQUIRED = '当前页面尚未配置站点绑定，请先在管理后台配置站点'

export function previewDestinationUrl(origin, currentUrl) {
  const destination = new URL(origin)
  try {
    const current = new URL(currentUrl)
    destination.pathname = current.pathname
    destination.search = current.search
    destination.hash = current.hash
  } catch {
    // Keep the origin root when the current tab URL cannot be parsed.
  }
  return destination.href
}

export function createPreviewRequest({ binding, siteArtifactId, selections, ttlMinutes = 480 }) {
  if (!binding) throw new Error(SITE_BINDING_REQUIRED)
  return {
    ttlMinutes,
    siteBindingId: binding.id,
    ...(siteArtifactId ? { siteArtifactId } : {}),
    selections: selections || [],
  }
}

export function mergeSelectedBranches({ sameBinding, previous, defaults }) {
  return Object.fromEntries(
    Object.entries(defaults).map(([targetId, branch]) => [
      targetId,
      sameBinding && Object.hasOwn(previous, targetId) ? previous[targetId] : branch,
    ])
  )
}

export function planPreviewApplication({ binding, previewOrigin, siteArtifactId, selections }) {
  const hasSelection = Boolean(siteArtifactId || selections?.length)
  if (!binding) {
    return {
      canApply: false,
      mode: null,
      requestedOrigin: null,
      reason: SITE_BINDING_REQUIRED,
    }
  }
  if (!hasSelection) {
    return {
      canApply: false,
      mode: 'site',
      requestedOrigin: null,
      reason: '请至少选择一个页面或热更产物',
    }
  }
  return {
    canApply: true,
    mode: 'site',
    requestedOrigin: new URL(previewOrigin).origin,
    reason: null,
  }
}
