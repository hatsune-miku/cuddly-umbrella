import assert from 'node:assert/strict'
import test from 'node:test'

import {
  createPreviewRequest,
  mergeSelectedBranches,
  planPreviewApplication,
  previewDestinationUrl,
  SITE_BINDING_REQUIRED,
} from '../preview-routing.js'

const binding = {
  id: 'main',
  hostname: 'main.bifrost.vanillacake.cn',
  officialOrigin: 'https://www.kookapp.cn',
}

test('routes a Remote-only selection through its site-bound preview origin', () => {
  const plan = planPreviewApplication({
    binding,
    previewOrigin: 'https://main.bifrost.vanillacake.cn/channels/1',
    siteArtifactId: null,
    selections: [{ targetId: 'base', artifactId: 'artifact-base' }],
  })

  assert.deepEqual(plan, {
    canApply: true,
    mode: 'site',
    requestedOrigin: 'https://main.bifrost.vanillacake.cn',
    reason: null,
  })
})

test('does not offer a Remote-only fallback without a site binding', () => {
  const plan = planPreviewApplication({
    binding: null,
    previewOrigin: null,
    siteArtifactId: null,
    selections: [{ targetId: 'base', artifactId: 'artifact-base' }],
  })

  assert.equal(plan.canApply, false)
  assert.equal(plan.mode, null)
  assert.equal(plan.requestedOrigin, null)
  assert.equal(plan.reason, SITE_BINDING_REQUIRED)
})

test('keeps an empty site selection disabled', () => {
  const plan = planPreviewApplication({
    binding,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    siteArtifactId: null,
    selections: [],
  })

  assert.equal(plan.canApply, false)
  assert.equal(plan.mode, 'site')
})

test('builds a site-bound Preview request and preserves the current tab route', () => {
  assert.deepEqual(
    createPreviewRequest({
      binding,
      siteArtifactId: null,
      selections: [{ targetId: 'base', artifactId: 'artifact-base' }],
    }),
    {
      ttlMinutes: 480,
      siteBindingId: 'main',
      selections: [{ targetId: 'base', artifactId: 'artifact-base' }],
    }
  )
  assert.equal(
    previewDestinationUrl(
      'https://main.bifrost.vanillacake.cn',
      'https://www.kookapp.cn/channels/42?view=compact#messages'
    ),
    'https://main.bifrost.vanillacake.cn/channels/42?view=compact#messages'
  )
})

test('keeps draft branch choices while refreshing the same site', () => {
  assert.deepEqual(
    mergeSelectedBranches({
      sameBinding: true,
      previous: { webapp: '', base: 'feature/qa' },
      defaults: { webapp: 'master', base: '' },
    }),
    { webapp: '', base: 'feature/qa' }
  )
  assert.deepEqual(
    mergeSelectedBranches({
      sameBinding: false,
      previous: { base: 'feature/qa' },
      defaults: { webapp: 'master', base: '' },
    }),
    { webapp: 'master', base: '' }
  )
})
