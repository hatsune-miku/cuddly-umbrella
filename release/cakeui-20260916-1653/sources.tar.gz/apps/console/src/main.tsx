import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { PRODUCT_DISPLAY_NAME } from '@cuddly/product'
import { CakeProvider } from '@a1knla/cakeui'
import '@a1knla/cakeui/style.css'
import '../../../packages/ui-theme/theme.css'
import './cake-layout.css'

import { App } from './App'
import { AuthGate } from './AuthGate'
import { ShareLanding, shareTokenFromPathname } from './ShareLanding'
import './styles.css'

const shareToken = shareTokenFromPathname(window.location.pathname)
document.title = PRODUCT_DISPLAY_NAME

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <CakeProvider theme="blue" mode="light" density="compact" className="bifrost-theme">
      <AuthGate>
        {(session, onLogout) =>
          shareToken ? (
            <ShareLanding token={shareToken} />
          ) : (
            <App identity={session.identity} onLogout={onLogout} />
          )
        }
      </AuthGate>
    </CakeProvider>
  </StrictMode>
)
