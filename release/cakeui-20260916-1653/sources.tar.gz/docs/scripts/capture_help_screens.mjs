// Render current application components with synthetic documentation data.
// No production API is contacted and no build, preview or share is created.
import http from 'node:http'
import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const { chromium } = require(
  process.env.PLAYWRIGHT_MODULE ||
    'C:/Users/guanz/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'
)
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..')
const output = path.join(root, 'apps/console/public/help/images')
const reviewOutput = path.join(root, 'output/cake-ui-review')
const capture = async (page, file) => {
  await page.evaluate(
    () => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)))
  )
  await page.screenshot({ path: file, animations: 'disabled' })
}
const manifest = JSON.parse(
  await fs.readFile(path.join(root, 'apps/browser-extension/manifest.json'), 'utf8')
)
const now = Date.now()
const uiErrors = []
const date = (minutes) => new Date(now - minutes * 60000).toISOString()
const environments = [
  {
    id: 'demo-test',
    slug: 'tttt',
    name: 'tttt',
    backendOrigin: 'https://tttt-www.dev.chuanyuapp.com',
    useInternalProxy: true,
  },
  {
    id: 'demo-online',
    slug: 'shared',
    name: '线上环境',
    backendOrigin: 'https://www.kookapp.cn',
    useInternalProxy: false,
  },
  {
    id: 'demo-qa',
    slug: 'qa',
    name: 'QA',
    backendOrigin: 'https://qa-www.dev.chuanyuapp.com',
    useInternalProxy: true,
  },
].map((e) => ({ ...e, status: 'ACTIVE', resourceProxyPrefixes: [], currentRevisionId: null }))
const environment = environments[0]
const targetNames = {
  webapp: '网页端',
  'online-h5': '在线 H5',
  base: 'base',
  discover: 'discover',
  guild: 'guild',
  voice_runtime: 'voice_runtime',
}
const targets = Object.entries(targetNames).map(([id, name]) => ({
  id,
  name,
  kind: id === 'webapp' ? 'webapp' : id === 'online-h5' ? 'online-h5' : 'remote',
  defaultBranch: 'master',
  enabled: true,
  required: false,
  configured: true,
}))
const binding = {
  id: 'main',
  name: '网页端',
  hostname: 'main.bifrost.vanillacake.cn',
  targetId: 'webapp',
  environmentSlug: 'tttt',
  fallbackOrigin: 'https://www.kookapp.cn',
  officialOrigin: 'https://tttt-www.dev.chuanyuapp.com',
  upstreamOrigin: environment.backendOrigin,
  enabled: true,
  remoteTargetIds: ['base', 'discover', 'guild', 'voice_runtime'],
  resourceProxyPrefixes: [],
}
const job = (id, targetId, branch, status, minutes, extra = {}) => ({
  id,
  environmentId: environment.id,
  environmentSlug: environment.slug,
  targetId,
  branch,
  profile: 'qa-web',
  status,
  requestedBy: '演示用户',
  createdAt: date(minutes + 1),
  startedAt: status === 'QUEUED' ? null : date(minutes),
  finishedAt: status === 'FAILED' || status === 'SUCCEEDED' ? date(8) : null,
  failureCode: null,
  failureMessage: null,
  targetSnapshot: null,
  logPath: null,
  ...extra,
})
const running = job('demo-build-001', 'discover', 'feature/discover-filter', 'BUILDING', 3, {
  queuePosition: null,
  isMine: true,
})
const queued = job('demo-build-002', 'guild', 'release/qa', 'QUEUED', 1, {
  queuePosition: 1,
  isMine: false,
  requestedBy: '另一位同事',
})
const failed = job('demo-build-003', 'online-h5', 'feature/party-page', 'FAILED', 13, {
  failureCode: 'BUILD_FAILED',
  failureMessage: '依赖模块尚未构建，请检查 workspace packages 的构建顺序。',
})
const history = [running, queued, failed, job('demo-build-004', 'base', 'master', 'SUCCEEDED', 20)]
const queue = { running: [running], queued: [queued], generatedAt: date(0) }
const artifact = (targetId, branch, minutes = 25) => ({
  id: `demo-${targetId}-${branch.replaceAll('/', '-')}`,
  branch,
  targetId,
  environmentId: environment.id,
  environmentSlug: environment.slug,
  builtAt: date(minutes),
  status: 'READY',
})
const branchItems = (id) => [
  {
    branch: 'feature/discover-filter',
    buildStatus: 'IDLE',
    latestArtifact: artifact(id, 'feature/discover-filter', 18),
    latestJob: id === 'discover' ? running : null,
  },
  {
    branch: 'release/qa',
    buildStatus: 'IDLE',
    latestArtifact: artifact(id, 'release/qa', 90),
    latestJob: id === 'guild' ? queued : null,
  },
  {
    branch: 'master',
    buildStatus: 'IDLE',
    latestArtifact: artifact(id, 'master', 120),
    latestJob: null,
  },
  {
    branch: 'feature/layout-draft',
    buildStatus: 'FAILED',
    latestArtifact: null,
    latestJob: { ...failed, targetId: id, branch: 'feature/layout-draft' },
  },
]
const groupToken = '00000000000000000000000000000001'
const group = {
  id: groupToken,
  token: groupToken,
  previewSlug: groupToken,
  previewHostnamePrefix: 'discover-review',
  name: '发现页筛选优化',
  environmentId: environment.id,
  environmentSlug: environment.slug,
  siteBindingId: binding.id,
  schemaVersion: 1,
  items: binding.remoteTargetIds
    .map((id) =>
      id === 'discover'
        ? { targetId: id, mode: 'branch', branch: 'feature/discover-filter' }
        : { targetId: id, mode: 'official' }
    )
    .concat({ targetId: 'webapp', mode: 'official' }),
  createdBy: '演示用户',
  updatedBy: '演示用户',
  createdAt: date(40),
  updatedAt: date(20),
  revision: 1,
  sharePath: `/s/${groupToken}`,
  directPreviewUrl: 'https://discover-review.bifrost.vanillacake.cn/',
}
const matrix = {
  environment,
  revision: null,
  rows: targets.map((target) => ({
    target,
    config: { enabled: true, required: false, targetId: target.id, environmentId: environment.id },
    current: null,
    latestArtifact: artifact(target.id, 'master'),
    activeJob: target.id === 'discover' ? running : target.id === 'guild' ? queued : null,
  })),
}

function api(url) {
  const p = url.pathname
  if (p.endsWith('/proxy-settings'))
    return {
      enabled: false,
      subscriptionConfigured: false,
      subscriptionUrlMasked: null,
      refreshIntervalMinutes: 60,
      sources: {
        enabled: 'default',
        subscriptionUrl: 'default',
        refreshIntervalMinutes: 'default',
      },
      status: {
        mihomoReachable: true,
        lastAppliedAt: null,
        lastCheckedAt: date(0),
        lastError: null,
      },
    }
  if (p.endsWith('/system-settings'))
    return {
      mobileUpstream: 'https://m.kookapp.cn',
      publicMobileOrigin: 'https://m.bifrost.vanillacake.cn',
      webappUpstream: 'https://www.kookapp.cn',
      publicPreviewOrigin: 'https://bifrost.vanillacake.cn',
      mobileHostnames: ['m.bifrost.vanillacake.cn'],
      cookieDomain: '',
      buildMaxConcurrency: 3,
      runnerRequestTimeoutMinutes: 30,
      useChinaRegistry: true,
      proxyRewriteMaxMegabytes: 2,
      autoSslEnabled: false,
      autoSslEmail: '',
      inPlaceUrlRules: [],
    }
  if (p.endsWith('/projects'))
    return {
      environment,
      items: targets.map((target) => ({
        targetId: target.id,
        environmentId: environment.id,
        enabled: true,
        required: false,
        installCommand: 'corepack pnpm install --frozen-lockfile',
        buildCommand: 'corepack pnpm build:test',
        outputDirectory: 'dist',
      })),
    }
  if (p.endsWith('/auth/session'))
    return {
      authenticated: true,
      identity: { name: '演示用户', avatarUrl: '' },
      csrfToken: 'documentation-fixture-only',
    }
  if (p.endsWith('/environments')) return { items: environments }
  if (p.endsWith('/runtime'))
    return { previewBaseDomain: 'bifrost.vanillacake.cn', inPlaceUrlRules: [] }
  if (p.endsWith('/matrix')) return matrix
  if (p.endsWith('/build-queue')) return queue
  if (p.endsWith('/build-targets')) return { items: targets, environment }
  if (p.endsWith('/branches'))
    return { items: branchItems(p.split('/').at(-2)), remoteAvailable: true }
  if (
    p.endsWith('/site-bindings/resolve') ||
    p.endsWith('/site-bindings/candidates') ||
    p.endsWith('/admin/site-bindings')
  )
    return { items: [binding] }
  if (p.endsWith('/config-groups/resolve-preview')) return null
  if (p.endsWith('/config-groups')) return { items: [group] }
  if (p.endsWith('/build-jobs'))
    return { items: history, total: history.length, page: 1, pageSize: 20, totalPages: 1 }
  if (p.endsWith('/detail')) {
    const selected = history.find((j) => j.id === p.split('/').at(-2)) || running
    return {
      job: selected,
      artifact: null,
      commands: [
        {
          stage: 'CHECKOUT',
          label: '准备源码',
          command: 'git fetch origin feature/discover-filter',
        },
        {
          stage: 'INSTALLING',
          label: '安装依赖',
          command: "corepack pnpm --filter '{./apps/discover}...' install --frozen-lockfile",
        },
        {
          stage: 'BUILDING',
          label: '打包',
          command:
            "corepack pnpm --filter '{./apps/discover}^...' --if-present build\ncorepack pnpm --filter './apps/discover' build:test",
        },
      ],
      events: ['QUEUED', 'LEASED', 'CHECKOUT', 'INSTALLING', 'BUILDING'].map((status, index) => ({
        id: `event-${index}`,
        jobId: selected.id,
        status,
        createdAt: date(4 - index * 0.5),
      })),
    }
  }
  if (p.endsWith('/log'))
    return {
      content:
        '[INSTALLING] Workspace dependencies ready\n[BUILDING] packages/utils build completed\n[BUILDING] packages/logic-models build completed\n[BUILDING] apps/discover\nRsbuild is compiling client bundles...\n',
      size: 200,
      complete: false,
      truncated: false,
      updatedAt: date(0),
    }
  throw new Error(`Unmocked documentation API: ${p}`)
}

const mime = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
}
const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://127.0.0.1')
  try {
    if (u.pathname.startsWith('/api/')) {
      if (req.method !== 'GET') throw new Error('Documentation fixtures do not perform writes')
      const body = api(u)
      res.writeHead(body === null ? 404 : 200, { 'content-type': 'application/json' })
      return res.end(JSON.stringify(body || {}))
    }
    const prefix = u.pathname.startsWith('/_extension/')
      ? 'apps/browser-extension'
      : 'apps/console/dist'
    const relative = u.pathname.startsWith('/_extension/')
      ? u.pathname.slice(12)
      : u.pathname.slice(1)
    const base = path.join(root, prefix)
    const target = path.resolve(base, relative || 'index.html')
    if (!target.startsWith(base + path.sep)) throw new Error('Invalid asset path')
    const bytes = await fs.readFile(target)
    res.writeHead(200, { 'content-type': mime[path.extname(target)] || 'application/octet-stream' })
    res.end(bytes)
  } catch (error) {
    res.writeHead(404, { 'content-type': 'text/plain' })
    res.end(error.message)
  }
})
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
const origin = `http://127.0.0.1:${server.address().port}`
await fs.mkdir(output, { recursive: true })
await fs.mkdir(reviewOutput, { recursive: true })
const browser = await chromium.launch({
  headless: true,
  executablePath:
    process.env.CHROMIUM_EXECUTABLE ||
    'C:/Users/guanz/AppData/Local/ms-playwright/chromium-1217/chrome-win64/chrome.exe',
})
try {
  const context = await browser.newContext({
    viewport: { width: 1180, height: 800 },
    deviceScaleFactor: 2,
    locale: 'zh-CN',
    timezoneId: 'Asia/Shanghai',
  })
  await context.route('**/*', (route) =>
    new URL(route.request().url()).origin === origin ? route.continue() : route.abort()
  )
  const page = await context.newPage()
  page.on('pageerror', (error) => uiErrors.push(`Console: ${error.message}`))
  await page.goto(origin)
  await page
    .getByRole('button', { name: '按分支', exact: true })
    .or(page.getByRole('tab', { name: '按分支', exact: true }))
    .click()
  await page.getByText('tttt 已刷新', { exact: true }).waitFor()
  await capture(page, path.join(output, 'console-projects.png'))
  await page.locator('.branch-picker-trigger').first().click()
  await page.locator('dialog.branch-picker-dialog[open]').first().waitFor()
  await page.locator('dialog[open]').getByPlaceholder('搜索分支名称').fill('layout')
  assert.equal(await page.locator('dialog[open] [role="option"]').count(), 2)
  await capture(page, path.join(reviewOutput, 'console-branch-picker.png'))
  await page.keyboard.press('Escape')
  assert.equal(await page.locator('dialog[open]').count(), 0)
  await page.getByTitle('环境与项目设置').click()
  await page.getByRole('switch', { name: /走公司内网/ }).waitFor()
  await capture(page, path.join(reviewOutput, 'console-environments.png'))
  for (const name of ['项目', '代理', '系统']) {
    await page.locator('.management-tabs').getByRole('button', { name, exact: true }).click()
    await capture(page, path.join(reviewOutput, `console-settings-${name}.png`))
  }
  await page.getByTitle('关闭管理后台').click()
  await page
    .getByRole('button', { name: '按需求', exact: true })
    .or(page.getByRole('tab', { name: '按需求', exact: true }))
    .click()
  await page.getByText('发现页筛选优化', { exact: true }).waitFor()
  await capture(page, path.join(output, 'console-requirements.png'))
  await page.setViewportSize({ width: 390, height: 844 })
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true)
  await capture(page, path.join(reviewOutput, 'console-mobile.png'))

  const popupContext = await browser.newContext({
    viewport: { width: 560, height: 600 },
    deviceScaleFactor: 2,
    locale: 'zh-CN',
    timezoneId: 'Asia/Shanghai',
  })
  await popupContext.route('**/*', (route) =>
    new URL(route.request().url()).origin === origin ? route.continue() : route.abort()
  )
  await popupContext.addInitScript(
    ({ origin, manifest }) => {
      let scoped = {
        selectedBranches: {
          webapp: '',
          base: '',
          discover: 'feature/discover-filter',
          guild: 'release/qa',
          voice_runtime: 'master',
        },
        submittedBuildBranches: {},
        siteOverrideEnabled: false,
      }
      const storage = { 'cuddly.controlOrigin': origin, 'cuddly.projectVersionTab.v1': 'branches' }
      const event = { addListener() {}, removeListener() {} }
      window.chrome = {
        runtime: {
          getManifest: () => manifest,
          getURL: (p) => `${origin}/_extension/${p}`,
          onMessage: event,
          sendMessage: async (m) => {
            if (m.type === 'read-popup-scoped-state') return { ok: true, state: scoped }
            if (m.type === 'write-popup-scoped-state') {
              scoped = m
              return { ok: true }
            }
            if (m.type === 'get-extension-capabilities')
              return {
                ok: true,
                capabilities: {
                  protocolVersion: 13,
                  commands: [
                    'apply-configuration-group',
                    'apply-site-preview-transaction',
                    'apply-remote-preview-transaction',
                    'remove-preview-transaction',
                  ],
                },
              }
            return { ok: true }
          },
        },
        tabs: {
          query: async () => [
            { id: 1, title: '网页端', url: 'https://main.bifrost.vanillacake.cn/' },
          ],
          onUpdated: event,
          onActivated: event,
          create: async () => {},
          update: async () => {},
        },
        storage: {
          local: {
            get: async () => storage,
            set: async (v) => Object.assign(storage, v),
            remove: async () => {},
          },
          onChanged: event,
        },
        permissions: { contains: async () => true, request: async () => true },
      }
    },
    { origin, manifest }
  )
  const popup = await popupContext.newPage()
  popup.on('pageerror', (error) => uiErrors.push(`Popup: ${error.message}`))
  await popup.goto(`${origin}/_extension/popup.html`)
  await popup.locator('#module-list .module-row').first().waitFor()
  assert.equal(await popup.locator('button:not(.cake-button)').count(), 0)
  await capture(popup, path.join(output, 'extension-projects.png'))
  const discoverRow = popup
    .locator('.module-row')
    .filter({ has: popup.getByText('discover', { exact: true }) })
  await discoverRow.locator('.branch-picker-trigger').click()
  await popup.getByRole('searchbox').waitFor()
  await capture(popup, path.join(output, 'extension-branches.png'))
  await popup.keyboard.press('Escape')
  await popup.locator('#queue-tab').click()
  await popup.waitForFunction(
    () => document.querySelector('#queue-tab').getAttribute('aria-selected') === 'true'
  )
  await popup
    .locator('#queue-list')
    .getByText('feature/discover-filter', { exact: false })
    .first()
    .waitFor()
  await capture(popup, path.join(output, 'extension-queue.png'))
  await popup
    .locator('#queue-list')
    .getByText('feature/discover-filter', { exact: false })
    .first()
    .click()
  await popup.locator('#job-detail-dialog[open]').waitFor()
  await popup.getByText('执行时间线', { exact: true }).waitFor()
  await capture(popup, path.join(output, 'extension-job.png'))
  assert.equal(await popup.locator('#job-detail-cancel').isVisible(), true)
  assert.equal(await popup.locator('#job-detail-retry').isVisible(), false)
  await popup.locator('#job-log-tab').click()
  await popup.locator('.job-console').waitFor()
  await capture(popup, path.join(reviewOutput, 'extension-log.png'))
  await popup.keyboard.press('Escape')
  await popup.locator('#build-history-tab').click()
  await popup
    .locator('#build-history-list')
    .getByText('feature/party-page', { exact: false })
    .click()
  await popup.locator('#job-detail-retry').waitFor()
  assert.equal(await popup.locator('#job-detail-cancel').isVisible(), false)
  await capture(popup, path.join(reviewOutput, 'extension-failed-job.png'))
  await popup.keyboard.press('Escape')
  assert.equal(await popup.locator('#build-history-previous').isDisabled(), true)
  assert.equal(await popup.locator('#build-history-next').isDisabled(), true)
  await capture(popup, path.join(reviewOutput, 'extension-history.png'))
  await popup.locator('#projects-tab').click()
  await popup.locator('#share-button').click()
  await popup.locator('#share-name').fill('发现页筛选优化')
  await popup.locator('#share-url-prefix').fill('发现页优化')
  await capture(popup, path.join(output, 'extension-share.png'))
  await popup.locator('#share-cancel').click()
  await discoverRow.locator('.branch-picker-trigger').click()
  await popup.getByRole('searchbox').fill('layout')
  await popup
    .locator('#branch-picker-list')
    .getByRole('option')
    .filter({ hasText: 'feature/layout-draft' })
    .click()
  assert.equal(await popup.locator('#apply-button').isDisabled(), true)
  assert.match(await discoverRow.locator('.branch-picker-trigger').innerText(), /上次打包失败/)
  await popup.reload()
  await popup.locator('#module-list .module-row').first().waitFor()
  // The fixture deliberately resets extension storage on reload; real persistence has
  // dedicated popup-state tests. Here we check that the UI can initialize a second time.
  assert.equal(await popup.locator('button:not(.cake-button)').count(), 0)
  assert.deepEqual(uiErrors, [], 'UI must not throw while switching views and dialogs')
  console.log(`Saved documentation screenshots to ${output}`)
} finally {
  await browser.close()
  await new Promise((resolve) => server.close(resolve))
}
