import assert from 'node:assert/strict'
import { fileURLToPath } from 'node:url'

import { Client } from '@modelcontextprotocol/sdk/client/index.js'
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js'

const entry = fileURLToPath(new URL('../dist/main.js', import.meta.url))
for (const mode of ['read', 'operate', 'admin']) {
  const client = new Client({ name: 'bifrost-smoke', version: '1.0.0' })
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [entry],
    env: {
      ...process.env,
      BIFROST_URL: 'http://127.0.0.1:1',
      BIFROST_MCP_ACCESS: mode,
      BIFROST_SESSION_TOKEN: '',
      BIFROST_CREDENTIALS_DIR: fileURLToPath(new URL('../.nonexistent-smoke-credentials', import.meta.url)),
    },
    stderr: 'pipe',
  })
  try {
    await client.connect(transport)
    const { tools } = await client.listTools()
    assert.ok(tools.length >= 20)
    const guide = await client.readResource({ uri: 'bifrost://guide' })
    assert.equal(guide.contents[0].mimeType, 'text/markdown')
    const unauthenticated = await client.callTool({ name: 'bifrost_whoami', arguments: {} })
    assert.equal(unauthenticated.isError, true)
    if (mode === 'read') assert.ok(tools.every((tool) => tool.annotations.readOnlyHint))
    console.log(`${mode}: ${tools.length} tools, stdio handshake/resources/auth error OK`)
  } finally {
    await client.close()
  }
}
