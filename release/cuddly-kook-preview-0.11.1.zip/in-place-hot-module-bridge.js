;(() => {
  const CHANNEL = 'bifrost:in-place-hot-module:v1'

  chrome.runtime
    .sendMessage({ type: 'read-in-place-hot-module-config' })
    .then((response) => {
      const source = response?.ok && Array.isArray(response.config) ? response.config : []
      const modules = source.map((item) => ({
        moduleKey: item?.moduleKey,
        name: item?.name,
        entry: item?.entry,
        version: item?.version,
        restartRequired: item?.restartRequired,
      }))
      window.postMessage(
        { channel: CHANNEL, type: 'configuration', modules },
        window.location.origin
      )
    })
    .catch(() => {
      window.postMessage(
        { channel: CHANNEL, type: 'configuration', modules: [] },
        window.location.origin
      )
    })
})()
