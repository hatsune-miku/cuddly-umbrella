const ACTIVE_KEY = 'cuddly.activePreviews'
const CONTROL_KEY = 'cuddly.controlOrigin'
const POPUP_SCOPED_STATE_KEY = 'cuddly.popupStateByTabBindingEnvironment.v2'
const TAB_ENVIRONMENT_PREFS_KEY = 'cuddly.environmentByTab.v1'
const READ_POPUP_SCOPED_STATE_COMMAND = 'read-popup-scoped-state'
const WRITE_POPUP_SCOPED_STATE_COMMAND = 'write-popup-scoped-state'
const READ_IN_PLACE_HOT_MODULE_CONFIG_COMMAND = 'read-in-place-hot-module-config'
const MAX_SCOPED_STATES = 100
const PREVIEW_ALARM_PREFIX = 'cuddly.previewExpiry.'
const EXTENSION_PROTOCOL_VERSION = 7
const EXTENSION_CAPABILITIES_COMMAND = 'get-extension-capabilities'
const APPLY_CONFIGURATION_GROUP_COMMAND = 'apply-configuration-group'
const APPLY_SITE_PREVIEW_TRANSACTION_COMMAND = 'apply-site-preview-transaction'
const APPLY_REMOTE_PREVIEW_TRANSACTION_COMMAND = 'apply-remote-preview-transaction'
const REMOVE_PREVIEW_TRANSACTION_COMMAND = 'remove-preview-transaction'
const DEFAULT_CONTROL_ORIGIN = 'https://bifrost.vanillacake.cn'
const CONFIGURATION_GROUP_TOKEN_PATTERN = /^[A-Za-z0-9_-]{32}$/
const EXTENSION_RELOAD_REQUIRED =
  '扩展前后台版本不一致，请在 chrome://extensions 重新加载浏览器扩展'
const PREVIEW_REVOKE_TIMEOUT_MS = 3_000
let mutationQueue = Promise.resolve()
let popupScopedStorageArea = null

function serializeMutation(task) {
  const result = mutationQueue.then(task, task)
  mutationQueue = result.catch(() => undefined)
  return result
}

function normalizeHttpOrigin(value) {
  if (typeof value !== 'string' || !value.trim()) return null
  try {
    const url = new URL(value.trim())
    if (
      !['http:', 'https:'].includes(url.protocol) ||
      url.username ||
      url.password ||
      url.pathname !== '/' ||
      url.search ||
      url.hash
    ) {
      return null
    }
    return url.origin
  } catch {
    return null
  }
}

async function configuredControlOrigin() {
  const stored = await chrome.storage.local.get(CONTROL_KEY)
  return normalizeHttpOrigin(stored[CONTROL_KEY]) || DEFAULT_CONTROL_ORIGIN
}

async function authenticatedRequestContext(controlOrigin, init = {}) {
  const origin = new URL(controlOrigin).origin
  const sessionResponse = await fetch(`${origin}/api/v1/auth/session`, {
    method: 'GET',
    cache: 'no-store',
    credentials: 'include',
    ...(init.signal ? { signal: init.signal } : {}),
  })
  const session = await sessionResponse.json().catch(() => null)
  const csrfToken =
    sessionResponse.ok && session?.authenticated === true && typeof session.csrfToken === 'string'
      ? session.csrfToken.trim()
      : ''
  if (!csrfToken) throw new Error('飞书登录状态无效，请重新登录')
  return { origin, csrfToken }
}

function authenticatedRequest(context, pathname, init = {}) {
  return fetch(`${context.origin}${pathname}`, {
    ...init,
    credentials: 'include',
    headers: {
      ...init.headers,
      'x-cuddly-csrf': context.csrfToken,
    },
  })
}

async function authenticatedMutation(controlOrigin, pathname, init = {}) {
  const context = await authenticatedRequestContext(controlOrigin, init)
  return authenticatedRequest(context, pathname, init)
}

function configurationShareUrl(value, controlOrigin) {
  try {
    const url = new URL(value)
    if (url.username || url.password || url.origin !== controlOrigin) return null
    const match = /^\/s\/([A-Za-z0-9_-]{32})$/.exec(url.pathname)
    if (!match || !CONFIGURATION_GROUP_TOKEN_PATTERN.test(match[1])) return null
    return {
      token: match[1],
      url: `${controlOrigin}/s/${match[1]}`,
    }
  } catch {
    return null
  }
}

function configurationGroupSelection(body, expectedToken) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new Error('Configuration group response is invalid')
  }
  const wrapped = body.configurationGroup !== undefined
  if (wrapped && body.mode !== 'preview' && body.mode !== 'official') {
    throw new Error('Configuration group response mode is invalid')
  }
  const group = wrapped ? body.configurationGroup : body
  if (!group || typeof group !== 'object' || Array.isArray(group)) {
    throw new Error('Configuration group is missing')
  }
  if (group.token !== expectedToken) throw new Error('Configuration group token does not match')
  const name = typeof group.name === 'string' ? group.name.trim() : ''
  const environmentSlug =
    typeof group.environmentSlug === 'string' ? group.environmentSlug.trim() : ''
  if (!name || name.length > 80 || !environmentSlug) {
    throw new Error('Configuration group identity is invalid')
  }
  const hasRevision = group.revision !== undefined
  const revision = hasRevision ? Number(group.revision) : null
  if (hasRevision && (!Number.isInteger(revision) || revision < 1)) {
    throw new Error('Configuration group revision is invalid')
  }
  const binding = group.siteBinding
  if (!binding || typeof binding !== 'object' || Array.isArray(binding)) {
    throw new Error('Configuration group site binding is missing')
  }
  const bindingId = typeof binding.id === 'string' ? binding.id.trim() : ''
  const hostname = typeof binding.hostname === 'string' ? binding.hostname.trim().toLowerCase() : ''
  const siteTargetId = typeof binding.targetId === 'string' ? binding.targetId.trim() : ''
  const officialOrigin = normalizeHttpOrigin(binding.officialOrigin)
  const bindingEnvironmentSlug =
    typeof binding.environmentSlug === 'string' ? binding.environmentSlug.trim() : ''
  if (!bindingId || !hostname || !officialOrigin || !bindingEnvironmentSlug) {
    throw new Error('Configuration group site binding is invalid')
  }
  if (!Array.isArray(group.items) || !group.items.length || group.items.length > 40) {
    throw new Error('Configuration group items are invalid')
  }
  const selectedBranches = {}
  for (const item of group.items) {
    const targetId = typeof item?.targetId === 'string' ? item.targetId.trim() : ''
    if (!targetId || targetId.length > 80 || Object.hasOwn(selectedBranches, targetId)) {
      throw new Error('Configuration group project is invalid')
    }
    if (item.mode === 'official') {
      selectedBranches[targetId] = ''
    } else if (
      item.mode === 'branch' &&
      typeof item.branch === 'string' &&
      item.branch.trim() &&
      item.branch.trim().length <= 240
    ) {
      selectedBranches[targetId] = item.branch.trim()
    } else {
      throw new Error('Configuration group branch selection is invalid')
    }
  }
  return {
    mode: wrapped ? body.mode : 'detail',
    group,
    bindingId,
    hostname,
    siteTargetId,
    officialOrigin,
    bindingEnvironmentSlug,
    name,
    environmentSlug,
    revision,
    selectedBranches,
    siteOverrideEnabled: Boolean(selectedBranches[siteTargetId]),
  }
}

function validatedPreviewResponse(body, selection) {
  if (selection.mode !== 'preview') return null
  const preview = body.preview
  if (!preview || typeof preview !== 'object' || Array.isArray(preview)) {
    throw new Error('Configuration group preview is missing')
  }
  if (
    typeof preview.token !== 'string' ||
    !preview.token ||
    preview.siteBindingId !== selection.bindingId ||
    preview.environmentSlug !== selection.environmentSlug ||
    !Number.isFinite(Date.parse(preview.expiresAt || '')) ||
    Date.parse(preview.expiresAt) <= Date.now()
  ) {
    throw new Error('Configuration group preview is invalid')
  }
  const previewOrigin = normalizeHttpOrigin(body.previewOrigin)
  if (!previewOrigin || new URL(previewOrigin).hostname.toLowerCase() !== selection.hostname) {
    throw new Error('Configuration group preview origin does not match its site binding')
  }
  return { preview, previewOrigin }
}

function stringRecord(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {}
  return Object.fromEntries(
    Object.entries(value).filter(
      ([key, entry]) => typeof key === 'string' && typeof entry === 'string'
    )
  )
}

function popupStateScopeKey(tabId, bindingId, environmentSlug) {
  if (
    !Number.isInteger(tabId) ||
    tabId < 0 ||
    typeof bindingId !== 'string' ||
    !bindingId ||
    typeof environmentSlug !== 'string' ||
    !environmentSlug
  ) {
    return ''
  }
  return `${tabId}:${bindingId}:${environmentSlug}`
}

function readScopedPopupState(store, { tabId, bindingId, environmentSlug }) {
  const key = popupStateScopeKey(tabId, bindingId, environmentSlug)
  const entry = key && store && typeof store === 'object' ? store[key] : null
  if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return null
  return {
    selectedBranches: stringRecord(entry.selectedBranches),
    submittedBuildBranches: stringRecord(entry.submittedBuildBranches),
    siteOverrideEnabled: entry.siteOverrideEnabled === true,
    updatedAt: Number.isFinite(entry.updatedAt) ? entry.updatedAt : 0,
  }
}

function writeScopedPopupState(
  store,
  {
    tabId,
    bindingId,
    environmentSlug,
    selectedBranches,
    submittedBuildBranches,
    siteOverrideEnabled = false,
    updatedAt = Date.now(),
  }
) {
  const key = popupStateScopeKey(tabId, bindingId, environmentSlug)
  if (!key) throw new Error('Popup state scope is invalid')
  const next = {
    ...(store && typeof store === 'object' && !Array.isArray(store) ? store : {}),
    [key]: {
      selectedBranches: stringRecord(selectedBranches),
      submittedBuildBranches: stringRecord(submittedBuildBranches),
      siteOverrideEnabled: siteOverrideEnabled === true,
      updatedAt,
    },
  }
  return Object.fromEntries(
    Object.entries(next)
      .sort(([, left], [, right]) => (right?.updatedAt || 0) - (left?.updatedAt || 0))
      .slice(0, MAX_SCOPED_STATES)
  )
}

function removeScopedPopupStatesForTab(store, tabId) {
  const prefix = `${tabId}:`
  return Object.fromEntries(
    Object.entries(store && typeof store === 'object' && !Array.isArray(store) ? store : {}).filter(
      ([key]) => !key.startsWith(prefix)
    )
  )
}

function retainScopedPopupStatesForTabs(store, tabIds) {
  const activeTabIds = new Set(tabIds)
  return Object.fromEntries(
    Object.entries(store && typeof store === 'object' && !Array.isArray(store) ? store : {}).filter(
      ([key]) => {
        const separator = key.indexOf(':')
        if (separator <= 0) return false
        const tabId = Number(key.slice(0, separator))
        return Number.isInteger(tabId) && activeTabIds.has(tabId)
      }
    )
  )
}

async function getPopupScopedStorageArea() {
  if (popupScopedStorageArea) return popupScopedStorageArea
  const session = chrome.storage?.session
  if (session?.get && session?.set) {
    try {
      await session.get(POPUP_SCOPED_STATE_KEY)
      popupScopedStorageArea = session
      return popupScopedStorageArea
    } catch {
      // Older Chromium builds can expose storage.session without making it usable here.
    }
  }
  popupScopedStorageArea = chrome.storage.local
  return popupScopedStorageArea
}

async function readPersistedPopupState(tabId, bindingId, environmentSlug) {
  const area = await getPopupScopedStorageArea()
  const stored = await area.get(POPUP_SCOPED_STATE_KEY)
  return readScopedPopupState(stored[POPUP_SCOPED_STATE_KEY] || {}, {
    tabId,
    bindingId,
    environmentSlug,
  })
}

async function persistPopupState(message) {
  const area = await getPopupScopedStorageArea()
  const stored = await area.get(POPUP_SCOPED_STATE_KEY)
  const next = writeScopedPopupState(stored[POPUP_SCOPED_STATE_KEY] || {}, message)
  await area.set({ [POPUP_SCOPED_STATE_KEY]: next })
  return readScopedPopupState(next, message)
}

async function persistActiveSiteOverride(tabId, active, enabled) {
  const bindingId =
    typeof active?.preview?.siteBindingId === 'string' ? active.preview.siteBindingId.trim() : ''
  const environmentSlug =
    typeof active?.preview?.environmentSlug === 'string'
      ? active.preview.environmentSlug.trim()
      : ''
  if (!bindingId || !environmentSlug) return
  const current = await readPersistedPopupState(tabId, bindingId, environmentSlug)
  await persistPopupState({
    tabId,
    bindingId,
    environmentSlug,
    selectedBranches: current?.selectedBranches || {},
    submittedBuildBranches: current?.submittedBuildBranches || {},
    siteOverrideEnabled: enabled === true,
  })
}

async function removePersistedPopupStatesForTab(tabId) {
  if (!Number.isInteger(tabId) || tabId < 0) return
  const area = await getPopupScopedStorageArea()
  const stored = await area.get(POPUP_SCOPED_STATE_KEY)
  const current = stored[POPUP_SCOPED_STATE_KEY] || {}
  const next = removeScopedPopupStatesForTab(current, tabId)
  if (Object.keys(next).length !== Object.keys(current).length) {
    await area.set({ [POPUP_SCOPED_STATE_KEY]: next })
  }
}

async function reconcilePersistedPopupStates() {
  const area = await getPopupScopedStorageArea()
  const [stored, tabs] = await Promise.all([
    area.get(POPUP_SCOPED_STATE_KEY),
    chrome.tabs.query({}),
  ])
  const current = stored[POPUP_SCOPED_STATE_KEY] || {}
  const next = retainScopedPopupStatesForTabs(
    current,
    tabs.flatMap((tab) => (Number.isInteger(tab.id) ? [tab.id] : []))
  )
  if (Object.keys(next).length !== Object.keys(current).length) {
    await area.set({ [POPUP_SCOPED_STATE_KEY]: next })
  }
}

function nextTabEnvironmentPreferences(
  store,
  {
    tabId,
    officialOrigin,
    environmentSlug,
    configurationGroupBindingId = '',
    configurationGroupHostname = '',
    updatedAt = Date.now(),
  }
) {
  const origin = normalizeHttpOrigin(officialOrigin)
  const slug = typeof environmentSlug === 'string' ? environmentSlug.trim() : ''
  const current = store && typeof store === 'object' && !Array.isArray(store) ? store : {}
  if (!Number.isInteger(tabId) || tabId < 0 || !origin || !slug) return { ...current }
  return Object.fromEntries(
    Object.entries({
      ...current,
      [String(tabId)]: {
        officialOrigin: origin,
        environmentSlug: slug,
        ...(typeof configurationGroupBindingId === 'string' && configurationGroupBindingId
          ? {
              configurationGroupBindingId,
              configurationGroupHostname:
                typeof configurationGroupHostname === 'string'
                  ? configurationGroupHostname.trim().toLowerCase()
                  : '',
            }
          : {}),
        updatedAt,
      },
    })
      .sort(([, left], [, right]) => (right?.updatedAt || 0) - (left?.updatedAt || 0))
      .slice(0, MAX_SCOPED_STATES)
  )
}

async function persistTabEnvironmentPreference(input) {
  const stored = await chrome.storage.local.get(TAB_ENVIRONMENT_PREFS_KEY)
  const next = nextTabEnvironmentPreferences(stored[TAB_ENVIRONMENT_PREFS_KEY] || {}, input)
  await chrome.storage.local.set({ [TAB_ENVIRONMENT_PREFS_KEY]: next })
}

async function removeTabEnvironmentPreference(tabId) {
  if (!Number.isInteger(tabId) || tabId < 0) return
  const stored = await chrome.storage.local.get(TAB_ENVIRONMENT_PREFS_KEY)
  const current = stored[TAB_ENVIRONMENT_PREFS_KEY] || {}
  if (!Object.hasOwn(current, String(tabId))) return
  const next = { ...current }
  delete next[String(tabId)]
  await chrome.storage.local.set({ [TAB_ENVIRONMENT_PREFS_KEY]: next })
}

async function reconcileTabEnvironmentPreferences() {
  const [stored, tabs] = await Promise.all([
    chrome.storage.local.get(TAB_ENVIRONMENT_PREFS_KEY),
    chrome.tabs.query({}),
  ])
  const activeTabIds = new Set(
    tabs.flatMap((tab) => (Number.isInteger(tab.id) ? [String(tab.id)] : []))
  )
  const current = stored[TAB_ENVIRONMENT_PREFS_KEY] || {}
  const next = Object.fromEntries(
    Object.entries(current).filter(([tabId]) => activeTabIds.has(tabId))
  )
  if (Object.keys(next).length !== Object.keys(current).length) {
    await chrome.storage.local.set({ [TAB_ENVIRONMENT_PREFS_KEY]: next })
  }
}

async function readActivePreviews() {
  return (await chrome.storage.local.get(ACTIVE_KEY))[ACTIVE_KEY] || {}
}

async function writeActivePreviews(value) {
  await chrome.storage.local.set({ [ACTIVE_KEY]: value })
}

function previewAlarmName(tabId) {
  return `${PREVIEW_ALARM_PREFIX}${tabId}`
}

function previewAlarmTabId(name) {
  if (!name.startsWith(PREVIEW_ALARM_PREFIX)) return null
  const tabId = Number(name.slice(PREVIEW_ALARM_PREFIX.length))
  return Number.isInteger(tabId) && tabId >= 0 ? tabId : null
}

function previewExpiresAt(active) {
  return Date.parse(active?.preview?.expiresAt || '')
}

async function schedulePreviewExpiry(tabId, active) {
  const when = previewExpiresAt(active)
  if (!Number.isFinite(when) || when <= Date.now()) {
    throw new Error('Preview session has already expired')
  }
  await chrome.alarms.create(previewAlarmName(tabId), { when })
}

async function revokeActivePreview(active) {
  const token = active?.preview?.token
  if (typeof token !== 'string' || !token || !active?.controlOrigin) return false
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), PREVIEW_REVOKE_TIMEOUT_MS)
  try {
    const origin = new URL(active.controlOrigin).origin
    const response = await authenticatedMutation(
      origin,
      `/api/v1/previews/${encodeURIComponent(token)}`,
      {
        method: 'DELETE',
        cache: 'no-store',
        keepalive: true,
        signal: controller.signal,
      }
    )
    return response.ok || response.status === 404
  } catch {
    return false
  } finally {
    clearTimeout(timeout)
  }
}

async function clearPreviewState(tabId) {
  const active = await readActivePreviews()
  const current = active[String(tabId)] || null
  if (current?.ruleIds?.length) {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: current.ruleIds })
  }
  delete active[String(tabId)]
  await writeActivePreviews(active)
  await chrome.alarms.clear(previewAlarmName(tabId))
  return current
}

async function removePreview(tabId) {
  const current = await clearPreviewState(tabId)
  await persistActiveSiteOverride(tabId, current, false).catch(() => undefined)
  await revokeActivePreview(current)
  return current
}

async function nextRuleIds(count) {
  const rules = await chrome.declarativeNetRequest.getSessionRules()
  const first = rules.reduce((maximum, rule) => Math.max(maximum, rule.id), 1000) + 1
  return Array.from({ length: count }, (_value, index) => first + index)
}

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function sitePreviewRules({ tabId, previewOrigin, token, previewHeaderRuleId }) {
  const origin = new URL(previewOrigin).origin
  return [
    {
      id: previewHeaderRuleId,
      priority: 3,
      action: {
        type: 'modifyHeaders',
        requestHeaders: [
          {
            header: 'x-cuddly-preview-token',
            operation: 'set',
            value: token,
          },
        ],
      },
      condition: {
        regexFilter: `^${escapeRegex(origin)}(?:/|$)`,
        tabIds: [tabId],
      },
    },
  ]
}

function rulesForActivePreview(tabId, active) {
  try {
    if (
      active?.mode === 'site' &&
      active.ruleIds?.length === 1 &&
      typeof active.preview?.token === 'string'
    ) {
      return sitePreviewRules({
        tabId,
        previewOrigin: active.previewOrigin,
        token: active.preview.token,
        previewHeaderRuleId: active.ruleIds[0],
      })
    }
    if (
      active?.mode === 'remote' &&
      active.ruleIds?.length === 0 &&
      typeof active.preview?.token === 'string' &&
      !active.preview.siteArtifactId &&
      Array.isArray(active.preview.selections) &&
      active.preview.selections.length > 0 &&
      active.pageOrigin &&
      active.previewOrigin &&
      active.bindingEnvironmentSlug &&
      active.preview.environmentSlug === active.bindingEnvironmentSlug &&
      new URL(active.pageOrigin).origin === new URL(active.officialOrigin).origin
    ) {
      return []
    }
  } catch {
    return null
  }
  return null
}

function activePreviewMatchesTab(active, tab) {
  if (!tab?.url) return false
  try {
    const expectedOrigin =
      active?.mode === 'site'
        ? active.previewOrigin
        : active?.mode === 'remote'
          ? active.pageOrigin
          : null
    return Boolean(expectedOrigin) && new URL(tab.url).origin === new URL(expectedOrigin).origin
  } catch {
    return false
  }
}

function inPlaceHotModuleEntry(previewOrigin, selection) {
  if (
    typeof selection?.artifactId !== 'string' ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(selection.artifactId) ||
    typeof selection.providerName !== 'string' ||
    !/^[A-Za-z0-9_]+$/.test(selection.providerName) ||
    typeof selection.entryPath !== 'string'
  ) {
    return null
  }
  const entryPath = selection.entryPath.replaceAll('\\', '/')
  if (
    !entryPath ||
    entryPath.startsWith('/') ||
    entryPath.split('/').some((part) => !part || part === '.' || part === '..')
  ) {
    return null
  }
  try {
    const base = new URL(
      `/__cuddly/preview-artifacts/${selection.artifactId}/${selection.providerName}/`,
      previewOrigin
    )
    const entry = new URL(entryPath, base)
    return entry.origin === base.origin && entry.pathname.startsWith(base.pathname)
      ? entry.href
      : null
  } catch {
    return null
  }
}

function inPlaceHotModuleConfig(active, tab) {
  if (
    active?.mode !== 'remote' ||
    !activePreviewMatchesTab(active, tab) ||
    previewExpiresAt(active) <= Date.now() ||
    active.preview?.siteArtifactId ||
    !active.bindingEnvironmentSlug ||
    active.preview?.environmentSlug !== active.bindingEnvironmentSlug ||
    new URL(active.pageOrigin).origin !== new URL(active.officialOrigin).origin ||
    !Array.isArray(active.preview?.selections)
  ) {
    return []
  }
  return active.preview.selections.flatMap((selection) => {
    const moduleKey = typeof selection?.moduleKey === 'string' ? selection.moduleKey.trim() : ''
    const name = typeof selection?.providerName === 'string' ? selection.providerName.trim() : ''
    const version = typeof selection?.version === 'string' ? selection.version.trim() : ''
    const entry = inPlaceHotModuleEntry(active.previewOrigin, selection)
    if (!moduleKey || moduleKey.length > 80 || !name || !version || !entry) return []
    return [{ moduleKey, name, entry, version, restartRequired: true }]
  })
}

async function readInPlaceHotModuleConfig(sender) {
  const tab = sender?.tab
  if (!Number.isInteger(tab?.id) || sender?.frameId !== 0) return []
  const active = await readActivePreviews()
  return inPlaceHotModuleConfig(active[String(tab.id)] || null, tab)
}

function officialUrlForActivePreview(active, tab) {
  if (active?.mode !== 'site' || !activePreviewMatchesTab(active, tab) || !active?.officialOrigin) {
    return null
  }
  try {
    const destination = new URL(active.officialOrigin)
    const current = new URL(tab.url)
    destination.pathname = current.pathname
    destination.search = current.search
    destination.hash = current.hash
    return destination.href
  } catch {
    return null
  }
}

function shareUrlForActivePreview(active) {
  const controlOrigin = normalizeHttpOrigin(active?.controlOrigin)
  if (!controlOrigin || !CONFIGURATION_GROUP_TOKEN_PATTERN.test(active?.configGroupToken || '')) {
    return null
  }
  const share = configurationShareUrl(active?.shareUrl, controlOrigin)
  return share?.token === active.configGroupToken ? share.url : null
}

function recoveryUrlForActivePreview(active, tab) {
  if (active?.mode === 'remote') return null
  return shareUrlForActivePreview(active) || officialUrlForActivePreview(active, tab)
}

async function storeActive(tabId, value) {
  const active = await readActivePreviews()
  active[String(tabId)] = value
  await writeActivePreviews(active)
  try {
    await schedulePreviewExpiry(tabId, value)
  } catch (error) {
    delete active[String(tabId)]
    await writeActivePreviews(active)
    await chrome.alarms.clear(previewAlarmName(tabId))
    throw error
  }
  return value
}

async function restoreActive(tabId, value) {
  if (!value) return null
  const rules = rulesForActivePreview(tabId, value)
  if (!rules) throw new Error('Previous preview state cannot be restored')
  if (rules.length) await chrome.declarativeNetRequest.updateSessionRules({ addRules: rules })
  try {
    return await storeActive(tabId, value)
  } catch (error) {
    if (rules.length) {
      await chrome.declarativeNetRequest.updateSessionRules({
        removeRuleIds: rules.map((rule) => rule.id),
      })
    }
    throw error
  }
}

async function discardPreviewState(tabId, value) {
  const ruleIds = Array.isArray(value?.ruleIds) ? value.ruleIds : []
  if (ruleIds.length) {
    await chrome.declarativeNetRequest
      .updateSessionRules({ removeRuleIds: ruleIds })
      .catch(() => undefined)
  }

  const active = await readActivePreviews().catch(() => null)
  const current = active?.[String(tabId)] || null
  const samePendingPreview =
    current?.mode === value?.mode &&
    typeof current?.preview?.token === 'string' &&
    current.preview.token === value?.preview?.token
  if (
    active &&
    (samePendingPreview || current?.ruleIds?.some((ruleId) => ruleIds.includes(ruleId)))
  ) {
    delete active[String(tabId)]
    await writeActivePreviews(active).catch(() => undefined)
  }
  await chrome.alarms.clear(previewAlarmName(tabId)).catch(() => undefined)
}

async function reconcilePreviewLifecycles() {
  const active = await readActivePreviews()
  const tabs = await chrome.tabs.query({})
  const tabsById = new Map(tabs.flatMap((tab) => (tab.id === undefined ? [] : [[tab.id, tab]])))
  const expectedAlarms = new Set()
  const restoredRules = []
  const restoredPreviews = []
  const stalePreviews = []
  const redirects = []
  const reloads = []
  const usedRuleIds = new Set()

  for (const [tabKey, preview] of Object.entries(active)) {
    const tabId = Number(tabKey)
    const tab = tabsById.get(tabId)
    const expiresAt = previewExpiresAt(preview)
    const rules =
      Number.isInteger(tabId) && tabId >= 0 ? rulesForActivePreview(tabId, preview) : null
    const ruleIds = rules?.map((rule) => rule.id) || []
    const rulesAreUnique = ruleIds.every(
      (ruleId) => Number.isInteger(ruleId) && ruleId > 0 && !usedRuleIds.has(ruleId)
    )
    if (
      !tab ||
      !Number.isFinite(expiresAt) ||
      expiresAt <= Date.now() ||
      !rules ||
      !rulesAreUnique ||
      !activePreviewMatchesTab(preview, tab)
    ) {
      const shouldReload = preview?.mode === 'remote' && activePreviewMatchesTab(preview, tab)
      delete active[tabKey]
      stalePreviews.push(preview)
      const recoveryUrl = recoveryUrlForActivePreview(preview, tab)
      if (recoveryUrl) redirects.push([tabId, recoveryUrl])
      else if (shouldReload) reloads.push(tabId)
      if (Number.isInteger(tabId) && tabId >= 0) await chrome.alarms.clear(previewAlarmName(tabId))
      continue
    }
    for (const ruleId of ruleIds) usedRuleIds.add(ruleId)
    restoredRules.push(...rules)
    restoredPreviews.push([tabId, preview])
    expectedAlarms.add(previewAlarmName(tabId))
  }

  const currentRules = await chrome.declarativeNetRequest.getSessionRules()
  if (currentRules.length || restoredRules.length) {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: currentRules.map((rule) => rule.id),
      addRules: restoredRules,
    })
  }
  await writeActivePreviews(active)
  await Promise.all(stalePreviews.map((preview) => revokeActivePreview(preview)))
  for (const [tabId, preview] of restoredPreviews) {
    await schedulePreviewExpiry(tabId, preview)
  }

  const alarms = await chrome.alarms.getAll()
  await Promise.all(
    alarms
      .filter(
        (alarm) => alarm.name.startsWith(PREVIEW_ALARM_PREFIX) && !expectedAlarms.has(alarm.name)
      )
      .map((alarm) => chrome.alarms.clear(alarm.name))
  )
  await Promise.all(
    redirects.map(([tabId, url]) => chrome.tabs.update(tabId, { url }).catch(() => undefined))
  )
  await Promise.all(reloads.map((tabId) => chrome.tabs.reload(tabId).catch(() => undefined)))
}

function transactionTargetUrl(message, previewOrigin) {
  const target = new URL(message.targetUrl)
  if (target.origin !== previewOrigin) {
    throw new Error('Preview target must use the configured preview origin')
  }
  return target.href
}

function configurationShareMetadata(message, controlOrigin) {
  const hasShareMetadata =
    message.shareUrl !== undefined ||
    message.configGroupToken !== undefined ||
    message.name !== undefined
  if (!hasShareMetadata) return {}
  const share = configurationShareUrl(message.shareUrl, controlOrigin)
  const name = typeof message.name === 'string' ? message.name.trim() : ''
  if (!share || share.token !== message.configGroupToken || !name || name.length > 80) {
    throw new Error('Configuration group preview metadata is invalid')
  }
  return {
    shareUrl: share.url,
    configGroupToken: share.token,
    name,
  }
}

async function applySitePreview(message, { navigate = false } = {}) {
  const tabId = message.tabId
  if (!Number.isInteger(tabId) || tabId < 0) throw new Error('Preview tab is invalid')
  const [previewHeaderRuleId] = await nextRuleIds(1)
  const origin = new URL(message.previewOrigin).origin
  const controlOrigin = new URL(message.controlOrigin).origin
  const officialOrigin = new URL(message.officialOrigin).origin
  const targetUrl = navigate ? transactionTargetUrl(message, origin) : message.targetUrl
  const shareMetadata = configurationShareMetadata(message, controlOrigin)
  const pending = {
    mode: 'site',
    ruleIds: [previewHeaderRuleId],
    preview: message.preview,
    previewOrigin: origin,
    controlOrigin,
    officialOrigin,
    originalUrl: message.originalUrl,
    targetUrl,
    appliedAt: new Date().toISOString(),
    ...shareMetadata,
  }
  const rules = sitePreviewRules({
    tabId,
    previewOrigin: origin,
    token: message.preview.token,
    previewHeaderRuleId,
  })
  const previous = await clearPreviewState(tabId)
  try {
    await chrome.declarativeNetRequest.updateSessionRules({ addRules: rules })
    const active = await storeActive(tabId, pending)
    await persistActiveSiteOverride(tabId, active, Boolean(active.preview?.siteArtifactId)).catch(
      () => undefined
    )
    if (navigate) await chrome.tabs.update(tabId, { url: targetUrl })
    await revokeActivePreview(previous)
    return active
  } catch (error) {
    await discardPreviewState(tabId, pending)
    try {
      const restored = await restoreActive(tabId, previous)
      await persistActiveSiteOverride(
        tabId,
        restored,
        Boolean(restored?.preview?.siteArtifactId)
      ).catch(() => undefined)
    } catch {
      await revokeActivePreview(previous)
    }
    await revokeActivePreview(pending)
    throw error
  }
}

async function applyRemotePreview(message) {
  const tabId = message.tabId
  if (!Number.isInteger(tabId) || tabId < 0) throw new Error('Preview tab is invalid')
  const tab = await chrome.tabs.get(tabId)
  const pageOrigin = new URL(message.pageOrigin).origin
  if (!tab?.url || new URL(tab.url).origin !== pageOrigin) {
    throw new Error('当前标签页与所选环境的官方页面不一致')
  }
  const previewOrigin = new URL(message.previewOrigin).origin
  const controlOrigin = new URL(message.controlOrigin).origin
  const officialOrigin = new URL(message.officialOrigin).origin
  const bindingEnvironmentSlug =
    typeof message.bindingEnvironmentSlug === 'string' ? message.bindingEnvironmentSlug.trim() : ''
  if (pageOrigin !== officialOrigin) {
    throw new Error('原地热更只能用于站点绑定的官方页面')
  }
  if (
    !bindingEnvironmentSlug ||
    message.preview?.environmentSlug !== bindingEnvironmentSlug ||
    message.preview?.siteArtifactId ||
    !Array.isArray(message.preview?.selections) ||
    message.preview.selections.length === 0
  ) {
    throw new Error('原地热更与站点环境或预览产物不匹配')
  }
  const shareMetadata = configurationShareMetadata(message, controlOrigin)
  const pending = {
    mode: 'remote',
    ruleIds: [],
    preview: message.preview,
    previewOrigin,
    pageOrigin,
    controlOrigin,
    officialOrigin,
    bindingEnvironmentSlug,
    originalUrl: tab.url,
    targetUrl: tab.url,
    appliedAt: new Date().toISOString(),
    ...shareMetadata,
  }
  const previous = await clearPreviewState(tabId)
  try {
    const active = await storeActive(tabId, pending)
    await persistActiveSiteOverride(tabId, active, false).catch(() => undefined)
    await chrome.tabs.reload(tabId)
    await revokeActivePreview(previous)
    return active
  } catch (error) {
    await discardPreviewState(tabId, pending)
    try {
      const restored = await restoreActive(tabId, previous)
      await persistActiveSiteOverride(
        tabId,
        restored,
        Boolean(restored?.preview?.siteArtifactId)
      ).catch(() => undefined)
    } catch {
      await revokeActivePreview(previous)
    }
    await revokeActivePreview(pending)
    throw error
  }
}

async function removePreviewAndNavigate(tabId) {
  if (!Number.isInteger(tabId) || tabId < 0) throw new Error('Preview tab is invalid')
  const active = await readActivePreviews()
  const current = active[String(tabId)] || null
  if (!current) return null

  const tab = await chrome.tabs.get(tabId)
  const expired = previewExpiresAt(current) <= Date.now()
  const destinationUrl = expired
    ? recoveryUrlForActivePreview(current, tab)
    : officialUrlForActivePreview(current, tab)
  const previous = await clearPreviewState(tabId)
  await persistActiveSiteOverride(tabId, previous, false).catch(() => undefined)
  try {
    if (destinationUrl) {
      await chrome.tabs.update(tabId, { url: destinationUrl })
    } else if (current.mode !== 'site') {
      await chrome.tabs.reload(tabId)
    }
  } catch (error) {
    try {
      const restored = await restoreActive(tabId, previous)
      await persistActiveSiteOverride(
        tabId,
        restored,
        Boolean(restored?.preview?.siteArtifactId)
      ).catch(() => undefined)
    } catch {
      await revokeActivePreview(previous)
    }
    throw error
  }
  await revokeActivePreview(previous)
  return previous
}

async function requestConfigurationGroup(authContext, token) {
  const response = await authenticatedRequest(
    authContext,
    `/api/v1/config-groups/${encodeURIComponent(token)}`,
    { method: 'GET', cache: 'no-store' }
  )
  const body = await response.json().catch(() => null)
  if (!response.ok) {
    const message = typeof body?.message === 'string' ? body.message.trim() : ''
    const error = new Error(message || `Configuration group returned HTTP ${response.status}`)
    error.status = response.status
    error.code = typeof body?.code === 'string' ? body.code : ''
    throw error
  }
  return body
}

async function requestConfigurationGroupPreview(authContext, token, expectedRevision) {
  const init = { method: 'POST', cache: 'no-store' }
  if (Number.isInteger(expectedRevision) && expectedRevision > 0) {
    init.headers = { 'content-type': 'application/json' }
    init.body = JSON.stringify({ expectedRevision })
  }
  const response = await authenticatedRequest(
    authContext,
    `/api/v1/config-groups/${encodeURIComponent(token)}/previews`,
    init
  )
  const body = await response.json().catch(() => null)
  if (!response.ok) {
    const missingArtifacts =
      body?.code === 'CONFIG_GROUP_ARTIFACTS_NOT_READY' && Array.isArray(body.missing)
        ? body.missing.slice(0, 40).flatMap((item) => {
            const targetName =
              typeof item?.targetName === 'string' && item.targetName.trim()
                ? item.targetName.trim().slice(0, 80)
                : typeof item?.targetId === 'string'
                  ? item.targetId.trim().slice(0, 80)
                  : ''
            const branch = typeof item?.branch === 'string' ? item.branch.trim().slice(0, 240) : ''
            return targetName && branch ? [`${targetName} · ${branch}`] : []
          })
        : []
    const message = missingArtifacts.length
      ? `缺少可用打包产物：${missingArtifacts.join('；')}`
      : typeof body?.message === 'string'
        ? body.message.trim()
        : ''
    const error = new Error(
      message || `Configuration group preview returned HTTP ${response.status}`
    )
    error.status = response.status
    error.code = typeof body?.code === 'string' ? body.code : ''
    throw error
  }
  return body
}

function configurationShareForToken(token, controlOrigin) {
  if (typeof token !== 'string' || !CONFIGURATION_GROUP_TOKEN_PATTERN.test(token)) {
    throw new Error('Configuration group token is invalid')
  }
  return { token, url: `${controlOrigin}/s/${token}` }
}

function configurationGroupDestinationUrl(
  tabUrl,
  destinationOrigin,
  officialOrigin,
  { preserveLocation = false } = {}
) {
  const destination = new URL(destinationOrigin)
  if (!preserveLocation) return new URL('/', destination).href
  try {
    const current = new URL(tabUrl)
    if (current.origin !== destination.origin && current.origin !== officialOrigin) {
      return new URL('/', destination).href
    }
    destination.pathname = current.pathname
    destination.search = current.search
    destination.hash = current.hash
    return destination.href
  } catch {
    return new URL('/', destination).href
  }
}

async function persistConfigurationGroupSelection(tabId, selection) {
  await Promise.all([
    persistPopupState({
      tabId,
      bindingId: selection.bindingId,
      environmentSlug: selection.environmentSlug,
      selectedBranches: selection.selectedBranches,
      submittedBuildBranches: {},
      siteOverrideEnabled: selection.siteOverrideEnabled,
    }),
    persistTabEnvironmentPreference({
      tabId,
      officialOrigin: selection.officialOrigin,
      environmentSlug: selection.environmentSlug,
      configurationGroupBindingId: selection.bindingId,
      configurationGroupHostname: selection.hostname,
    }),
  ])
}

async function applyConfigurationGroup(tab, share, { preserveLocation = false } = {}) {
  if (!Number.isInteger(tab?.id) || !tab.url) throw new Error('Preview tab is invalid')
  const controlOrigin = await configuredControlOrigin()
  if (share.url !== `${controlOrigin}/s/${share.token}`) {
    throw new Error('Configuration group share URL is invalid')
  }
  const authContext = await authenticatedRequestContext(controlOrigin)
  const groupBody = await requestConfigurationGroup(authContext, share.token)
  const groupSelection = configurationGroupSelection(groupBody, share.token)

  // A share selects branch intent even when its latest Artifact is not ready. Persist the draft
  // before requesting a Preview so a failed apply still leaves the popup ready to build it.
  await persistConfigurationGroupSelection(tab.id, groupSelection)

  let previewToRevoke = null
  try {
    let selection = groupSelection
    let body
    try {
      body = await requestConfigurationGroupPreview(authContext, share.token, selection.revision)
    } catch (error) {
      if (error?.code !== 'CONFIG_GROUP_REVISION_CONFLICT') throw error

      const refreshedBody = await requestConfigurationGroup(authContext, share.token)
      selection = configurationGroupSelection(refreshedBody, share.token)
      await persistConfigurationGroupSelection(tab.id, selection)
      body = await requestConfigurationGroupPreview(authContext, share.token, selection.revision)
    }
    selection = configurationGroupSelection(body, share.token)
    const previewResponse = validatedPreviewResponse(body, selection)
    previewToRevoke = previewResponse?.preview || null

    // The group may have been edited between GET and POST. The Preview response is authoritative;
    // persist it again before any navigation so the visible branch draft matches what was applied.
    await persistConfigurationGroupSelection(tab.id, selection)

    if (selection.mode === 'official') {
      await removePreview(tab.id)
      await persistTabEnvironmentPreference({
        tabId: tab.id,
        officialOrigin: selection.officialOrigin,
        environmentSlug: selection.environmentSlug,
      })
      await chrome.tabs.update(tab.id, {
        url: configurationGroupDestinationUrl(
          tab.url,
          selection.officialOrigin,
          selection.officialOrigin,
          { preserveLocation }
        ),
      })
      return null
    }

    const previewMessage = {
      tabId: tab.id,
      previewOrigin: previewResponse.previewOrigin,
      controlOrigin,
      officialOrigin: selection.officialOrigin,
      bindingEnvironmentSlug: selection.bindingEnvironmentSlug,
      originalUrl: tab.url,
      preview: previewResponse.preview,
      shareUrl: share.url,
      configGroupToken: share.token,
      name: selection.name,
    }
    const remoteOnlyOnOfficialPage =
      !previewResponse.preview.siteArtifactId &&
      previewResponse.preview.selections?.length > 0 &&
      selection.environmentSlug === selection.bindingEnvironmentSlug &&
      new URL(tab.url).origin === selection.officialOrigin
    const active = remoteOnlyOnOfficialPage
      ? await applyRemotePreview({ ...previewMessage, pageOrigin: selection.officialOrigin })
      : await applySitePreview(
          {
            ...previewMessage,
            targetUrl: configurationGroupDestinationUrl(
              tab.url,
              previewResponse.previewOrigin,
              selection.officialOrigin,
              { preserveLocation }
            ),
          },
          { navigate: true }
        )
    await persistTabEnvironmentPreference({
      tabId: tab.id,
      officialOrigin: selection.officialOrigin,
      environmentSlug: selection.environmentSlug,
    })
    previewToRevoke = null
    return active
  } catch (error) {
    if (previewToRevoke) {
      await revokeActivePreview({ preview: previewToRevoke, controlOrigin })
    }
    if (error && typeof error === 'object') error.selectionPersisted = true
    throw error
  }
}

async function applyConfigurationGroupCommand(message) {
  if (!Number.isInteger(message?.tabId) || message.tabId < 0) {
    throw new Error('Preview tab is invalid')
  }
  const controlOrigin = await configuredControlOrigin()
  const share = configurationShareForToken(message.token, controlOrigin)
  const tab = await chrome.tabs.get(message.tabId)
  return applyConfigurationGroup(tab, share, { preserveLocation: true })
}

async function applyConfigurationShare(tab) {
  if (!Number.isInteger(tab?.id) || !tab.url) return false
  const controlOrigin = await configuredControlOrigin()
  const expectedShare = configurationShareUrl(tab.url, controlOrigin)
  if (!expectedShare) return false

  // Multiple onUpdated events can carry the same stale landing URL. Re-read the tab only when the
  // queued task starts so a previous task's navigation prevents a duplicate Preview creation.
  const currentTab = await chrome.tabs.get(tab.id).catch(() => null)
  const currentShare = configurationShareUrl(currentTab?.url, controlOrigin)
  if (!currentShare || currentShare.token !== expectedShare.token) return false

  try {
    await applyConfigurationGroup(currentTab, currentShare)
    return true
  } catch {
    return false
  }
}

async function scanConfigurationShareTabs() {
  const tabs = await chrome.tabs.query({})
  for (const tab of tabs) await applyConfigurationShare(tab)
}

function extensionCapabilities() {
  return {
    protocolVersion: EXTENSION_PROTOCOL_VERSION,
    commands: [
      APPLY_CONFIGURATION_GROUP_COMMAND,
      'apply-site-preview',
      'remove-preview',
      APPLY_SITE_PREVIEW_TRANSACTION_COMMAND,
      APPLY_REMOTE_PREVIEW_TRANSACTION_COMMAND,
      REMOVE_PREVIEW_TRANSACTION_COMMAND,
    ],
  }
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  const task =
    message?.type === READ_IN_PLACE_HOT_MODULE_CONFIG_COMMAND
      ? readInPlaceHotModuleConfig(sender)
      : serializeMutation(() => {
          if (message?.type === EXTENSION_CAPABILITIES_COMMAND) return extensionCapabilities()
          if (message?.type === READ_POPUP_SCOPED_STATE_COMMAND) {
            return readPersistedPopupState(
              message.tabId,
              message.bindingId,
              message.environmentSlug
            )
          }
          if (message?.type === WRITE_POPUP_SCOPED_STATE_COMMAND) return persistPopupState(message)
          if (message?.type === APPLY_CONFIGURATION_GROUP_COMMAND) {
            return applyConfigurationGroupCommand(message)
          }
          if (message?.type === 'apply-site-preview') return applySitePreview(message)
          if (message?.type === 'remove-preview') return removePreview(message.tabId)
          if (message?.type === APPLY_SITE_PREVIEW_TRANSACTION_COMMAND) {
            return applySitePreview(message, { navigate: true })
          }
          if (message?.type === APPLY_REMOTE_PREVIEW_TRANSACTION_COMMAND) {
            return applyRemotePreview(message)
          }
          if (message?.type === REMOVE_PREVIEW_TRANSACTION_COMMAND) {
            return removePreviewAndNavigate(message.tabId)
          }
          if (message?.type === 'apply-preview' || message?.type === 'apply-remote-preview') {
            return Promise.reject(new Error(EXTENSION_RELOAD_REQUIRED))
          }
          return Promise.reject(new Error('Unsupported extension command'))
        })

  task
    .then((result) =>
      respond(
        message?.type === EXTENSION_CAPABILITIES_COMMAND
          ? { ok: true, capabilities: result }
          : message?.type === READ_POPUP_SCOPED_STATE_COMMAND ||
              message?.type === WRITE_POPUP_SCOPED_STATE_COMMAND
            ? { ok: true, state: result }
            : message?.type === READ_IN_PLACE_HOT_MODULE_CONFIG_COMMAND
              ? { ok: true, config: result }
              : { ok: true, active: result }
      )
    )
    .catch((error) =>
      respond({
        ok: false,
        message: error.message,
        ...(error?.code ? { code: error.code } : {}),
        ...(error?.selectionPersisted ? { selectionPersisted: true } : {}),
      })
    )
  return true
})

chrome.tabs.onRemoved.addListener((tabId) => {
  void serializeMutation(async () => {
    try {
      await removePreview(tabId)
    } finally {
      await Promise.all([
        removePersistedPopupStatesForTab(tabId),
        removeTabEnvironmentPreference(tabId),
      ])
    }
  })
})

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!changeInfo.url) return
  void serializeMutation(async () => {
    const currentTab = await chrome.tabs.get(tabId).catch(() => tab)
    if (currentTab?.url !== changeInfo.url) return
    const active = await readActivePreviews()
    const current = active[String(tabId)] || null
    if (current && !activePreviewMatchesTab(current, currentTab)) await removePreview(tabId)
    await applyConfigurationShare(currentTab)
  })
})

chrome.alarms.onAlarm.addListener((alarm) => {
  const tabId = previewAlarmTabId(alarm.name)
  if (tabId === null) return
  void serializeMutation(async () => {
    const active = await readActivePreviews()
    const current = active[String(tabId)] || null
    if (!current) {
      await chrome.alarms.clear(alarm.name)
      return
    }
    if (previewExpiresAt(current) > Date.now()) {
      await schedulePreviewExpiry(tabId, current)
      return
    }
    const tab = await chrome.tabs.get(tabId).catch(() => null)
    const recoveryUrl = recoveryUrlForActivePreview(current, tab)
    const shouldReload = current.mode === 'remote' && activePreviewMatchesTab(current, tab)
    await removePreview(tabId)
    if (recoveryUrl) await chrome.tabs.update(tabId, { url: recoveryUrl }).catch(() => undefined)
    else if (shouldReload) await chrome.tabs.reload(tabId).catch(() => undefined)
  })
})

async function reconcileExtensionLifecycles() {
  try {
    await reconcilePreviewLifecycles()
  } finally {
    await Promise.all([reconcilePersistedPopupStates(), reconcileTabEnvironmentPreferences()])
  }
  await scanConfigurationShareTabs()
}

chrome.runtime.onStartup.addListener(() => {
  void serializeMutation(reconcileExtensionLifecycles)
})

chrome.runtime.onInstalled.addListener(() => {
  void serializeMutation(reconcileExtensionLifecycles)
})
