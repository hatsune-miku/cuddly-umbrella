;(() => {
  const CHANNEL = 'bifrost:in-place-hot-module:v1'
  const CONFIG_WAIT_MS = 1_000
  const nativeFetch = window.fetch
  if (typeof nativeFetch !== 'function') return

  let configuration = null
  let resolveConfiguration
  const configurationReady = new Promise((resolve) => {
    resolveConfiguration = resolve
  })

  function isRecord(value) {
    return Boolean(value && typeof value === 'object' && !Array.isArray(value))
  }

  function normalizedModules(value) {
    if (!Array.isArray(value) || value.length > 40) return null
    const seen = new Set()
    const modules = []
    for (const candidate of value) {
      if (!isRecord(candidate)) return null
      const moduleKey = typeof candidate.moduleKey === 'string' ? candidate.moduleKey.trim() : ''
      const name = typeof candidate.name === 'string' ? candidate.name.trim() : ''
      const version = typeof candidate.version === 'string' ? candidate.version.trim() : ''
      if (
        !moduleKey ||
        moduleKey.length > 80 ||
        seen.has(moduleKey) ||
        !name ||
        name.length > 160 ||
        !version ||
        version.length > 320 ||
        candidate.restartRequired !== true
      ) {
        return null
      }
      let entry
      try {
        entry = new URL(candidate.entry)
      } catch {
        return null
      }
      if (!['http:', 'https:'].includes(entry.protocol) || entry.username || entry.password) {
        return null
      }
      seen.add(moduleKey)
      modules.push({
        moduleKey,
        name,
        entry: entry.href,
        version,
        restartRequired: true,
      })
    }
    return modules
  }

  function receiveConfiguration(event) {
    if (
      configuration !== null ||
      event.source !== window ||
      event.origin !== window.location.origin ||
      event.data?.channel !== CHANNEL ||
      event.data?.type !== 'configuration'
    ) {
      return
    }
    const modules = normalizedModules(event.data.modules)
    if (!modules) return
    configuration = modules
    window.removeEventListener('message', receiveConfiguration)
    resolveConfiguration(modules)
  }

  function isHotModuleRequest(input, init) {
    try {
      const requestUrl = input instanceof Request ? input.url : String(input)
      const method = String(init?.method || (input instanceof Request ? input.method : 'GET'))
        .trim()
        .toUpperCase()
      const url = new URL(requestUrl, window.location.href)
      return (
        method === 'GET' &&
        url.origin === window.location.origin &&
        (url.pathname === '/api/v3/version/hot-module' || url.pathname === '/v3/version/hot-module')
      )
    } catch {
      return false
    }
  }

  function applyOverlay(responseBody, modules) {
    if (!modules.length || !isRecord(responseBody)) return false
    if ('code' in responseBody && responseBody.code !== 0) return false
    const root = 'data' in responseBody ? responseBody.data : responseBody
    if (!isRecord(root)) return false

    if (Array.isArray(root.modules)) {
      const next = [...root.modules]
      for (const override of modules) {
        const index = next.findIndex(
          (candidate) => isRecord(candidate) && candidate.key === override.moduleKey
        )
        const existing = index >= 0 && isRecord(next[index]) ? next[index] : {}
        const replacement = {
          ...existing,
          key: override.moduleKey,
          name: override.name,
          entry: override.entry,
          version: override.version,
          restartRequired: override.restartRequired,
        }
        if (index >= 0) next[index] = replacement
        else next.push(replacement)
      }
      root.modules = next
      return true
    }

    if (!isRecord(root.modules)) return false
    const next = { ...root.modules }
    for (const override of modules) {
      const existing = isRecord(next[override.moduleKey]) ? next[override.moduleKey] : {}
      next[override.moduleKey] = {
        ...existing,
        name: override.name,
        entry: override.entry,
        version: override.version,
        restartRequired: override.restartRequired,
      }
    }
    root.modules = next
    return true
  }

  async function availableConfiguration() {
    if (configuration !== null) return configuration
    return Promise.race([
      configurationReady,
      new Promise((resolve) => window.setTimeout(() => resolve([]), CONFIG_WAIT_MS)),
    ])
  }

  window.addEventListener('message', receiveConfiguration)
  window.fetch = function bifrostInPlaceFetch(...args) {
    const [input, init] = args
    const responsePromise = Reflect.apply(nativeFetch, this, args)
    if (!isHotModuleRequest(input, init)) return responsePromise

    return Promise.resolve(responsePromise).then(async (response) => {
      try {
        if (!response?.ok) return response
        const modules = await availableConfiguration()
        if (!modules.length) return response
        const body = await response.clone().json()
        if (!applyOverlay(body, modules)) return response
        const headers = new Headers(response.headers)
        headers.delete('content-encoding')
        headers.delete('content-length')
        const replacement = new Response(JSON.stringify(body), {
          status: response.status,
          statusText: response.statusText,
          headers,
        })
        for (const property of ['url', 'redirected', 'type']) {
          try {
            Object.defineProperty(replacement, property, { value: response[property] })
          } catch {
            // These metadata properties are non-essential to hot-module JSON consumers.
          }
        }
        return replacement
      } catch {
        return response
      }
    })
  }
})()
