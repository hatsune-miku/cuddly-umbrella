export const SITE_BINDING_REQUIRED = '当前页面尚未配置站点绑定，请先在管理后台配置站点'
export const ENVIRONMENT_REQUIRED = '请选择运行环境'

function normalizedOrigin(value) {
  if (typeof value !== 'string' || !value.trim()) return null
  try {
    return new URL(value.trim()).origin
  } catch {
    return null
  }
}

export function previewDestinationUrl(origin, currentUrl) {
  const destination = new URL(origin)
  try {
    const current = new URL(currentUrl)
    destination.pathname = current.pathname
    destination.search = current.search
    destination.hash = current.hash
  } catch {
    // Keep the origin root when the current tab URL cannot be parsed.
  }
  return destination.href
}

export function createPreviewRequest({
  binding,
  environmentSlug,
  siteArtifactId,
  selections,
  ttlMinutes = 480,
}) {
  if (!binding) throw new Error(SITE_BINDING_REQUIRED)
  if (!environmentSlug) throw new Error(ENVIRONMENT_REQUIRED)
  return {
    ttlMinutes,
    siteBindingId: binding.id,
    environmentSlug,
    ...(siteArtifactId ? { siteArtifactId } : {}),
    selections: selections || [],
  }
}

export function mergeSelectedBranches({ sameBinding, previous, defaults }) {
  return Object.fromEntries(
    Object.entries(defaults).map(([targetId, branch]) => [
      targetId,
      sameBinding && Object.hasOwn(previous, targetId) ? previous[targetId] : branch,
    ])
  )
}

export function resolveSelectedArtifacts({
  targets = [],
  selectedBranches = {},
  branchCatalogs = {},
  siteTargetId = null,
}) {
  let siteArtifactId = null
  const selections = []
  const missing = []
  for (const target of targets) {
    const branch = selectedBranches[target.id] || ''
    if (!branch) continue
    const artifact =
      branchCatalogs[target.id]?.items?.find((item) => item.branch === branch)?.latestArtifact ||
      null
    if (!artifact) {
      missing.push({ targetId: target.id, targetName: target.name || target.id, branch })
      continue
    }
    if (target.id === siteTargetId) {
      siteArtifactId = artifact.id
    } else {
      selections.push({
        targetId: target.id,
        artifactId: artifact.id,
        branch,
        builtAt: artifact.builtAt,
      })
    }
  }
  return { siteArtifactId, selections, missing }
}

export function planPreviewApplication({
  binding,
  environmentSlug,
  previewOrigin,
  currentUrl = '',
  siteArtifactId = null,
  selections = [],
}) {
  if (!binding) {
    return {
      canApply: false,
      mode: null,
      requestedOrigin: null,
      reason: SITE_BINDING_REQUIRED,
    }
  }
  if (!environmentSlug) {
    return {
      canApply: false,
      mode: 'site',
      requestedOrigin: null,
      reason: ENVIRONMENT_REQUIRED,
    }
  }
  const requestedOrigin = normalizedOrigin(previewOrigin)
  const selectedPageOrigin = normalizedOrigin(binding.officialOrigin)
  const currentOrigin = normalizedOrigin(currentUrl)
  if (
    !siteArtifactId &&
    selections.length > 0 &&
    requestedOrigin &&
    selectedPageOrigin &&
    currentOrigin === selectedPageOrigin &&
    binding.environmentSlug === environmentSlug
  ) {
    return {
      canApply: true,
      mode: 'remote',
      requestedOrigin,
      pageOrigin: selectedPageOrigin,
      reason: null,
    }
  }
  return {
    canApply: true,
    mode: 'site',
    requestedOrigin,
    reason: null,
  }
}
