import assert from 'node:assert/strict'
import test from 'node:test'

import {
  createPreviewRequest,
  ENVIRONMENT_REQUIRED,
  mergeSelectedBranches,
  planPreviewApplication,
  previewDestinationUrl,
  resolveSelectedArtifacts,
  SITE_BINDING_REQUIRED,
} from '../preview-routing.js'

const binding = {
  id: 'main',
  hostname: 'main.bifrost.vanillacake.cn',
  officialOrigin: 'https://www.kookapp.cn',
  environmentSlug: 'online',
}

test('keeps a Remote-only selection on the matching environment page', () => {
  const plan = planPreviewApplication({
    binding,
    environmentSlug: 'online',
    previewOrigin: 'https://main.bifrost.vanillacake.cn/channels/1',
    currentUrl: 'https://www.kookapp.cn/channels/1?view=compact',
    siteArtifactId: null,
    selections: [{ targetId: 'base', artifactId: 'artifact-base' }],
  })

  assert.deepEqual(plan, {
    canApply: true,
    mode: 'remote',
    requestedOrigin: 'https://main.bifrost.vanillacake.cn',
    pageOrigin: 'https://www.kookapp.cn',
    reason: null,
  })
})

test('uses the site preview when the selected environment does not match the current page', () => {
  const plan = planPreviewApplication({
    binding,
    environmentSlug: 'tttt',
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    currentUrl: 'https://www.kookapp.cn/channels/1',
    siteArtifactId: null,
    selections: [{ targetId: 'base', artifactId: 'artifact-base' }],
  })

  assert.deepEqual(plan, {
    canApply: true,
    mode: 'site',
    requestedOrigin: 'https://main.bifrost.vanillacake.cn',
    reason: null,
  })
})

test('uses the site preview whenever a page Artifact is selected', () => {
  const plan = planPreviewApplication({
    binding,
    environmentSlug: 'online',
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    currentUrl: 'https://www.kookapp.cn/channels/1',
    siteArtifactId: 'artifact-webapp',
    selections: [{ targetId: 'base', artifactId: 'artifact-base' }],
  })

  assert.equal(plan.mode, 'site')
})

test('does not offer a Remote-only fallback without a site binding', () => {
  const plan = planPreviewApplication({
    binding: null,
    environmentSlug: 'online',
    previewOrigin: null,
    siteArtifactId: null,
    selections: [{ targetId: 'base', artifactId: 'artifact-base' }],
  })

  assert.equal(plan.canApply, false)
  assert.equal(plan.mode, null)
  assert.equal(plan.requestedOrigin, null)
  assert.equal(plan.reason, SITE_BINDING_REQUIRED)
})

test('allows an all-official Preview so the selected backend environment is still isolated', () => {
  const plan = planPreviewApplication({
    binding,
    environmentSlug: 'test',
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    siteArtifactId: null,
    selections: [],
  })

  assert.equal(plan.canApply, true)
  assert.equal(plan.mode, 'site')
  assert.equal(plan.reason, null)
})

test('requires an environment even when all projects use official artifacts', () => {
  const plan = planPreviewApplication({
    binding,
    environmentSlug: '',
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    siteArtifactId: null,
    selections: [],
  })

  assert.equal(plan.canApply, false)
  assert.equal(plan.reason, ENVIRONMENT_REQUIRED)
})

test('builds a site-bound Preview request and preserves the current tab route', () => {
  assert.deepEqual(
    createPreviewRequest({
      binding,
      environmentSlug: 'test',
      siteArtifactId: null,
      selections: [{ targetId: 'base', artifactId: 'artifact-base' }],
    }),
    {
      ttlMinutes: 480,
      siteBindingId: 'main',
      environmentSlug: 'test',
      selections: [{ targetId: 'base', artifactId: 'artifact-base' }],
    }
  )
  assert.equal(
    previewDestinationUrl(
      'https://main.bifrost.vanillacake.cn',
      'https://www.kookapp.cn/channels/42?view=compact#messages'
    ),
    'https://main.bifrost.vanillacake.cn/channels/42?view=compact#messages'
  )
  assert.deepEqual(
    createPreviewRequest({
      binding,
      environmentSlug: 'test',
      siteArtifactId: null,
      selections: [],
    }),
    {
      ttlMinutes: 480,
      siteBindingId: 'main',
      environmentSlug: 'test',
      selections: [],
    }
  )
})

test('keeps draft branch choices while refreshing the same site', () => {
  assert.deepEqual(
    mergeSelectedBranches({
      sameBinding: true,
      previous: { webapp: '', base: 'feature/qa' },
      defaults: { webapp: 'master', base: '' },
    }),
    { webapp: '', base: 'feature/qa' }
  )
  assert.deepEqual(
    mergeSelectedBranches({
      sameBinding: false,
      previous: { base: 'feature/qa' },
      defaults: { webapp: 'master', base: '' },
    }),
    { webapp: 'master', base: '' }
  )
})

test('blocks a selected branch until every selected project has a successful artifact', () => {
  const result = resolveSelectedArtifacts({
    targets: [
      { id: 'webapp', name: '网页端' },
      { id: 'base', name: '基础热更' },
      { id: 'voice', name: '语音热更' },
    ],
    selectedBranches: {
      webapp: 'feature/page',
      base: 'feature/base',
      voice: '',
    },
    branchCatalogs: {
      webapp: {
        items: [
          {
            branch: 'feature/page',
            latestArtifact: { id: 'artifact-page', builtAt: '2026-08-25T08:00:00.000Z' },
          },
        ],
      },
      base: {
        items: [{ branch: 'feature/base', latestArtifact: null }],
      },
    },
    siteTargetId: 'webapp',
  })

  assert.equal(result.siteArtifactId, 'artifact-page')
  assert.deepEqual(result.selections, [])
  assert.deepEqual(result.missing, [
    { targetId: 'base', targetName: '基础热更', branch: 'feature/base' },
  ])
})
