import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const manifest = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8'))
if (manifest.manifest_version !== 3) throw new Error('Browser extension must use Manifest V3')
if (!manifest.permissions?.includes('alarms')) {
  throw new Error('Browser extension must declare the alarms permission')
}
for (const file of [
  'popup.html',
  'popup.css',
  'popup.js',
  'popup-state.js',
  'popup-tabs.js',
  'branch-picker.js',
  'build-queue.js',
  'binding-selection.js',
  'popup-identity.js',
  'preview-routing.js',
  'extension-protocol.js',
  'service-worker.js',
]) {
  await readFile(path.join(root, file))
}

const popupHtml = await readFile(path.join(root, 'popup.html'), 'utf8')
for (const requiredId of [
  'module-list',
  'queue-list',
  'queue-summary',
  'job-detail-dialog',
  'job-detail-content',
  'job-detail-cancel',
  'apply-button-wrap',
  'projects-tab',
  'queue-tab',
  'projects-panel',
  'branch-picker-dropdown',
  'branch-picker-search',
  'branch-picker-list',
  'branch-picker-count',
]) {
  if (!popupHtml.includes(`id="${requiredId}"`)) {
    throw new Error(`Browser extension popup is missing #${requiredId}`)
  }
}
if (popupHtml.includes('Proudly Crafted With CakeDesign.')) {
  throw new Error('Browser extension popup must not include the CakeDesign credit line')
}
if (popupHtml.includes('branch-picker-dialog')) {
  throw new Error('Branch picker must use an anchored dropdown instead of a full-screen dialog')
}
const popupJs = await readFile(path.join(root, 'popup.js'), 'utf8')
for (const match of popupJs.matchAll(/document\.querySelector\('#([^']+)'\)/g)) {
  if (!popupHtml.includes(`id="${match[1]}"`)) {
    throw new Error(`popup.js references missing element #${match[1]}`)
  }
}
const popupCss = await readFile(path.join(root, 'popup.css'), 'utf8')
if (!popupCss.includes('width: 560px;') || !popupCss.includes('height: 600px;')) {
  throw new Error('Browser extension popup must stay within the Chromium 800x600 limit')
}
const branchPickerJs = await readFile(path.join(root, 'branch-picker.js'), 'utf8')
if (popupJs.includes('queueJumpButton') || branchPickerJs.includes('showModal(')) {
  throw new Error('Popup still contains the legacy queue jump or modal branch picker behavior')
}
console.log('[browser-extension] manifest and entry files are valid')
