import type { Artifact, BuildJob, BuildTarget, EnvironmentRecord } from '@cuddly/contracts'
import { afterEach, describe, expect, it, vi } from 'vitest'

import { PostgresStore } from './postgres-store'
import { schemaSql } from './schema'

const environment: EnvironmentRecord = {
  id: '00000000-0000-4000-8000-000000000002',
  slug: 'staging',
  name: '测试环境',
  status: 'ACTIVE',
  backendOrigin: 'https://staging-api.example.test',
  currentRevisionId: null,
}

const target: BuildTarget = {
  id: 'webapp',
  name: '网页端',
  kind: 'webapp',
  repositoryUrl: 'https://git.example.test/webapp.git',
  defaultBranch: 'master',
  installCommand: 'pnpm install',
  buildCommand: 'pnpm build',
  outputDirectory: 'dist',
  siteAdapter: 'generic-static-v1',
  enabled: true,
  required: false,
  configurationSource: 'database',
}

const artifact: Artifact = {
  id: '00000000-0000-4000-8000-000000000010',
  buildJobId: '00000000-0000-4000-8000-000000000011',
  environmentId: environment.id,
  environmentSlug: environment.slug,
  targetId: target.id,
  branch: 'feature/latest',
  status: 'READY',
  storageKey: 'ready/webapp/latest',
  manifest: {
    schemaVersion: 1,
    artifactId: '00000000-0000-4000-8000-000000000010',
    target: target.id,
    branch: 'feature/latest',
    builtAt: '2026-08-25T08:00:00.000Z',
    serve: {
      siteAdapter: 'generic-static-v1',
      entrypoints: ['index.html'],
      publicBase: '/artifacts/latest/',
    },
    files: [],
  },
  builtAt: '2026-08-25T08:00:00.000Z',
  createdBy: 'gz',
}

const activeJob: BuildJob = {
  id: '00000000-0000-4000-8000-000000000012',
  environmentId: environment.id,
  environmentSlug: environment.slug,
  targetId: target.id,
  branch: 'feature/building',
  profile: 'qa-web',
  status: 'BUILDING',
  requestedBy: 'gz',
  createdAt: '2026-08-25T09:00:00.000Z',
  startedAt: '2026-08-25T09:00:01.000Z',
  finishedAt: null,
  failureCode: null,
  failureMessage: null,
  logPath: null,
  targetSnapshot: null,
}

function artifactRow(value: Artifact) {
  return {
    id: value.id,
    build_job_id: value.buildJobId,
    environment_id: value.environmentId,
    environment_slug: value.environmentSlug,
    target_id: value.targetId,
    branch: value.branch,
    status: value.status,
    storage_key: value.storageKey,
    manifest: value.manifest,
    built_at: value.builtAt,
    created_by: value.createdBy,
  }
}

function jobRow(value: BuildJob) {
  return {
    id: value.id,
    environment_id: value.environmentId,
    environment_slug: value.environmentSlug,
    target_id: value.targetId,
    branch: value.branch,
    profile: value.profile,
    status: value.status,
    requested_by: value.requestedBy,
    created_at: value.createdAt,
    started_at: value.startedAt,
    finished_at: value.finishedAt,
    failure_code: value.failureCode,
    failure_message: value.failureMessage,
    log_path: value.logPath,
    target_snapshot: value.targetSnapshot,
  }
}

describe('PostgresStore matrix queries', () => {
  const stores: PostgresStore[] = []

  afterEach(async () => {
    vi.restoreAllMocks()
    await Promise.all(stores.splice(0).map((store) => store.close()))
  })

  it('uses two environment-scoped latest-row queries instead of loading history per project', async () => {
    const store = new PostgresStore('postgres://unused:unused@127.0.0.1:1/unused')
    stores.push(store)
    vi.spyOn(store, 'getEnvironment').mockResolvedValue(environment)
    vi.spyOn(store, 'listBuildTargets').mockResolvedValue([target])
    vi.spyOn(store, 'listProjectEnvironmentConfigs').mockResolvedValue([
      {
        targetId: target.id,
        environmentId: environment.id,
        enabled: true,
        required: false,
        installCommand: 'pnpm install --staging',
        buildCommand: 'pnpm build --staging',
        outputDirectory: 'staging-dist',
      },
    ])
    const listArtifacts = vi.spyOn(store, 'listArtifacts')
    const listJobs = vi.spyOn(store, 'listBuildJobs')
    const queries: string[] = []
    vi.spyOn(store.pool, 'query').mockImplementation((async (query: unknown) => {
      const sql = String(query)
      queries.push(sql)
      if (sql.includes('FROM artifacts')) return { rows: [artifactRow(artifact)] }
      if (sql.includes('FROM build_jobs')) return { rows: [jobRow(activeJob)] }
      throw new Error(`Unexpected matrix query: ${sql}`)
    }) as typeof store.pool.query)

    const matrix = await store.getEnvironmentMatrix(environment.slug)

    expect(matrix?.rows).toEqual([
      expect.objectContaining({
        latestArtifact: { id: artifact.id, branch: artifact.branch, builtAt: artifact.builtAt },
        activeJob: expect.objectContaining({ id: activeJob.id, status: 'BUILDING' }),
      }),
    ])
    expect(listArtifacts).not.toHaveBeenCalled()
    expect(listJobs).not.toHaveBeenCalled()
    expect(queries).toHaveLength(2)
    expect(queries.every((sql) => sql.includes('DISTINCT ON (target_id)'))).toBe(true)
    expect(queries.every((sql) => sql.includes('environment_id = $1'))).toBe(true)
  })
})

describe('Postgres environment migration', () => {
  it('backfills without overwriting origins and enforces paired environment identity', () => {
    expect(schemaSql).toContain("setting.key = 'system.webapp_upstream'")
    expect(schemaSql).toContain('WHERE backend_origin IS NULL')
    expect(schemaSql).toContain(
      "ALTER TABLE environments ALTER COLUMN backend_origin SET DEFAULT 'https://www.kookapp.cn'"
    )
    expect(schemaSql).toMatch(
      /INSERT INTO environments \(id, slug, name, status, backend_origin\)[\s\S]+?'https:\/\/www\.kookapp\.cn'/
    )
    expect(
      schemaSql.indexOf('ALTER TABLE environments ADD COLUMN IF NOT EXISTS backend_origin text')
    ).toBeLessThan(
      schemaSql.indexOf('INSERT INTO environments (id, slug, name, status, backend_origin)')
    )
    expect(schemaSql).toContain('environments_id_slug_unique_idx')
    expect(schemaSql).toContain(
      'FOREIGN KEY (environment_id, environment_slug) REFERENCES environments(id, slug)'
    )
    expect(schemaSql).toContain('pg_get_constraintdef(constraint_row.oid)')
    expect(schemaSql).not.toContain(
      'ALTER TABLE build_jobs DROP CONSTRAINT IF EXISTS build_jobs_environment_identity_fkey'
    )
    expect(schemaSql).not.toContain(
      'ALTER TABLE artifacts DROP CONSTRAINT IF EXISTS artifacts_environment_identity_fkey'
    )
    expect(schemaSql).not.toContain(
      'ALTER TABLE preview_sessions DROP CONSTRAINT IF EXISTS preview_sessions_environment_identity_fkey'
    )
  })

  it('keeps old site origin writes synchronized and seeds only the shared environment', () => {
    expect(schemaSql).toContain('cuddly_sync_site_binding_origins')
    expect(schemaSql).toContain("WHERE environment.slug = 'shared'")
    expect(schemaSql).toContain('ON CONFLICT (environment_id, target_id) DO NOTHING')
    expect(schemaSql).toContain('site_bindings_official_environment_unique_idx')
  })

  it('indexes bounded matrix lookups and environment-scoped Artifact retention', () => {
    expect(schemaSql).toContain('build_jobs_environment_active_idx')
    expect(schemaSql).toContain('artifacts_environment_catalog_idx')
  })
})
