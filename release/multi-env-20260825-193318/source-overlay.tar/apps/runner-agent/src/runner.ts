import { spawn } from 'node:child_process'
import { createHash, timingSafeEqual } from 'node:crypto'
import { createWriteStream, type WriteStream } from 'node:fs'
import { access, mkdir, readFile, rm, statfs, writeFile } from 'node:fs/promises'
import path from 'node:path'

import { createArtifactStore, type FileArtifactStore } from '@cuddly/artifact-store'
import {
  createOnlineH5Manifest,
  createRemoteManifest,
  createStaticManifest,
} from '@cuddly/build-adapters'
import {
  CHINA_NPM_REGISTRY,
  runnerArtifactDeleteSchema,
  runnerJobSchema,
  type RunnerEvent,
  type RunnerJobInput,
  type RunnerStage,
} from '@cuddly/contracts'
import { decryptSetting, gitSshCommand, readOrCreateSecret } from '@cuddly/domain'
import express, { type Request, type Response } from 'express'

import {
  DEFAULT_REPOSITORY_CACHE_POLICY,
  RepositoryCache,
  RepositoryCacheDiskPressureError,
  RepositoryCacheUnavailableError,
  reserveRepositoryCheckoutCapacity,
  type RepositoryCheckoutInput,
} from './repository-cache'

class RunnerFailure extends Error {
  constructor(
    readonly code: string,
    message: string
  ) {
    super(message)
    this.name = 'RunnerFailure'
  }
}

export interface RunnerOptions {
  internalToken: string
  runnerRoot: string
  artifactStore: FileArtifactStore
  keepWorkspace: boolean
  settingsSecret: string
  repositoryCache?: Pick<RepositoryCache, 'checkout'>
  availableDiskBytes?: (directory: string) => Promise<number>
  readGitSshIdentity?: () => Promise<Buffer>
}

function authorized(req: Request, token: string): boolean {
  const value = req.headers.authorization
  if (!value?.startsWith('Bearer ')) return false
  const supplied = Buffer.from(value.slice('Bearer '.length))
  const expected = Buffer.from(token)
  return supplied.length === expected.length && timingSafeEqual(supplied, expected)
}

function writeEvent(res: Response, event: RunnerEvent): void {
  if (res.destroyed || res.writableEnded) return
  res.write(`${JSON.stringify(event)}\n`)
}

export function writeRunnerHeartbeat(
  res: Pick<Response, 'destroyed' | 'writableEnded' | 'write'>
): boolean {
  if (res.destroyed || res.writableEnded) return false
  res.write('\n')
  return true
}

function writeLog(stream: WriteStream, value: string): void {
  stream.write(value.endsWith('\n') ? value : `${value}\n`)
}

interface RunnerCommandInput {
  command: string
  args: string[]
  cwd: string
  env?: NodeJS.ProcessEnv
  log: WriteStream
  displayCommand?: string
  captureStdout?: boolean
  signal?: AbortSignal
}

type RunnerCommand = (input: RunnerCommandInput) => Promise<string>

const GIT_SSH_IDENTITY_PATH = '/srv/cuddly/secrets/git_id_ed25519'

function cancellationFailure(): RunnerFailure {
  return new RunnerFailure('BUILD_CANCELED', 'Build cancellation was requested')
}

function throwIfCanceled(signal?: AbortSignal): void {
  if (signal?.aborted) throw cancellationFailure()
}

function awaitWithCancellation<T>(promise: Promise<T>, signal?: AbortSignal): Promise<T> {
  if (!signal) return promise
  throwIfCanceled(signal)
  return new Promise<T>((resolve, reject) => {
    const canceled = () => {
      cleanup()
      reject(cancellationFailure())
    }
    const cleanup = () => signal.removeEventListener('abort', canceled)
    signal.addEventListener('abort', canceled, { once: true })
    promise.then(
      (value) => {
        cleanup()
        resolve(value)
      },
      (error) => {
        cleanup()
        reject(error)
      }
    )
  })
}

function killCommandProcess(child: ReturnType<typeof spawn>, signal: NodeJS.Signals): void {
  if (!child.pid) return
  if (process.platform !== 'win32') {
    try {
      process.kill(-child.pid, signal)
      return
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ESRCH') return
    }
  }
  try {
    child.kill(signal)
  } catch {
    // The process may already have exited between the cancellation check and the signal.
  }
}

const runCommand: RunnerCommand = async (input) => {
  throwIfCanceled(input.signal)
  writeLog(input.log, `\n$ ${input.displayCommand || `${input.command} ${input.args.join(' ')}`}`)
  return new Promise<string>((resolve, reject) => {
    let stdout = ''
    let canceled = false
    let settled = false
    let forceKill: NodeJS.Timeout | undefined
    const child = spawn(input.command, input.args, {
      cwd: input.cwd,
      env: input.env || process.env,
      shell: false,
      windowsHide: true,
      detached: process.platform !== 'win32',
    })
    const cleanup = () => {
      input.signal?.removeEventListener('abort', cancel)
      if (forceKill) clearTimeout(forceKill)
    }
    const cancel = () => {
      if (canceled) return
      canceled = true
      writeLog(input.log, '[CANCELING] Stopping command process group')
      killCommandProcess(child, 'SIGTERM')
      forceKill = setTimeout(() => killCommandProcess(child, 'SIGKILL'), 5_000)
      forceKill.unref()
    }
    input.signal?.addEventListener('abort', cancel, { once: true })
    if (input.signal?.aborted) cancel()
    child.stdout.on('data', (chunk: Buffer) => {
      input.log.write(chunk)
      if (input.captureStdout) stdout += chunk.toString('utf8')
    })
    child.stderr.on('data', (chunk: Buffer) => input.log.write(chunk))
    child.on('error', (error) => {
      if (settled) return
      settled = true
      if (canceled) killCommandProcess(child, 'SIGKILL')
      cleanup()
      reject(
        canceled ? cancellationFailure() : new RunnerFailure('COMMAND_START_FAILED', error.message)
      )
    })
    child.on('close', (code, signal) => {
      if (settled) return
      settled = true
      if (canceled) killCommandProcess(child, 'SIGKILL')
      cleanup()
      if (canceled) {
        reject(cancellationFailure())
        return
      }
      if (code === 0) {
        resolve(stdout)
        return
      }
      reject(
        new RunnerFailure(
          'COMMAND_FAILED',
          `${input.command} exited with ${code ?? `signal ${signal || 'unknown'}`}`
        )
      )
    })
  })
}

function unsafeHttpRepositoryUrl(repositoryUrl: string): boolean {
  const trimmed = repositoryUrl.trim()
  if (!/^https?:\/\//i.test(trimmed)) return false
  try {
    const parsed = new URL(trimmed)
    return (
      Boolean(parsed.username || parsed.password) ||
      /^https?:\/\/[^/?#]*@/i.test(trimmed) ||
      trimmed.includes('?') ||
      trimmed.includes('#')
    )
  } catch {
    return false
  }
}

function repositoryUsesSsh(repositoryUrl: string): boolean {
  const trimmed = repositoryUrl.trim()
  if (/^ssh:\/\//i.test(trimmed)) return true
  return /^[^/@:\s]+@[^/:\s]+:.+/.test(trimmed)
}

async function repositoryCredentialScope(
  repositoryUrl: string,
  authorizationHeader: string | undefined,
  readGitSshIdentity: () => Promise<Buffer>
): Promise<string | null> {
  if (!repositoryUsesSsh(repositoryUrl)) {
    return authorizationHeader ? `http-header:${authorizationHeader}` : 'anonymous'
  }

  try {
    const identity = await readGitSshIdentity()
    return `ssh-key:${createHash('sha256').update(identity).digest('hex')}`
  } catch {
    return null
  }
}

let directCloneTail: Promise<void> = Promise.resolve()

async function withDirectCloneQueue<T>(action: () => Promise<T>, signal?: AbortSignal): Promise<T> {
  const previous = directCloneTail
  let release!: () => void
  const gate = new Promise<void>((resolve) => {
    release = resolve
  })
  const tail = previous.catch(() => {}).then(() => gate)
  directCloneTail = tail
  try {
    await awaitWithCancellation(
      previous.catch(() => {}),
      signal
    )
    throwIfCanceled(signal)
    return await action()
  } finally {
    release()
    if (directCloneTail === tail) directCloneTail = Promise.resolve()
  }
}

async function filesystemAvailableBytes(directory: string): Promise<number> {
  const stats = await statfs(directory)
  return stats.bavail * stats.bsize
}

function diskPressureFailure(availableBytes: number): RunnerFailure {
  const pressure = new RepositoryCacheDiskPressureError(availableBytes)
  return new RunnerFailure('RUNNER_DISK_PRESSURE', pressure.message)
}

export async function checkoutRepository(input: {
  job: RunnerJobInput
  options: RunnerOptions
  jobDirectory: string
  sourceDirectory: string
  log: WriteStream
  runCommand?: RunnerCommand
  signal?: AbortSignal
}): Promise<void> {
  const executeCommand = input.runCommand || runCommand
  if (unsafeHttpRepositoryUrl(input.job.project.repositoryUrl)) {
    throw new RunnerFailure(
      'UNSAFE_REPOSITORY_URL',
      'HTTP(S) Git repository URLs must not contain credentials, query parameters, or fragments; configure an encrypted Authorization header instead'
    )
  }
  const authorizationHeader = input.job.project.gitAuthorization
    ? decryptSetting(input.job.project.gitAuthorization, input.options.settingsSecret)
    : undefined
  const gitEnvironment: NodeJS.ProcessEnv = {
    ...process.env,
    ...(authorizationHeader
      ? {
          GIT_CONFIG_COUNT: '1',
          GIT_CONFIG_KEY_0: 'http.extraHeader',
          GIT_CONFIG_VALUE_0: authorizationHeader,
        }
      : {}),
    GIT_TERMINAL_PROMPT: '0',
    GIT_SSH_COMMAND: gitSshCommand(),
  }
  const availableDiskBytes = input.options.availableDiskBytes || filesystemAvailableBytes
  const directClone = () =>
    withDirectCloneQueue(async () => {
      throwIfCanceled(input.signal)
      await executeCommand({
        command: 'git',
        args: ['check-ref-format', '--branch', input.job.branch],
        cwd: input.jobDirectory,
        env: gitEnvironment,
        log: input.log,
        displayCommand: 'git check-ref-format <branch>',
        signal: input.signal,
      })
      let releaseCapacity: () => void
      try {
        releaseCapacity = await reserveRepositoryCheckoutCapacity({
          root: input.options.runnerRoot,
          estimatedBytes:
            DEFAULT_REPOSITORY_CACHE_POLICY.cleanupFreeBytes -
            DEFAULT_REPOSITORY_CACHE_POLICY.rejectFreeBytes,
          rejectFreeBytes: DEFAULT_REPOSITORY_CACHE_POLICY.rejectFreeBytes,
          availableBytes: availableDiskBytes,
        })
      } catch (error) {
        if (error instanceof RepositoryCacheDiskPressureError) {
          throw diskPressureFailure(error.availableBytes)
        }
        throw error
      }
      try {
        await executeCommand({
          command: 'git',
          args: [
            'clone',
            '--depth',
            '1',
            '--single-branch',
            '--branch',
            input.job.branch,
            '--',
            input.job.project.repositoryUrl,
            input.sourceDirectory,
          ],
          cwd: input.jobDirectory,
          env: gitEnvironment,
          log: input.log,
          displayCommand: `git clone --depth 1 --single-branch --branch ${input.job.branch} <repository> ${input.sourceDirectory}`,
          signal: input.signal,
        })
        const afterClone = await availableDiskBytes(input.jobDirectory)
        if (afterClone < DEFAULT_REPOSITORY_CACHE_POLICY.rejectFreeBytes) {
          await rm(input.sourceDirectory, { recursive: true, force: true })
          throw diskPressureFailure(afterClone)
        }
      } finally {
        releaseCapacity()
      }
    }, input.signal)

  if (!input.options.repositoryCache) {
    await directClone()
    return
  }
  const credentialScope = await repositoryCredentialScope(
    input.job.project.repositoryUrl,
    authorizationHeader,
    input.options.readGitSshIdentity || (() => readFile(GIT_SSH_IDENTITY_PATH))
  )
  if (credentialScope === null) {
    writeLog(
      input.log,
      '[WARN] Git cache skipped because the configured SSH identity could not be fingerprinted safely'
    )
    await directClone()
    return
  }

  const checkoutInput: RepositoryCheckoutInput = {
    repositoryUrl: input.job.project.repositoryUrl,
    credentialScope,
    branch: input.job.branch,
    destination: input.sourceDirectory,
    cwd: input.jobDirectory,
    runGit: (request) =>
      executeCommand({
        command: 'git',
        args: request.args,
        cwd: request.cwd,
        env: gitEnvironment,
        log: input.log,
        displayCommand: request.displayCommand,
        captureStdout: request.captureStdout,
        signal: input.signal,
      }),
    log: (message) => writeLog(input.log, message),
    signal: input.signal,
  }

  try {
    await input.options.repositoryCache.checkout(checkoutInput)
  } catch (error) {
    if (input.signal?.aborted) throw cancellationFailure()
    if (error instanceof RepositoryCacheDiskPressureError) {
      throw new RunnerFailure('RUNNER_DISK_PRESSURE', error.message)
    }
    if (!(error instanceof RepositoryCacheUnavailableError)) throw error
    writeLog(
      input.log,
      `[WARN] Git cache unavailable (${error instanceof Error ? error.message : String(error)}); retrying the original shallow clone`
    )
    await rm(input.sourceDirectory, { recursive: true, force: true })
    await directClone()
  }
}

function shellCommand(command: string): { command: string; args: string[] } {
  return { command: '/bin/sh', args: ['-lc', command] }
}

export function packageManagerEnvironment(
  baseEnvironment: NodeJS.ProcessEnv,
  useChinaRegistry: boolean,
  allowPnpmDependencyBuilds = false
): NodeJS.ProcessEnv {
  const environment = { ...baseEnvironment }
  delete environment.npm_config_registry
  delete environment.NPM_CONFIG_REGISTRY
  delete environment.COREPACK_NPM_REGISTRY
  delete environment.npm_config_dangerously_allow_all_builds
  delete environment.pnpm_config_dangerously_allow_all_builds
  if (useChinaRegistry) {
    environment.npm_config_registry = CHINA_NPM_REGISTRY
    environment.COREPACK_NPM_REGISTRY = CHINA_NPM_REGISTRY
  }
  if (allowPnpmDependencyBuilds) {
    // pnpm 10 reads the npm-prefixed key; pnpm 11 reads the pnpm-prefixed key.
    environment.npm_config_dangerously_allow_all_builds = 'true'
    environment.pnpm_config_dangerously_allow_all_builds = 'true'
  }
  return environment
}

export function projectInstallEnvironment(
  baseEnvironment: NodeJS.ProcessEnv,
  useChinaRegistry: boolean,
  allowPnpmDependencyBuilds = false
): NodeJS.ProcessEnv {
  const environment = packageManagerEnvironment(
    baseEnvironment,
    useChinaRegistry,
    allowPnpmDependencyBuilds
  )
  delete environment.npm_config_omit
  delete environment.NPM_CONFIG_OMIT
  delete environment.npm_config_production
  delete environment.NPM_CONFIG_PRODUCTION
  delete environment.npm_config_only
  delete environment.NPM_CONFIG_ONLY
  return {
    ...environment,
    NODE_ENV: 'development',
    HUSKY: '0',
  }
}

/**
 * Stable inputs inherited by project commands. An explicit assignment inside the configured
 * shell command still wins, so existing project-owned command semantics are preserved.
 */
export function projectEnvironmentVariables(
  job: Pick<RunnerJobInput, 'environmentId' | 'environmentSlug' | 'project'>
): NodeJS.ProcessEnv {
  return {
    CUDDLY_ENVIRONMENT_SLUG: job.environmentSlug,
    CUDDLY_BACKEND_ORIGIN: job.project.environment.backendOrigin,
  }
}

export function runnerEnvironmentMatchesSnapshot(
  job: Pick<RunnerJobInput, 'environmentId' | 'environmentSlug' | 'project'>
): boolean {
  return (
    job.environmentId === job.project.environment.id &&
    job.environmentSlug === job.project.environment.slug
  )
}

export function commandUsesPnpm(command: string): boolean {
  return /(?:^|[;&|()]\s*)(?:(?:[A-Za-z_][A-Za-z0-9_]*=\S+)\s+)*(?:corepack\s+)?pnpm(?:@[\w.-]+)?(?=$|\s|[;&|()])/i.test(
    command
  )
}

export function packageManagerLockfileWarning(
  installCommand: string,
  lockfiles: { packageLock: boolean; pnpmLock: boolean }
): string | null {
  if (commandUsesPnpm(installCommand) && lockfiles.packageLock && !lockfiles.pnpmLock) {
    return "Install command uses pnpm, but the repository only contains package-lock.json; dependency resolution may differ from the project's intended npm workflow"
  }
  const usesNpm =
    /(?:^|[;&|()]\s*)(?:(?:[A-Za-z_][A-Za-z0-9_]*=\S+)\s+)*(?:corepack\s+)?npm(?:@[\w.-]+)?(?=$|\s|[;&|()])/i.test(
      installCommand
    )
  if (usesNpm && lockfiles.pnpmLock && !lockfiles.packageLock) {
    return "Install command uses npm, but the repository only contains pnpm-lock.yaml; dependency resolution may differ from the project's intended pnpm workflow"
  }
  return null
}

async function warnPackageManagerLockfileMismatch(
  projectDirectory: string,
  installCommand: string,
  log: WriteStream
): Promise<void> {
  const [packageLock = false, pnpmLock = false] = await Promise.all(
    ['package-lock.json', 'pnpm-lock.yaml'].map((filename) =>
      access(path.join(projectDirectory, filename)).then(
        () => true,
        () => false
      )
    )
  )
  const warning = packageManagerLockfileWarning(installCommand, { packageLock, pnpmLock })
  if (warning) writeLog(log, `[WARN] ${warning}`)
}

function remoteProviderName(targetId: string, artifactId: string): string {
  const target = targetId.replace(/[^A-Za-z0-9_]/g, '_')
  return `cuddly_${target}_${artifactId.replaceAll('-', '').slice(0, 12)}`
}

export function remoteArtifactPublicBase(artifactId: string, providerName: string): string {
  return `/__cuddly/preview-artifacts/${artifactId}/${providerName}/`
}

export function buildPublicPath(
  job: Pick<RunnerJobInput, 'artifactId' | 'project'>,
  remotePublicBase: string
): string | undefined {
  if (job.project.siteAdapter === 'kook-remote-v1') return remotePublicBase
  if (job.project.kind === 'webapp' || (!job.project.kind && job.project.id === 'webapp')) {
    return `/__cuddly/artifacts/${job.artifactId}/app/`
  }
  return undefined
}

async function closeLog(log: WriteStream): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    log.on('error', reject)
    log.end(resolve)
  })
}

export function patchOnlineH5AssetPrefixSource(source: string): string {
  let patched = source
  for (const key of ['test', 'online']) {
    const propertyPattern = new RegExp(
      `(^\\s*(?:${key}|["']${key}["'])\\s*:\\s*)([^\\r\\n,]+?)(\\s*,)`,
      'm'
    )
    const match = propertyPattern.exec(patched)
    if (!match) {
      throw new RunnerFailure(
        'ONLINE_H5_ASSET_PREFIX_UNSUPPORTED',
        `Online H5 CDN config does not expose the expected ${key} property`
      )
    }
    if (match[2]?.includes('process.env.CUDDLY_ASSET_PREFIX')) continue
    patched = patched.replace(propertyPattern, '$1process.env.CUDDLY_ASSET_PREFIX || $2$3')
  }
  return patched
}

async function applyAssetPrefixPatch(sourceDirectory: string, log: WriteStream) {
  const targetPath = path.join(sourceDirectory, 'rsbuild-config', 'cdnPath.js')
  let current: string
  try {
    current = await readFile(targetPath, 'utf8')
  } catch (error) {
    throw new RunnerFailure(
      'ONLINE_H5_ASSET_PREFIX_CONFIG_MISSING',
      `Online H5 CDN config is unavailable: ${error instanceof Error ? error.message : String(error)}`
    )
  }
  const patched = patchOnlineH5AssetPrefixSource(current)
  if (patched === current) {
    writeLog(log, 'CUDDLY_ASSET_PREFIX support is already present; patch skipped')
    return
  }
  await writeFile(targetPath, patched, 'utf8')
  writeLog(
    log,
    `Applied CUDDLY_ASSET_PREFIX support to ${path.relative(sourceDirectory, targetPath)}`
  )
}

export function patchRemoteAssetPrefixSource(source: string): string {
  if (source.includes('process.env.CUDDLY_ASSET_PREFIX ||')) return source
  const pattern =
    /(const\s+publicPath\s*=\s*)(`\$\{process\.env\.PUB_PATH\}\$\{(?:templateName|remoteName)\}\/`)/
  if (!pattern.test(source)) {
    throw new RunnerFailure(
      'REMOTE_ASSET_PREFIX_UNSUPPORTED',
      'Remote build config does not expose the expected PUB_PATH publicPath expression'
    )
  }
  return source.replace(pattern, '$1process.env.CUDDLY_ASSET_PREFIX || $2')
}

export function patchRemoteProviderVersionSource(source: string): string {
  const versionAwareDeclaration =
    /^\s*(?:const|let)\s+(?:templateName|remoteName)\s*=\s*(?:process\.env\.(?:VERSION|npm_config_VERSION|npm_config_version)\b|resolve_build_remote_version\s*\()/m
  if (versionAwareDeclaration.test(source)) return source

  const declaration = /^(\s*(?:const|let)\s+(?:templateName|remoteName)\s*=\s*)([^\r\n]+)$/m
  if (!declaration.test(source)) {
    throw new RunnerFailure(
      'REMOTE_PROVIDER_VERSION_UNSUPPORTED',
      'Remote build config does not expose a supported templateName or remoteName declaration'
    )
  }
  return source.replace(declaration, '$1process.env.VERSION || $2')
}

export function patchRemoteSentryPluginSource(source: string): string {
  if (
    !source.includes('sentryWebpackPlugin') ||
    source.includes('process.env.CUDDLY_DISABLE_SENTRY_UPLOAD')
  ) {
    return source
  }

  const pluginStart = /^([\t ]*)sentryWebpackPlugin\(\{(\r?\n)/m.exec(source)
  if (!pluginStart || pluginStart.index === undefined) return source

  const blockStart = pluginStart.index + pluginStart[0].length
  const blockEnd = source.indexOf(`${pluginStart[2]}${pluginStart[1]}})`, blockStart)
  if (blockEnd === -1) {
    throw new RunnerFailure(
      'REMOTE_SENTRY_CONFIG_UNSUPPORTED',
      'Remote Sentry plugin configuration could not be bounded safely'
    )
  }
  if (/^[\t ]*disable\s*:/m.test(source.slice(blockStart, blockEnd))) {
    throw new RunnerFailure(
      'REMOTE_SENTRY_CONFIG_UNSUPPORTED',
      'Remote Sentry plugin already defines a disable condition'
    )
  }

  const property = `${pluginStart[1]}  disable: process.env.CUDDLY_DISABLE_SENTRY_UPLOAD === '1',${pluginStart[2]}`
  return `${source.slice(0, blockStart)}${property}${source.slice(blockStart)}`
}

async function applyRemoteBuildPatches(outputDirectory: string, log: WriteStream) {
  const projectDirectory = path.dirname(outputDirectory)
  const configPath = path.join(projectDirectory, 'scripts', 'get_config.js')
  let current: string
  try {
    current = await readFile(configPath, 'utf8')
  } catch (error) {
    throw new RunnerFailure(
      'REMOTE_ASSET_PREFIX_CONFIG_MISSING',
      `Remote build config is unavailable: ${error instanceof Error ? error.message : String(error)}`
    )
  }
  const patched = patchRemoteAssetPrefixSource(patchRemoteProviderVersionSource(current))
  if (patched === current) {
    writeLog(log, 'CUDDLY_ASSET_PREFIX support is already present; Remote patch skipped')
  } else {
    await writeFile(configPath, patched, 'utf8')
    writeLog(
      log,
      `Applied CUDDLY_ASSET_PREFIX support to ${path.relative(projectDirectory, configPath)}`
    )
  }

  const rspackConfigPath = path.join(projectDirectory, 'scripts', 'rspack.config.build.js')
  let rspackConfig: string
  try {
    rspackConfig = await readFile(rspackConfigPath, 'utf8')
  } catch (error) {
    throw new RunnerFailure(
      'REMOTE_BUILD_CONFIG_MISSING',
      `Remote production build config is unavailable: ${error instanceof Error ? error.message : String(error)}`
    )
  }
  const patchedRspackConfig = patchRemoteSentryPluginSource(rspackConfig)
  if (patchedRspackConfig !== rspackConfig) {
    await writeFile(rspackConfigPath, patchedRspackConfig, 'utf8')
    writeLog(
      log,
      `Disabled Sentry release upload for Cuddly builds in ${path.relative(projectDirectory, rspackConfigPath)}`
    )
  }
}

async function executeBuild(
  job: RunnerJobInput,
  options: RunnerOptions,
  res: Response,
  cancellationSignal: AbortSignal
): Promise<void> {
  if (!runnerEnvironmentMatchesSnapshot(job)) {
    throw new RunnerFailure(
      'RUNNER_ENVIRONMENT_MISMATCH',
      'Runner job environment does not match its project configuration snapshot'
    )
  }
  const jobDirectory = path.join(options.runnerRoot, 'runner-jobs', job.jobId)
  const sourceDirectory = path.join(jobDirectory, 'source')
  const outputDirectory = path.resolve(sourceDirectory, job.project.outputDirectory)
  const relativeOutput = path.relative(sourceDirectory, outputDirectory)
  if (!relativeOutput || relativeOutput.startsWith('..') || path.isAbsolute(relativeOutput)) {
    throw new RunnerFailure(
      'INVALID_OUTPUT_DIRECTORY',
      'Output directory must stay inside the repository'
    )
  }
  const logDirectory = path.join(options.runnerRoot, 'logs')
  const logPath = path.join(logDirectory, `${job.jobId}.log`)
  let publishedStorageKey: string | null = null

  await mkdir(logDirectory, { recursive: true })
  await rm(jobDirectory, { recursive: true, force: true })
  await mkdir(jobDirectory, { recursive: true })
  const log = createWriteStream(logPath, { flags: 'a' })
  writeLog(log, `Environment: ${job.environmentSlug}`)
  writeLog(log, `Backend origin: ${job.project.environment.backendOrigin}`)

  const stage = (value: RunnerStage) => {
    throwIfCanceled(cancellationSignal)
    const at = new Date().toISOString()
    writeLog(log, `\n[${at}] ${value}`)
    writeEvent(res, { type: 'stage', stage: value, at })
  }

  try {
    throwIfCanceled(cancellationSignal)
    stage('CHECKOUT')
    await checkoutRepository({
      job,
      options,
      jobDirectory,
      sourceDirectory,
      log,
      signal: cancellationSignal,
    })
    throwIfCanceled(cancellationSignal)
    await warnPackageManagerLockfileMismatch(sourceDirectory, job.project.installCommand, log)
    if (job.project.siteAdapter === 'kook-online-h5-v1') {
      await applyAssetPrefixPatch(sourceDirectory, log)
    } else if (job.project.siteAdapter === 'kook-remote-v1') {
      await applyRemoteBuildPatches(outputDirectory, log)
    }
    throwIfCanceled(cancellationSignal)

    stage('INSTALLING')
    const install = shellCommand(job.project.installCommand)
    const useChinaRegistry = job.project.useChinaRegistry !== false
    const allowPnpmDependencyBuilds = commandUsesPnpm(job.project.installCommand)
    const installEnvironment = projectInstallEnvironment(
      process.env,
      useChinaRegistry,
      allowPnpmDependencyBuilds
    )
    Object.assign(installEnvironment, projectEnvironmentVariables(job))
    writeLog(
      log,
      useChinaRegistry
        ? `Package registry: ${CHINA_NPM_REGISTRY}`
        : 'Package registry: project or package-manager default'
    )
    if (allowPnpmDependencyBuilds) {
      writeLog(log, 'pnpm dependency build scripts: enabled for trusted project build')
    }
    await runCommand({
      ...install,
      cwd: sourceDirectory,
      env: installEnvironment,
      log,
      displayCommand: job.project.installCommand,
      signal: cancellationSignal,
    })

    throwIfCanceled(cancellationSignal)
    stage('BUILDING')
    const build = shellCommand(job.project.buildCommand)
    const artifactPublicBase = `/__cuddly/preview-artifacts/${job.artifactId}/`
    const providerName = remoteProviderName(job.targetId, job.artifactId)
    const remotePublicBase = remoteArtifactPublicBase(job.artifactId, providerName)
    const publicPath = buildPublicPath(job, artifactPublicBase)
    await runCommand({
      ...build,
      cwd: sourceDirectory,
      env: {
        ...packageManagerEnvironment(process.env, useChinaRegistry),
        ...projectEnvironmentVariables(job),
        NODE_ENV: 'production',
        PUB_PATH: publicPath,
        VERSION: job.project.siteAdapter === 'kook-remote-v1' ? providerName : undefined,
        npm_config_VERSION: job.project.siteAdapter === 'kook-remote-v1' ? providerName : undefined,
        CUDDLY_DISABLE_SENTRY_UPLOAD:
          job.project.siteAdapter === 'kook-remote-v1' ? '1' : undefined,
        CUDDLY_ASSET_PREFIX:
          job.project.siteAdapter === 'kook-remote-v1'
            ? remotePublicBase
            : publicPath || `/__cuddly/artifacts/${job.artifactId}/`,
      },
      log,
      displayCommand: job.project.buildCommand,
      signal: cancellationSignal,
    })

    throwIfCanceled(cancellationSignal)
    stage('VALIDATING')
    const builtAt = new Date().toISOString()
    const manifest =
      job.project.siteAdapter === 'kook-online-h5-v1'
        ? await createOnlineH5Manifest({
            outputDirectory,
            artifactId: job.artifactId,
            targetId: job.targetId,
            branch: job.branch,
            builtAt,
          })
        : job.project.siteAdapter === 'kook-remote-v1'
          ? await createRemoteManifest({
              outputDirectory,
              artifactId: job.artifactId,
              targetId: job.targetId,
              branch: job.branch,
              builtAt,
              publicBase: remotePublicBase,
              siteAdapter: job.project.siteAdapter,
              moduleKey: job.targetId,
              providerName,
            })
          : await createStaticManifest({
              outputDirectory,
              artifactId: job.artifactId,
              targetId: job.targetId,
              branch: job.branch,
              builtAt,
              siteAdapter: job.project.siteAdapter,
              publicBase: publicPath,
            })

    throwIfCanceled(cancellationSignal)
    stage('UPLOADING')
    const storageKey = await options.artifactStore.publishDirectory({
      sourceDirectory: outputDirectory,
      targetId: job.targetId,
      artifactId: job.artifactId,
      manifest,
    })
    publishedStorageKey = storageKey
    throwIfCanceled(cancellationSignal)
    writeEvent(res, {
      type: 'result',
      artifactId: job.artifactId,
      storageKey,
      manifest,
      builtAt,
      logPath,
    })
  } catch (error) {
    const failure =
      error instanceof RunnerFailure ? error : new RunnerFailure('RUNNER_FAILED', String(error))
    if (failure.code === 'BUILD_CANCELED' && publishedStorageKey) {
      await options.artifactStore
        .deleteArtifactDirectory({ artifactId: job.artifactId, storageKey: publishedStorageKey })
        .catch((cleanupError) =>
          writeLog(
            log,
            `[WARN] Canceled Artifact cleanup failed: ${cleanupError instanceof Error ? cleanupError.message : String(cleanupError)}`
          )
        )
    }
    writeLog(log, `\n[FAILED] ${failure.stack || failure.message}`)
    writeEvent(res, {
      type: 'error',
      code: failure.code,
      message: failure.message,
      logPath,
    })
  } finally {
    await closeLog(log)
    if (!options.keepWorkspace) await rm(jobDirectory, { recursive: true, force: true })
  }
}

export type RunnerExecutor = (
  job: RunnerJobInput,
  options: RunnerOptions,
  res: Response,
  cancellationSignal: AbortSignal
) => Promise<void>

export function createRunnerApp(options: RunnerOptions, runBuild: RunnerExecutor = executeBuild) {
  const app = express()
  const activeTargets = new Map<string, string>()
  const activeJobs = new Map<string, AbortController>()
  app.disable('x-powered-by')
  app.use(express.json({ limit: '64kb' }))

  app.get('/health/live', (_req, res) => res.json({ ok: true }))
  app.get('/health/ready', async (_req, res) => {
    await options.artifactStore.initialize()
    res.json({
      ok: true,
      busy: activeTargets.size > 0,
      activeCount: activeTargets.size,
      activeTargets: [...activeTargets.keys()],
    })
  })

  app.get('/internal/artifacts/inventory', async (req, res) => {
    if (!authorized(req, options.internalToken)) {
      res.status(401).json({ code: 'UNAUTHENTICATED' })
      return
    }
    res.json({ artifacts: await options.artifactStore.listArtifactInventory() })
  })

  app.post('/internal/artifacts/delete', async (req, res) => {
    if (!authorized(req, options.internalToken)) {
      res.status(401).json({ code: 'UNAUTHENTICATED' })
      return
    }
    const parsed = runnerArtifactDeleteSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_REQUEST', issues: parsed.error.issues })
      return
    }
    await options.artifactStore.deleteArtifactDirectory(parsed.data)
    res.status(204).end()
  })

  app.post('/internal/runs/:jobId/cancel', (req, res) => {
    if (!authorized(req, options.internalToken)) {
      res.status(401).json({ code: 'UNAUTHENTICATED' })
      return
    }
    const cancellation = activeJobs.get(req.params.jobId)
    if (!cancellation) {
      res.status(404).json({ code: 'RUNNER_JOB_NOT_FOUND' })
      return
    }
    cancellation.abort(cancellationFailure())
    res.status(202).json({ jobId: req.params.jobId, status: 'CANCELING' })
  })

  app.post('/internal/run', async (req, res) => {
    if (!authorized(req, options.internalToken)) {
      res.status(401).json({ code: 'UNAUTHENTICATED' })
      return
    }
    const parsed = runnerJobSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ code: 'INVALID_REQUEST', issues: parsed.error.issues })
      return
    }
    if (!runnerEnvironmentMatchesSnapshot(parsed.data)) {
      res.status(400).json({ code: 'RUNNER_ENVIRONMENT_MISMATCH' })
      return
    }
    const activeJobId = activeTargets.get(parsed.data.targetId)
    if (activeJobId) {
      res.status(409).json({
        code: 'RUNNER_TARGET_BUSY',
        targetId: parsed.data.targetId,
        activeJobId,
      })
      return
    }

    const cancellation = new AbortController()
    activeTargets.set(parsed.data.targetId, parsed.data.jobId)
    activeJobs.set(parsed.data.jobId, cancellation)
    res.status(200)
    res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8')
    res.setHeader('Cache-Control', 'no-store')
    res.flushHeaders()
    const heartbeat = setInterval(() => writeRunnerHeartbeat(res), 15_000)
    heartbeat.unref()
    const cancelOnDisconnect = () => {
      if (!res.writableEnded) cancellation.abort(cancellationFailure())
    }
    res.once('close', cancelOnDisconnect)
    try {
      await runBuild(parsed.data, options, res, cancellation.signal)
    } finally {
      clearInterval(heartbeat)
      res.off('close', cancelOnDisconnect)
      activeTargets.delete(parsed.data.targetId)
      activeJobs.delete(parsed.data.jobId)
      res.end()
    }
  })

  return app
}

export async function createRunnerOptions(): Promise<RunnerOptions> {
  const runnerRoot = process.env.NODE_ENV === 'production' ? '/srv/cuddly' : path.resolve('data')
  const settingsSecret = await readOrCreateSecret(
    process.env.NODE_ENV === 'production'
      ? '/srv/cuddly/secrets/settings.key'
      : path.resolve('data/secrets/settings.key')
  )
  return {
    internalToken: 'cuddly-internal-runner-v1',
    runnerRoot,
    artifactStore: createArtifactStore(),
    keepWorkspace: false,
    settingsSecret,
    repositoryCache: new RepositoryCache({
      root: path.join(runnerRoot, 'git-cache', 'v1'),
      secret: settingsSecret,
    }),
  }
}
