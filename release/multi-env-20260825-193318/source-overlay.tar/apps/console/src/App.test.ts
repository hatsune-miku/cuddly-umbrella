import { describe, expect, it } from 'vitest'
import type { SiteBinding } from '@cuddly/contracts'

import {
  DEFAULT_RESOURCE_PROXY_PREFIXES,
  isRevisionSelectionChanged,
  projectSiteSummary,
  revisionArtifactId,
  revisionSelections,
  selectedEnvironmentOrFirst,
  siteHostnameForId,
} from './App'

function siteBinding(id: string, targetId: string): SiteBinding {
  return {
    id,
    name: id,
    hostname: `${id}.bifrost.vanillacake.cn`,
    targetId,
    environmentSlug: 'shared',
    fallbackOrigin: 'https://www.kookapp.cn',
    upstreamOrigin: 'https://www.kookapp.cn',
    officialOrigin: `https://${id}.kookapp.cn`,
    enabled: true,
    remoteTargetIds: [],
    resourceProxyPrefixes: ['https://img.kookapp.cn/'],
  }
}

describe('site hostname generation', () => {
  it('proxies the complete KOOK image origin by default', () => {
    expect(DEFAULT_RESOURCE_PROXY_PREFIXES).toEqual(['https://img.kookapp.cn/'])
  })

  it('uses the deployed preview base domain by default', () => {
    expect(siteHostnameForId('main')).toBe('main.bifrost.vanillacake.cn')
    expect(siteHostnameForId('main-preview')).toBe('main-preview.bifrost.vanillacake.cn')
  })

  it('uses a runtime-provided preview base domain', () => {
    expect(siteHostnameForId('main', 'preview.example.test')).toBe('main.preview.example.test')
    expect(siteHostnameForId('mobile', '.QA.EXAMPLE.TEST.')).toBe('mobile.qa.example.test')
  })

  it('rejects invalid DNS-label site ids', () => {
    expect(siteHostnameForId('main_preview')).toBe('')
    expect(siteHostnameForId('main-')).toBe('')
    expect(siteHostnameForId('a'.repeat(64))).toBe('')
  })
})

describe('project site summary', () => {
  it('keeps remote projects distinct from page projects', () => {
    expect(projectSiteSummary({ id: 'base', kind: 'remote' }, [])).toBe('Remote')
    expect(projectSiteSummary({ id: 'webapp', kind: 'webapp' }, [])).toBe('未配置站点')
  })

  it('shows the hostname for one site and a count for multiple sites', () => {
    const main = siteBinding('main', 'webapp')
    const staging = siteBinding('staging', 'webapp')
    const mobile = siteBinding('mobile', 'online-h5')

    expect(projectSiteSummary({ id: 'webapp', kind: 'webapp' }, [main, mobile])).toBe(main.hostname)
    expect(projectSiteSummary({ id: 'webapp', kind: 'webapp' }, [main, staging, mobile])).toBe(
      '2 个站点'
    )
  })
})

describe('revision Artifact selection', () => {
  it('keeps the current Artifact when no candidate is staged', () => {
    expect(revisionArtifactId('current-artifact', undefined)).toBe('current-artifact')
    expect(revisionArtifactId(null, undefined)).toBeNull()
  })

  it('uses null as an explicit request to restore the official Remote', () => {
    expect(revisionArtifactId('current-remote', null)).toBeNull()
    expect(isRevisionSelectionChanged('current-remote', null)).toBe(true)
    expect(isRevisionSelectionChanged(null, null)).toBe(false)
  })

  it('keeps every current selection unless that target is explicitly restored to official', () => {
    const rows = [
      { target: { id: 'disabled-current' }, current: { artifactId: 'artifact-a' } },
      { target: { id: 'updated' }, current: { artifactId: 'artifact-b' } },
      { target: { id: 'official' }, current: { artifactId: 'artifact-c' } },
    ]
    expect(
      revisionSelections(rows, {
        updated: { id: 'artifact-b2' },
        official: { id: null },
      })
    ).toEqual([
      { targetId: 'disabled-current', artifactId: 'artifact-a' },
      { targetId: 'updated', artifactId: 'artifact-b2' },
    ])
  })
})

describe('environment settings selection', () => {
  const environments = [{ slug: 'shared' }, { slug: 'qa-local' }]

  it('opens the environment that is selected in the main console', () => {
    expect(selectedEnvironmentOrFirst(environments, 'qa-local')).toEqual({ slug: 'qa-local' })
  })

  it('falls back to the first environment when the current selection is unavailable', () => {
    expect(selectedEnvironmentOrFirst(environments, 'missing')).toEqual({ slug: 'shared' })
    expect(selectedEnvironmentOrFirst([], 'missing')).toBeNull()
  })
})
