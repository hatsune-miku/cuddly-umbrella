import type {
  BranchCatalogItem,
  BuildJob,
  BuildJobDetail,
  BuildJobLogView,
  BuildJobStatus,
  BuildQueueSnapshot,
  BuildTargetSettingsView,
  BuildTargetSummary,
  EnvironmentMatrix,
  EnvironmentRecord,
  EnvironmentRevision,
  ProjectEnvironmentConfig,
  ProxySettingsView,
  PublicRuntimeSettings,
  PreviewSessionView,
  SiteBinding,
  SystemSettingsView,
} from '@cuddly/contracts'

export interface EnvironmentSettingsView extends EnvironmentRecord {
  backendOrigin: string
}

export type ProjectEnvironmentSettingsView = ProjectEnvironmentConfig

const defaultActorName = 'QA Operator'

export function getActorName(): string {
  return localStorage.getItem('cuddly.displayName')?.trim() || defaultActorName
}

export function setActorName(value: string): string {
  const normalized = value.trim().replace(/\s+/g, ' ').slice(0, 40) || defaultActorName
  localStorage.setItem('cuddly.displayName', normalized)
  return normalized
}

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly body: unknown
  ) {
    super(`API request failed with ${status}`)
  }
}

async function request<T>(pathname: string, init?: RequestInit): Promise<T> {
  const response = await fetch(pathname, {
    credentials: 'include',
    ...init,
    headers: {
      'x-cuddly-actor': getActorName(),
      ...(init?.body ? { 'content-type': 'application/json' } : {}),
      ...init?.headers,
    },
  })
  if (!response.ok) {
    const body = await response.json().catch(() => null)
    throw new ApiError(response.status, body)
  }
  if (response.status === 204) return undefined as T
  return response.json() as Promise<T>
}

export async function getEnvironments(): Promise<{ items: EnvironmentSettingsView[] }> {
  return request('/api/v1/admin/environments')
}

export async function saveEnvironment(
  environment: Omit<EnvironmentSettingsView, 'id' | 'currentRevisionId'>
): Promise<EnvironmentSettingsView> {
  return request(`/api/v1/admin/environments/${encodeURIComponent(environment.slug)}`, {
    method: 'PUT',
    body: JSON.stringify(environment),
  })
}

export async function getEnvironmentProjectSettings(
  environmentSlug: string
): Promise<{ items: ProjectEnvironmentSettingsView[] }> {
  return request(`/api/v1/admin/environments/${encodeURIComponent(environmentSlug)}/projects`)
}

export async function saveEnvironmentProjectSettings(
  environmentSlug: string,
  items: ProjectEnvironmentSettingsView[]
): Promise<{ items: ProjectEnvironmentSettingsView[] }> {
  return request(`/api/v1/admin/environments/${encodeURIComponent(environmentSlug)}/projects`, {
    method: 'PUT',
    body: JSON.stringify({
      items: items.map(({ environmentId: _environmentId, ...item }) => item),
    }),
  })
}

export async function getMatrix(environmentSlug: string): Promise<EnvironmentMatrix> {
  return request(`/api/v1/environments/${encodeURIComponent(environmentSlug)}/matrix`)
}

export async function getBuildTargets(
  environmentSlug: string
): Promise<{ items: BuildTargetSummary[] }> {
  const query = new URLSearchParams({ environment: environmentSlug })
  return request(`/api/v1/build-targets?${query}`)
}

export async function getBranches(
  targetId: string,
  environmentSlug: string
): Promise<{
  items: BranchCatalogItem[]
  remoteAvailable: boolean
}> {
  const query = new URLSearchParams({ environment: environmentSlug })
  return request(`/api/v1/build-targets/${encodeURIComponent(targetId)}/branches?${query}`)
}

export async function createBuild(
  targetId: string,
  branch: string,
  environmentSlug: string
): Promise<BuildJob> {
  return request('/api/v1/build-jobs', {
    method: 'POST',
    headers: { 'idempotency-key': crypto.randomUUID() },
    body: JSON.stringify({ targetId, branch, environmentSlug, profile: 'qa-web' }),
  })
}

export async function getArtifacts(targetId: string, environmentSlug: string, branch?: string) {
  const query = new URLSearchParams({ targetId, environment: environmentSlug })
  if (branch) query.set('branch', branch)
  return request<{ items: unknown[] }>(`/api/v1/artifacts?${query}`)
}

export async function getBuildQueue(): Promise<BuildQueueSnapshot> {
  return request('/api/v1/build-queue')
}

export async function getBuildJob(jobId: string): Promise<BuildJob> {
  return request(`/api/v1/build-jobs/${jobId}`)
}

export async function cancelBuildJob(jobId: string): Promise<BuildJob> {
  return request(`/api/v1/build-jobs/${encodeURIComponent(jobId)}/cancel`, {
    method: 'POST',
  })
}

export async function getBuildHistory(
  filters: {
    environmentSlug?: string
    targetId?: string
    status?: BuildJobStatus | ''
    query?: string
    before?: string
    limit?: number
  } = {}
): Promise<{ items: BuildJob[]; nextCursor: string | null }> {
  const query = new URLSearchParams()
  if (filters.environmentSlug) query.set('environment', filters.environmentSlug)
  if (filters.targetId) query.set('targetId', filters.targetId)
  if (filters.status) query.set('status', filters.status)
  if (filters.query) query.set('query', filters.query)
  if (filters.before) query.set('before', filters.before)
  query.set('limit', String(filters.limit || 50))
  return request(`/api/v1/build-jobs?${query}`)
}

export async function getBuildJobDetail(jobId: string): Promise<BuildJobDetail> {
  return request(`/api/v1/build-jobs/${encodeURIComponent(jobId)}/detail`)
}

export async function getBuildJobLog(jobId: string): Promise<BuildJobLogView> {
  return request(`/api/v1/build-jobs/${encodeURIComponent(jobId)}/log`)
}

export async function getProxySettings(): Promise<ProxySettingsView> {
  return request('/api/v1/admin/proxy-settings')
}

export async function getProjectSettings(): Promise<{ items: BuildTargetSettingsView[] }> {
  return request('/api/v1/admin/build-targets')
}

export async function getSiteBindings(): Promise<{ items: SiteBinding[] }> {
  return request('/api/v1/admin/site-bindings')
}

export async function saveSiteBinding(
  binding: SiteBinding & { fallbackOrigin?: string }
): Promise<SiteBinding & { fallbackOrigin?: string }> {
  return request(`/api/v1/admin/site-bindings/${encodeURIComponent(binding.id)}`, {
    method: 'PUT',
    body: JSON.stringify(binding),
  })
}

export async function deleteSiteBinding(bindingId: string): Promise<void> {
  await request(`/api/v1/admin/site-bindings/${encodeURIComponent(bindingId)}`, {
    method: 'DELETE',
  })
}

export async function saveProjectSettings(
  project: Omit<
    BuildTargetSettingsView,
    'configurationSource' | 'canReset' | 'gitAuthorizationConfigured'
  > & {
    gitAuthorizationHeader?: string
    clearGitAuthorizationHeader?: boolean
  }
): Promise<BuildTargetSettingsView> {
  return request(`/api/v1/admin/build-targets/${encodeURIComponent(project.id)}`, {
    method: 'PUT',
    body: JSON.stringify({ ...project, repositoryUrl: project.repositoryUrl || '' }),
  })
}

export async function resetProjectSettings(targetId: string): Promise<BuildTargetSettingsView> {
  return request(`/api/v1/admin/build-targets/${encodeURIComponent(targetId)}/reset`, {
    method: 'POST',
  })
}

export async function updateProxySettings(input: {
  enabled?: boolean
  subscriptionUrl?: string
  refreshIntervalMinutes?: number
}): Promise<ProxySettingsView> {
  return request('/api/v1/admin/proxy-settings', {
    method: 'PATCH',
    body: JSON.stringify(input),
  })
}

export async function resetProxySettings(
  keys: Array<'enabled' | 'subscriptionUrl' | 'refreshIntervalMinutes'>
): Promise<ProxySettingsView> {
  return request('/api/v1/admin/proxy-settings/reset', {
    method: 'POST',
    body: JSON.stringify({ keys }),
  })
}

export async function refreshProxySettings(): Promise<ProxySettingsView> {
  return request('/api/v1/admin/proxy-settings/refresh', { method: 'POST' })
}

export async function getSystemSettings(): Promise<SystemSettingsView> {
  return request('/api/v1/admin/system-settings')
}

export async function updateSystemSettings(input: {
  cookieDomain: string
  buildMaxConcurrency: number
  runnerRequestTimeoutMinutes: number
  useChinaRegistry: boolean
  proxyRewriteMaxMegabytes: number
  autoSslEnabled: boolean
  autoSslEmail: string
}): Promise<SystemSettingsView> {
  return request('/api/v1/admin/system-settings', {
    method: 'PATCH',
    body: JSON.stringify(input),
  })
}

export async function getPublicRuntimeSettings(): Promise<PublicRuntimeSettings> {
  return request('/api/v1/runtime')
}

export async function createPreview(input: {
  siteBindingId: string
  siteArtifactId?: string
  selections?: Array<{ targetId: string; artifactId: string }>
  ttlMinutes?: number
}): Promise<PreviewSessionView> {
  return request('/api/v1/previews', {
    method: 'POST',
    body: JSON.stringify(input),
  })
}

export async function publishRevision(
  environmentSlug: string,
  input: {
    baseRevisionId: string | null
    selections: Array<{ targetId: string; artifactId: string }>
    message: string
  }
): Promise<EnvironmentRevision> {
  return request(`/api/v1/environments/${encodeURIComponent(environmentSlug)}/revisions`, {
    method: 'POST',
    body: JSON.stringify({
      baseRevisionId: input.baseRevisionId,
      message: input.message,
      selections: input.selections,
    }),
  })
}
