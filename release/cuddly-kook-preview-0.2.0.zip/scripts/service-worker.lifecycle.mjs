import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import test from 'node:test'
import vm from 'node:vm'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const source = await readFile(path.join(root, 'service-worker.js'), 'utf8')
const activeKey = 'cuddly.activePreviews'
const alarmPrefix = 'cuddly.previewExpiry.'

function clone(value) {
  return value === undefined ? undefined : structuredClone(value)
}

function createHarness({ active = {}, rules = [], tabs = [] } = {}) {
  const storage = { [activeKey]: clone(active) }
  const sessionRules = clone(rules)
  const alarms = new Map()
  const listeners = {}
  const event = (name) => ({ addListener: (listener) => (listeners[name] = listener) })
  const chrome = {
    alarms: {
      create: async (name, info) => void alarms.set(name, clone(info)),
      clear: async (name) => alarms.delete(name),
      getAll: async () => [...alarms].map(([name, info]) => ({ name, ...clone(info) })),
      onAlarm: event('alarm'),
    },
    declarativeNetRequest: {
      getSessionRules: async () => clone(sessionRules),
      updateSessionRules: async ({ addRules = [], removeRuleIds = [] }) => {
        for (const ruleId of removeRuleIds) {
          const index = sessionRules.findIndex((rule) => rule.id === ruleId)
          if (index >= 0) sessionRules.splice(index, 1)
        }
        sessionRules.push(...clone(addRules))
      },
    },
    runtime: {
      onInstalled: event('installed'),
      onMessage: event('message'),
      onStartup: event('startup'),
    },
    storage: {
      local: {
        get: async (key) => ({ [key]: clone(storage[key]) }),
        set: async (values) => Object.assign(storage, clone(values)),
      },
    },
    tabs: {
      onRemoved: event('removed'),
      query: async () => clone(tabs),
    },
  }
  const context = vm.createContext({ chrome, Date, Promise, URL })
  new vm.Script(source, { filename: 'service-worker.js' }).runInContext(context)
  return {
    alarms,
    sessionRules,
    listeners,
    storage,
    flush: () => vm.runInContext('mutationQueue', context),
  }
}

async function sendMessage(harness, message) {
  return new Promise((resolve) => {
    assert.equal(harness.listeners.message(message, {}, resolve), true)
  })
}

test('creates and clears a one-time expiry alarm with a preview', async () => {
  const harness = createHarness({ tabs: [{ id: 7 }] })
  const expiresAt = new Date(Date.now() + 60_000).toISOString()
  const applied = await sendMessage(harness, {
    type: 'apply-remote-preview',
    tabId: 7,
    webappOrigin: 'https://www.kookapp.cn',
    hotModuleUrl: 'https://bifrost.vanillacake.cn/preview/hot-module',
    preview: { token: 'preview', expiresAt, selections: [] },
  })

  assert.equal(applied.ok, true)
  assert.equal(harness.sessionRules.length, 2)
  assert.ok(harness.sessionRules.every((rule) => rule.condition.tabIds?.[0] === 7))
  assert.equal(harness.alarms.get(`${alarmPrefix}7`).when, Date.parse(expiresAt))
  assert.equal(harness.storage[activeKey]['7'].preview.token, 'preview')

  const removed = await sendMessage(harness, { type: 'remove-preview', tabId: 7 })
  assert.equal(removed.ok, true)
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.alarms.has(`${alarmPrefix}7`), false)
  assert.equal(harness.storage[activeKey]['7'], undefined)
})

test('restores valid alarms and removes expired or closed-tab previews', async () => {
  const future = new Date(Date.now() + 60_000).toISOString()
  const past = new Date(Date.now() - 60_000).toISOString()
  const active = {
    1: {
      mode: 'remote',
      ruleIds: [1001, 1002],
      preview: { expiresAt: future },
      webappOrigin: 'https://www.kookapp.cn',
      hotModuleUrl: 'https://bifrost.vanillacake.cn/preview/valid/hot-module',
    },
    2: {
      mode: 'remote',
      ruleIds: [1003, 1004],
      preview: { expiresAt: past },
      webappOrigin: 'https://www.kookapp.cn',
      hotModuleUrl: 'https://bifrost.vanillacake.cn/preview/expired/hot-module',
    },
    3: {
      mode: 'site',
      ruleIds: [1005],
      preview: { token: 'closed', expiresAt: future },
      previewOrigin: 'https://main.bifrost.vanillacake.cn',
    },
  }
  const harness = createHarness({
    active,
    rules: [{ id: 1999 }],
    tabs: [
      { id: 1, url: 'https://www.kookapp.cn/channels/1' },
      { id: 2, url: 'https://www.kookapp.cn/channels/2' },
    ],
  })
  harness.alarms.set(`${alarmPrefix}99`, { when: Date.now() + 60_000 })

  harness.listeners.installed({ reason: 'update' })
  await harness.flush()

  assert.deepEqual(Object.keys(harness.storage[activeKey]), ['1'])
  assert.deepEqual(
    harness.sessionRules.map((rule) => rule.id),
    [1001, 1002]
  )
  assert.equal(harness.alarms.get(`${alarmPrefix}1`).when, Date.parse(future))
  assert.equal(harness.alarms.has(`${alarmPrefix}99`), false)

  harness.storage[activeKey]['1'].preview.expiresAt = past
  harness.listeners.alarm({ name: `${alarmPrefix}1` })
  await harness.flush()

  assert.equal(harness.storage[activeKey]['1'], undefined)
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.alarms.has(`${alarmPrefix}1`), false)
})

test('applies a site preview with one tab-scoped session header rule', async () => {
  const harness = createHarness({
    tabs: [{ id: 11, url: 'https://main.bifrost.vanillacake.cn/channels/11' }],
  })
  const expiresAt = new Date(Date.now() + 60_000).toISOString()

  const applied = await sendMessage(harness, {
    type: 'apply-site-preview',
    tabId: 11,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    officialOrigin: 'https://www.kookapp.cn',
    originalUrl: 'https://www.kookapp.cn/channels/11',
    targetUrl: 'https://main.bifrost.vanillacake.cn/channels/11',
    preview: { token: 'site-preview', expiresAt, selections: [] },
  })

  assert.equal(applied.ok, true)
  assert.equal(harness.sessionRules.length, 1)
  assert.deepEqual(harness.sessionRules[0].condition.tabIds, [11])
  assert.deepEqual(harness.sessionRules[0].action.requestHeaders, [
    { header: 'x-cuddly-preview-token', operation: 'set', value: 'site-preview' },
  ])
})
