import {
  createBranchPicker,
  describeBranchBuild,
  endedQueueTargetIds,
  flattenBuildQueue,
  prepareTargetBranchItems,
} from './branch-picker.js'
import {
  createPreviewRequest,
  mergeSelectedBranches,
  planPreviewApplication,
  previewDestinationUrl,
  resolveSelectedArtifacts,
  SITE_BINDING_REQUIRED,
} from './preview-routing.js'
import {
  APPLY_SITE_PREVIEW_TRANSACTION_COMMAND,
  extensionCommandErrorMessage,
  REMOVE_PREVIEW_TRANSACTION_COMMAND,
  requireExtensionCapabilities,
} from './extension-protocol.js'
import {
  bindingEnvironmentLabel,
  chooseBindingCandidate,
  normalizeBindingCandidates,
} from './binding-selection.js'
import { normalizeActorName, resolveActorIdentity } from './popup-identity.js'
import {
  buildJobPresentation,
  buildQueueSummary,
  isBuildSubmissionLocked,
  orderedBuildQueue,
  replaceBuildQueueJob,
  shouldPollBuildJob,
  TERMINAL_BUILD_STATUSES,
} from './build-queue.js'
import {
  operationMatchesContext,
  POPUP_SCOPED_STATE_KEY,
  readScopedPopupState,
  writeScopedPopupState,
} from './popup-state.js'

const CONTROL_KEY = 'cuddly.controlOrigin'
const ACTOR_KEY = 'cuddly.actorName'
const ACTOR_ID_KEY = 'cuddly.actorId'
const ACTIVE_KEY = 'cuddly.activePreviews'
const ENVIRONMENT_PREFS_KEY = 'cuddly.environmentByOfficialOrigin'
const DEFAULT_CONTROL_ORIGIN = 'https://bifrost.vanillacake.cn'
const BUILD_QUEUE_POLL_MS = 2_500
const emptyQueue = { running: [], queued: [] }

const state = {
  tab: null,
  controlOrigin: DEFAULT_CONTROL_ORIGIN,
  actorId: '',
  actorOverride: '',
  actorName: '',
  binding: null,
  bindingCandidates: [],
  bindingPreferenceKey: null,
  environmentPreferences: {},
  environment: null,
  targets: [],
  targetNames: {},
  siteTargetId: null,
  currentSiteBranch: '',
  branches: {},
  selectedBranches: {},
  active: null,
  busyTargets: new Map(),
  submittedBuildBranches: {},
  applyingToken: null,
  cancelingJobs: new Set(),
  dirtyCatalogTargets: new Set(),
  queue: emptyQueue,
  queueLastSuccessAt: null,
  queueRefreshError: '',
  selectedJobId: null,
  jobDetail: null,
  jobLog: null,
  jobDetailTab: 'overview',
  jobDetailError: '',
  jobDetailRefreshError: '',
  jobDetailLoading: false,
  jobLogFollow: true,
  jobLogScrollTop: 0,
  jobDetailScrollTop: 0,
}

const elements = {
  pageTitle: document.querySelector('#page-title'),
  pageMeta: document.querySelector('#page-meta'),
  queueJumpButton: document.querySelector('#queue-jump-button'),
  queueJumpCount: document.querySelector('#queue-jump-count'),
  refreshButton: document.querySelector('#refresh-button'),
  settingsButton: document.querySelector('#settings-button'),
  settingsDialog: document.querySelector('#settings-dialog'),
  settingsForm: document.querySelector('#settings-form'),
  settingsCancel: document.querySelector('#settings-cancel'),
  settingsClose: document.querySelector('#settings-close'),
  controlOrigin: document.querySelector('#control-origin'),
  actorName: document.querySelector('#actor-name'),
  actorHint: document.querySelector('#actor-hint'),
  environmentBar: document.querySelector('#environment-bar'),
  environmentSelect: document.querySelector('#environment-select'),
  environmentHint: document.querySelector('#environment-hint'),
  activePanel: document.querySelector('#active-panel'),
  activeSummary: document.querySelector('#active-summary'),
  removeButton: document.querySelector('#remove-button'),
  moduleList: document.querySelector('#module-list'),
  queuePanel: document.querySelector('#queue-panel'),
  queueSummary: document.querySelector('#queue-summary'),
  queueList: document.querySelector('#queue-list'),
  selectionSummary: document.querySelector('#selection-summary'),
  applyButton: document.querySelector('#apply-button'),
  applyButtonWrap: document.querySelector('#apply-button-wrap'),
  statusBar: document.querySelector('#status-bar'),
  statusText: document.querySelector('#status-text'),
  branchPickerDialog: document.querySelector('#branch-picker-dialog'),
  jobDetailDialog: document.querySelector('#job-detail-dialog'),
  jobDetailTitle: document.querySelector('#job-detail-title'),
  jobDetailContext: document.querySelector('#job-detail-context'),
  jobDetailClose: document.querySelector('#job-detail-close'),
  jobOverviewTab: document.querySelector('#job-overview-tab'),
  jobLogTab: document.querySelector('#job-log-tab'),
  jobDetailContent: document.querySelector('#job-detail-content'),
  jobDetailRefreshHint: document.querySelector('#job-detail-refresh-hint'),
  jobDetailCancel: document.querySelector('#job-detail-cancel'),
}

const branchPicker = createBranchPicker(elements.branchPickerDialog)
let queuePollTimer = null
let queuePollRunning = false
let loadGeneration = 0
let jobDetailGeneration = 0
let scopedStorageArea = null
let scopedStateCache = null
let scopedStateWriteChain = Promise.resolve()

function setStatus(text, tone = '') {
  elements.statusText.textContent = text
  elements.statusBar.className = `status-bar ${tone}`.trim()
}

function formatTime(value) {
  if (!value) return '尚未打包'
  return new Intl.DateTimeFormat('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(new Date(value))
}

function errorText(error) {
  if (error?.body?.message) return error.body.message
  return error instanceof Error ? error.message : String(error)
}

async function apiWithContext(context, pathname, init) {
  const response = await fetch(`${context.controlOrigin.replace(/\/$/, '')}${pathname}`, {
    ...init,
    headers: {
      'x-cuddly-actor': context.actorName,
      ...(init?.body ? { 'content-type': 'application/json' } : {}),
      ...init?.headers,
    },
  })
  const body = await response.json().catch(() => null)
  if (!response.ok) {
    const error = new Error(`Cuddly 返回 HTTP ${response.status}`)
    error.status = response.status
    error.body = body
    throw error
  }
  return body
}

async function api(pathname, init) {
  return apiWithContext(
    { controlOrigin: state.controlOrigin, actorName: state.actorName },
    pathname,
    init
  )
}

async function popupStateStorageArea() {
  if (scopedStorageArea) return scopedStorageArea
  const session = chrome.storage?.session
  if (session?.get && session?.set) {
    try {
      await session.get(POPUP_SCOPED_STATE_KEY)
      scopedStorageArea = session
      return scopedStorageArea
    } catch {
      // Older Chromium builds may expose storage.session without allowing this context to use it.
    }
  }
  scopedStorageArea = chrome.storage.local
  return scopedStorageArea
}

async function readPersistedPopupState(tabId, bindingId) {
  const area = await popupStateStorageArea()
  if (!scopedStateCache) {
    const stored = await area.get(POPUP_SCOPED_STATE_KEY)
    scopedStateCache = stored[POPUP_SCOPED_STATE_KEY] || {}
  }
  return readScopedPopupState(scopedStateCache, { tabId, bindingId })
}

function persistPopupState({ tabId, bindingId, selectedBranches, submittedBuildBranches }) {
  scopedStateWriteChain = scopedStateWriteChain
    .catch(() => undefined)
    .then(async () => {
      const area = await popupStateStorageArea()
      if (!scopedStateCache) {
        const stored = await area.get(POPUP_SCOPED_STATE_KEY)
        scopedStateCache = stored[POPUP_SCOPED_STATE_KEY] || {}
      }
      scopedStateCache = writeScopedPopupState(scopedStateCache, {
        tabId,
        bindingId,
        selectedBranches,
        submittedBuildBranches,
      })
      await area.set({ [POPUP_SCOPED_STATE_KEY]: scopedStateCache })
    })
  return scopedStateWriteChain.catch(() => undefined)
}

function persistCurrentPopupState() {
  const tabId = state.tab?.id
  const bindingId = state.binding?.id
  if (!Number.isInteger(tabId) || !bindingId) return Promise.resolve()
  return persistPopupState({
    tabId,
    bindingId,
    selectedBranches: { ...state.selectedBranches },
    submittedBuildBranches: { ...state.submittedBuildBranches },
  })
}

function currentOperationContext(targetId = '', branch = '') {
  return {
    tabId: state.tab?.id,
    bindingId: state.binding?.id || '',
    environmentSlug: state.binding?.environmentSlug || '',
    targetId,
    branch,
    contextVersion: loadGeneration,
  }
}

async function optionalApi(pathname) {
  try {
    return await api(pathname)
  } catch (error) {
    if (error?.status === 404) return null
    throw error
  }
}

function branchForArtifact(targetId, artifactId) {
  if (!artifactId) return ''
  return (
    state.branches[targetId]?.items?.find((item) => item.latestArtifact?.id === artifactId)
      ?.branch || ''
  )
}

function selectedArtifacts() {
  return resolveSelectedArtifacts({
    targets: state.targets,
    selectedBranches: state.selectedBranches,
    branchCatalogs: state.branches,
    siteTargetId: state.siteTargetId,
  })
}

function previewOrigin() {
  if (!state.binding) return null
  try {
    const current = new URL(state.tab?.url || '')
    const protocol = current.hostname === state.binding.hostname ? current.protocol : 'https:'
    return `${protocol}//${state.binding.hostname}`
  } catch {
    return `https://${state.binding.hostname}`
  }
}

function isPreviewHostname(tabUrl, binding) {
  try {
    return new URL(tabUrl).hostname === binding.hostname
  } catch {
    return false
  }
}

function activeSummary() {
  if (!state.active?.preview) return ''
  const labels = []
  if (state.active.preview.siteArtifactId && state.binding) {
    const branch =
      state.active.preview.siteSelection?.branch ||
      branchForArtifact(state.binding.targetId, state.active.preview.siteArtifactId)
    labels.push(`${state.binding.name} · ${branch || '页面产物'}`)
  }
  for (const selection of state.active.preview.selections || []) {
    labels.push(`${selection.moduleKey} · ${selection.branch}`)
  }
  return labels.join('；') || '已应用预览产物'
}

function renderActive() {
  elements.activePanel.hidden = !state.active
  if (!state.active) return
  elements.activeSummary.textContent = activeSummary()
}

function renderEnvironmentPicker() {
  const candidates = state.bindingCandidates || []
  const show = candidates.length > 1
  elements.environmentBar.hidden = !show
  elements.environmentSelect.replaceChildren()
  if (!show) return

  for (const binding of candidates) {
    const option = document.createElement('option')
    option.value = binding.id
    option.textContent = bindingEnvironmentLabel(binding)
    option.selected = binding.id === state.binding?.id
    elements.environmentSelect.append(option)
  }
  elements.environmentHint.textContent = `${candidates.length} 个可选`
}

function targetBranchItems(target, catalog, selectedBranch) {
  return prepareTargetBranchItems({
    target,
    catalog,
    selectedBranch,
    environmentStatus: state.environment?.status || '',
  })
}

function officialChoice(isSite) {
  return isSite
    ? { label: '官网页面', detail: '不替换页面产物' }
    : { label: '官方热更', detail: '由 KOOK 官方热更响应决定' }
}

function openTargetBranchPicker(target, trigger) {
  const isSite = target.id === state.siteTargetId
  const catalog = state.branches[target.id] || { items: [], remoteAvailable: false }
  const selectedBranch = state.selectedBranches[target.id] || ''
  branchPicker.open({
    targetId: target.id,
    targetName: target.name,
    items: targetBranchItems(target, catalog, selectedBranch),
    queue: state.queue,
    environmentSlug: state.binding?.environmentSlug || '',
    selectedBranch,
    official: officialChoice(isSite),
    trigger,
    onSelect: (branch) => {
      if (state.selectedBranches[target.id] !== branch) {
        delete state.submittedBuildBranches[target.id]
      }
      state.selectedBranches[target.id] = branch
      renderModules()
      void persistCurrentPopupState()
    },
  })
}

function refreshOpenBranchPicker() {
  const target = state.targets.find((candidate) => candidate.id === branchPicker.targetId)
  if (!target) {
    if (branchPicker.targetId) branchPicker.close({ restoreFocus: false })
    return
  }
  const selectedBranch = state.selectedBranches[target.id] || ''
  const catalog = state.branches[target.id] || { items: [], remoteAvailable: false }
  branchPicker.update({
    items: targetBranchItems(target, catalog, selectedBranch),
    queue: state.queue,
    environmentSlug: state.binding?.environmentSlug || '',
    selectedBranch,
  })
}

function renderModules() {
  elements.moduleList.replaceChildren()
  if (!state.targets.length) {
    const empty = document.createElement('div')
    empty.className = 'empty-state'
    empty.innerHTML = state.binding
      ? '<strong>这个站点还没有可用项目</strong><span>检查页面项目、Remote 项目是否已启用并配置 Git 仓库。</span>'
      : '<strong>当前页面没有站点绑定</strong><span>在管理后台添加站点，并把它对应到当前官网地址。</span>'
    elements.moduleList.append(empty)
  }

  for (const target of state.targets) {
    const isSite = target.id === state.siteTargetId
    const catalog = state.branches[target.id] || { items: [], remoteAvailable: false }
    const branch = state.selectedBranches[target.id] || ''
    const branchItems = targetBranchItems(target, catalog, branch)
    const branchItem = branch ? branchItems.find((item) => item.branch === branch) : null
    const artifact = branchItem?.latestArtifact || null
    const buildPresentation = branch
      ? describeBranchBuild({
          item: branchItem,
          queueItems: flattenBuildQueue(state.queue),
          targetId: target.id,
          environmentSlug: state.binding?.environmentSlug || '',
        })
      : null
    const row = document.createElement('article')
    row.className = `module-row ${isSite ? 'site-module' : 'remote-module'}`

    const heading = document.createElement('div')
    heading.className = 'module-heading'
    const name = document.createElement('strong')
    name.textContent = target.name
    heading.append(name)
    if (isSite) {
      const kind = document.createElement('span')
      kind.className = 'module-kind site-kind'
      kind.textContent = '页面'
      heading.append(kind)
    }

    const controls = document.createElement('div')
    controls.className = 'module-controls'
    const pickerTrigger = document.createElement('button')
    pickerTrigger.type = 'button'
    pickerTrigger.className = 'branch-picker-trigger'
    pickerTrigger.dataset.targetId = target.id
    pickerTrigger.setAttribute('aria-label', `${target.name} 分支`)
    pickerTrigger.setAttribute('aria-haspopup', 'dialog')
    pickerTrigger.setAttribute('aria-expanded', 'false')
    pickerTrigger.setAttribute('aria-controls', 'branch-picker-dialog')
    const pickerValue = document.createElement('span')
    pickerValue.className = 'branch-picker-trigger-value'
    pickerValue.textContent = branch || officialChoice(isSite).label
    pickerValue.title = pickerValue.textContent
    const pickerChevron = document.createElement('span')
    pickerChevron.className = 'branch-picker-trigger-chevron'
    pickerChevron.setAttribute('aria-hidden', 'true')
    pickerChevron.textContent = '⌄'
    pickerTrigger.append(pickerValue, pickerChevron)
    pickerTrigger.addEventListener('click', () => openTargetBranchPicker(target, pickerTrigger))
    const build = document.createElement('button')
    build.type = 'button'
    build.className = 'secondary-button build-button'
    const submitting = operationMatchesContext(
      state.busyTargets.get(target.id),
      currentOperationContext(target.id, branch),
      { requireBranch: true }
    )
    const submitted = isBuildSubmissionLocked(state.submittedBuildBranches, target.id, branch)
    const activeBuild = Boolean(buildPresentation?.active)
    const environmentActive = state.environment?.status === 'ACTIVE'
    build.textContent = submitting
      ? '提交中'
      : submitted
        ? '已提交'
        : activeBuild
          ? buildPresentation.status === 'QUEUED'
            ? '已排队'
            : '构建中'
          : '打最新包'
    build.disabled =
      submitting ||
      submitted ||
      activeBuild ||
      !branch ||
      !environmentActive ||
      !target.enabled ||
      !target.configured
    if (submitted) {
      build.title = '任务已提交；刷新数据或切换分支后可再次提交'
    } else if (activeBuild) {
      build.title = '该分支已有活动任务，可点击下方进度状态查看详情'
    } else if (!branch) {
      build.title = '请先选择要打包的分支'
    } else if (!environmentActive || !target.enabled || !target.configured) {
      build.title = !target.configured
        ? '项目未配置 Git 仓库，只能选择已有产物进行预览'
        : state.environment?.status === 'FROZEN'
          ? '环境已冻结，只能选择已有产物进行预览'
          : state.environment?.status === 'ARCHIVED'
            ? '环境已归档，不能发起构建'
            : '项目当前不可构建'
    }
    build.addEventListener('click', () => void createBuild(target.id, branch))
    controls.append(pickerTrigger, build)

    const meta = document.createElement('div')
    meta.className = 'module-meta'
    const builtAt = document.createElement('span')
    builtAt.textContent = !branch
      ? isSite
        ? `使用 ${state.binding?.officialOrigin || '官网页面'}`
        : '由 KOOK 官方热更响应决定'
      : artifact
        ? `上次打包 ${formatTime(artifact.builtAt)}`
        : '这个分支还没有可用产物'
    const buildState = document.createElement(buildPresentation?.jobId ? 'button' : 'span')
    if (buildState instanceof HTMLButtonElement) {
      buildState.type = 'button'
      buildState.className = 'queue-job-link'
      buildState.title = '打开当前构建的详情和日志'
      buildState.addEventListener('click', () => void openJobDetail(buildPresentation.jobId))
    }
    if (!branch) {
      buildState.textContent = isSite ? '不替换页面' : '不覆盖'
    } else if (buildPresentation?.active) {
      buildState.classList.add('working')
      buildState.textContent = buildPresentation.label
    } else if (buildPresentation?.tone === 'failed') {
      buildState.classList.add('failed')
      buildState.textContent = buildPresentation.label
    } else if (buildPresentation?.tone === 'canceled') {
      buildState.textContent = buildPresentation.label
    } else if (state.environment?.status === 'FROZEN') {
      buildState.textContent = '环境已冻结，可预览已有包'
    } else if (!target.configured) {
      buildState.textContent = '未配置 Git，可预览已有包'
    } else if (!target.enabled) {
      buildState.textContent = '当前环境不可构建'
    } else if (isSite && state.active?.mode !== 'site' && branch === state.currentSiteBranch) {
      buildState.textContent = '当前环境'
    } else {
      buildState.textContent = catalog.remoteAvailable ? 'Git 已连接' : '使用本地分支记录'
    }
    meta.append(builtAt, buildState)
    row.append(heading, controls, meta)
    elements.moduleList.append(row)
  }

  const selected = selectedArtifacts()
  const plan = planPreviewApplication({
    binding: state.binding,
    previewOrigin: previewOrigin(),
    siteArtifactId: selected.siteArtifactId,
    selections: selected.selections,
  })
  const labels = state.targets
    .filter((target) => state.selectedBranches[target.id])
    .map((target) => `${target.name} · ${state.selectedBranches[target.id]}`)
  elements.selectionSummary.textContent = labels.length ? labels.join('；') : '全部使用官网版本'
  const missingReason = selected.missing.length
    ? `${selected.missing[0].targetName} 的 ${selected.missing[0].branch} 尚无成功可用的产物${selected.missing.length > 1 ? `，另有 ${selected.missing.length - 1} 项也未就绪` : ''}`
    : ''
  const applyDisabledReason = state.applyingToken
    ? '正在应用到当前标签页，请稍候'
    : missingReason || plan.reason || ''
  elements.applyButton.textContent = state.applyingToken ? '应用中' : '应用'
  elements.applyButton.disabled = Boolean(applyDisabledReason)
  elements.applyButton.title = applyDisabledReason
  elements.applyButtonWrap.title = applyDisabledReason
  elements.applyButtonWrap.tabIndex = applyDisabledReason ? 0 : -1
  if (applyDisabledReason) {
    elements.applyButtonWrap.setAttribute('aria-label', `无法应用：${applyDisabledReason}`)
  } else {
    elements.applyButtonWrap.removeAttribute('aria-label')
  }
  elements.applyButton.setAttribute(
    'aria-label',
    applyDisabledReason ? `无法应用：${applyDisabledReason}` : '应用到当前标签页'
  )
  refreshOpenBranchPicker()
}

function fullTime(value) {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '—'
  return new Intl.DateTimeFormat('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).format(date)
}

function targetDisplayName(targetId) {
  return state.targetNames[targetId] || targetId
}

function renderProgress(presentation, className = 'build-progress') {
  const wrap = document.createElement('span')
  wrap.className = className
  const track = document.createElement('span')
  track.className = 'build-progress-track'
  track.setAttribute('role', 'progressbar')
  track.setAttribute('aria-valuemin', '0')
  track.setAttribute('aria-valuemax', '100')
  track.setAttribute('aria-valuenow', String(presentation.progress))
  track.setAttribute('aria-label', `${presentation.label}，阶段进度 ${presentation.progressLabel}`)
  const value = document.createElement('span')
  value.className = `build-progress-value ${presentation.tone}`
  value.style.width = `${presentation.progress}%`
  track.append(value)
  const label = document.createElement('span')
  label.className = 'build-progress-label'
  label.textContent = presentation.progressLabel
  wrap.append(track, label)
  return wrap
}

function renderBuildQueue() {
  const jobs = orderedBuildQueue(state.queue)
  const runningCount = state.queue?.running?.length || 0
  const queuedCount = state.queue?.queued?.length || 0
  elements.queueJumpCount.textContent = String(jobs.length)
  elements.queueJumpButton.setAttribute(
    'aria-label',
    `查看全局构建队列，运行 ${runningCount}，排队 ${queuedCount}`
  )
  const queueSummary = buildQueueSummary(state.queue)
  if (state.queueRefreshError) {
    const lastSuccess = state.queueLastSuccessAt
      ? `最后成功 ${formatTime(state.queueLastSuccessAt)}`
      : '尚无成功刷新'
    elements.queueSummary.textContent = `${queueSummary} · 刷新中断 · ${lastSuccess}`
    elements.queueSummary.title = `队列刷新失败：${state.queueRefreshError}`
  } else {
    elements.queueSummary.textContent = queueSummary
    elements.queueSummary.removeAttribute('title')
  }
  elements.queueList.replaceChildren()
  if (!jobs.length) {
    const empty = document.createElement('div')
    empty.className = 'queue-empty'
    empty.textContent =
      state.queueRefreshError && !state.queueLastSuccessAt
        ? '构建队列刷新中断，暂时无法确认打包机状态。'
        : '打包机当前空闲，没有排队或运行中的任务。'
    elements.queueList.append(empty)
    return
  }

  const fragment = document.createDocumentFragment()
  for (const job of jobs) {
    const presentation = buildJobPresentation(job)
    const item = document.createElement('article')
    item.className = `queue-item ${presentation.tone}${
      job.environmentSlug === state.binding?.environmentSlug ? ' current-environment' : ''
    }`

    const open = document.createElement('button')
    open.type = 'button'
    open.className = 'queue-job-open'
    open.title = '打开任务详情、命令和实时日志'
    open.addEventListener('click', () => void openJobDetail(job.id))

    const heading = document.createElement('span')
    heading.className = 'queue-job-heading'
    const name = document.createElement('strong')
    name.textContent = `${targetDisplayName(job.targetId)} · ${job.branch}`
    name.title = `${job.targetId} · ${job.branch}`
    const status = document.createElement('span')
    status.className = `queue-status ${presentation.tone}`
    status.textContent = presentation.label
    heading.append(name, status)

    const meta = document.createElement('span')
    meta.className = 'queue-job-meta'
    const actor = job.requestedBy || '未记录操作人'
    meta.textContent = `${job.environmentSlug || '未记录环境'} · ${
      job.isMine ? '我（' + actor + '）' : actor
    } · ${formatTime(job.startedAt || job.createdAt)}`
    open.append(heading, meta, renderProgress(presentation))
    item.append(open)

    if (presentation.cancelable) {
      const cancel = document.createElement('button')
      cancel.type = 'button'
      cancel.className = 'queue-cancel-button'
      cancel.textContent = state.cancelingJobs.has(job.id) ? '中断中' : '中断'
      cancel.disabled = state.cancelingJobs.has(job.id)
      cancel.title = job.status === 'QUEUED' ? '取消这个排队任务' : '请求 Runner 中断这个任务'
      cancel.addEventListener('click', () => void cancelBuildJob(job.id))
      item.append(cancel)
    }
    fragment.append(item)
  }
  elements.queueList.append(fragment)
}

function appendDetailField(list, labelText, valueText, title = '') {
  const row = document.createElement('div')
  const label = document.createElement('dt')
  label.textContent = labelText
  const value = document.createElement('dd')
  value.textContent = valueText
  if (title) value.title = title
  row.append(label, value)
  list.append(row)
}

function sectionTitle(text) {
  const heading = document.createElement('h3')
  heading.textContent = text
  return heading
}

function renderJobOverview(detail) {
  const fragment = document.createDocumentFragment()
  const presentation = buildJobPresentation(detail.job)
  const snapshotEnvironment = detail.job.targetSnapshot?.environment || null
  const summary = document.createElement('section')
  summary.className = 'job-summary-card'
  const status = document.createElement('div')
  status.className = 'job-summary-status'
  const badge = document.createElement('strong')
  badge.className = `queue-status ${presentation.tone}`
  badge.textContent = presentation.label
  status.append(badge, renderProgress(presentation, 'build-progress detail-progress'))
  summary.append(status)

  const fields = document.createElement('dl')
  fields.className = 'job-detail-fields'
  appendDetailField(fields, '项目', targetDisplayName(detail.job.targetId), detail.job.targetId)
  appendDetailField(
    fields,
    '环境',
    snapshotEnvironment?.name
      ? `${snapshotEnvironment.name} · ${detail.job.environmentSlug}`
      : detail.job.environmentSlug || '未记录'
  )
  appendDetailField(
    fields,
    '业务后端',
    snapshotEnvironment?.backendOrigin || '历史任务未记录',
    snapshotEnvironment?.backendOrigin || ''
  )
  appendDetailField(fields, '操作人', detail.job.requestedBy || '未记录')
  appendDetailField(fields, '提交', fullTime(detail.job.createdAt))
  appendDetailField(fields, '开始', fullTime(detail.job.startedAt))
  appendDetailField(fields, '结束', fullTime(detail.job.finishedAt))
  summary.append(fields)

  if (detail.job.failureMessage) {
    const failure = document.createElement('div')
    failure.className = 'job-failure'
    const code = document.createElement('strong')
    code.textContent = detail.job.failureCode || 'BUILD_FAILED'
    const message = document.createElement('span')
    message.textContent = detail.job.failureMessage
    failure.append(code, message)
    summary.append(failure)
  }
  fragment.append(summary)

  const timeline = document.createElement('section')
  timeline.className = 'job-detail-section'
  timeline.append(sectionTitle('执行时间线'))
  const events = document.createElement('ol')
  events.className = 'job-timeline'
  for (const event of detail.events || []) {
    const row = document.createElement('li')
    const dot = document.createElement('span')
    dot.className = `timeline-dot ${buildJobPresentation(event).tone}`
    const copy = document.createElement('span')
    const name = document.createElement('strong')
    name.textContent = buildJobPresentation(event).label
    const time = document.createElement('time')
    time.textContent = fullTime(event.createdAt)
    copy.append(name, time)
    row.append(dot, copy)
    events.append(row)
  }
  if (!events.children.length) {
    const empty = document.createElement('p')
    empty.className = 'detail-empty-copy'
    empty.textContent = '暂无执行事件'
    timeline.append(empty)
  } else {
    timeline.append(events)
  }
  fragment.append(timeline)

  const commands = document.createElement('section')
  commands.className = 'job-detail-section'
  commands.append(sectionTitle('执行命令'))
  const commandList = document.createElement('div')
  commandList.className = 'job-command-list'
  for (const step of detail.commands || []) {
    const row = document.createElement('div')
    const label = document.createElement('span')
    label.textContent = step.label
    const command = document.createElement('code')
    command.textContent = step.command
    row.append(label, command)
    commandList.append(row)
  }
  if (!commandList.children.length) {
    const empty = document.createElement('p')
    empty.className = 'detail-empty-copy'
    empty.textContent = '历史任务没有保存命令快照'
    commands.append(empty)
  } else {
    commands.append(commandList)
  }
  fragment.append(commands)

  const result = document.createElement('section')
  result.className = 'job-detail-section job-result'
  result.append(sectionTitle('构建结果'))
  if (detail.artifact) {
    const resultFields = document.createElement('dl')
    resultFields.className = 'job-detail-fields compact-fields'
    appendDetailField(resultFields, 'Artifact', detail.artifact.id.slice(0, 12), detail.artifact.id)
    appendDetailField(resultFields, '文件', `${detail.artifact.fileCount} 个`)
    appendDetailField(resultFields, '生成', fullTime(detail.artifact.builtAt))
    result.append(resultFields)
  } else {
    const empty = document.createElement('p')
    empty.className = 'detail-empty-copy'
    empty.textContent = TERMINAL_BUILD_STATUSES.has(detail.job.status)
      ? '任务没有生成可用产物'
      : '构建完成后显示产物信息'
    result.append(empty)
  }
  fragment.append(result)
  return fragment
}

function renderJobLog(detail, log) {
  const section = document.createElement('section')
  section.className = 'job-log-section'
  const toolbar = document.createElement('div')
  toolbar.className = 'job-log-toolbar'
  const stateText = document.createElement('span')
  stateText.textContent = log
    ? `${log.complete ? '日志已结束' : '实时日志'}${log.truncated ? ' · 已截断' : ''}`
    : '正在读取日志'
  const actions = document.createElement('span')
  actions.className = 'job-log-actions'
  const copy = document.createElement('button')
  copy.type = 'button'
  copy.className = 'text-button compact-action'
  copy.textContent = '复制'
  copy.disabled = !log?.content
  copy.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(log?.content || '')
      setStatus('日志已复制', 'success')
    } catch (error) {
      setStatus(`复制失败：${errorText(error)}`, 'warning')
    }
  })
  const download = document.createElement('a')
  download.className = 'text-link compact-action'
  download.href = `${state.controlOrigin.replace(/\/$/, '')}/api/v1/build-jobs/${encodeURIComponent(
    detail.job.id
  )}/log?download=1`
  download.target = '_blank'
  download.rel = 'noreferrer'
  download.textContent = '下载'
  actions.append(copy, download)
  toolbar.append(stateText, actions)
  const consoleView = document.createElement('pre')
  consoleView.className = 'job-console'
  consoleView.tabIndex = 0
  consoleView.textContent = log?.content || (log?.complete ? '没有日志输出' : '等待 Runner 输出...')
  consoleView.addEventListener('scroll', () => {
    state.jobLogScrollTop = consoleView.scrollTop
    state.jobLogFollow =
      consoleView.scrollHeight - consoleView.scrollTop - consoleView.clientHeight < 28
  })
  section.append(toolbar, consoleView)
  window.requestAnimationFrame(() => {
    if (state.jobLogFollow) {
      consoleView.scrollTop = consoleView.scrollHeight
    } else {
      consoleView.scrollTop = state.jobLogScrollTop
    }
  })
  return section
}

function renderJobDetail() {
  const detail = state.jobDetail
  const preservedScrollTop = state.jobDetailScrollTop
  elements.jobOverviewTab.classList.toggle('active', state.jobDetailTab === 'overview')
  elements.jobLogTab.classList.toggle('active', state.jobDetailTab === 'log')
  elements.jobOverviewTab.setAttribute('aria-selected', String(state.jobDetailTab === 'overview'))
  elements.jobLogTab.setAttribute('aria-selected', String(state.jobDetailTab === 'log'))
  elements.jobDetailContent.replaceChildren()
  const expectedJobId = state.selectedJobId
  const expectedTab = state.jobDetailTab
  window.requestAnimationFrame(() => {
    if (state.selectedJobId === expectedJobId && state.jobDetailTab === expectedTab) {
      elements.jobDetailContent.scrollTop = preservedScrollTop
      state.jobDetailScrollTop = preservedScrollTop
    }
  })

  if (detail) {
    elements.jobDetailTitle.textContent = detail.job.branch
    const environmentName = detail.job.targetSnapshot?.environment?.name
    elements.jobDetailContext.textContent = `${targetDisplayName(detail.job.targetId)} · ${
      environmentName
        ? `${environmentName} · ${detail.job.environmentSlug}`
        : detail.job.environmentSlug || '未记录环境'
    } · ${detail.job.requestedBy || '未记录操作人'} · ${detail.job.id.slice(0, 8)}`
    const presentation = buildJobPresentation(detail.job)
    elements.jobDetailCancel.hidden = !presentation.cancelable
    elements.jobDetailCancel.disabled = state.cancelingJobs.has(detail.job.id)
    elements.jobDetailCancel.textContent = state.cancelingJobs.has(detail.job.id)
      ? '正在中断'
      : '中断构建'
    const refreshHint = TERMINAL_BUILD_STATUSES.has(detail.job.status)
      ? '任务已结束'
      : '任务进行中，每 2.5 秒自动刷新'
    elements.jobDetailRefreshHint.textContent = state.jobDetailRefreshError
      ? `${refreshHint} · 刷新中断`
      : refreshHint
    if (state.jobDetailRefreshError) {
      elements.jobDetailRefreshHint.title = state.jobDetailRefreshError
    } else {
      elements.jobDetailRefreshHint.removeAttribute('title')
    }
  } else {
    elements.jobDetailTitle.textContent = '构建任务'
    elements.jobDetailContext.textContent = state.selectedJobId?.slice(0, 8) || '正在读取任务'
    elements.jobDetailCancel.hidden = true
  }

  if (state.jobDetailError) {
    const error = document.createElement('div')
    error.className = 'job-detail-message error'
    const message = document.createElement('span')
    message.textContent = state.jobDetailError
    const retry = document.createElement('button')
    retry.type = 'button'
    retry.className = 'text-button'
    retry.textContent = '重试'
    retry.addEventListener('click', () => void refreshJobDetail())
    error.append(message, retry)
    elements.jobDetailContent.append(error)
    return
  }
  if (!detail) {
    const loading = document.createElement('div')
    loading.className = 'job-detail-message'
    loading.textContent = state.jobDetailLoading ? '正在读取任务详情…' : '暂无任务详情'
    elements.jobDetailContent.append(loading)
    return
  }
  elements.jobDetailContent.append(
    state.jobDetailTab === 'log' ? renderJobLog(detail, state.jobLog) : renderJobOverview(detail)
  )
}

async function refreshJobDetail() {
  const jobId = state.selectedJobId
  if (!jobId) return
  const generation = ++jobDetailGeneration
  state.jobDetailLoading = !state.jobDetail
  state.jobDetailError = ''
  renderJobDetail()
  try {
    const wantsLog = state.jobDetailTab === 'log'
    const [detail, log] = await Promise.all([
      api(`/api/v1/build-jobs/${encodeURIComponent(jobId)}/detail`),
      wantsLog
        ? api(`/api/v1/build-jobs/${encodeURIComponent(jobId)}/log`)
        : Promise.resolve(state.jobLog),
    ])
    if (generation !== jobDetailGeneration || state.selectedJobId !== jobId) return
    state.jobDetail = detail
    if (wantsLog) state.jobLog = log
    state.jobDetailRefreshError = ''
  } catch (error) {
    if (generation !== jobDetailGeneration || state.selectedJobId !== jobId) return
    if (state.jobDetail) {
      state.jobDetailRefreshError = `刷新失败：${errorText(error)}`
    } else {
      state.jobDetailError = `读取失败：${errorText(error)}`
    }
  } finally {
    if (generation === jobDetailGeneration && state.selectedJobId === jobId) {
      state.jobDetailLoading = false
      renderJobDetail()
    }
  }
}

async function openJobDetail(jobId) {
  state.selectedJobId = jobId
  state.jobDetail = null
  state.jobLog = null
  state.jobLogFollow = true
  state.jobLogScrollTop = 0
  state.jobDetailScrollTop = 0
  state.jobDetailTab = 'overview'
  state.jobDetailError = ''
  state.jobDetailRefreshError = ''
  state.jobDetailLoading = true
  renderJobDetail()
  if (!elements.jobDetailDialog.open) {
    elements.jobDetailDialog.showModal()
    window.requestAnimationFrame(() => elements.jobDetailClose.focus())
  }
  await refreshJobDetail()
}

function closeJobDetail() {
  jobDetailGeneration += 1
  state.selectedJobId = null
  state.jobDetail = null
  state.jobLog = null
  state.jobDetailScrollTop = 0
  state.jobDetailError = ''
  state.jobDetailRefreshError = ''
  if (elements.jobDetailDialog.open) elements.jobDetailDialog.close()
}

async function changeJobDetailTab(tab) {
  if (tab !== 'overview' && tab !== 'log') return
  state.jobDetailTab = tab
  state.jobDetailScrollTop = 0
  renderJobDetail()
  if (tab === 'log') await refreshJobDetail()
}

async function cancelBuildJob(jobId) {
  if (!jobId || state.cancelingJobs.has(jobId)) return
  state.cancelingJobs.add(jobId)
  renderBuildQueue()
  renderJobDetail()
  setStatus('正在提交中断请求', 'busy')
  let canceled = null
  try {
    canceled = await api(`/api/v1/build-jobs/${encodeURIComponent(jobId)}/cancel`, {
      method: 'POST',
    })
  } catch (error) {
    setStatus(`中断失败：${errorText(error)}`, 'warning')
    return
  } finally {
    if (!canceled) {
      state.cancelingJobs.delete(jobId)
      renderBuildQueue()
      renderJobDetail()
    }
  }

  try {
    state.queue = replaceBuildQueueJob(state.queue, canceled)
    if (state.jobDetail?.job.id === jobId) {
      state.jobDetail = { ...state.jobDetail, job: canceled }
    }
    setStatus(
      canceled.status === 'CANCELED' ? '构建已取消' : '已提交中断请求',
      canceled.status === 'CANCELED' ? 'success' : 'busy'
    )
    renderBuildQueue()
    renderJobDetail()
    scheduleQueuePoll(300)
  } finally {
    state.cancelingJobs.delete(jobId)
    renderBuildQueue()
    renderJobDetail()
  }
}

async function resolveBindings(tabUrl) {
  if (!tabUrl) return { candidates: [], preferenceKey: null }
  const url = new URL(tabUrl)
  const byHostname = normalizeBindingCandidates(
    await optionalApi(`/api/v1/site-bindings/resolve?hostname=${encodeURIComponent(url.hostname)}`)
  )
  if (byHostname.length) return { candidates: byHostname, preferenceKey: null }

  const byOfficialOrigin = normalizeBindingCandidates(
    await optionalApi(
      `/api/v1/site-bindings/candidates?officialOrigin=${encodeURIComponent(url.origin)}`
    )
  )
  return { candidates: byOfficialOrigin, preferenceKey: url.origin }
}

async function loadActive() {
  const stored = (await chrome.storage.local.get(ACTIVE_KEY))[ACTIVE_KEY] || {}
  const active = stored[String(state.tab.id)] || null
  const expiresAt = Date.parse(active?.preview?.expiresAt || '')
  if (
    active &&
    (active.mode !== 'site' || !Number.isFinite(expiresAt) || expiresAt <= Date.now())
  ) {
    const result = await chrome.runtime.sendMessage({
      type: REMOVE_PREVIEW_TRANSACTION_COMMAND,
      tabId: state.tab.id,
    })
    state.active = result?.ok ? null : active
  } else {
    state.active = active
  }
  renderActive()
}

async function refreshBranchCatalog(targetId) {
  if (!state.targets.some((target) => target.id === targetId)) return false
  const bindingId = state.binding?.id || ''
  const environmentSlug = state.binding?.environmentSlug || ''
  if (!bindingId || !environmentSlug) return false
  try {
    const catalog = await api(
      `/api/v1/build-targets/${encodeURIComponent(targetId)}/branches?environment=${encodeURIComponent(environmentSlug)}`
    )
    if (state.binding?.id !== bindingId) return false
    state.branches[targetId] = catalog
    return true
  } catch {
    return false
  }
}

function queueSnapshotSignature(snapshot) {
  return flattenBuildQueue(snapshot)
    .map(
      (job) =>
        `${job.id}:${job.environmentSlug || ''}:${job.status}:${job.queuePosition ?? ''}:${job.startedAt || ''}:${job.createdAt}:${job.requestedBy || ''}:${job.isMine ? 'mine' : ''}`
    )
    .sort()
    .join('|')
}

async function applyQueueSnapshot(nextQueue, { refreshEnded = true } = {}) {
  const previousJobs = flattenBuildQueue(state.queue)
  const previousSignature = queueSnapshotSignature(state.queue)
  state.queue = nextQueue || emptyQueue
  const queueChanged = previousSignature !== queueSnapshotSignature(state.queue)
  if (queueChanged) {
    renderModules()
    renderBuildQueue()
  }

  if (refreshEnded && previousJobs.length) {
    for (const targetId of endedQueueTargetIds(
      { running: previousJobs, queued: [] },
      state.queue,
      state.targets.map((target) => target.id),
      state.binding?.environmentSlug || ''
    )) {
      state.dirtyCatalogTargets.add(targetId)
    }
  }

  const retryTargets = [...state.dirtyCatalogTargets].filter((targetId) =>
    state.targets.some((target) => target.id === targetId)
  )
  if (!retryTargets.length) return
  const results = await Promise.all(
    retryTargets.map(async (targetId) => [targetId, await refreshBranchCatalog(targetId)])
  )
  let refreshed = false
  for (const [targetId, succeeded] of results) {
    if (!succeeded) continue
    state.dirtyCatalogTargets.delete(targetId)
    refreshed = true
  }
  if (refreshed) renderModules()
}

function scheduleQueuePoll(delay = BUILD_QUEUE_POLL_MS) {
  if (queuePollTimer !== null) window.clearTimeout(queuePollTimer)
  queuePollTimer = window.setTimeout(() => {
    queuePollTimer = null
    void pollBuildQueue()
  }, delay)
}

async function pollBuildQueue() {
  if (queuePollRunning) return
  if (queuePollTimer !== null) {
    window.clearTimeout(queuePollTimer)
    queuePollTimer = null
  }
  queuePollRunning = true
  try {
    const nextQueue = await api('/api/v1/build-queue')
    state.queueLastSuccessAt = Date.now()
    state.queueRefreshError = ''
    await applyQueueSnapshot(nextQueue)
    renderBuildQueue()
    if (state.selectedJobId && shouldPollBuildJob(state.jobDetail)) {
      await refreshJobDetail()
    }
  } catch (error) {
    // Keep the last known queue state; a transient polling error must not hide branch choices.
    state.queueRefreshError = errorText(error)
    renderBuildQueue()
  } finally {
    queuePollRunning = false
    scheduleQueuePoll()
  }
}

async function load({ resetSubmitted = false } = {}) {
  const generation = ++loadGeneration
  if (resetSubmitted) {
    state.submittedBuildBranches = {}
    await persistCurrentPopupState()
    if (generation !== loadGeneration) return
  }
  const previousBindingId = state.binding?.id || null
  const previousSelectedBranches = { ...state.selectedBranches }
  const previousSubmittedBuildBranches = { ...state.submittedBuildBranches }
  setStatus('正在读取站点、项目和分支', 'busy')
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (generation !== loadGeneration) return
  state.tab = tab
  const saved = await chrome.storage.local.get([
    CONTROL_KEY,
    ACTOR_KEY,
    ACTOR_ID_KEY,
    ENVIRONMENT_PREFS_KEY,
  ])
  if (generation !== loadGeneration) return
  const identity = resolveActorIdentity({
    storedActorId: saved[ACTOR_ID_KEY],
    storedActorName: saved[ACTOR_KEY],
  })
  state.controlOrigin = saved[CONTROL_KEY] || DEFAULT_CONTROL_ORIGIN
  state.actorId = identity.actorId
  state.actorOverride = identity.actorOverride
  state.actorName = identity.actorName
  state.environmentPreferences =
    saved[ENVIRONMENT_PREFS_KEY] && typeof saved[ENVIRONMENT_PREFS_KEY] === 'object'
      ? saved[ENVIRONMENT_PREFS_KEY]
      : {}
  elements.controlOrigin.value = state.controlOrigin
  elements.actorName.value = state.actorOverride
  elements.actorName.placeholder = state.actorId
  elements.actorHint.textContent = `留空时使用本机标识 ${state.actorId}；仅用于队列和审计，不是登录身份。`
  if (
    saved[ACTOR_ID_KEY] !== state.actorId ||
    normalizeActorName(saved[ACTOR_KEY]) !== state.actorOverride
  ) {
    await chrome.storage.local.set({
      [ACTOR_ID_KEY]: state.actorId,
      [ACTOR_KEY]: state.actorOverride,
    })
  }
  elements.pageTitle.textContent = tab?.title || '当前标签页'
  elements.pageMeta.textContent = tab?.url || '无法读取页面地址'
  await loadActive()
  if (generation !== loadGeneration) return

  try {
    const [resolution, queueResult] = await Promise.all([
      resolveBindings(tab?.url),
      api('/api/v1/build-queue')
        .then((queue) => ({ queue, error: null }))
        .catch((error) => ({ queue: state.queue, error })),
    ])
    if (generation !== loadGeneration) return
    const binding = chooseBindingCandidate({
      candidates: resolution.candidates,
      rememberedEnvironmentSlug: resolution.preferenceKey
        ? state.environmentPreferences[resolution.preferenceKey]
        : '',
      activeSiteBindingId: state.active?.preview?.siteBindingId || '',
    })
    if (previousBindingId !== (binding?.id || null)) {
      state.dirtyCatalogTargets.clear()
      state.submittedBuildBranches = {}
      state.busyTargets.clear()
      state.targets = []
      state.targetNames = {}
      state.branches = {}
      state.selectedBranches = {}
      branchPicker.close({ restoreFocus: false })
    }
    state.queue = queueResult.queue || emptyQueue
    if (queueResult.error) {
      state.queueRefreshError = errorText(queueResult.error)
    } else {
      state.queueLastSuccessAt = Date.now()
      state.queueRefreshError = ''
    }
    state.bindingCandidates = resolution.candidates
    state.bindingPreferenceKey = resolution.preferenceKey
    state.binding = binding
    state.environment = null
    state.currentSiteBranch = ''
    renderEnvironmentPicker()

    if (binding) {
      const environment = encodeURIComponent(binding.environmentSlug)
      const [targetBody, matrix] = await Promise.all([
        api(`/api/v1/build-targets?environment=${environment}`),
        isPreviewHostname(tab?.url, binding)
          ? api(`/api/v1/environments/${environment}/matrix`)
          : Promise.resolve(null),
      ])
      if (generation !== loadGeneration) return
      const allTargets = targetBody.items || []
      state.targetNames = Object.fromEntries(allTargets.map((target) => [target.id, target.name]))
      state.environment = targetBody.environment || null
      const allowedIds = new Set([binding.targetId, ...(binding.remoteTargetIds || [])])
      state.targets = allTargets.filter((target) => allowedIds.has(target.id))
      state.siteTargetId = state.targets.some((target) => target.id === binding.targetId)
        ? binding.targetId
        : null
      if (state.siteTargetId && matrix) {
        state.currentSiteBranch =
          matrix.rows?.find((row) => row.target.id === binding.targetId)?.current?.branch || ''
      }
      elements.pageTitle.textContent = binding.name
    } else {
      state.targets = []
      state.targetNames = {}
      state.siteTargetId = null
    }

    const catalogs = await Promise.all(
      state.targets.map(async (target) => [
        target.id,
        await api(
          `/api/v1/build-targets/${encodeURIComponent(target.id)}/branches?environment=${encodeURIComponent(binding.environmentSlug)}`
        ),
      ])
    )
    if (generation !== loadGeneration) return
    state.branches = Object.fromEntries(catalogs)
    const persistedPopupState = binding
      ? await readPersistedPopupState(tab?.id, binding.id).catch(() => null)
      : null
    if (generation !== loadGeneration) return
    const defaultSelectedBranches = {}
    for (const target of state.targets) {
      if (target.id === state.siteTargetId) {
        const activeUsesOfficialPage =
          state.active?.mode === 'site' && !state.active.preview?.siteArtifactId
        defaultSelectedBranches[target.id] = activeUsesOfficialPage
          ? ''
          : state.active?.preview?.siteSelection?.branch ||
            branchForArtifact(target.id, state.active?.preview?.siteArtifactId) ||
            state.currentSiteBranch
        continue
      }
      const activeSelection = state.active?.preview?.selections?.find(
        (item) => item.targetId === target.id
      )
      defaultSelectedBranches[target.id] =
        activeSelection?.branch || branchForArtifact(target.id, activeSelection?.artifactId)
    }
    const inMemoryPopupState =
      previousBindingId === (binding?.id || null)
        ? {
            selectedBranches: previousSelectedBranches,
            submittedBuildBranches: previousSubmittedBuildBranches,
          }
        : null
    const restoredPopupState = persistedPopupState || inMemoryPopupState
    state.selectedBranches = mergeSelectedBranches({
      sameBinding: Boolean(restoredPopupState),
      previous: restoredPopupState?.selectedBranches || {},
      defaults: defaultSelectedBranches,
    })
    const allowedTargetIds = new Set(state.targets.map((target) => target.id))
    state.submittedBuildBranches = Object.fromEntries(
      Object.entries(restoredPopupState?.submittedBuildBranches || {}).filter(([targetId]) =>
        allowedTargetIds.has(targetId)
      )
    )
    void persistCurrentPopupState()
    renderActive()
    renderModules()
    renderBuildQueue()
    setStatus(
      binding
        ? `已关联 ${binding.hostname}`
        : `${SITE_BINDING_REQUIRED}，Remote 热更不能单独应用到官网标签页`,
      binding ? '' : 'warning'
    )
  } catch (error) {
    if (generation !== loadGeneration) return
    state.binding = null
    state.environment = null
    state.bindingCandidates = []
    state.bindingPreferenceKey = null
    state.targets = []
    state.targetNames = {}
    state.siteTargetId = null
    state.currentSiteBranch = ''
    renderEnvironmentPicker()
    renderModules()
    renderBuildQueue()
    setStatus(`连接失败：${errorText(error)}`, 'warning')
  }
}

async function createBuild(targetId, branch) {
  const operation = {
    ...currentOperationContext(targetId, branch),
    controlOrigin: state.controlOrigin,
    actorName: state.actorName,
    token: crypto.randomUUID(),
  }
  if (!operation.environmentSlug) {
    setStatus('当前页面没有可用环境，无法发起打包', 'warning')
    return
  }
  const target = state.targets.find((candidate) => candidate.id === targetId)
  if (!target?.enabled || !target.configured || state.environment?.status !== 'ACTIVE') {
    setStatus(
      !target?.configured
        ? '项目没有配置 Git 仓库，只能选择已有产物进行预览'
        : state.environment?.status === 'FROZEN'
          ? '当前环境已冻结，只能选择已有产物进行预览'
          : '项目当前不可构建',
      'warning'
    )
    return
  }
  state.busyTargets.set(targetId, operation)
  renderModules()
  setStatus(`${branch} 正在提交打包任务`, 'busy')
  try {
    const job = await apiWithContext(operation, '/api/v1/build-jobs', {
      method: 'POST',
      headers: { 'idempotency-key': crypto.randomUUID() },
      body: JSON.stringify({
        environmentSlug: operation.environmentSlug,
        targetId,
        branch,
        profile: 'qa-web',
      }),
    })
    scheduleQueuePoll(300)
    const operationStillInScope = operationMatchesContext(
      operation,
      currentOperationContext(targetId, state.selectedBranches[targetId] || '')
    )
    if (!operationStillInScope) return
    const sameSelectedBranch = operationMatchesContext(
      operation,
      currentOperationContext(targetId, state.selectedBranches[targetId] || ''),
      { requireBranch: true }
    )
    if (sameSelectedBranch) {
      state.submittedBuildBranches[targetId] = branch
      void persistCurrentPopupState()
    }
    state.queue = {
      ...state.queue,
      queued: [
        ...(state.queue.queued || []).filter((item) => item.id !== job.id),
        {
          id: job.id,
          environmentId: job.environmentId,
          environmentSlug: job.environmentSlug,
          targetId: job.targetId,
          branch: job.branch,
          status: job.status,
          requestedBy: job.requestedBy,
          createdAt: job.createdAt,
          startedAt: job.startedAt,
          queuePosition: null,
          isMine: true,
        },
      ],
    }
    renderBuildQueue()
    setStatus(`${branch} 已加入 ${operation.environmentSlug} 环境的全局队列`, 'success')
  } catch (error) {
    if (
      operationMatchesContext(
        operation,
        currentOperationContext(targetId, state.selectedBranches[targetId] || '')
      )
    ) {
      setStatus(`提交失败：${errorText(error)}`, 'warning')
    }
  } finally {
    if (state.busyTargets.get(targetId)?.token === operation.token) {
      state.busyTargets.delete(targetId)
      renderModules()
    }
  }
}

async function applyPreview() {
  if (state.applyingToken) return
  const selectedSnapshot = selectedArtifacts()
  const selected = {
    siteArtifactId: selectedSnapshot.siteArtifactId,
    selections: selectedSnapshot.selections.map((selection) => ({ ...selection })),
    missing: selectedSnapshot.missing.map((item) => ({ ...item })),
  }
  if (selected.missing.length) {
    const first = selected.missing[0]
    setStatus(`${first.targetName} 的 ${first.branch} 尚无成功可用的产物，请先打包`, 'warning')
    return
  }
  const binding = state.binding
    ? {
        ...state.binding,
        remoteTargetIds: [...(state.binding.remoteTargetIds || [])],
      }
    : null
  const tab = state.tab ? { id: state.tab.id, url: state.tab.url } : null
  const operation = {
    ...currentOperationContext(),
    controlOrigin: state.controlOrigin,
    actorName: state.actorName,
    binding,
    tab,
    token: crypto.randomUUID(),
  }
  const plan = planPreviewApplication({
    binding,
    previewOrigin: previewOrigin(),
    siteArtifactId: selected.siteArtifactId,
    selections: selected.selections,
  })
  if (!tab?.id) return
  if (!plan.canApply) {
    setStatus(plan.reason, 'warning')
    return
  }
  state.applyingToken = operation.token
  renderModules()
  setStatus('正在创建标签页预览', 'busy')
  let preview = null
  try {
    await requireExtensionCapabilities((message) => chrome.runtime.sendMessage(message))

    const granted = await chrome.permissions.request({ origins: [`${plan.requestedOrigin}/*`] })
    if (!granted) throw new Error(`没有获得 ${plan.requestedOrigin} 的预览访问权限`)

    preview = await apiWithContext(operation, '/api/v1/previews', {
      method: 'POST',
      body: JSON.stringify(
        createPreviewRequest({
          binding,
          siteArtifactId: selected.siteArtifactId,
          selections: selected.selections,
        })
      ),
    })

    const origin = plan.requestedOrigin
    const targetUrl = previewDestinationUrl(origin, tab.url)
    const result = await chrome.runtime.sendMessage({
      type: APPLY_SITE_PREVIEW_TRANSACTION_COMMAND,
      tabId: tab.id,
      previewOrigin: origin,
      controlOrigin: operation.controlOrigin,
      officialOrigin: binding.officialOrigin,
      originalUrl: tab.url,
      targetUrl,
      preview,
    })
    if (!result?.ok) throw new Error(extensionCommandErrorMessage(result, '扩展规则应用失败'))
    if (operationMatchesContext(operation, currentOperationContext())) {
      state.active = result.active
      renderActive()
      setStatus(
        selected.siteArtifactId
          ? '页面与热更预览已应用，正在打开预览域名'
          : '热更预览已应用，正在打开隔离预览域名',
        'success'
      )
    }
  } catch (error) {
    if (operationMatchesContext(operation, currentOperationContext())) {
      setStatus(`应用失败：${errorText(error)}`, 'warning')
    }
  } finally {
    if (state.applyingToken === operation.token) {
      state.applyingToken = null
      renderModules()
    }
  }
}

async function removePreview() {
  if (!state.tab?.id) return
  setStatus('正在停用当前标签页预览', 'busy')
  const result = await chrome.runtime.sendMessage({
    type: REMOVE_PREVIEW_TRANSACTION_COMMAND,
    tabId: state.tab.id,
  })
  if (!result?.ok) {
    setStatus(`停用失败：${extensionCommandErrorMessage(result, '扩展规则移除失败')}`, 'warning')
    return
  }
  state.active = null
  renderActive()
  setStatus('预览已停用', 'success')
}

async function changeEnvironment() {
  const binding = state.bindingCandidates.find(
    (candidate) => candidate.id === elements.environmentSelect.value
  )
  if (!binding || binding.id === state.binding?.id) return

  elements.environmentSelect.disabled = true
  setStatus(`正在切换到 ${bindingEnvironmentLabel(binding)}`, 'busy')
  try {
    if (state.bindingPreferenceKey) {
      state.environmentPreferences = {
        ...state.environmentPreferences,
        [state.bindingPreferenceKey]: binding.environmentSlug,
      }
      await chrome.storage.local.set({
        [ENVIRONMENT_PREFS_KEY]: state.environmentPreferences,
      })
    }
    await load()
  } catch (error) {
    renderEnvironmentPicker()
    setStatus(`环境切换失败：${errorText(error)}`, 'warning')
  } finally {
    elements.environmentSelect.disabled = false
  }
}

async function saveSettings(event) {
  event.preventDefault()
  const origin = new URL(elements.controlOrigin.value).origin
  const permission = `${origin}/*`
  const granted = await chrome.permissions.request({ origins: [permission] })
  if (!granted) {
    setStatus(`未获得 ${origin} 的访问权限，服务地址没有修改`, 'warning')
    return
  }
  state.controlOrigin = origin
  state.actorOverride = normalizeActorName(elements.actorName.value)
  state.actorName = state.actorOverride || state.actorId
  await chrome.storage.local.set({
    [CONTROL_KEY]: origin,
    [ACTOR_ID_KEY]: state.actorId,
    [ACTOR_KEY]: state.actorOverride,
  })
  elements.settingsDialog.close()
  await load()
}

elements.refreshButton.addEventListener('click', () => void load({ resetSubmitted: true }))
elements.queueJumpButton.addEventListener('click', () => {
  elements.queuePanel.scrollIntoView({
    behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
    block: 'start',
  })
})
elements.settingsButton.addEventListener('click', () => {
  if (!elements.settingsDialog.open) elements.settingsDialog.showModal()
  elements.controlOrigin.focus()
})
elements.settingsCancel.addEventListener('click', () => elements.settingsDialog.close())
elements.settingsClose.addEventListener('click', () => elements.settingsDialog.close())
elements.settingsForm.addEventListener('submit', (event) => void saveSettings(event))
elements.environmentSelect.addEventListener('change', () => void changeEnvironment())
elements.applyButton.addEventListener('click', () => void applyPreview())
elements.removeButton.addEventListener('click', () => void removePreview())
elements.jobDetailClose.addEventListener('click', closeJobDetail)
elements.jobOverviewTab.addEventListener('click', () => void changeJobDetailTab('overview'))
elements.jobLogTab.addEventListener('click', () => void changeJobDetailTab('log'))
elements.jobDetailCancel.addEventListener('click', () => {
  if (state.selectedJobId) void cancelBuildJob(state.selectedJobId)
})
elements.jobDetailContent.addEventListener('scroll', () => {
  state.jobDetailScrollTop = elements.jobDetailContent.scrollTop
})
elements.jobDetailDialog.addEventListener('cancel', (event) => {
  event.preventDefault()
  closeJobDetail()
})
elements.jobDetailDialog.addEventListener('click', (event) => {
  if (event.target === elements.jobDetailDialog) closeJobDetail()
})
window.addEventListener('unload', () => {
  if (queuePollTimer !== null) window.clearTimeout(queuePollTimer)
})

void load().finally(() => scheduleQueuePoll())
