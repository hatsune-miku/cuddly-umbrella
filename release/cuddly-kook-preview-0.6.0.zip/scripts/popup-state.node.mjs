import assert from 'node:assert/strict'
import test from 'node:test'

import {
  operationMatchesContext,
  popupStateScopeKey,
  readScopedPopupState,
  writeScopedPopupState,
} from '../popup-state.js'

test('keeps branch choices and submission locks isolated by tab and binding', () => {
  let store = writeScopedPopupState(null, {
    tabId: 7,
    bindingId: 'binding-online',
    selectedBranches: { webapp: 'feature/chat' },
    submittedBuildBranches: { webapp: 'feature/chat' },
    updatedAt: 1,
  })
  store = writeScopedPopupState(store, {
    tabId: 7,
    bindingId: 'binding-test',
    selectedBranches: { webapp: 'develop' },
    submittedBuildBranches: {},
    updatedAt: 2,
  })

  assert.equal(popupStateScopeKey(7, 'binding-online'), '7:binding-online')
  assert.deepEqual(readScopedPopupState(store, { tabId: 7, bindingId: 'binding-online' }), {
    selectedBranches: { webapp: 'feature/chat' },
    submittedBuildBranches: { webapp: 'feature/chat' },
    updatedAt: 1,
  })
  assert.deepEqual(readScopedPopupState(store, { tabId: 7, bindingId: 'binding-test' }), {
    selectedBranches: { webapp: 'develop' },
    submittedBuildBranches: {},
    updatedAt: 2,
  })
  assert.equal(readScopedPopupState(store, { tabId: 8, bindingId: 'binding-online' }), null)
})

test('sanitizes persisted popup state', () => {
  const stored = readScopedPopupState(
    {
      '3:binding': {
        selectedBranches: { webapp: 'main', invalid: 3 },
        submittedBuildBranches: ['not', 'a', 'record'],
        updatedAt: 'yesterday',
      },
    },
    { tabId: 3, bindingId: 'binding' }
  )
  assert.deepEqual(stored, {
    selectedBranches: { webapp: 'main' },
    submittedBuildBranches: {},
    updatedAt: 0,
  })
})

test('rejects stale async operations after environment or branch changes', () => {
  const operation = {
    tabId: 5,
    bindingId: 'online-binding',
    environmentSlug: 'online',
    targetId: 'webapp',
    branch: 'feature/chat',
    contextVersion: 4,
  }
  assert.equal(operationMatchesContext(operation, operation, { requireBranch: true }), true)
  assert.equal(
    operationMatchesContext(operation, { ...operation, bindingId: 'test-binding' }),
    false
  )
  assert.equal(operationMatchesContext(operation, { ...operation, environmentSlug: 'test' }), false)
  assert.equal(operationMatchesContext(operation, { ...operation, contextVersion: 5 }), false)
  assert.equal(
    operationMatchesContext(
      operation,
      { ...operation, branch: 'feature/voice' },
      { requireBranch: true }
    ),
    false
  )
})
