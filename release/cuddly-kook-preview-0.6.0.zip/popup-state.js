export const POPUP_SCOPED_STATE_KEY = 'cuddly.popupStateByTabBinding.v1'

const MAX_SCOPED_STATES = 100

function stringRecord(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {}
  return Object.fromEntries(
    Object.entries(value).filter(
      ([key, entry]) => typeof key === 'string' && typeof entry === 'string'
    )
  )
}

export function popupStateScopeKey(tabId, bindingId) {
  if (!Number.isInteger(tabId) || tabId < 0 || typeof bindingId !== 'string' || !bindingId) {
    return ''
  }
  return `${tabId}:${bindingId}`
}

export function readScopedPopupState(store, { tabId, bindingId }) {
  const key = popupStateScopeKey(tabId, bindingId)
  const entry = key && store && typeof store === 'object' ? store[key] : null
  if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return null
  return {
    selectedBranches: stringRecord(entry.selectedBranches),
    submittedBuildBranches: stringRecord(entry.submittedBuildBranches),
    updatedAt: Number.isFinite(entry.updatedAt) ? entry.updatedAt : 0,
  }
}

export function writeScopedPopupState(
  store,
  { tabId, bindingId, selectedBranches, submittedBuildBranches, updatedAt = Date.now() }
) {
  const key = popupStateScopeKey(tabId, bindingId)
  if (!key) return store && typeof store === 'object' ? { ...store } : {}
  const next = {
    ...(store && typeof store === 'object' && !Array.isArray(store) ? store : {}),
    [key]: {
      selectedBranches: stringRecord(selectedBranches),
      submittedBuildBranches: stringRecord(submittedBuildBranches),
      updatedAt,
    },
  }
  const entries = Object.entries(next)
    .sort(([, left], [, right]) => (right?.updatedAt || 0) - (left?.updatedAt || 0))
    .slice(0, MAX_SCOPED_STATES)
  return Object.fromEntries(entries)
}

export function operationMatchesContext(operation, current, { requireBranch = false } = {}) {
  if (!operation || !current) return false
  const sameScope =
    operation.tabId === current.tabId &&
    operation.bindingId === current.bindingId &&
    operation.environmentSlug === current.environmentSlug &&
    (operation.contextVersion === undefined ||
      current.contextVersion === undefined ||
      operation.contextVersion === current.contextVersion)
  if (!sameScope) return false
  if (!requireBranch) return true
  return operation.targetId === current.targetId && operation.branch === (current.branch || '')
}
