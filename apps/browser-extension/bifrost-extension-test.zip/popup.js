import {
  createBranchPicker,
  describeBranchBuild,
  endedQueueTargetIds,
  flattenBuildQueue,
  prepareTargetBranchItems,
} from './branch-picker.js'
import {
  createPreviewRequest,
  mergeSelectedBranches,
  planPreviewApplication,
  previewDestinationUrl,
  resolveSelectedArtifacts,
  SITE_BINDING_REQUIRED,
} from './preview-routing.js'
import {
  APPLY_CONFIGURATION_GROUP_COMMAND,
  APPLY_SITE_PREVIEW_TRANSACTION_COMMAND,
  extensionCommandErrorMessage,
  REMOVE_PREVIEW_TRANSACTION_COMMAND,
  requireExtensionCapabilities,
} from './extension-protocol.js'
import { chooseBindingCandidate, normalizeBindingCandidates } from './binding-selection.js'
import {
  chooseEnvironment,
  environmentOptionLabel,
  normalizeEnvironments,
  readTabEnvironmentPreference,
  TAB_ENVIRONMENT_PREFS_KEY,
  writeTabEnvironmentPreference,
} from './environment-selection.js'
import { authenticatedRequestInit, feishuLoginUrl, normalizeAuthSession } from './auth-session.js'
import {
  buildJobPresentation,
  buildQueueSummary,
  isBuildSubmissionLocked,
  orderedBuildQueue,
  replaceBuildQueueJob,
  shouldPollBuildJob,
  TERMINAL_BUILD_STATUSES,
} from './build-queue.js'
import {
  chooseRestoredPopupState,
  operationMatchesContext,
  READ_POPUP_SCOPED_STATE_COMMAND,
  WRITE_POPUP_SCOPED_STATE_COMMAND,
} from './popup-state.js'
import {
  configurationGroupFingerprint,
  configurationGroupItems,
  configurationGroupShareUrl,
} from './config-share.js'
import {
  configurationGroupBranchSummary,
  configurationGroupUpdateInput,
  isConfigurationGroupRevisionConflict,
  normalizeConfigurationGroups,
  normalizeProjectVersionTab,
  PROJECT_VERSION_TAB_KEY,
  projectVersionTabForKey,
} from './configuration-groups.js'
import { normalizePopupTab, popupTabForKey } from './popup-tabs.js'

const CONTROL_KEY = 'cuddly.controlOrigin'
const ACTIVE_KEY = 'cuddly.activePreviews'
const ENVIRONMENT_PREFS_KEY = 'cuddly.environmentByOfficialOrigin'
const DEFAULT_CONTROL_ORIGIN = 'https://bifrost.vanillacake.cn'
const BUILD_QUEUE_POLL_MS = 2_500
const emptyQueue = { running: [], queued: [] }

const state = {
  tab: null,
  controlOrigin: DEFAULT_CONTROL_ORIGIN,
  authenticated: false,
  authLoading: true,
  authHint: '正在检查登录状态',
  loggingOut: false,
  identity: null,
  csrfToken: '',
  binding: null,
  environmentPreferences: {},
  tabEnvironmentPreferences: {},
  environments: [],
  environment: null,
  environmentChanging: false,
  targets: [],
  targetNames: {},
  siteTargetId: null,
  branches: {},
  selectedBranches: {},
  active: null,
  busyTargets: new Map(),
  submittedBuildBranches: {},
  applyingToken: null,
  sharing: false,
  shareResult: null,
  workspaceTab: 'projects',
  projectVersionTab: 'branches',
  configurationGroups: [],
  configurationGroupsLoading: true,
  configurationGroupsError: '',
  configurationGroupActionToken: null,
  editingConfigurationGroup: null,
  deletingConfigurationGroup: null,
  cancelingJobs: new Set(),
  dirtyCatalogTargets: new Set(),
  queue: emptyQueue,
  queueLastSuccessAt: null,
  queueRefreshError: '',
  selectedJobId: null,
  jobDetail: null,
  jobLog: null,
  jobDetailTab: 'overview',
  jobDetailError: '',
  jobDetailRefreshError: '',
  jobDetailLoading: false,
  jobLogFollow: true,
  jobLogScrollTop: 0,
  jobDetailScrollTop: 0,
}

const elements = {
  pageTitle: document.querySelector('#page-title'),
  pageMeta: document.querySelector('#page-meta'),
  identityPanel: document.querySelector('#identity-panel'),
  identityAvatar: document.querySelector('#identity-avatar'),
  identityAvatarFallback: document.querySelector('#identity-avatar-fallback'),
  identityName: document.querySelector('#identity-name'),
  logoutButton: document.querySelector('#logout-button'),
  authGate: document.querySelector('#auth-gate'),
  authGateHint: document.querySelector('#auth-gate-hint'),
  loginButton: document.querySelector('#login-button'),
  workspaceTabs: document.querySelector('#workspace-tabs'),
  projectsTab: document.querySelector('#projects-tab'),
  queueTab: document.querySelector('#queue-tab'),
  queueTabCount: document.querySelector('#queue-tab-count'),
  projectsPanel: document.querySelector('#projects-panel'),
  projectVersionTabs: document.querySelector('#project-version-tabs'),
  requirementsTab: document.querySelector('#requirements-tab'),
  branchesTab: document.querySelector('#branches-tab'),
  requirementsPanel: document.querySelector('#requirements-panel'),
  branchesPanel: document.querySelector('#branches-panel'),
  requirementsSummary: document.querySelector('#requirements-summary'),
  requirementsRefresh: document.querySelector('#requirements-refresh'),
  requirementsList: document.querySelector('#requirements-list'),
  shareButton: document.querySelector('#share-button'),
  shareDialog: document.querySelector('#share-dialog'),
  shareForm: document.querySelector('#share-form'),
  shareClose: document.querySelector('#share-close'),
  shareCancel: document.querySelector('#share-cancel'),
  shareName: document.querySelector('#share-name'),
  shareContext: document.querySelector('#share-context'),
  shareCaveat: document.querySelector('#share-caveat'),
  shareResultField: document.querySelector('#share-result-field'),
  shareResult: document.querySelector('#share-result'),
  shareSubmit: document.querySelector('#share-submit'),
  configurationGroupEditDialog: document.querySelector('#configuration-group-edit-dialog'),
  configurationGroupEditForm: document.querySelector('#configuration-group-edit-form'),
  configurationGroupEditClose: document.querySelector('#configuration-group-edit-close'),
  configurationGroupEditCancel: document.querySelector('#configuration-group-edit-cancel'),
  configurationGroupEditName: document.querySelector('#configuration-group-edit-name'),
  configurationGroupEditContext: document.querySelector('#configuration-group-edit-context'),
  configurationGroupOverwrite: document.querySelector('#configuration-group-overwrite'),
  configurationGroupOverwriteHint: document.querySelector('#configuration-group-overwrite-hint'),
  configurationGroupEditSubmit: document.querySelector('#configuration-group-edit-submit'),
  configurationGroupDeleteDialog: document.querySelector('#configuration-group-delete-dialog'),
  configurationGroupDeleteForm: document.querySelector('#configuration-group-delete-form'),
  configurationGroupDeleteClose: document.querySelector('#configuration-group-delete-close'),
  configurationGroupDeleteCancel: document.querySelector('#configuration-group-delete-cancel'),
  configurationGroupDeleteCopy: document.querySelector('#configuration-group-delete-copy'),
  configurationGroupDeleteSubmit: document.querySelector('#configuration-group-delete-submit'),
  refreshButton: document.querySelector('#refresh-button'),
  settingsButton: document.querySelector('#settings-button'),
  settingsDialog: document.querySelector('#settings-dialog'),
  settingsForm: document.querySelector('#settings-form'),
  settingsCancel: document.querySelector('#settings-cancel'),
  settingsClose: document.querySelector('#settings-close'),
  controlOrigin: document.querySelector('#control-origin'),
  environmentBar: document.querySelector('#environment-bar'),
  environmentSelect: document.querySelector('#environment-select'),
  environmentHint: document.querySelector('#environment-hint'),
  activePanel: document.querySelector('#active-panel'),
  activeTitle: document.querySelector('#active-title'),
  activeSummary: document.querySelector('#active-summary'),
  removeButton: document.querySelector('#remove-button'),
  moduleList: document.querySelector('#module-list'),
  queuePanel: document.querySelector('#queue-panel'),
  queueSummary: document.querySelector('#queue-summary'),
  queueList: document.querySelector('#queue-list'),
  selectionSummary: document.querySelector('#selection-summary'),
  applyButton: document.querySelector('#apply-button'),
  applyButtonWrap: document.querySelector('#apply-button-wrap'),
  statusBar: document.querySelector('#status-bar'),
  statusText: document.querySelector('#status-text'),
  branchPickerDropdown: document.querySelector('#branch-picker-dropdown'),
  jobDetailDialog: document.querySelector('#job-detail-dialog'),
  jobDetailTitle: document.querySelector('#job-detail-title'),
  jobDetailContext: document.querySelector('#job-detail-context'),
  jobDetailClose: document.querySelector('#job-detail-close'),
  jobOverviewTab: document.querySelector('#job-overview-tab'),
  jobLogTab: document.querySelector('#job-log-tab'),
  jobDetailContent: document.querySelector('#job-detail-content'),
  jobDetailRefreshHint: document.querySelector('#job-detail-refresh-hint'),
  jobDetailCancel: document.querySelector('#job-detail-cancel'),
}

const branchPicker = createBranchPicker(elements.branchPickerDropdown)
let queuePollTimer = null
let queuePollRunning = false
let loadGeneration = 0
let jobDetailGeneration = 0
let configurationGroupsGeneration = 0

function setStatus(text, tone = '') {
  const message = typeof text === 'string' ? text : String(text ?? '')
  elements.statusText.textContent = message
  if (message) {
    elements.statusText.title = message
  } else {
    elements.statusText.removeAttribute('title')
  }
  elements.statusBar.className = `status-bar ${tone}`.trim()
}

function renderAuthentication() {
  const authenticated = state.authenticated && state.identity && state.csrfToken
  elements.authGate.hidden = Boolean(authenticated)
  elements.workspaceTabs.hidden = !authenticated
  elements.identityPanel.hidden = !authenticated
  elements.shareButton.hidden = !authenticated
  elements.refreshButton.hidden = !authenticated
  elements.loginButton.disabled = state.authLoading
  elements.authGateHint.textContent = state.authHint

  if (authenticated) {
    const { name, avatarUrl } = state.identity
    elements.identityName.textContent = name
    elements.identityPanel.title = `当前操作人：${name}`
    elements.logoutButton.disabled = state.loggingOut
    elements.logoutButton.textContent = state.loggingOut ? '退出中' : '退出'
    elements.identityAvatar.hidden = !avatarUrl
    elements.identityAvatarFallback.hidden = Boolean(avatarUrl)
    if (avatarUrl) elements.identityAvatar.src = avatarUrl
  } else {
    elements.identityName.textContent = ''
    elements.identityPanel.removeAttribute('title')
    elements.identityAvatar.hidden = true
    elements.identityAvatar.removeAttribute('src')
    elements.identityAvatarFallback.hidden = false
    elements.projectsPanel.hidden = true
    elements.queuePanel.hidden = true
    branchPicker.close({ restoreFocus: false })
    if (elements.configurationGroupEditDialog.open) elements.configurationGroupEditDialog.close()
    if (elements.configurationGroupDeleteDialog.open)
      elements.configurationGroupDeleteDialog.close()
  }
  setWorkspaceTab(state.workspaceTab)
}

function setAuthenticatedSession(session) {
  state.authenticated = true
  state.authLoading = false
  state.authHint = ''
  state.identity = session.identity
  state.csrfToken = session.csrfToken
  renderAuthentication()
}

function expireAuthentication(message = '登录已过期，请重新登录') {
  state.authenticated = false
  state.authLoading = false
  state.authHint = '登录后可查看项目版本和构建队列'
  state.loggingOut = false
  state.identity = null
  state.csrfToken = ''
  if (queuePollTimer !== null) {
    window.clearTimeout(queuePollTimer)
    queuePollTimer = null
  }
  if (elements.shareDialog.open) elements.shareDialog.close()
  closeJobDetail()
  renderAuthentication()
  setStatus(message, 'warning')
}

async function readAuthSession(controlOrigin) {
  const response = await fetch(
    `${controlOrigin.replace(/\/$/, '')}/api/v1/auth/session`,
    authenticatedRequestInit({ cache: 'no-store' })
  )
  const body = await response.json().catch(() => null)
  if (response.status === 401) return null
  if (!response.ok) {
    const error = new Error(`登录状态接口返回 HTTP ${response.status}`)
    error.status = response.status
    error.body = body
    throw error
  }
  const session = normalizeAuthSession(body)
  if (!session) throw new Error('登录状态接口返回了无效身份')
  return session
}

async function startFeishuLogin() {
  if (state.authLoading) return
  state.authLoading = true
  state.authHint = '正在打开飞书登录页'
  renderAuthentication()
  try {
    await chrome.tabs.create({ url: feishuLoginUrl(state.controlOrigin) })
    state.authHint = '登录完成后重新打开扩展即可继续'
    setStatus('已在新标签页打开飞书登录', 'success')
  } catch (error) {
    state.authHint = '无法打开登录页，请重试'
    setStatus(`打开登录页失败：${errorText(error)}`, 'warning')
  } finally {
    state.authLoading = false
    renderAuthentication()
  }
}

async function logout() {
  if (!state.authenticated || state.loggingOut) return
  state.loggingOut = true
  renderAuthentication()
  setStatus('正在退出飞书登录', 'busy')
  try {
    await api('/api/v1/auth/logout', { method: 'POST' })
    expireAuthentication('已退出登录')
  } catch (error) {
    if (!state.authenticated) return
    state.loggingOut = false
    renderAuthentication()
    setStatus(`退出失败：${errorText(error)}`, 'warning')
  }
}

function setWorkspaceTab(nextTab, { focus = false } = {}) {
  const tab = normalizePopupTab(nextTab)
  state.workspaceTab = tab
  const projectsActive = tab === 'projects'
  elements.projectsTab.classList.toggle('active', projectsActive)
  elements.projectsTab.setAttribute('aria-selected', String(projectsActive))
  elements.projectsTab.tabIndex = projectsActive ? 0 : -1
  elements.projectsPanel.hidden = !state.authenticated || !projectsActive
  elements.queueTab.classList.toggle('active', !projectsActive)
  elements.queueTab.setAttribute('aria-selected', String(!projectsActive))
  elements.queueTab.tabIndex = projectsActive ? -1 : 0
  elements.queuePanel.hidden = !state.authenticated || projectsActive
  branchPicker.close({ restoreFocus: false })
  setProjectVersionTab(state.projectVersionTab)
  if (focus) (projectsActive ? elements.projectsTab : elements.queueTab).focus()
}

function handleWorkspaceTabKey(event) {
  const nextTab = popupTabForKey(state.workspaceTab, event.key)
  if (nextTab === state.workspaceTab && !['Home', 'End'].includes(event.key)) return
  event.preventDefault()
  setWorkspaceTab(nextTab, { focus: true })
}

function setProjectVersionTab(nextTab, { focus = false, persist = false } = {}) {
  const tab = normalizeProjectVersionTab(nextTab)
  state.projectVersionTab = tab
  const requirementsActive = tab === 'requirements'
  elements.requirementsTab.classList.toggle('active', requirementsActive)
  elements.requirementsTab.setAttribute('aria-selected', String(requirementsActive))
  elements.requirementsTab.tabIndex = requirementsActive ? 0 : -1
  elements.requirementsPanel.hidden = !requirementsActive
  elements.branchesTab.classList.toggle('active', !requirementsActive)
  elements.branchesTab.setAttribute('aria-selected', String(!requirementsActive))
  elements.branchesTab.tabIndex = requirementsActive ? -1 : 0
  elements.branchesPanel.hidden = requirementsActive
  branchPicker.close({ restoreFocus: false })
  if (persist) {
    void chrome.storage.local.set({ [PROJECT_VERSION_TAB_KEY]: tab }).catch(() => undefined)
  }
  if (focus) (requirementsActive ? elements.requirementsTab : elements.branchesTab).focus()
}

function handleProjectVersionTabKey(event) {
  const nextTab = projectVersionTabForKey(state.projectVersionTab, event.key)
  if (nextTab === state.projectVersionTab && !['Home', 'End'].includes(event.key)) return
  event.preventDefault()
  setProjectVersionTab(nextTab, { focus: true, persist: true })
}

function formatTime(value) {
  if (!value) return '尚未打包'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '时间未知'
  return new Intl.DateTimeFormat('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(date)
}

function errorText(error) {
  if (error?.body?.message) return error.body.message
  return error instanceof Error ? error.message : String(error)
}

async function apiWithContext(context, pathname, init) {
  const response = await fetch(
    `${context.controlOrigin.replace(/\/$/, '')}${pathname}`,
    authenticatedRequestInit(init, context.csrfToken)
  )
  const body = await response.json().catch(() => null)
  if (!response.ok) {
    const error = new Error(`Cuddly 返回 HTTP ${response.status}`)
    error.status = response.status
    error.body = body
    if (response.status === 401 && context.controlOrigin === state.controlOrigin) {
      expireAuthentication()
    }
    throw error
  }
  return body
}

async function api(pathname, init) {
  return apiWithContext(
    { controlOrigin: state.controlOrigin, csrfToken: state.csrfToken },
    pathname,
    init
  )
}

async function readPersistedPopupState(tabId, bindingId, environmentSlug) {
  const response = await chrome.runtime.sendMessage({
    type: READ_POPUP_SCOPED_STATE_COMMAND,
    tabId,
    bindingId,
    environmentSlug,
  })
  if (!response?.ok) {
    throw new Error(response?.message || '扩展后台无法读取分支选择')
  }
  return response.state || null
}

function persistPopupState({
  tabId,
  bindingId,
  environmentSlug,
  selectedBranches,
  submittedBuildBranches,
}) {
  try {
    // Send immediately: the service worker owns the write lifecycle and can finish after the
    // popup document closes. Delaying sendMessage behind a popup-local promise loses that guarantee.
    return chrome.runtime
      .sendMessage({
        type: WRITE_POPUP_SCOPED_STATE_COMMAND,
        tabId,
        bindingId,
        environmentSlug,
        selectedBranches,
        submittedBuildBranches,
      })
      .then((response) => {
        if (!response?.ok) throw new Error(response?.message || '扩展后台无法保存分支选择')
      })
      .catch(() => undefined)
  } catch {
    return Promise.resolve()
  }
}

function persistCurrentPopupState() {
  const tabId = state.tab?.id
  const bindingId = state.binding?.id
  const environmentSlug = state.environment?.slug
  if (!Number.isInteger(tabId) || !bindingId || !environmentSlug) return Promise.resolve()
  return persistPopupState({
    tabId,
    bindingId,
    environmentSlug,
    selectedBranches: { ...state.selectedBranches },
    submittedBuildBranches: { ...state.submittedBuildBranches },
  })
}

function selectedOfficialOrigin() {
  try {
    return state.binding?.officialOrigin ? new URL(state.binding.officialOrigin).origin : ''
  } catch {
    return ''
  }
}

async function persistEnvironmentSelection(environmentSlug, { rememberGlobally = true } = {}) {
  const tabId = state.tab?.id
  const officialOrigin = selectedOfficialOrigin()
  if (!Number.isInteger(tabId) || !officialOrigin || !environmentSlug) return
  state.tabEnvironmentPreferences = writeTabEnvironmentPreference(state.tabEnvironmentPreferences, {
    tabId,
    officialOrigin,
    environmentSlug,
  })
  if (rememberGlobally) {
    state.environmentPreferences = {
      ...state.environmentPreferences,
      [officialOrigin]: environmentSlug,
    }
  }
  await chrome.storage.local.set({
    [TAB_ENVIRONMENT_PREFS_KEY]: state.tabEnvironmentPreferences,
    ...(rememberGlobally ? { [ENVIRONMENT_PREFS_KEY]: state.environmentPreferences } : {}),
  })
}

function currentOperationContext(targetId = '', branch = '') {
  return {
    tabId: state.tab?.id,
    bindingId: state.binding?.id || '',
    environmentSlug: state.environment?.slug || '',
    targetId,
    branch,
    contextVersion: loadGeneration,
  }
}

async function optionalApi(pathname) {
  try {
    return await api(pathname)
  } catch (error) {
    if (error?.status === 404) return null
    throw error
  }
}

function branchForArtifact(targetId, artifactId) {
  if (!artifactId) return ''
  return (
    state.branches[targetId]?.items?.find((item) => item.latestArtifact?.id === artifactId)
      ?.branch || ''
  )
}

function selectedArtifacts() {
  return resolveSelectedArtifacts({
    targets: state.targets,
    selectedBranches: state.selectedBranches,
    branchCatalogs: state.branches,
    siteTargetId: state.siteTargetId,
  })
}

function currentConfigurationGroupSnapshot() {
  const items = configurationGroupItems(state.targets, state.selectedBranches)
  return {
    bindingId: state.binding?.id || '',
    environmentSlug: state.environment?.slug || '',
    items,
    fingerprint: configurationGroupFingerprint({
      bindingId: state.binding?.id || '',
      environmentSlug: state.environment?.slug || '',
      items,
    }),
  }
}

function shareUnavailableReason() {
  if (!state.binding || !state.environment) return '当前标签页还没有关联可分享的站点与环境'
  if (state.environment.status === 'ARCHIVED') return '归档环境不能创建新的配置组'
  const expectedTargetIds = new Set([
    state.binding.targetId,
    ...(state.binding.remoteTargetIds || []),
  ])
  const actualTargetIds = new Set(state.targets.map((target) => target.id))
  if (
    expectedTargetIds.size !== actualTargetIds.size ||
    [...expectedTargetIds].some((targetId) => !actualTargetIds.has(targetId))
  ) {
    return '站点项目尚未完整加载，刷新后再分享'
  }
  return ''
}

function renderShareButton() {
  const reason = shareUnavailableReason()
  elements.shareButton.disabled = Boolean(reason || state.sharing)
  elements.shareButton.title = reason || '创建并复制当前环境与全部项目分支的配置组链接'
}

function renderShareDialog() {
  const snapshot = currentConfigurationGroupSnapshot()
  const branchCount = snapshot.items.filter((item) => item.mode === 'branch').length
  const officialCount = snapshot.items.length - branchCount
  elements.shareContext.textContent = `${state.environment?.name || snapshot.environmentSlug || '当前环境'} · ${snapshot.items.length} 个项目 · ${branchCount} 个指定分支`
  elements.shareCaveat.textContent = officialCount
    ? `${officialCount} 个项目会跟随 KOOK 官网版本；指定分支仅在该分支产生新的成功包后变化。`
    : '所有项目均固定跟随所选分支；只有分支产生新的成功包后，重新打开链接才会变化。'
  const resultIsCurrent =
    state.shareResult?.fingerprint === snapshot.fingerprint &&
    state.shareResult?.name === elements.shareName.value.trim()
  elements.shareResultField.hidden = !resultIsCurrent
  elements.shareResult.value = resultIsCurrent ? state.shareResult.url : ''
  elements.shareName.disabled = state.sharing
  elements.shareSubmit.disabled = state.sharing || !elements.shareName.value.trim()
  elements.shareSubmit.textContent = state.sharing
    ? '创建中'
    : resultIsCurrent
      ? '复制链接'
      : '创建并复制'
}

function openShareDialog() {
  const reason = shareUnavailableReason()
  if (reason) {
    setStatus(reason, 'warning')
    return
  }
  const snapshot = currentConfigurationGroupSnapshot()
  if (state.shareResult && state.shareResult.fingerprint !== snapshot.fingerprint) {
    state.shareResult = null
    elements.shareName.value = ''
  }
  renderShareDialog()
  if (!elements.shareDialog.open) elements.shareDialog.showModal()
  if (elements.shareResultField.hidden) elements.shareName.focus()
  else elements.shareResult.select()
}

async function copyShareUrl(url) {
  try {
    await navigator.clipboard.writeText(url)
    return
  } catch {
    elements.shareResult.value = url
    elements.shareResultField.hidden = false
    elements.shareResult.focus()
    elements.shareResult.select()
    if (!document.execCommand('copy')) {
      throw new Error('浏览器没有允许自动复制，请手动复制输入框中的链接')
    }
  }
}

async function shareConfiguration(event) {
  event.preventDefault()
  if (state.sharing) return
  const reason = shareUnavailableReason()
  if (reason) {
    setStatus(reason, 'warning')
    return
  }
  const name = elements.shareName.value.trim()
  if (!name) {
    elements.shareName.focus()
    return
  }
  const snapshot = currentConfigurationGroupSnapshot()
  if (state.shareResult?.fingerprint === snapshot.fingerprint && state.shareResult?.name === name) {
    try {
      await copyShareUrl(state.shareResult.url)
      setStatus(`已复制配置组「${name}」`, 'success')
    } catch (error) {
      setStatus(errorText(error), 'warning')
    }
    return
  }

  state.sharing = true
  renderShareButton()
  renderShareDialog()
  setStatus(`正在创建配置组「${name}」`, 'busy')
  let created = false
  try {
    const group = await api('/api/v1/config-groups', {
      method: 'POST',
      body: JSON.stringify({
        schemaVersion: 1,
        name,
        environmentSlug: snapshot.environmentSlug,
        siteBindingId: snapshot.bindingId,
        items: snapshot.items,
      }),
    })
    const url = configurationGroupShareUrl(state.controlOrigin, group)
    state.shareResult = { name, url, token: group.token, fingerprint: snapshot.fingerprint }
    created = true
    await copyShareUrl(url)
    setStatus(`配置组「${name}」已创建并复制`, 'success')
  } catch (error) {
    setStatus(`分享失败：${errorText(error)}`, 'warning')
  } finally {
    if (created) await refreshConfigurationGroups()
    state.sharing = false
    renderShareButton()
    renderShareDialog()
  }
}

function configurationGroupEnvironmentName(slug) {
  const environment = state.environments.find((candidate) => candidate.slug === slug)
  return environment?.name || slug
}

function renderConfigurationGroupState(message, { retry = false } = {}) {
  const stateView = document.createElement('div')
  stateView.className = 'requirement-state'
  const copy = document.createElement('span')
  copy.textContent = message
  stateView.append(copy)
  if (retry) {
    const button = document.createElement('button')
    button.className = 'text-button'
    button.type = 'button'
    button.textContent = '重新读取'
    button.addEventListener('click', () => void refreshConfigurationGroups())
    stateView.append(button)
  }
  elements.requirementsList.append(stateView)
}

function renderConfigurationGroups() {
  elements.requirementsList.replaceChildren()
  elements.requirementsList.setAttribute(
    'aria-busy',
    String(Boolean(state.configurationGroupsLoading))
  )
  elements.requirementsRefresh.disabled =
    state.configurationGroupsLoading || Boolean(state.configurationGroupActionToken)

  if (state.configurationGroupsLoading) {
    elements.requirementsSummary.textContent = '正在读取'
    const loading = document.createElement('div')
    loading.className = 'requirement-state'
    const spinner = document.createElement('span')
    spinner.className = 'module-loading-spinner'
    spinner.setAttribute('aria-hidden', 'true')
    const label = document.createElement('span')
    label.textContent = '正在读取所有提测需求'
    loading.append(spinner, label)
    elements.requirementsList.append(loading)
    return
  }
  if (state.configurationGroupsError) {
    elements.requirementsSummary.textContent = '读取失败'
    renderConfigurationGroupState(state.configurationGroupsError, { retry: true })
    return
  }
  elements.requirementsSummary.textContent = `${state.configurationGroups.length} 个需求 · 按创建时间倒序`
  if (!state.configurationGroups.length) {
    renderConfigurationGroupState('还没有人创建提测需求，请先在“按分支”中选好版本后分享。')
    return
  }

  const fragment = document.createDocumentFragment()
  for (const group of state.configurationGroups) {
    const actionBusy = state.configurationGroupActionToken === group.token
    const anotherActionBusy =
      Boolean(state.configurationGroupActionToken) &&
      state.configurationGroupActionToken !== group.token
    const row = document.createElement('article')
    row.className = 'requirement-row'

    const use = document.createElement('button')
    use.className = 'requirement-use'
    use.type = 'button'
    use.disabled = actionBusy || anotherActionBusy
    use.setAttribute('aria-label', `使用需求 ${group.name}`)
    use.addEventListener('click', () => void applyConfigurationGroup(group))

    const titleLine = document.createElement('span')
    titleLine.className = 'requirement-title-line'
    const title = document.createElement('strong')
    title.textContent = actionBusy ? `${group.name} · 处理中` : group.name
    title.title = group.name
    const environment = document.createElement('span')
    environment.className = 'requirement-environment'
    environment.textContent = configurationGroupEnvironmentName(group.environmentSlug)
    titleLine.append(title, environment)

    const branches = document.createElement('span')
    branches.className = 'requirement-branches'
    branches.textContent = configurationGroupBranchSummary(group, state.targetNames)
    branches.title = branches.textContent

    const meta = document.createElement('span')
    meta.className = 'requirement-meta'
    const creator = group.createdBy || '未知操作人'
    meta.textContent = `${creator} · ${formatTime(group.createdAt)} · ${group.siteBindingId}`
    meta.title = `由 ${creator} 创建于 ${fullTime(group.createdAt)}；最后更新 ${fullTime(group.updatedAt || group.createdAt)}`
    use.append(titleLine, branches, meta)

    const actions = document.createElement('span')
    actions.className = 'requirement-actions'
    const action = (label, handler, className = '') => {
      const button = document.createElement('button')
      button.className = `requirement-action ${className}`.trim()
      button.type = 'button'
      button.textContent = label
      button.disabled = actionBusy || anotherActionBusy
      button.setAttribute('aria-label', `${label}需求 ${group.name}`)
      button.addEventListener('click', handler)
      return button
    }
    actions.append(
      action('复制', () => void copyConfigurationGroup(group)),
      action('编辑', () => openConfigurationGroupEdit(group)),
      action('删除', () => openConfigurationGroupDelete(group), 'danger-text')
    )
    row.append(use, actions)
    fragment.append(row)
  }
  elements.requirementsList.append(fragment)
}

async function refreshConfigurationGroups() {
  if (!state.authenticated) return
  const generation = ++configurationGroupsGeneration
  state.configurationGroupsLoading = true
  state.configurationGroupsError = ''
  renderConfigurationGroups()
  try {
    const body = await api('/api/v1/config-groups')
    if (generation !== configurationGroupsGeneration) return
    state.configurationGroups = normalizeConfigurationGroups(body)
  } catch (error) {
    if (generation !== configurationGroupsGeneration) return
    state.configurationGroupsError = errorText(error)
  } finally {
    if (generation === configurationGroupsGeneration) {
      state.configurationGroupsLoading = false
      renderConfigurationGroups()
    }
  }
}

async function copyConfigurationGroup(group) {
  try {
    const url = configurationGroupShareUrl(state.controlOrigin, group)
    await copyShareUrl(url)
    setStatus(`已复制需求「${group.name}」的分享链接`, 'success')
  } catch (error) {
    setStatus(`复制失败：${errorText(error)}`, 'warning')
  }
}

async function applyConfigurationGroup(group) {
  if (state.configurationGroupActionToken || !Number.isInteger(state.tab?.id)) return
  state.configurationGroupActionToken = group.token
  renderConfigurationGroups()
  setStatus(`正在使用需求「${group.name}」`, 'busy')
  try {
    await requireExtensionCapabilities((message) => chrome.runtime.sendMessage(message))
    const response = await chrome.runtime.sendMessage({
      type: APPLY_CONFIGURATION_GROUP_COMMAND,
      tabId: state.tab.id,
      token: group.token,
    })
    if (!response?.ok) {
      const message = extensionCommandErrorMessage(response, '需求应用失败')
      if (response?.selectionPersisted) await load().catch(() => undefined)
      throw new Error(message)
    }
    state.active = response.active || null
    renderActive()
    setStatus(`需求「${group.name}」已应用，正在打开预览站点`, 'success')
  } catch (error) {
    setStatus(`需求应用失败：${errorText(error)}`, 'warning')
  } finally {
    if (state.configurationGroupActionToken === group.token) {
      state.configurationGroupActionToken = null
      renderConfigurationGroups()
    }
  }
}

function overwriteCurrentConfigurationReason() {
  return shareUnavailableReason()
}

function renderConfigurationGroupEditDialog() {
  const group = state.editingConfigurationGroup
  if (!group) return
  const reason = overwriteCurrentConfigurationReason()
  const snapshot = currentConfigurationGroupSnapshot()
  const busy = state.configurationGroupActionToken === group.token
  elements.configurationGroupEditContext.textContent = `${configurationGroupEnvironmentName(group.environmentSlug)} · 修订 ${group.revision} · 链接保持不变`
  elements.configurationGroupOverwrite.disabled = Boolean(reason || busy)
  if (reason) elements.configurationGroupOverwrite.checked = false
  elements.configurationGroupOverwriteHint.textContent = reason
    ? reason
    : `可替换为 ${state.environment?.name || snapshot.environmentSlug} 的 ${snapshot.items.length} 个项目选择`
  elements.configurationGroupEditName.disabled = busy
  elements.configurationGroupEditSubmit.disabled =
    busy || !elements.configurationGroupEditName.value.trim()
  elements.configurationGroupEditSubmit.textContent = busy ? '保存中' : '保存'
}

function openConfigurationGroupEdit(group) {
  state.editingConfigurationGroup = group
  elements.configurationGroupEditName.value = group.name
  elements.configurationGroupOverwrite.checked = false
  renderConfigurationGroupEditDialog()
  if (!elements.configurationGroupEditDialog.open) elements.configurationGroupEditDialog.showModal()
  elements.configurationGroupEditName.focus()
  elements.configurationGroupEditName.select()
}

function closeConfigurationGroupEdit() {
  if (state.editingConfigurationGroup && state.configurationGroupActionToken) return
  state.editingConfigurationGroup = null
  if (elements.configurationGroupEditDialog.open) elements.configurationGroupEditDialog.close()
}

async function updateConfigurationGroup(event) {
  event.preventDefault()
  const group = state.editingConfigurationGroup
  if (!group || state.configurationGroupActionToken) return
  const snapshot = elements.configurationGroupOverwrite.checked
    ? currentConfigurationGroupSnapshot()
    : null
  let body
  try {
    body = configurationGroupUpdateInput(group, {
      name: elements.configurationGroupEditName.value,
      snapshot,
    })
  } catch (error) {
    setStatus(errorText(error), 'warning')
    return
  }

  state.configurationGroupActionToken = group.token
  renderConfigurationGroupEditDialog()
  renderConfigurationGroups()
  setStatus(`正在保存需求「${group.name}」`, 'busy')
  try {
    await api(`/api/v1/config-groups/${encodeURIComponent(group.token)}`, {
      method: 'PUT',
      body: JSON.stringify(body),
    })
    state.configurationGroupActionToken = null
    state.editingConfigurationGroup = null
    elements.configurationGroupEditDialog.close()
    await refreshConfigurationGroups()
    setStatus(`需求「${body.name}」已更新`, 'success')
  } catch (error) {
    state.configurationGroupActionToken = null
    if (isConfigurationGroupRevisionConflict(error)) {
      state.editingConfigurationGroup = null
      elements.configurationGroupEditDialog.close()
      await refreshConfigurationGroups()
      setStatus('需求已被其他人修改，请刷新后重新编辑', 'warning')
    } else {
      renderConfigurationGroupEditDialog()
      setStatus(`保存失败：${errorText(error)}`, 'warning')
    }
  } finally {
    renderConfigurationGroups()
  }
}

function renderConfigurationGroupDeleteDialog() {
  const group = state.deletingConfigurationGroup
  if (!group) return
  const busy = state.configurationGroupActionToken === group.token
  elements.configurationGroupDeleteCopy.textContent = `确认删除「${group.name}」？所有人将无法再通过原链接使用它；已经应用的标签页会继续服役至本次预览到期。`
  elements.configurationGroupDeleteSubmit.disabled = busy
  elements.configurationGroupDeleteSubmit.textContent = busy ? '删除中' : '确认删除'
}

function openConfigurationGroupDelete(group) {
  state.deletingConfigurationGroup = group
  renderConfigurationGroupDeleteDialog()
  if (!elements.configurationGroupDeleteDialog.open)
    elements.configurationGroupDeleteDialog.showModal()
  elements.configurationGroupDeleteCancel.focus()
}

function closeConfigurationGroupDelete() {
  if (state.deletingConfigurationGroup && state.configurationGroupActionToken) return
  state.deletingConfigurationGroup = null
  if (elements.configurationGroupDeleteDialog.open) elements.configurationGroupDeleteDialog.close()
}

async function deleteConfigurationGroup(event) {
  event.preventDefault()
  const group = state.deletingConfigurationGroup
  if (!group || state.configurationGroupActionToken) return
  state.configurationGroupActionToken = group.token
  renderConfigurationGroupDeleteDialog()
  renderConfigurationGroups()
  setStatus(`正在删除需求「${group.name}」`, 'busy')
  try {
    await api(`/api/v1/config-groups/${encodeURIComponent(group.token)}`, { method: 'DELETE' })
    state.configurationGroupActionToken = null
    state.deletingConfigurationGroup = null
    elements.configurationGroupDeleteDialog.close()
    await refreshConfigurationGroups()
    setStatus(`需求「${group.name}」已删除`, 'success')
  } catch (error) {
    state.configurationGroupActionToken = null
    renderConfigurationGroupDeleteDialog()
    setStatus(`删除失败：${errorText(error)}`, 'warning')
  } finally {
    renderConfigurationGroups()
  }
}

function previewOrigin() {
  if (!state.binding) return null
  try {
    const current = new URL(state.tab?.url || '')
    const protocol = current.hostname === state.binding.hostname ? current.protocol : 'https:'
    return `${protocol}//${state.binding.hostname}`
  } catch {
    return `https://${state.binding.hostname}`
  }
}

function activeSummary() {
  if (!state.active?.preview) return ''
  const labels = []
  if (state.active.preview.siteArtifactId && state.binding) {
    const branch =
      state.active.preview.siteSelection?.branch ||
      branchForArtifact(state.binding.targetId, state.active.preview.siteArtifactId)
    labels.push(`${state.binding.name} · ${branch || '页面产物'}`)
  }
  for (const selection of state.active.preview.selections || []) {
    labels.push(`${selection.moduleKey} · ${selection.branch}`)
  }
  return labels.join('；') || '页面与热更均使用官网版本'
}

function renderActive() {
  elements.activePanel.hidden = !state.active
  if (!state.active) return
  const servingSlug = state.active.preview?.environmentSlug || ''
  const servingEnvironment = state.environments.find(
    (environment) => environment.slug === servingSlug
  )
  const servingName = servingEnvironment?.name || servingSlug || '未知环境'
  const editingSlug = state.environment?.slug || ''
  const editingName = state.environment?.name || editingSlug
  const mismatched = Boolean(servingSlug && editingSlug && servingSlug !== editingSlug)
  elements.activePanel.classList.toggle('environment-mismatch', mismatched)
  elements.activeTitle.textContent = mismatched
    ? `当前仍在 ${servingName}`
    : `此标签页正在预览 · ${servingName}`
  elements.activeSummary.textContent = mismatched
    ? `应用后切换至 ${editingName}；${activeSummary()}`
    : activeSummary()
}

function renderEnvironmentPicker() {
  const environments = state.environments || []
  elements.environmentBar.hidden = false
  elements.environmentSelect.replaceChildren()
  if (!environments.length) {
    const option = document.createElement('option')
    option.value = ''
    option.textContent = '暂无可用环境'
    elements.environmentSelect.append(option)
    elements.environmentSelect.disabled = true
    elements.environmentHint.textContent = '请先配置'
    elements.environmentHint.removeAttribute('title')
    return
  }

  for (const environment of environments) {
    const option = document.createElement('option')
    option.value = environment.slug
    option.textContent = environmentOptionLabel(environment)
    option.selected = environment.slug === state.environment?.slug
    elements.environmentSelect.append(option)
  }
  elements.environmentSelect.disabled = state.environmentChanging
  elements.environmentHint.textContent = `${environments.length} 个可选`
  if (state.environment?.backendOrigin) {
    elements.environmentHint.title = `业务后端：${state.environment.backendOrigin}`
  } else {
    elements.environmentHint.removeAttribute('title')
  }
}

function targetBranchItems(target, catalog, selectedBranch) {
  return prepareTargetBranchItems({
    target,
    catalog,
    selectedBranch,
    environmentStatus: state.environment?.status || '',
  })
}

function officialChoice(isSite) {
  return isSite
    ? { label: '官网页面', detail: '不替换页面产物' }
    : { label: '官方热更', detail: '由 KOOK 官方热更响应决定' }
}

function openTargetBranchPicker(target, trigger) {
  if (branchPicker.targetId === target.id) {
    branchPicker.close()
    return
  }
  const isSite = target.id === state.siteTargetId
  const catalog = state.branches[target.id] || { items: [], remoteAvailable: false }
  const selectedBranch = state.selectedBranches[target.id] || ''
  branchPicker.open({
    targetId: target.id,
    targetName: target.name,
    items: targetBranchItems(target, catalog, selectedBranch),
    queue: state.queue,
    environmentSlug: state.environment?.slug || '',
    selectedBranch,
    official: officialChoice(isSite),
    trigger,
    onSelect: (branch) => {
      if (state.selectedBranches[target.id] !== branch) {
        delete state.submittedBuildBranches[target.id]
      }
      state.selectedBranches[target.id] = branch
      renderModules()
      void persistCurrentPopupState()
    },
  })
}

function refreshOpenBranchPicker() {
  const target = state.targets.find((candidate) => candidate.id === branchPicker.targetId)
  if (!target) {
    if (branchPicker.targetId) branchPicker.close({ restoreFocus: false })
    return
  }
  const selectedBranch = state.selectedBranches[target.id] || ''
  const catalog = state.branches[target.id] || { items: [], remoteAvailable: false }
  branchPicker.update({
    items: targetBranchItems(target, catalog, selectedBranch),
    queue: state.queue,
    environmentSlug: state.environment?.slug || '',
    selectedBranch,
  })
}

function renderModules() {
  elements.moduleList.replaceChildren()
  elements.moduleList.removeAttribute('aria-busy')
  if (!state.targets.length) {
    const empty = document.createElement('div')
    empty.className = 'empty-state'
    empty.innerHTML = state.binding
      ? '<strong>这个站点还没有可用项目</strong><span>检查页面项目、Remote 项目是否已启用并配置 Git 仓库。</span>'
      : '<strong>当前页面没有站点绑定</strong><span>在管理后台添加站点，并把它对应到当前官网地址。</span>'
    elements.moduleList.append(empty)
  }

  for (const target of state.targets) {
    const isSite = target.id === state.siteTargetId
    const catalog = state.branches[target.id] || { items: [], remoteAvailable: false }
    const branch = state.selectedBranches[target.id] || ''
    const branchItems = targetBranchItems(target, catalog, branch)
    const branchItem = branch ? branchItems.find((item) => item.branch === branch) : null
    const artifact = branchItem?.latestArtifact || null
    const buildPresentation = branch
      ? describeBranchBuild({
          item: branchItem,
          queueItems: flattenBuildQueue(state.queue),
          targetId: target.id,
          environmentSlug: state.environment?.slug || '',
        })
      : null
    const row = document.createElement('article')
    row.className = `module-row ${isSite ? 'site-module' : 'remote-module'}`

    const heading = document.createElement('div')
    heading.className = 'module-heading'
    const name = document.createElement('strong')
    name.textContent = target.name
    heading.append(name)
    if (isSite) {
      const kind = document.createElement('span')
      kind.className = 'module-kind site-kind'
      kind.textContent = '页面'
      heading.append(kind)
    }

    const controls = document.createElement('div')
    controls.className = 'module-controls'
    const pickerTrigger = document.createElement('button')
    pickerTrigger.type = 'button'
    pickerTrigger.className = 'branch-picker-trigger'
    pickerTrigger.dataset.targetId = target.id
    pickerTrigger.setAttribute('aria-label', `${target.name} 分支`)
    pickerTrigger.setAttribute('aria-haspopup', 'listbox')
    pickerTrigger.setAttribute('aria-expanded', 'false')
    pickerTrigger.setAttribute('aria-controls', 'branch-picker-list')
    const pickerValue = document.createElement('span')
    pickerValue.className = 'branch-picker-trigger-value'
    pickerValue.textContent = branch || officialChoice(isSite).label
    pickerValue.title = pickerValue.textContent
    const pickerChevron = document.createElement('span')
    pickerChevron.className = 'branch-picker-trigger-chevron'
    pickerChevron.setAttribute('aria-hidden', 'true')
    pickerChevron.textContent = '⌄'
    pickerTrigger.append(pickerValue, pickerChevron)
    pickerTrigger.addEventListener('click', () => openTargetBranchPicker(target, pickerTrigger))
    const build = document.createElement('button')
    build.type = 'button'
    build.className = 'secondary-button build-button'
    const submitting = operationMatchesContext(
      state.busyTargets.get(target.id),
      currentOperationContext(target.id, branch),
      { requireBranch: true }
    )
    const submitted = isBuildSubmissionLocked(state.submittedBuildBranches, target.id, branch)
    const activeBuild = Boolean(buildPresentation?.active)
    const environmentActive = state.environment?.status === 'ACTIVE'
    build.textContent = submitting
      ? '提交中'
      : submitted
        ? '已提交'
        : activeBuild
          ? buildPresentation.status === 'QUEUED'
            ? '已排队'
            : '构建中'
          : '打最新包'
    build.disabled =
      submitting ||
      submitted ||
      activeBuild ||
      !branch ||
      !environmentActive ||
      !target.enabled ||
      !target.configured
    if (submitted) {
      build.title = '任务已提交；刷新数据或切换分支后可再次提交'
    } else if (activeBuild) {
      build.title = '该分支已有活动任务，可点击下方进度状态查看详情'
    } else if (!branch) {
      build.title = '请先选择要打包的分支'
    } else if (!environmentActive || !target.enabled || !target.configured) {
      build.title = !target.configured
        ? '项目未配置 Git 仓库，只能选择已有产物进行预览'
        : state.environment?.status === 'FROZEN'
          ? '环境已冻结，只能选择已有产物进行预览'
          : state.environment?.status === 'ARCHIVED'
            ? '环境已归档，不能发起构建'
            : '项目当前不可构建'
    }
    build.addEventListener('click', () => void createBuild(target.id, branch))
    controls.append(pickerTrigger, build)

    const meta = document.createElement('div')
    meta.className = 'module-meta'
    const builtAt = document.createElement('span')
    builtAt.textContent = !branch
      ? isSite
        ? `使用 ${state.binding?.officialOrigin || '官网页面'}`
        : '由 KOOK 官方热更响应决定'
      : artifact
        ? `上次打包 ${formatTime(artifact.builtAt)}`
        : '这个分支还没有可用产物'
    const buildState = document.createElement(buildPresentation?.jobId ? 'button' : 'span')
    if (buildState instanceof HTMLButtonElement) {
      buildState.type = 'button'
      buildState.className = 'queue-job-link'
      buildState.title = '打开当前构建的详情和日志'
      buildState.addEventListener('click', () => void openJobDetail(buildPresentation.jobId))
    }
    if (!branch) {
      buildState.textContent = isSite ? '不替换页面' : '不覆盖'
    } else if (buildPresentation?.active) {
      buildState.classList.add('working')
      buildState.textContent = buildPresentation.label
    } else if (buildPresentation?.tone === 'failed') {
      buildState.classList.add('failed')
      buildState.textContent = buildPresentation.label
    } else if (buildPresentation?.tone === 'canceled') {
      buildState.textContent = buildPresentation.label
    } else if (state.environment?.status === 'FROZEN') {
      buildState.textContent = '环境已冻结，可预览已有包'
    } else if (!target.configured) {
      buildState.textContent = '未配置 Git，可预览已有包'
    } else if (!target.enabled) {
      buildState.textContent = '当前环境不可构建'
    } else {
      buildState.textContent = catalog.remoteAvailable ? 'Git 已连接' : '使用本地分支记录'
    }
    if (branch || isSite) {
      meta.append(builtAt, buildState)
      row.append(heading, controls, meta)
    } else {
      row.append(heading, controls)
    }
    elements.moduleList.append(row)
  }

  const selected = selectedArtifacts()
  const plan = planPreviewApplication({
    binding: state.binding,
    environmentSlug: state.environment?.slug || '',
    previewOrigin: previewOrigin(),
    siteArtifactId: selected.siteArtifactId,
    selections: selected.selections,
  })
  const labels = state.targets
    .filter((target) => state.selectedBranches[target.id])
    .map((target) => `${target.name} · ${state.selectedBranches[target.id]}`)
  elements.selectionSummary.textContent = labels.length ? labels.join('；') : '全部使用官网版本'
  const missingReason = selected.missing.length
    ? `${selected.missing[0].targetName} 的 ${selected.missing[0].branch} 尚无成功可用的产物${selected.missing.length > 1 ? `，另有 ${selected.missing.length - 1} 项也未就绪` : ''}`
    : ''
  const applyDisabledReason = state.applyingToken
    ? '正在应用到当前标签页，请稍候'
    : missingReason || plan.reason || ''
  elements.applyButton.textContent = state.applyingToken ? '应用中' : '应用'
  elements.applyButton.disabled = Boolean(applyDisabledReason)
  elements.applyButton.title = applyDisabledReason
  elements.applyButtonWrap.title = applyDisabledReason
  elements.applyButtonWrap.tabIndex = applyDisabledReason ? 0 : -1
  if (applyDisabledReason) {
    elements.applyButtonWrap.setAttribute('aria-label', `无法应用：${applyDisabledReason}`)
  } else {
    elements.applyButtonWrap.removeAttribute('aria-label')
  }
  elements.applyButton.setAttribute(
    'aria-label',
    applyDisabledReason ? `无法应用：${applyDisabledReason}` : '应用到当前标签页'
  )
  renderShareButton()
  refreshOpenBranchPicker()
}

function renderModuleLoading() {
  elements.moduleList.replaceChildren()
  elements.moduleList.setAttribute('aria-busy', 'true')

  const loading = document.createElement('div')
  loading.className = 'module-loading'
  loading.setAttribute('role', 'status')

  const spinner = document.createElement('span')
  spinner.className = 'module-loading-spinner'
  spinner.setAttribute('aria-hidden', 'true')

  const label = document.createElement('span')
  label.textContent = '正在读取站点、项目和分支'
  loading.append(spinner, label)
  elements.moduleList.append(loading)
}

function fullTime(value) {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '—'
  return new Intl.DateTimeFormat('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).format(date)
}

function targetDisplayName(targetId) {
  return state.targetNames[targetId] || targetId
}

function renderProgress(presentation, className = 'build-progress') {
  const wrap = document.createElement('span')
  wrap.className = className
  const track = document.createElement('span')
  track.className = 'build-progress-track'
  track.setAttribute('role', 'progressbar')
  track.setAttribute('aria-valuemin', '0')
  track.setAttribute('aria-valuemax', '100')
  track.setAttribute('aria-valuenow', String(presentation.progress))
  track.setAttribute('aria-label', `${presentation.label}，阶段进度 ${presentation.progressLabel}`)
  const value = document.createElement('span')
  value.className = `build-progress-value ${presentation.tone}`
  value.style.width = `${presentation.progress}%`
  track.append(value)
  const label = document.createElement('span')
  label.className = 'build-progress-label'
  label.textContent = presentation.progressLabel
  wrap.append(track, label)
  return wrap
}

function renderBuildQueue() {
  const jobs = orderedBuildQueue(state.queue)
  const runningCount = state.queue?.running?.length || 0
  const queuedCount = state.queue?.queued?.length || 0
  elements.queueTabCount.textContent = String(jobs.length)
  elements.queueTab.setAttribute(
    'aria-label',
    `构建队列，运行 ${runningCount}，排队 ${queuedCount}`
  )
  const queueSummary = buildQueueSummary(state.queue)
  if (state.queueRefreshError) {
    const lastSuccess = state.queueLastSuccessAt
      ? `最后成功 ${formatTime(state.queueLastSuccessAt)}`
      : '尚无成功刷新'
    elements.queueSummary.textContent = `${queueSummary} · 刷新中断 · ${lastSuccess}`
    elements.queueSummary.title = `队列刷新失败：${state.queueRefreshError}`
  } else {
    elements.queueSummary.textContent = queueSummary
    elements.queueSummary.removeAttribute('title')
  }
  elements.queueList.replaceChildren()
  if (!jobs.length) {
    const empty = document.createElement('div')
    empty.className = 'queue-empty'
    empty.textContent =
      state.queueRefreshError && !state.queueLastSuccessAt
        ? '构建队列刷新中断，暂时无法确认打包机状态。'
        : '打包机当前空闲，没有排队或运行中的任务。'
    elements.queueList.append(empty)
    return
  }

  const fragment = document.createDocumentFragment()
  for (const job of jobs) {
    const presentation = buildJobPresentation(job)
    const item = document.createElement('article')
    item.className = `queue-item ${presentation.tone}${
      job.environmentSlug === state.environment?.slug ? ' current-environment' : ''
    }`

    const open = document.createElement('button')
    open.type = 'button'
    open.className = 'queue-job-open'
    open.title = '打开任务详情、命令和实时日志'
    open.addEventListener('click', () => void openJobDetail(job.id))

    const heading = document.createElement('span')
    heading.className = 'queue-job-heading'
    const name = document.createElement('strong')
    name.textContent = `${targetDisplayName(job.targetId)} · ${job.branch}`
    name.title = `${job.targetId} · ${job.branch}`
    const status = document.createElement('span')
    status.className = `queue-status ${presentation.tone}`
    status.textContent = presentation.label
    heading.append(name, status)

    const meta = document.createElement('span')
    meta.className = 'queue-job-meta'
    const actor = job.requestedBy || '未记录操作人'
    meta.textContent = `${job.environmentSlug || '未记录环境'} · ${
      job.isMine ? '我（' + actor + '）' : actor
    } · ${formatTime(job.startedAt || job.createdAt)}`
    open.append(heading, meta, renderProgress(presentation))
    item.append(open)

    if (presentation.cancelable) {
      const cancel = document.createElement('button')
      cancel.type = 'button'
      cancel.className = 'queue-cancel-button'
      cancel.textContent = state.cancelingJobs.has(job.id) ? '中断中' : '中断'
      cancel.disabled = state.cancelingJobs.has(job.id)
      cancel.title = job.status === 'QUEUED' ? '取消这个排队任务' : '请求 Runner 中断这个任务'
      cancel.addEventListener('click', () => void cancelBuildJob(job.id))
      item.append(cancel)
    }
    fragment.append(item)
  }
  elements.queueList.append(fragment)
}

function appendDetailField(list, labelText, valueText, title = '') {
  const row = document.createElement('div')
  const label = document.createElement('dt')
  label.textContent = labelText
  const value = document.createElement('dd')
  value.textContent = valueText
  if (title) value.title = title
  row.append(label, value)
  list.append(row)
}

function sectionTitle(text) {
  const heading = document.createElement('h3')
  heading.textContent = text
  return heading
}

function renderJobOverview(detail) {
  const fragment = document.createDocumentFragment()
  const presentation = buildJobPresentation(detail.job)
  const snapshotEnvironment = detail.job.targetSnapshot?.environment || null
  const summary = document.createElement('section')
  summary.className = 'job-summary-card'
  const status = document.createElement('div')
  status.className = 'job-summary-status'
  const badge = document.createElement('strong')
  badge.className = `queue-status ${presentation.tone}`
  badge.textContent = presentation.label
  status.append(badge, renderProgress(presentation, 'build-progress detail-progress'))
  summary.append(status)

  const fields = document.createElement('dl')
  fields.className = 'job-detail-fields'
  appendDetailField(fields, '项目', targetDisplayName(detail.job.targetId), detail.job.targetId)
  appendDetailField(
    fields,
    '环境',
    snapshotEnvironment?.name
      ? `${snapshotEnvironment.name} · ${detail.job.environmentSlug}`
      : detail.job.environmentSlug || '未记录'
  )
  appendDetailField(
    fields,
    '业务后端',
    snapshotEnvironment?.backendOrigin || '历史任务未记录',
    snapshotEnvironment?.backendOrigin || ''
  )
  appendDetailField(fields, '操作人', detail.job.requestedBy || '未记录')
  appendDetailField(fields, '提交', fullTime(detail.job.createdAt))
  appendDetailField(fields, '开始', fullTime(detail.job.startedAt))
  appendDetailField(fields, '结束', fullTime(detail.job.finishedAt))
  summary.append(fields)

  if (detail.job.failureMessage) {
    const failure = document.createElement('div')
    failure.className = 'job-failure'
    const code = document.createElement('strong')
    code.textContent = detail.job.failureCode || 'BUILD_FAILED'
    const message = document.createElement('span')
    message.textContent = detail.job.failureMessage
    failure.append(code, message)
    summary.append(failure)
  }
  fragment.append(summary)

  const timeline = document.createElement('section')
  timeline.className = 'job-detail-section'
  timeline.append(sectionTitle('执行时间线'))
  const events = document.createElement('ol')
  events.className = 'job-timeline'
  for (const event of detail.events || []) {
    const row = document.createElement('li')
    const dot = document.createElement('span')
    dot.className = `timeline-dot ${buildJobPresentation(event).tone}`
    const copy = document.createElement('span')
    const name = document.createElement('strong')
    name.textContent = buildJobPresentation(event).label
    const time = document.createElement('time')
    time.textContent = fullTime(event.createdAt)
    copy.append(name, time)
    row.append(dot, copy)
    events.append(row)
  }
  if (!events.children.length) {
    const empty = document.createElement('p')
    empty.className = 'detail-empty-copy'
    empty.textContent = '暂无执行事件'
    timeline.append(empty)
  } else {
    timeline.append(events)
  }
  fragment.append(timeline)

  const commands = document.createElement('section')
  commands.className = 'job-detail-section'
  commands.append(sectionTitle('执行命令'))
  const commandList = document.createElement('div')
  commandList.className = 'job-command-list'
  for (const step of detail.commands || []) {
    const row = document.createElement('div')
    const label = document.createElement('span')
    label.textContent = step.label
    const command = document.createElement('code')
    command.textContent = step.command
    row.append(label, command)
    commandList.append(row)
  }
  if (!commandList.children.length) {
    const empty = document.createElement('p')
    empty.className = 'detail-empty-copy'
    empty.textContent = '历史任务没有保存命令快照'
    commands.append(empty)
  } else {
    commands.append(commandList)
  }
  fragment.append(commands)

  const result = document.createElement('section')
  result.className = 'job-detail-section job-result'
  result.append(sectionTitle('构建结果'))
  if (detail.artifact) {
    const resultFields = document.createElement('dl')
    resultFields.className = 'job-detail-fields compact-fields'
    appendDetailField(resultFields, 'Artifact', detail.artifact.id.slice(0, 12), detail.artifact.id)
    appendDetailField(resultFields, '文件', `${detail.artifact.fileCount} 个`)
    appendDetailField(resultFields, '生成', fullTime(detail.artifact.builtAt))
    result.append(resultFields)
  } else {
    const empty = document.createElement('p')
    empty.className = 'detail-empty-copy'
    empty.textContent = TERMINAL_BUILD_STATUSES.has(detail.job.status)
      ? '任务没有生成可用产物'
      : '构建完成后显示产物信息'
    result.append(empty)
  }
  fragment.append(result)
  return fragment
}

function renderJobLog(detail, log) {
  const section = document.createElement('section')
  section.className = 'job-log-section'
  const toolbar = document.createElement('div')
  toolbar.className = 'job-log-toolbar'
  const stateText = document.createElement('span')
  stateText.textContent = log
    ? `${log.complete ? '日志已结束' : '实时日志'}${log.truncated ? ' · 已截断' : ''}`
    : '正在读取日志'
  const actions = document.createElement('span')
  actions.className = 'job-log-actions'
  const copy = document.createElement('button')
  copy.type = 'button'
  copy.className = 'text-button compact-action'
  copy.textContent = '复制'
  copy.disabled = !log?.content
  copy.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(log?.content || '')
      setStatus('日志已复制', 'success')
    } catch (error) {
      setStatus(`复制失败：${errorText(error)}`, 'warning')
    }
  })
  const download = document.createElement('a')
  download.className = 'text-link compact-action'
  download.href = `${state.controlOrigin.replace(/\/$/, '')}/api/v1/build-jobs/${encodeURIComponent(
    detail.job.id
  )}/log?download=1`
  download.target = '_blank'
  download.rel = 'noreferrer'
  download.textContent = '下载'
  actions.append(copy, download)
  toolbar.append(stateText, actions)
  const consoleView = document.createElement('pre')
  consoleView.className = 'job-console'
  consoleView.tabIndex = 0
  consoleView.textContent = log?.content || (log?.complete ? '没有日志输出' : '等待 Runner 输出...')
  consoleView.addEventListener('scroll', () => {
    state.jobLogScrollTop = consoleView.scrollTop
    state.jobLogFollow =
      consoleView.scrollHeight - consoleView.scrollTop - consoleView.clientHeight < 28
  })
  section.append(toolbar, consoleView)
  window.requestAnimationFrame(() => {
    if (state.jobLogFollow) {
      consoleView.scrollTop = consoleView.scrollHeight
    } else {
      consoleView.scrollTop = state.jobLogScrollTop
    }
  })
  return section
}

function renderJobDetail() {
  const detail = state.jobDetail
  const preservedScrollTop = state.jobDetailScrollTop
  elements.jobOverviewTab.classList.toggle('active', state.jobDetailTab === 'overview')
  elements.jobLogTab.classList.toggle('active', state.jobDetailTab === 'log')
  elements.jobOverviewTab.setAttribute('aria-selected', String(state.jobDetailTab === 'overview'))
  elements.jobLogTab.setAttribute('aria-selected', String(state.jobDetailTab === 'log'))
  elements.jobDetailContent.replaceChildren()
  const expectedJobId = state.selectedJobId
  const expectedTab = state.jobDetailTab
  window.requestAnimationFrame(() => {
    if (state.selectedJobId === expectedJobId && state.jobDetailTab === expectedTab) {
      elements.jobDetailContent.scrollTop = preservedScrollTop
      state.jobDetailScrollTop = preservedScrollTop
    }
  })

  if (detail) {
    elements.jobDetailTitle.textContent = detail.job.branch
    const environmentName = detail.job.targetSnapshot?.environment?.name
    elements.jobDetailContext.textContent = `${targetDisplayName(detail.job.targetId)} · ${
      environmentName
        ? `${environmentName} · ${detail.job.environmentSlug}`
        : detail.job.environmentSlug || '未记录环境'
    } · ${detail.job.requestedBy || '未记录操作人'} · ${detail.job.id.slice(0, 8)}`
    const presentation = buildJobPresentation(detail.job)
    elements.jobDetailCancel.hidden = !presentation.cancelable
    elements.jobDetailCancel.disabled = state.cancelingJobs.has(detail.job.id)
    elements.jobDetailCancel.textContent = state.cancelingJobs.has(detail.job.id)
      ? '正在中断'
      : '中断构建'
    const refreshHint = TERMINAL_BUILD_STATUSES.has(detail.job.status)
      ? '任务已结束'
      : '任务进行中，每 2.5 秒自动刷新'
    elements.jobDetailRefreshHint.textContent = state.jobDetailRefreshError
      ? `${refreshHint} · 刷新中断`
      : refreshHint
    if (state.jobDetailRefreshError) {
      elements.jobDetailRefreshHint.title = state.jobDetailRefreshError
    } else {
      elements.jobDetailRefreshHint.removeAttribute('title')
    }
  } else {
    elements.jobDetailTitle.textContent = '构建任务'
    elements.jobDetailContext.textContent = state.selectedJobId?.slice(0, 8) || '正在读取任务'
    elements.jobDetailCancel.hidden = true
  }

  if (state.jobDetailError) {
    const error = document.createElement('div')
    error.className = 'job-detail-message error'
    const message = document.createElement('span')
    message.textContent = state.jobDetailError
    const retry = document.createElement('button')
    retry.type = 'button'
    retry.className = 'text-button'
    retry.textContent = '重试'
    retry.addEventListener('click', () => void refreshJobDetail())
    error.append(message, retry)
    elements.jobDetailContent.append(error)
    return
  }
  if (!detail) {
    const loading = document.createElement('div')
    loading.className = 'job-detail-message'
    loading.textContent = state.jobDetailLoading ? '正在读取任务详情…' : '暂无任务详情'
    elements.jobDetailContent.append(loading)
    return
  }
  elements.jobDetailContent.append(
    state.jobDetailTab === 'log' ? renderJobLog(detail, state.jobLog) : renderJobOverview(detail)
  )
}

async function refreshJobDetail() {
  const jobId = state.selectedJobId
  if (!jobId) return
  const generation = ++jobDetailGeneration
  state.jobDetailLoading = !state.jobDetail
  state.jobDetailError = ''
  renderJobDetail()
  try {
    const wantsLog = state.jobDetailTab === 'log'
    const [detail, log] = await Promise.all([
      api(`/api/v1/build-jobs/${encodeURIComponent(jobId)}/detail`),
      wantsLog
        ? api(`/api/v1/build-jobs/${encodeURIComponent(jobId)}/log`)
        : Promise.resolve(state.jobLog),
    ])
    if (generation !== jobDetailGeneration || state.selectedJobId !== jobId) return
    state.jobDetail = detail
    if (wantsLog) state.jobLog = log
    state.jobDetailRefreshError = ''
  } catch (error) {
    if (generation !== jobDetailGeneration || state.selectedJobId !== jobId) return
    if (state.jobDetail) {
      state.jobDetailRefreshError = `刷新失败：${errorText(error)}`
    } else {
      state.jobDetailError = `读取失败：${errorText(error)}`
    }
  } finally {
    if (generation === jobDetailGeneration && state.selectedJobId === jobId) {
      state.jobDetailLoading = false
      renderJobDetail()
    }
  }
}

async function openJobDetail(jobId) {
  state.selectedJobId = jobId
  state.jobDetail = null
  state.jobLog = null
  state.jobLogFollow = true
  state.jobLogScrollTop = 0
  state.jobDetailScrollTop = 0
  state.jobDetailTab = 'overview'
  state.jobDetailError = ''
  state.jobDetailRefreshError = ''
  state.jobDetailLoading = true
  renderJobDetail()
  if (!elements.jobDetailDialog.open) {
    elements.jobDetailDialog.showModal()
    window.requestAnimationFrame(() => elements.jobDetailClose.focus())
  }
  await refreshJobDetail()
}

function closeJobDetail() {
  jobDetailGeneration += 1
  state.selectedJobId = null
  state.jobDetail = null
  state.jobLog = null
  state.jobDetailScrollTop = 0
  state.jobDetailError = ''
  state.jobDetailRefreshError = ''
  if (elements.jobDetailDialog.open) elements.jobDetailDialog.close()
}

async function changeJobDetailTab(tab) {
  if (tab !== 'overview' && tab !== 'log') return
  state.jobDetailTab = tab
  state.jobDetailScrollTop = 0
  renderJobDetail()
  if (tab === 'log') await refreshJobDetail()
}

async function cancelBuildJob(jobId) {
  if (!jobId || state.cancelingJobs.has(jobId)) return
  state.cancelingJobs.add(jobId)
  renderBuildQueue()
  renderJobDetail()
  setStatus('正在提交中断请求', 'busy')
  let canceled = null
  try {
    canceled = await api(`/api/v1/build-jobs/${encodeURIComponent(jobId)}/cancel`, {
      method: 'POST',
    })
  } catch (error) {
    setStatus(`中断失败：${errorText(error)}`, 'warning')
    return
  } finally {
    if (!canceled) {
      state.cancelingJobs.delete(jobId)
      renderBuildQueue()
      renderJobDetail()
    }
  }

  try {
    state.queue = replaceBuildQueueJob(state.queue, canceled)
    if (state.jobDetail?.job.id === jobId) {
      state.jobDetail = { ...state.jobDetail, job: canceled }
    }
    setStatus(
      canceled.status === 'CANCELED' ? '构建已取消' : '已提交中断请求',
      canceled.status === 'CANCELED' ? 'success' : 'busy'
    )
    renderBuildQueue()
    renderJobDetail()
    scheduleQueuePoll(300)
  } finally {
    state.cancelingJobs.delete(jobId)
    renderBuildQueue()
    renderJobDetail()
  }
}

async function resolveBindings(tabUrl, preferredBinding = null) {
  if (!tabUrl) return { candidates: [], preferenceKey: null }
  if (
    typeof preferredBinding?.id === 'string' &&
    preferredBinding.id &&
    typeof preferredBinding?.hostname === 'string' &&
    preferredBinding.hostname
  ) {
    try {
      const preferred = normalizeBindingCandidates(
        await optionalApi(
          `/api/v1/site-bindings/resolve?hostname=${encodeURIComponent(preferredBinding.hostname)}`
        )
      )
      const exact = preferred.find((binding) => binding.id === preferredBinding.id)
      if (exact)
        return {
          candidates: [exact, ...preferred.filter((binding) => binding !== exact)],
          preferenceKey: exact.officialOrigin,
        }
    } catch {
      // The current page can still resolve normally if a saved requirement binding was removed.
    }
  }
  const url = new URL(tabUrl)
  const byHostname = normalizeBindingCandidates(
    await optionalApi(`/api/v1/site-bindings/resolve?hostname=${encodeURIComponent(url.hostname)}`)
  )
  if (byHostname.length) return { candidates: byHostname, preferenceKey: null }

  const byOfficialOrigin = normalizeBindingCandidates(
    await optionalApi(
      `/api/v1/site-bindings/candidates?officialOrigin=${encodeURIComponent(url.origin)}`
    )
  )
  return { candidates: byOfficialOrigin, preferenceKey: url.origin }
}

async function loadActive() {
  const stored = (await chrome.storage.local.get(ACTIVE_KEY))[ACTIVE_KEY] || {}
  const active = stored[String(state.tab.id)] || null
  const expiresAt = Date.parse(active?.preview?.expiresAt || '')
  if (
    active &&
    (active.mode !== 'site' || !Number.isFinite(expiresAt) || expiresAt <= Date.now())
  ) {
    const result = await chrome.runtime.sendMessage({
      type: REMOVE_PREVIEW_TRANSACTION_COMMAND,
      tabId: state.tab.id,
    })
    state.active = result?.ok ? null : active
  } else {
    state.active = active
  }
  renderActive()
}

async function refreshBranchCatalog(targetId) {
  if (!state.targets.some((target) => target.id === targetId)) return false
  const bindingId = state.binding?.id || ''
  const environmentSlug = state.environment?.slug || ''
  if (!bindingId || !environmentSlug) return false
  try {
    const catalog = await api(
      `/api/v1/build-targets/${encodeURIComponent(targetId)}/branches?environment=${encodeURIComponent(environmentSlug)}`
    )
    if (state.binding?.id !== bindingId) return false
    state.branches[targetId] = catalog
    return true
  } catch {
    return false
  }
}

function queueSnapshotSignature(snapshot) {
  return flattenBuildQueue(snapshot)
    .map(
      (job) =>
        `${job.id}:${job.environmentSlug || ''}:${job.status}:${job.queuePosition ?? ''}:${job.startedAt || ''}:${job.createdAt}:${job.requestedBy || ''}:${job.isMine ? 'mine' : ''}`
    )
    .sort()
    .join('|')
}

async function applyQueueSnapshot(nextQueue, { refreshEnded = true } = {}) {
  const previousJobs = flattenBuildQueue(state.queue)
  const previousSignature = queueSnapshotSignature(state.queue)
  state.queue = nextQueue || emptyQueue
  const queueChanged = previousSignature !== queueSnapshotSignature(state.queue)
  if (queueChanged) {
    renderModules()
    renderBuildQueue()
  }

  if (refreshEnded && previousJobs.length) {
    for (const targetId of endedQueueTargetIds(
      { running: previousJobs, queued: [] },
      state.queue,
      state.targets.map((target) => target.id),
      state.environment?.slug || ''
    )) {
      state.dirtyCatalogTargets.add(targetId)
    }
  }

  const retryTargets = [...state.dirtyCatalogTargets].filter((targetId) =>
    state.targets.some((target) => target.id === targetId)
  )
  if (!retryTargets.length) return
  const results = await Promise.all(
    retryTargets.map(async (targetId) => [targetId, await refreshBranchCatalog(targetId)])
  )
  let refreshed = false
  for (const [targetId, succeeded] of results) {
    if (!succeeded) continue
    state.dirtyCatalogTargets.delete(targetId)
    refreshed = true
  }
  if (refreshed) renderModules()
}

function scheduleQueuePoll(delay = BUILD_QUEUE_POLL_MS) {
  if (!state.authenticated) return
  if (queuePollTimer !== null) window.clearTimeout(queuePollTimer)
  queuePollTimer = window.setTimeout(() => {
    queuePollTimer = null
    void pollBuildQueue()
  }, delay)
}

async function pollBuildQueue() {
  if (queuePollRunning || !state.authenticated) return
  if (queuePollTimer !== null) {
    window.clearTimeout(queuePollTimer)
    queuePollTimer = null
  }
  queuePollRunning = true
  try {
    const nextQueue = await api('/api/v1/build-queue')
    state.queueLastSuccessAt = Date.now()
    state.queueRefreshError = ''
    await applyQueueSnapshot(nextQueue)
    renderBuildQueue()
    if (state.selectedJobId && shouldPollBuildJob(state.jobDetail)) {
      await refreshJobDetail()
    }
  } catch (error) {
    // Keep the last known queue state; a transient polling error must not hide branch choices.
    state.queueRefreshError = errorText(error)
    renderBuildQueue()
  } finally {
    queuePollRunning = false
    scheduleQueuePoll()
  }
}

async function load({ resetSubmitted = false } = {}) {
  const generation = ++loadGeneration
  setStatus('正在读取站点、项目和分支', 'busy')
  renderModuleLoading()
  if (resetSubmitted) {
    state.submittedBuildBranches = {}
    await persistCurrentPopupState()
    if (generation !== loadGeneration) return
  }
  const previousBindingId = state.binding?.id || null
  const previousEnvironmentSlug = state.environment?.slug || null
  const previousSelectedBranches = { ...state.selectedBranches }
  const previousSubmittedBuildBranches = { ...state.submittedBuildBranches }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (generation !== loadGeneration) return
  state.tab = tab
  const saved = await chrome.storage.local.get([
    CONTROL_KEY,
    ENVIRONMENT_PREFS_KEY,
    TAB_ENVIRONMENT_PREFS_KEY,
    PROJECT_VERSION_TAB_KEY,
  ])
  if (generation !== loadGeneration) return
  state.controlOrigin = saved[CONTROL_KEY] || DEFAULT_CONTROL_ORIGIN
  state.environmentPreferences =
    saved[ENVIRONMENT_PREFS_KEY] && typeof saved[ENVIRONMENT_PREFS_KEY] === 'object'
      ? saved[ENVIRONMENT_PREFS_KEY]
      : {}
  state.tabEnvironmentPreferences =
    saved[TAB_ENVIRONMENT_PREFS_KEY] && typeof saved[TAB_ENVIRONMENT_PREFS_KEY] === 'object'
      ? saved[TAB_ENVIRONMENT_PREFS_KEY]
      : {}
  state.projectVersionTab = normalizeProjectVersionTab(saved[PROJECT_VERSION_TAB_KEY])
  setProjectVersionTab(state.projectVersionTab)
  elements.controlOrigin.value = state.controlOrigin
  elements.pageTitle.textContent = tab?.title || '当前标签页'
  elements.pageMeta.textContent = tab?.url || '无法读取页面地址'

  state.authenticated = false
  state.authLoading = true
  state.authHint = '正在检查登录状态'
  state.identity = null
  state.csrfToken = ''
  if (queuePollTimer !== null) {
    window.clearTimeout(queuePollTimer)
    queuePollTimer = null
  }
  renderAuthentication()
  let session
  try {
    session = await readAuthSession(state.controlOrigin)
  } catch (error) {
    if (generation !== loadGeneration) return
    expireAuthentication(`无法检查登录状态：${errorText(error)}`)
    return
  }
  if (generation !== loadGeneration) return
  if (!session) {
    expireAuthentication('请使用飞书登录后继续')
    return
  }
  setAuthenticatedSession(session)
  void refreshConfigurationGroups()
  await loadActive()
  if (generation !== loadGeneration) return

  try {
    const tabConfigurationPreference =
      Number.isInteger(tab?.id) &&
      state.tabEnvironmentPreferences[String(tab.id)]?.configurationGroupBindingId
        ? {
            id: state.tabEnvironmentPreferences[String(tab.id)].configurationGroupBindingId,
            hostname:
              state.tabEnvironmentPreferences[String(tab.id)].configurationGroupHostname || '',
          }
        : null
    const [resolution, environmentBody, queueResult] = await Promise.all([
      resolveBindings(tab?.url, tabConfigurationPreference),
      api('/api/v1/environments'),
      api('/api/v1/build-queue')
        .then((queue) => ({ queue, error: null }))
        .catch((error) => ({ queue: state.queue, error })),
    ])
    if (generation !== loadGeneration) return
    const binding = chooseBindingCandidate({
      candidates: resolution.candidates,
      activeSiteBindingId: state.active?.preview?.siteBindingId || '',
    })
    state.binding = binding
    state.environments = normalizeEnvironments(environmentBody)
    const officialOrigin = selectedOfficialOrigin()
    const tabEnvironmentSlug = readTabEnvironmentPreference(state.tabEnvironmentPreferences, {
      tabId: tab?.id,
      officialOrigin,
    })
    const activeEnvironmentSlug =
      state.active?.preview?.siteBindingId === binding?.id
        ? state.active?.preview?.environmentSlug || ''
        : ''
    state.environment = chooseEnvironment({
      environments: state.environments,
      tabEnvironmentSlug,
      activeEnvironmentSlug,
      rememberedEnvironmentSlug: officialOrigin
        ? state.environmentPreferences[officialOrigin] || ''
        : '',
    })
    const sameScope =
      previousBindingId === (binding?.id || null) &&
      previousEnvironmentSlug === (state.environment?.slug || null)
    if (!sameScope) {
      state.dirtyCatalogTargets.clear()
      state.submittedBuildBranches = {}
      state.busyTargets.clear()
      state.targets = []
      state.targetNames = {}
      state.branches = {}
      state.selectedBranches = {}
      branchPicker.close({ restoreFocus: false })
    }
    state.queue = queueResult.queue || emptyQueue
    if (queueResult.error) {
      state.queueRefreshError = errorText(queueResult.error)
    } else {
      state.queueLastSuccessAt = Date.now()
      state.queueRefreshError = ''
    }
    renderEnvironmentPicker()

    if (binding && state.environment) {
      const targetBody = await api(
        `/api/v1/build-targets?environment=${encodeURIComponent(state.environment.slug)}`
      )
      if (generation !== loadGeneration) return
      const allTargets = targetBody.items || []
      state.targetNames = Object.fromEntries(allTargets.map((target) => [target.id, target.name]))
      state.environment = targetBody.environment || state.environment
      const allowedIds = new Set([binding.targetId, ...(binding.remoteTargetIds || [])])
      state.targets = allTargets.filter((target) => allowedIds.has(target.id))
      state.siteTargetId = state.targets.some((target) => target.id === binding.targetId)
        ? binding.targetId
        : null
      elements.pageTitle.textContent = binding.name
    } else {
      state.targets = []
      state.targetNames = {}
      state.siteTargetId = null
    }

    const catalogs = await Promise.all(
      state.targets.map(async (target) => [
        target.id,
        await api(
          `/api/v1/build-targets/${encodeURIComponent(target.id)}/branches?environment=${encodeURIComponent(state.environment?.slug || '')}`
        ),
      ])
    )
    if (generation !== loadGeneration) return
    state.branches = Object.fromEntries(catalogs)
    const persistedPopupState =
      binding && state.environment
        ? await readPersistedPopupState(tab?.id, binding.id, state.environment.slug).catch(
            () => null
          )
        : null
    if (generation !== loadGeneration) return
    const defaultSelectedBranches = {}
    const activeMatchesScope =
      state.active?.preview?.siteBindingId === binding?.id &&
      state.active?.preview?.environmentSlug === state.environment?.slug
    for (const target of state.targets) {
      defaultSelectedBranches[target.id] = ''
      if (!activeMatchesScope) continue
      if (target.id === state.siteTargetId) {
        defaultSelectedBranches[target.id] = state.active?.preview?.siteArtifactId
          ? state.active?.preview?.siteSelection?.branch ||
            branchForArtifact(target.id, state.active.preview.siteArtifactId)
          : ''
        continue
      }
      const activeSelection = state.active?.preview?.selections?.find(
        (item) => item.targetId === target.id
      )
      defaultSelectedBranches[target.id] = activeSelection
        ? activeSelection.branch || branchForArtifact(target.id, activeSelection.artifactId)
        : ''
    }
    const inMemoryPopupState = sameScope
      ? {
          selectedBranches: previousSelectedBranches,
          submittedBuildBranches: previousSubmittedBuildBranches,
        }
      : null
    // During an in-place refresh the popup's current selection is newer than the persisted
    // snapshot. On a newly opened popup there is no in-memory scope, so the worker snapshot wins.
    const restoredPopupState = chooseRestoredPopupState(inMemoryPopupState, persistedPopupState)
    state.selectedBranches = mergeSelectedBranches({
      sameBinding: Boolean(restoredPopupState),
      previous: restoredPopupState?.selectedBranches || {},
      defaults: defaultSelectedBranches,
    })
    const allowedTargetIds = new Set(state.targets.map((target) => target.id))
    state.submittedBuildBranches = Object.fromEntries(
      Object.entries(restoredPopupState?.submittedBuildBranches || {}).filter(([targetId]) =>
        allowedTargetIds.has(targetId)
      )
    )
    void persistCurrentPopupState()
    if (state.environment && !tabEnvironmentSlug) {
      void persistEnvironmentSelection(state.environment.slug, { rememberGlobally: false })
    }
    renderActive()
    renderModules()
    renderConfigurationGroups()
    renderBuildQueue()
    setStatus(
      binding
        ? `已关联 ${binding.hostname} · ${state.environment?.name || '暂无环境'}`
        : `${SITE_BINDING_REQUIRED}，Remote 热更不能单独应用到官网标签页`,
      binding ? '' : 'warning'
    )
    scheduleQueuePoll()
  } catch (error) {
    if (generation !== loadGeneration) return
    state.binding = null
    state.environment = null
    state.environments = []
    state.targets = []
    state.targetNames = {}
    state.siteTargetId = null
    renderEnvironmentPicker()
    renderActive()
    renderModules()
    renderBuildQueue()
    setStatus(`连接失败：${errorText(error)}`, 'warning')
  }
}

async function createBuild(targetId, branch) {
  const operation = {
    ...currentOperationContext(targetId, branch),
    controlOrigin: state.controlOrigin,
    csrfToken: state.csrfToken,
    token: crypto.randomUUID(),
  }
  if (!operation.environmentSlug) {
    setStatus('当前页面没有可用环境，无法发起打包', 'warning')
    return
  }
  const target = state.targets.find((candidate) => candidate.id === targetId)
  if (!target?.enabled || !target.configured || state.environment?.status !== 'ACTIVE') {
    setStatus(
      !target?.configured
        ? '项目没有配置 Git 仓库，只能选择已有产物进行预览'
        : state.environment?.status === 'FROZEN'
          ? '当前环境已冻结，只能选择已有产物进行预览'
          : '项目当前不可构建',
      'warning'
    )
    return
  }
  state.busyTargets.set(targetId, operation)
  renderModules()
  setStatus(`${branch} 正在提交打包任务`, 'busy')
  try {
    const job = await apiWithContext(operation, '/api/v1/build-jobs', {
      method: 'POST',
      headers: { 'idempotency-key': crypto.randomUUID() },
      body: JSON.stringify({
        environmentSlug: operation.environmentSlug,
        targetId,
        branch,
        profile: 'qa-web',
      }),
    })
    scheduleQueuePoll(300)
    const operationStillInScope = operationMatchesContext(
      operation,
      currentOperationContext(targetId, state.selectedBranches[targetId] || '')
    )
    if (!operationStillInScope) return
    const sameSelectedBranch = operationMatchesContext(
      operation,
      currentOperationContext(targetId, state.selectedBranches[targetId] || ''),
      { requireBranch: true }
    )
    if (sameSelectedBranch) {
      state.submittedBuildBranches[targetId] = branch
      void persistCurrentPopupState()
    }
    state.queue = {
      ...state.queue,
      queued: [
        ...(state.queue.queued || []).filter((item) => item.id !== job.id),
        {
          id: job.id,
          environmentId: job.environmentId,
          environmentSlug: job.environmentSlug,
          targetId: job.targetId,
          branch: job.branch,
          status: job.status,
          requestedBy: job.requestedBy,
          createdAt: job.createdAt,
          startedAt: job.startedAt,
          queuePosition: null,
          isMine: true,
        },
      ],
    }
    renderBuildQueue()
    setStatus(`${branch} 已加入 ${operation.environmentSlug} 环境的全局队列`, 'success')
  } catch (error) {
    if (
      operationMatchesContext(
        operation,
        currentOperationContext(targetId, state.selectedBranches[targetId] || '')
      )
    ) {
      setStatus(`提交失败：${errorText(error)}`, 'warning')
    }
  } finally {
    if (state.busyTargets.get(targetId)?.token === operation.token) {
      state.busyTargets.delete(targetId)
      renderModules()
    }
  }
}

async function applyPreview() {
  if (state.applyingToken) return
  const selectedSnapshot = selectedArtifacts()
  const selected = {
    siteArtifactId: selectedSnapshot.siteArtifactId,
    selections: selectedSnapshot.selections.map((selection) => ({ ...selection })),
    missing: selectedSnapshot.missing.map((item) => ({ ...item })),
  }
  if (selected.missing.length) {
    const first = selected.missing[0]
    setStatus(`${first.targetName} 的 ${first.branch} 尚无成功可用的产物，请先打包`, 'warning')
    return
  }
  const binding = state.binding
    ? {
        ...state.binding,
        remoteTargetIds: [...(state.binding.remoteTargetIds || [])],
      }
    : null
  const tab = state.tab ? { id: state.tab.id, url: state.tab.url } : null
  const operation = {
    ...currentOperationContext(),
    controlOrigin: state.controlOrigin,
    csrfToken: state.csrfToken,
    binding,
    tab,
    token: crypto.randomUUID(),
  }
  const plan = planPreviewApplication({
    binding,
    environmentSlug: operation.environmentSlug,
    previewOrigin: previewOrigin(),
    siteArtifactId: selected.siteArtifactId,
    selections: selected.selections,
  })
  if (!tab?.id) return
  if (!plan.canApply) {
    setStatus(plan.reason, 'warning')
    return
  }
  state.applyingToken = operation.token
  renderModules()
  setStatus('正在创建标签页预览', 'busy')
  let preview = null
  try {
    await requireExtensionCapabilities((message) => chrome.runtime.sendMessage(message))

    const granted = await chrome.permissions.request({ origins: [`${plan.requestedOrigin}/*`] })
    if (!granted) throw new Error(`没有获得 ${plan.requestedOrigin} 的预览访问权限`)

    preview = await apiWithContext(operation, '/api/v1/previews', {
      method: 'POST',
      body: JSON.stringify(
        createPreviewRequest({
          binding,
          environmentSlug: operation.environmentSlug,
          siteArtifactId: selected.siteArtifactId,
          selections: selected.selections,
        })
      ),
    })

    const origin = plan.requestedOrigin
    const targetUrl = previewDestinationUrl(origin, tab.url)
    const result = await chrome.runtime.sendMessage({
      type: APPLY_SITE_PREVIEW_TRANSACTION_COMMAND,
      tabId: tab.id,
      previewOrigin: origin,
      controlOrigin: operation.controlOrigin,
      officialOrigin: binding.officialOrigin,
      originalUrl: tab.url,
      targetUrl,
      preview,
    })
    if (!result?.ok) throw new Error(extensionCommandErrorMessage(result, '扩展规则应用失败'))
    if (operationMatchesContext(operation, currentOperationContext())) {
      state.active = result.active
      renderActive()
      setStatus(
        selected.siteArtifactId
          ? '页面与热更预览已应用，正在打开预览域名'
          : selected.selections.length
            ? '热更预览已应用，正在打开隔离预览域名'
            : `${state.environment?.name || operation.environmentSlug} 已应用，页面与热更使用官网版本`,
        'success'
      )
    }
  } catch (error) {
    if (operationMatchesContext(operation, currentOperationContext())) {
      setStatus(`应用失败：${errorText(error)}`, 'warning')
    }
  } finally {
    if (state.applyingToken === operation.token) {
      state.applyingToken = null
      renderModules()
    }
  }
}

async function removePreview() {
  if (!state.tab?.id) return
  setStatus('正在停用当前标签页预览', 'busy')
  const result = await chrome.runtime.sendMessage({
    type: REMOVE_PREVIEW_TRANSACTION_COMMAND,
    tabId: state.tab.id,
  })
  if (!result?.ok) {
    setStatus(`停用失败：${extensionCommandErrorMessage(result, '扩展规则移除失败')}`, 'warning')
    return
  }
  state.active = null
  renderActive()
  setStatus('预览已停用', 'success')
}

async function changeEnvironment() {
  const environment = state.environments.find(
    (candidate) => candidate.slug === elements.environmentSelect.value
  )
  if (!environment || environment.slug === state.environment?.slug) return

  state.environmentChanging = true
  renderEnvironmentPicker()
  setStatus(`正在切换到 ${environmentOptionLabel(environment)}`, 'busy')
  try {
    await persistEnvironmentSelection(environment.slug)
    await load()
  } catch (error) {
    renderEnvironmentPicker()
    setStatus(`环境切换失败：${errorText(error)}`, 'warning')
  } finally {
    state.environmentChanging = false
    renderEnvironmentPicker()
  }
}

async function saveSettings(event) {
  event.preventDefault()
  const origin = new URL(elements.controlOrigin.value).origin
  const permission = `${origin}/*`
  const granted = await chrome.permissions.request({ origins: [permission] })
  if (!granted) {
    setStatus(`未获得 ${origin} 的访问权限，服务地址没有修改`, 'warning')
    return
  }
  state.controlOrigin = origin
  await chrome.storage.local.set({ [CONTROL_KEY]: origin })
  elements.settingsDialog.close()
  await load()
}

elements.refreshButton.addEventListener('click', () => void load({ resetSubmitted: true }))
elements.loginButton.addEventListener('click', () => void startFeishuLogin())
elements.logoutButton.addEventListener('click', () => void logout())
elements.identityAvatar.addEventListener('error', () => {
  elements.identityAvatar.hidden = true
  elements.identityAvatarFallback.hidden = false
})
elements.shareButton.addEventListener('click', openShareDialog)
elements.shareClose.addEventListener('click', () => elements.shareDialog.close())
elements.shareCancel.addEventListener('click', () => elements.shareDialog.close())
elements.shareForm.addEventListener('submit', (event) => void shareConfiguration(event))
elements.shareName.addEventListener('input', renderShareDialog)
elements.shareDialog.addEventListener('cancel', (event) => {
  event.preventDefault()
  if (!state.sharing) elements.shareDialog.close()
})
elements.shareDialog.addEventListener('click', (event) => {
  if (event.target === elements.shareDialog && !state.sharing) elements.shareDialog.close()
})
elements.projectsTab.addEventListener('click', () => setWorkspaceTab('projects'))
elements.queueTab.addEventListener('click', () => setWorkspaceTab('queue'))
elements.projectsTab.addEventListener('keydown', handleWorkspaceTabKey)
elements.queueTab.addEventListener('keydown', handleWorkspaceTabKey)
elements.requirementsTab.addEventListener('click', () =>
  setProjectVersionTab('requirements', { persist: true })
)
elements.branchesTab.addEventListener('click', () =>
  setProjectVersionTab('branches', { persist: true })
)
elements.requirementsTab.addEventListener('keydown', handleProjectVersionTabKey)
elements.branchesTab.addEventListener('keydown', handleProjectVersionTabKey)
elements.requirementsRefresh.addEventListener('click', () => void refreshConfigurationGroups())
elements.configurationGroupEditForm.addEventListener(
  'submit',
  (event) => void updateConfigurationGroup(event)
)
elements.configurationGroupEditName.addEventListener('input', renderConfigurationGroupEditDialog)
elements.configurationGroupOverwrite.addEventListener('change', renderConfigurationGroupEditDialog)
elements.configurationGroupEditClose.addEventListener('click', closeConfigurationGroupEdit)
elements.configurationGroupEditCancel.addEventListener('click', closeConfigurationGroupEdit)
elements.configurationGroupEditDialog.addEventListener('cancel', (event) => {
  event.preventDefault()
  closeConfigurationGroupEdit()
})
elements.configurationGroupEditDialog.addEventListener('click', (event) => {
  if (event.target === elements.configurationGroupEditDialog) closeConfigurationGroupEdit()
})
elements.configurationGroupDeleteForm.addEventListener(
  'submit',
  (event) => void deleteConfigurationGroup(event)
)
elements.configurationGroupDeleteClose.addEventListener('click', closeConfigurationGroupDelete)
elements.configurationGroupDeleteCancel.addEventListener('click', closeConfigurationGroupDelete)
elements.configurationGroupDeleteDialog.addEventListener('cancel', (event) => {
  event.preventDefault()
  closeConfigurationGroupDelete()
})
elements.configurationGroupDeleteDialog.addEventListener('click', (event) => {
  if (event.target === elements.configurationGroupDeleteDialog) closeConfigurationGroupDelete()
})
elements.settingsButton.addEventListener('click', () => {
  if (!elements.settingsDialog.open) elements.settingsDialog.showModal()
  elements.controlOrigin.focus()
})
elements.settingsCancel.addEventListener('click', () => elements.settingsDialog.close())
elements.settingsClose.addEventListener('click', () => elements.settingsDialog.close())
elements.settingsForm.addEventListener('submit', (event) => void saveSettings(event))
elements.environmentSelect.addEventListener('change', () => void changeEnvironment())
elements.applyButton.addEventListener('click', () => void applyPreview())
elements.removeButton.addEventListener('click', () => void removePreview())
elements.jobDetailClose.addEventListener('click', closeJobDetail)
elements.jobOverviewTab.addEventListener('click', () => void changeJobDetailTab('overview'))
elements.jobLogTab.addEventListener('click', () => void changeJobDetailTab('log'))
elements.jobDetailCancel.addEventListener('click', () => {
  if (state.selectedJobId) void cancelBuildJob(state.selectedJobId)
})
elements.jobDetailContent.addEventListener('scroll', () => {
  state.jobDetailScrollTop = elements.jobDetailContent.scrollTop
})
elements.jobDetailDialog.addEventListener('cancel', (event) => {
  event.preventDefault()
  closeJobDetail()
})
elements.jobDetailDialog.addEventListener('click', (event) => {
  if (event.target === elements.jobDetailDialog) closeJobDetail()
})
window.addEventListener('unload', () => {
  if (queuePollTimer !== null) window.clearTimeout(queuePollTimer)
})

setWorkspaceTab(state.workspaceTab)
renderConfigurationGroups()
void load().finally(() => scheduleQueuePoll())
