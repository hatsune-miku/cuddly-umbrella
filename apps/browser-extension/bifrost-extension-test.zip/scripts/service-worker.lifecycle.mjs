import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import test from 'node:test'
import vm from 'node:vm'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const source = await readFile(path.join(root, 'service-worker.js'), 'utf8')
const activeKey = 'cuddly.activePreviews'
const controlKey = 'cuddly.controlOrigin'
const popupStateKey = 'cuddly.popupStateByTabBindingEnvironment.v2'
const tabEnvironmentKey = 'cuddly.environmentByTab.v1'
const alarmPrefix = 'cuddly.previewExpiry.'

function clone(value) {
  return value === undefined ? undefined : structuredClone(value)
}

function createHarness({
  active = {},
  rules = [],
  tabs = [],
  popupState = undefined,
  localPopupState = undefined,
  tabEnvironmentPreferences = undefined,
  controlOrigin = undefined,
  fetchHandler = undefined,
  authSession = {
    authenticated: true,
    identity: { name: 'QA Alice', avatarUrl: '' },
    csrfToken: 'csrf-token',
  },
  sessionUnavailable = false,
  alarmCreateFailures = 0,
  tabReloadFailures = 0,
  tabUpdateFailures = 0,
} = {}) {
  const storage = {
    [activeKey]: clone(active),
    ...(controlOrigin === undefined ? {} : { [controlKey]: controlOrigin }),
    ...(localPopupState === undefined ? {} : { [popupStateKey]: clone(localPopupState) }),
    ...(tabEnvironmentPreferences === undefined
      ? {}
      : { [tabEnvironmentKey]: clone(tabEnvironmentPreferences) }),
  }
  const sessionStorage = {
    ...(popupState === undefined ? {} : { [popupStateKey]: clone(popupState) }),
  }
  const sessionRules = clone(rules)
  const tabState = clone(tabs)
  const tabUpdates = []
  const fetchRequests = []
  const sessionRequests = []
  const operationLog = []
  const alarms = new Map()
  const listeners = {}
  const event = (name) => ({ addListener: (listener) => (listeners[name] = listener) })
  const updatedEvent = {
    addListener: (listener) => {
      listeners.updated = (tabId, changeInfo, tab) => {
        const current = tabState.find((candidate) => candidate.id === tabId)
        if (current && changeInfo?.url) Object.assign(current, clone(tab), { url: changeInfo.url })
        return listener(tabId, changeInfo, tab)
      }
    },
  }
  const chrome = {
    alarms: {
      create: async (name, info) => {
        if (alarmCreateFailures > 0) {
          alarmCreateFailures -= 1
          throw new Error('Alarm create failed')
        }
        alarms.set(name, clone(info))
      },
      clear: async (name) => alarms.delete(name),
      getAll: async () => [...alarms].map(([name, info]) => ({ name, ...clone(info) })),
      onAlarm: event('alarm'),
    },
    declarativeNetRequest: {
      getSessionRules: async () => clone(sessionRules),
      updateSessionRules: async ({ addRules = [], removeRuleIds = [] }) => {
        for (const ruleId of removeRuleIds) {
          const index = sessionRules.findIndex((rule) => rule.id === ruleId)
          if (index >= 0) sessionRules.splice(index, 1)
        }
        sessionRules.push(...clone(addRules))
      },
    },
    runtime: {
      onInstalled: event('installed'),
      onMessage: event('message'),
      onStartup: event('startup'),
    },
    storage: {
      local: {
        get: async (key) => ({ [key]: clone(storage[key]) }),
        set: async (values) => Object.assign(storage, clone(values)),
      },
      session: {
        get: async (key) => {
          if (sessionUnavailable) throw new Error('Session storage unavailable')
          return { [key]: clone(sessionStorage[key]) }
        },
        set: async (values) => {
          if (sessionUnavailable) throw new Error('Session storage unavailable')
          Object.assign(sessionStorage, clone(values))
          operationLog.push({ type: 'session-storage-set', values: clone(values) })
        },
      },
    },
    tabs: {
      onRemoved: event('removed'),
      onUpdated: updatedEvent,
      get: async (tabId) => {
        const tab = tabState.find((candidate) => candidate.id === tabId)
        if (!tab) throw new Error('No tab with id')
        return clone(tab)
      },
      query: async () => clone(tabState),
      reload: async (tabId) => {
        if (tabReloadFailures > 0) {
          tabReloadFailures -= 1
          throw new Error('Tab reload failed')
        }
        const tab = tabState.find((candidate) => candidate.id === tabId)
        if (!tab) throw new Error('No tab with id')
        tabUpdates.push({ tabId, reload: true })
      },
      update: async (tabId, update) => {
        if (tabUpdateFailures > 0) {
          tabUpdateFailures -= 1
          throw new Error('Tab update failed')
        }
        const tab = tabState.find((candidate) => candidate.id === tabId)
        if (!tab) throw new Error('No tab with id')
        Object.assign(tab, clone(update))
        tabUpdates.push({ tabId, ...clone(update) })
        operationLog.push({ type: 'tab-update', tabId, update: clone(update) })
        return clone(tab)
      },
    },
  }
  const fetch = async (url, init) => {
    const request = { url: String(url), init: clone(init) }
    if (request.url.endsWith('/api/v1/auth/session')) {
      sessionRequests.push(request)
      operationLog.push({ type: 'session-fetch', ...request })
      return {
        ok: Boolean(authSession),
        status: authSession ? 200 : 401,
        json: async () => clone(authSession),
      }
    }
    fetchRequests.push(request)
    operationLog.push({ type: 'fetch', ...request })
    if (fetchHandler) return fetchHandler(String(url), init)
    return { ok: true, status: 204, json: async () => null }
  }
  const context = vm.createContext({
    chrome,
    Date,
    Promise,
    URL,
    AbortController,
    clearTimeout,
    encodeURIComponent,
    fetch,
    setTimeout,
  })
  new vm.Script(source, { filename: 'service-worker.js' }).runInContext(context)
  return {
    alarms,
    fetchRequests,
    sessionRules,
    listeners,
    operationLog,
    sessionRequests,
    sessionStorage,
    storage,
    tabUpdates,
    flush: () => vm.runInContext('mutationQueue', context),
  }
}

async function sendMessage(harness, message) {
  return new Promise((resolve) => {
    assert.equal(harness.listeners.message(message, {}, resolve), true)
  })
}

const shareToken = 'AbcdEFGHijklMNOPqrstUVWXyz01_-23'
const shareUrl = `https://bifrost.vanillacake.cn/s/${shareToken}`

function configurationGroupResponse({
  mode = 'preview',
  previewOrigin = 'https://main.bifrost.vanillacake.cn',
  previewToken = 'configuration-group-preview',
  revision = 1,
} = {}) {
  return {
    mode,
    configurationGroup: {
      token: shareToken,
      name: '消息列表提测',
      revision,
      environmentSlug: 'shared',
      items: [
        { targetId: 'webapp', mode: 'official' },
        { targetId: 'base', mode: 'branch', branch: 'feature/message-list' },
      ],
      siteBinding: {
        id: 'main-online',
        hostname: 'main.bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
      },
    },
    ...(mode === 'preview'
      ? {
          previewOrigin,
          preview: {
            token: previewToken,
            siteBindingId: 'main-online',
            environmentSlug: 'shared',
            expiresAt: new Date(Date.now() + 60_000).toISOString(),
            selections: [],
          },
        }
      : {}),
  }
}

function jsonResponse(body, { ok = true, status = 201 } = {}) {
  return { ok, status, json: async () => clone(body) }
}

function configurationGroupFetchHandler(options = {}) {
  const response = configurationGroupResponse(options)
  return async (url) =>
    jsonResponse(url.endsWith('/previews') ? response : response.configurationGroup, {
      status: url.endsWith('/previews') ? 201 : 200,
    })
}

test('claims an exact same-origin share once and persists branches before preview navigation', async () => {
  const harness = createHarness({
    tabs: [{ id: 21, url: shareUrl }],
    fetchHandler: configurationGroupFetchHandler(),
  })

  harness.listeners.updated(21, { url: shareUrl }, { id: 21, url: shareUrl })
  harness.listeners.updated(21, { url: shareUrl }, { id: 21, url: shareUrl })
  await harness.flush()

  assert.equal(harness.fetchRequests.length, 2)
  assert.equal(
    harness.fetchRequests[0].url,
    `https://bifrost.vanillacake.cn/api/v1/config-groups/${shareToken}`
  )
  assert.deepEqual(harness.fetchRequests[0].init, {
    method: 'GET',
    cache: 'no-store',
    credentials: 'include',
    headers: { 'x-cuddly-csrf': 'csrf-token' },
  })
  assert.equal(
    harness.fetchRequests[1].url,
    `https://bifrost.vanillacake.cn/api/v1/config-groups/${shareToken}/previews`
  )
  assert.deepEqual(harness.fetchRequests[1].init, {
    method: 'POST',
    cache: 'no-store',
    body: JSON.stringify({ expectedRevision: 1 }),
    credentials: 'include',
    headers: { 'content-type': 'application/json', 'x-cuddly-csrf': 'csrf-token' },
  })
  assert.deepEqual(harness.sessionRequests[0].init, {
    method: 'GET',
    cache: 'no-store',
    credentials: 'include',
  })
  assert.deepEqual(
    harness.sessionStorage[popupStateKey]['21:main-online:shared'].selectedBranches,
    {
      webapp: '',
      base: 'feature/message-list',
    }
  )
  assert.deepEqual(harness.storage[tabEnvironmentKey]['21'], {
    officialOrigin: 'https://www.kookapp.cn',
    environmentSlug: 'shared',
    updatedAt: harness.storage[tabEnvironmentKey]['21'].updatedAt,
  })
  assert.deepEqual(harness.tabUpdates, [{ tabId: 21, url: 'https://main.bifrost.vanillacake.cn/' }])
  const active = harness.storage[activeKey]['21']
  assert.equal(active.shareUrl, shareUrl)
  assert.equal(active.configGroupToken, shareToken)
  assert.equal(active.name, '消息列表提测')
  const persistedAt = harness.operationLog.findIndex(
    (entry) =>
      entry.type === 'session-storage-set' && entry.values[popupStateKey]?.['21:main-online:shared']
  )
  const previewRequestedAt = harness.operationLog.findIndex(
    (entry) => entry.type === 'fetch' && entry.url.endsWith('/previews')
  )
  const navigatedAt = harness.operationLog.findIndex((entry) => entry.type === 'tab-update')
  assert.ok(
    persistedAt >= 0 && persistedAt < previewRequestedAt && previewRequestedAt < navigatedAt
  )
})

test('keeps a bodyless preview request compatible with a legacy group response without revision', async () => {
  const response = configurationGroupResponse()
  delete response.configurationGroup.revision
  const harness = createHarness({
    tabs: [{ id: 34, url: shareUrl }],
    fetchHandler: async (url) =>
      jsonResponse(url.endsWith('/previews') ? response : response.configurationGroup, {
        status: url.endsWith('/previews') ? 201 : 200,
      }),
  })

  harness.listeners.updated(34, { url: shareUrl }, { id: 34, url: shareUrl })
  await harness.flush()

  assert.deepEqual(harness.fetchRequests[1].init, {
    method: 'POST',
    cache: 'no-store',
    credentials: 'include',
    headers: { 'x-cuddly-csrf': 'csrf-token' },
  })
  assert.equal(harness.storage[activeKey]['34'].preview.token, 'configuration-group-preview')
})

test('does not mutate a shared configuration without an authenticated Feishu session', async () => {
  const harness = createHarness({
    authSession: null,
    tabs: [{ id: 30, url: shareUrl }],
    fetchHandler: async () => {
      throw new Error('mutation must not run')
    },
  })

  harness.listeners.updated(30, { url: shareUrl }, { id: 30, url: shareUrl })
  await harness.flush()

  assert.equal(harness.sessionRequests.length, 1)
  assert.equal(harness.fetchRequests.length, 0)
  assert.equal(harness.tabUpdates.length, 0)
  assert.equal(harness.storage[activeKey]['30'], undefined)
})

test('does not claim shares from another origin or a non-exact token path', async () => {
  for (const url of [
    shareUrl,
    'https://preview-control.example/s/short',
    `https://preview-control.example/s/${shareToken}/`,
  ]) {
    const harness = createHarness({
      controlOrigin: 'https://preview-control.example',
      tabs: [{ id: 22, url }],
      fetchHandler: async () => {
        throw new Error('must not fetch')
      },
    })
    harness.listeners.updated(22, { url }, { id: 22, url })
    await harness.flush()
    assert.equal(harness.fetchRequests.length, 0)
    assert.equal(harness.tabUpdates.length, 0)
  }
})

test('uses the currently configured control origin when claiming a share', async () => {
  const customOrigin = 'https://preview-control.example'
  const customShareUrl = `${customOrigin}/s/${shareToken}`
  const harness = createHarness({
    controlOrigin: customOrigin,
    tabs: [{ id: 29, url: customShareUrl }],
    fetchHandler: configurationGroupFetchHandler(),
  })

  harness.listeners.updated(29, { url: customShareUrl }, { id: 29, url: customShareUrl })
  await harness.flush()

  assert.deepEqual(
    harness.fetchRequests.map((request) => request.url),
    [
      `${customOrigin}/api/v1/config-groups/${shareToken}`,
      `${customOrigin}/api/v1/config-groups/${shareToken}/previews`,
    ]
  )
  assert.equal(harness.storage[activeKey]['29'].controlOrigin, customOrigin)
  assert.equal(harness.storage[activeKey]['29'].shareUrl, customShareUrl)
})

test('keeps a share landing in place when an artifact is unavailable', async () => {
  const harness = createHarness({
    tabs: [{ id: 23, url: shareUrl }],
    fetchHandler: async (url) =>
      url.endsWith('/previews')
        ? jsonResponse(
            {
              code: 'CONFIGURATION_GROUP_ARTIFACT_NOT_READY',
              message: 'base 分支尚无可用产物',
            },
            { ok: false, status: 409 }
          )
        : jsonResponse(configurationGroupResponse().configurationGroup, { status: 200 }),
  })

  harness.listeners.updated(23, { url: shareUrl }, { id: 23, url: shareUrl })
  await harness.flush()

  assert.equal(harness.fetchRequests.length, 2)
  assert.equal(harness.tabUpdates.length, 0)
  assert.equal(harness.storage[activeKey]['23'], undefined)
  assert.equal(
    harness.sessionStorage[popupStateKey]['23:main-online:shared'].selectedBranches.base,
    'feature/message-list'
  )
})

test('applies a configuration group command without visiting its landing and preserves the route', async () => {
  const currentUrl = 'https://www.kookapp.cn/channels/31?from=requirement#voice'
  const harness = createHarness({
    tabs: [{ id: 31, url: currentUrl }],
    fetchHandler: configurationGroupFetchHandler({ previewToken: 'direct-requirement-preview' }),
  })

  const result = await sendMessage(harness, {
    type: 'apply-configuration-group',
    tabId: 31,
    token: shareToken,
  })

  assert.equal(result.ok, true)
  assert.equal(result.active.preview.token, 'direct-requirement-preview')
  assert.deepEqual(harness.tabUpdates, [
    {
      tabId: 31,
      url: 'https://main.bifrost.vanillacake.cn/channels/31?from=requirement#voice',
    },
  ])
  assert.equal(harness.storage[activeKey]['31'].shareUrl, shareUrl)
  assert.equal(harness.storage[tabEnvironmentKey]['31'].configurationGroupBindingId, undefined)
  assert.equal(
    harness.sessionStorage[popupStateKey]['31:main-online:shared'].selectedBranches.base,
    'feature/message-list'
  )
  assert.deepEqual(
    harness.fetchRequests.map((request) => request.url),
    [
      `https://bifrost.vanillacake.cn/api/v1/config-groups/${shareToken}`,
      `https://bifrost.vanillacake.cn/api/v1/config-groups/${shareToken}/previews`,
    ]
  )
})

test('returns a persisted-selection marker and keeps the business page when a group is not ready', async () => {
  const currentUrl = 'https://www.kookapp.cn/channels/32'
  const harness = createHarness({
    tabs: [{ id: 32, url: currentUrl }],
    fetchHandler: async (url) =>
      url.endsWith('/previews')
        ? jsonResponse(
            {
              code: 'CONFIG_GROUP_ARTIFACTS_NOT_READY',
              message: '配置组中仍有分支没有成功可用的打包产物',
              missing: [
                {
                  targetId: 'base',
                  targetName: '基础模块',
                  branch: 'feature/message-list',
                },
              ],
            },
            { ok: false, status: 409 }
          )
        : jsonResponse(configurationGroupResponse().configurationGroup, { status: 200 }),
  })

  const result = await sendMessage(harness, {
    type: 'apply-configuration-group',
    tabId: 32,
    token: shareToken,
  })

  assert.deepEqual(clone(result), {
    ok: false,
    message: '缺少可用打包产物：基础模块 · feature/message-list',
    code: 'CONFIG_GROUP_ARTIFACTS_NOT_READY',
    selectionPersisted: true,
  })
  assert.equal(harness.tabUpdates.length, 0)
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.storage[activeKey]['32'], undefined)
  assert.equal(
    harness.sessionStorage[popupStateKey]['32:main-online:shared'].selectedBranches.base,
    'feature/message-list'
  )
  assert.equal(harness.storage[tabEnvironmentKey]['32'].environmentSlug, 'shared')
  assert.equal(harness.storage[tabEnvironmentKey]['32'].configurationGroupBindingId, 'main-online')
})

test('refreshes and persists a concurrently edited group before retrying its preview once', async () => {
  const currentUrl = 'https://www.kookapp.cn/channels/33'
  let detailReads = 0
  let previewWrites = 0
  const harness = createHarness({
    tabs: [{ id: 33, url: currentUrl }],
    fetchHandler: async (url) => {
      if (!url.endsWith('/previews')) {
        detailReads += 1
        const detail = configurationGroupResponse({ revision: detailReads }).configurationGroup
        if (detailReads === 2) {
          detail.environmentSlug = 'tttt'
          detail.items = [
            { targetId: 'webapp', mode: 'official' },
            { targetId: 'base', mode: 'branch', branch: 'feature/concurrent-update' },
          ]
        }
        return jsonResponse(detail, { status: 200 })
      }

      previewWrites += 1
      if (previewWrites === 1) {
        return jsonResponse(
          {
            code: 'CONFIG_GROUP_REVISION_CONFLICT',
            message: '配置组已被其他人更新，请刷新后重试',
            currentRevision: 2,
          },
          { ok: false, status: 409 }
        )
      }
      return jsonResponse(
        {
          code: 'CONFIG_GROUP_ARTIFACTS_NOT_READY',
          message: '配置组中仍有分支没有成功可用的打包产物',
          missing: [
            {
              targetId: 'base',
              targetName: '基础模块',
              branch: 'feature/concurrent-update',
            },
          ],
        },
        { ok: false, status: 409 }
      )
    },
  })

  const result = await sendMessage(harness, {
    type: 'apply-configuration-group',
    tabId: 33,
    token: shareToken,
  })

  assert.deepEqual(clone(result), {
    ok: false,
    message: '缺少可用打包产物：基础模块 · feature/concurrent-update',
    code: 'CONFIG_GROUP_ARTIFACTS_NOT_READY',
    selectionPersisted: true,
  })
  assert.equal(detailReads, 2)
  assert.equal(previewWrites, 2)
  assert.deepEqual(
    harness.fetchRequests
      .filter((request) => request.url.endsWith('/previews'))
      .map((request) => JSON.parse(request.init.body)),
    [{ expectedRevision: 1 }, { expectedRevision: 2 }]
  )
  assert.deepEqual(harness.sessionStorage[popupStateKey]['33:main-online:tttt'].selectedBranches, {
    webapp: '',
    base: 'feature/concurrent-update',
  })
  assert.deepEqual(harness.storage[tabEnvironmentKey]['33'], {
    officialOrigin: 'https://www.kookapp.cn',
    environmentSlug: 'tttt',
    configurationGroupBindingId: 'main-online',
    configurationGroupHostname: 'main.bifrost.vanillacake.cn',
    updatedAt: harness.storage[tabEnvironmentKey]['33'].updatedAt,
  })
  assert.equal(harness.tabUpdates.length, 0)
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.storage[activeKey]['33'], undefined)
})

test('persists an official configuration and navigates to the bound official origin', async () => {
  const harness = createHarness({
    tabs: [{ id: 24, url: shareUrl }],
    fetchHandler: configurationGroupFetchHandler({ mode: 'official' }),
  })

  harness.listeners.updated(24, { url: shareUrl }, { id: 24, url: shareUrl })
  await harness.flush()

  assert.deepEqual(
    harness.sessionStorage[popupStateKey]['24:main-online:shared'].selectedBranches,
    {
      webapp: '',
      base: 'feature/message-list',
    }
  )
  assert.deepEqual(harness.tabUpdates, [{ tabId: 24, url: 'https://www.kookapp.cn/' }])
  assert.equal(harness.storage[activeKey]['24'], undefined)
  assert.equal(harness.sessionRules.length, 0)
})

test('rejects a preview origin that does not match the configuration site binding', async () => {
  const harness = createHarness({
    tabs: [{ id: 25, url: shareUrl }],
    fetchHandler: configurationGroupFetchHandler({ previewOrigin: 'https://attacker.example' }),
  })

  harness.listeners.updated(25, { url: shareUrl }, { id: 25, url: shareUrl })
  await harness.flush()

  assert.equal(harness.tabUpdates.length, 0)
  assert.equal(harness.storage[activeKey]['25'], undefined)
  assert.equal(
    harness.sessionStorage[popupStateKey]['25:main-online:shared'].selectedBranches.base,
    'feature/message-list'
  )
})

test('scans existing share landing tabs on both browser startup and extension install', async () => {
  for (const eventName of ['startup', 'installed']) {
    const harness = createHarness({
      tabs: [{ id: 26, url: shareUrl }],
      fetchHandler: configurationGroupFetchHandler(),
    })

    harness.listeners[eventName]()
    await harness.flush()

    assert.deepEqual(harness.tabUpdates, [
      { tabId: 26, url: 'https://main.bifrost.vanillacake.cn/' },
    ])
    assert.equal(harness.storage[activeKey]['26'].configGroupToken, shareToken)
  }
})

test('returns an expired shared preview to its share landing instead of the official site', async () => {
  const past = new Date(Date.now() - 60_000).toISOString()
  const harness = createHarness({
    active: {
      27: {
        mode: 'site',
        ruleIds: [1027],
        preview: { token: 'expired-shared-preview', expiresAt: past },
        previewOrigin: 'https://main.bifrost.vanillacake.cn',
        controlOrigin: 'https://bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
        shareUrl,
        configGroupToken: shareToken,
        name: '消息列表提测',
      },
    },
    rules: [{ id: 1027 }],
    tabs: [{ id: 27, url: 'https://main.bifrost.vanillacake.cn/' }],
  })

  harness.listeners.alarm({ name: `${alarmPrefix}27` })
  await harness.flush()

  assert.deepEqual(harness.tabUpdates, [{ tabId: 27, url: shareUrl }])
  assert.equal(harness.storage[activeKey]['27'], undefined)
  assert.equal(harness.sessionRules.length, 0)
})

test('reconciles an expired shared preview through the landing and rebuilds it', async () => {
  const past = new Date(Date.now() - 60_000).toISOString()
  const harness = createHarness({
    active: {
      28: {
        mode: 'site',
        ruleIds: [1028],
        preview: { token: 'old-shared-preview', expiresAt: past },
        previewOrigin: 'https://main.bifrost.vanillacake.cn',
        controlOrigin: 'https://bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
        shareUrl,
        configGroupToken: shareToken,
        name: '消息列表提测',
      },
    },
    rules: [{ id: 1028 }],
    tabs: [{ id: 28, url: 'https://main.bifrost.vanillacake.cn/' }],
    fetchHandler: async (url) => {
      if (!url.includes('/config-groups/')) return jsonResponse(null, { status: 204 })
      return configurationGroupFetchHandler({ previewToken: 'rebuilt-shared-preview' })(url)
    },
  })

  harness.listeners.installed()
  await harness.flush()

  assert.deepEqual(harness.tabUpdates, [
    { tabId: 28, url: shareUrl },
    { tabId: 28, url: 'https://main.bifrost.vanillacake.cn/' },
  ])
  assert.equal(harness.storage[activeKey]['28'].preview.token, 'rebuilt-shared-preview')
  assert.equal(
    harness.fetchRequests.filter((request) => request.url.includes('/config-groups/')).length,
    2
  )
})

test('finishes a session-scoped branch selection write after the popup stops listening', async () => {
  const harness = createHarness({ tabs: [{ id: 7 }] })

  assert.equal(
    harness.listeners.message(
      {
        type: 'write-popup-scoped-state',
        tabId: 7,
        bindingId: 'main',
        environmentSlug: 'online',
        selectedBranches: { base: 'feature/share-config' },
        submittedBuildBranches: { base: 'feature/share-config' },
      },
      {},
      () => undefined
    ),
    true
  )
  await harness.flush()

  assert.equal(
    harness.sessionStorage[popupStateKey]['7:main:online'].selectedBranches.base,
    'feature/share-config'
  )
  assert.equal(harness.storage[popupStateKey], undefined)

  const restored = await sendMessage(harness, {
    type: 'read-popup-scoped-state',
    tabId: 7,
    bindingId: 'main',
    environmentSlug: 'online',
  })
  assert.equal(restored.ok, true)
  assert.equal(restored.state.selectedBranches.base, 'feature/share-config')
})

test('serializes rapid popup writes without losing another tab or binding scope', async () => {
  const harness = createHarness({ tabs: [{ id: 7 }, { id: 8 }] })
  const first = sendMessage(harness, {
    type: 'write-popup-scoped-state',
    tabId: 7,
    bindingId: 'main',
    environmentSlug: 'online',
    selectedBranches: { base: 'feature/a' },
    submittedBuildBranches: {},
  })
  const otherScope = sendMessage(harness, {
    type: 'write-popup-scoped-state',
    tabId: 8,
    bindingId: 'main',
    environmentSlug: 'test',
    selectedBranches: { base: 'develop' },
    submittedBuildBranches: {},
  })
  const latest = sendMessage(harness, {
    type: 'write-popup-scoped-state',
    tabId: 7,
    bindingId: 'main',
    environmentSlug: 'online',
    selectedBranches: { base: 'feature/b' },
    submittedBuildBranches: {},
  })
  await Promise.all([first, otherScope, latest])

  assert.equal(
    harness.sessionStorage[popupStateKey]['7:main:online'].selectedBranches.base,
    'feature/b'
  )
  assert.equal(
    harness.sessionStorage[popupStateKey]['8:main:test'].selectedBranches.base,
    'develop'
  )
})

test('cleans stale local fallback scopes at startup and when a tab closes', async () => {
  const harness = createHarness({
    sessionUnavailable: true,
    tabs: [{ id: 7, url: 'https://www.kookapp.cn' }],
    localPopupState: {
      '7:main:online': { selectedBranches: { base: 'feature/live' }, updatedAt: 2 },
      '8:main:online': { selectedBranches: { base: 'feature/stale' }, updatedAt: 1 },
      malformed: { selectedBranches: { base: 'feature/invalid' }, updatedAt: 3 },
    },
    tabEnvironmentPreferences: {
      7: {
        officialOrigin: 'https://www.kookapp.cn',
        environmentSlug: 'online',
        updatedAt: 2,
      },
      8: {
        officialOrigin: 'https://www.kookapp.cn',
        environmentSlug: 'test',
        updatedAt: 1,
      },
    },
  })

  harness.listeners.startup()
  await harness.flush()
  assert.deepEqual(Object.keys(harness.storage[popupStateKey]), ['7:main:online'])
  assert.deepEqual(Object.keys(harness.storage[tabEnvironmentKey]), ['7'])

  harness.listeners.removed(7)
  await harness.flush()
  assert.deepEqual(harness.storage[popupStateKey], {})
  assert.deepEqual(harness.storage[tabEnvironmentKey], {})
})

test('creates and clears a one-time expiry alarm with a Remote-only site preview', async () => {
  const harness = createHarness({ tabs: [{ id: 7 }] })
  const expiresAt = new Date(Date.now() + 60_000).toISOString()
  const applied = await sendMessage(harness, {
    type: 'apply-site-preview',
    tabId: 7,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    controlOrigin: 'https://bifrost.vanillacake.cn',
    officialOrigin: 'https://www.kookapp.cn',
    originalUrl: 'https://www.kookapp.cn/channels/7',
    targetUrl: 'https://main.bifrost.vanillacake.cn/channels/7',
    preview: {
      token: 'preview',
      expiresAt,
      selections: [{ moduleKey: 'base', artifactId: 'artifact-base' }],
    },
  })

  assert.equal(applied.ok, true)
  assert.equal(applied.active.mode, 'site')
  assert.equal(harness.sessionRules.length, 1)
  assert.ok(harness.sessionRules.every((rule) => rule.condition.tabIds?.[0] === 7))
  assert.equal(harness.alarms.get(`${alarmPrefix}7`).when, Date.parse(expiresAt))
  assert.equal(harness.storage[activeKey]['7'].preview.token, 'preview')

  const removed = await sendMessage(harness, { type: 'remove-preview', tabId: 7 })
  assert.equal(removed.ok, true)
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.alarms.has(`${alarmPrefix}7`), false)
  assert.equal(harness.storage[activeKey]['7'], undefined)
  assert.deepEqual(
    harness.fetchRequests.map((request) => request.url),
    ['https://bifrost.vanillacake.cn/api/v1/previews/preview']
  )
})

test('restores valid alarms and removes expired or closed-tab previews', async () => {
  const future = new Date(Date.now() + 60_000).toISOString()
  const past = new Date(Date.now() - 60_000).toISOString()
  const active = {
    1: {
      mode: 'site',
      ruleIds: [1001],
      preview: { token: 'valid', expiresAt: future },
      previewOrigin: 'https://main.bifrost.vanillacake.cn',
      controlOrigin: 'https://bifrost.vanillacake.cn',
      officialOrigin: 'https://www.kookapp.cn',
    },
    2: {
      mode: 'remote',
      ruleIds: [1002, 1003],
      preview: { expiresAt: future },
      webappOrigin: 'https://www.kookapp.cn',
      hotModuleUrl: 'https://bifrost.vanillacake.cn/preview/legacy/hot-module',
    },
    3: {
      mode: 'site',
      ruleIds: [1004],
      preview: { token: 'closed', expiresAt: future },
      previewOrigin: 'https://main.bifrost.vanillacake.cn',
      controlOrigin: 'https://bifrost.vanillacake.cn',
    },
    4: {
      mode: 'site',
      ruleIds: [1005],
      preview: { token: 'expired', expiresAt: past },
      previewOrigin: 'https://main.bifrost.vanillacake.cn',
      controlOrigin: 'https://bifrost.vanillacake.cn',
      officialOrigin: 'https://www.kookapp.cn',
    },
  }
  const harness = createHarness({
    active,
    rules: [{ id: 1999 }],
    tabs: [
      { id: 1, url: 'https://main.bifrost.vanillacake.cn/channels/1' },
      { id: 2, url: 'https://www.kookapp.cn/channels/2' },
      { id: 4, url: 'https://main.bifrost.vanillacake.cn/channels/4' },
    ],
  })
  harness.alarms.set(`${alarmPrefix}99`, { when: Date.now() + 60_000 })

  harness.listeners.installed({ reason: 'update' })
  await harness.flush()

  assert.deepEqual(Object.keys(harness.storage[activeKey]), ['1'])
  assert.deepEqual(
    harness.sessionRules.map((rule) => rule.id),
    [1001]
  )
  assert.equal(harness.alarms.get(`${alarmPrefix}1`).when, Date.parse(future))
  assert.equal(harness.alarms.has(`${alarmPrefix}99`), false)
  assert.deepEqual(harness.tabUpdates, [{ tabId: 4, url: 'https://www.kookapp.cn/channels/4' }])
  assert.deepEqual(harness.fetchRequests.map((request) => request.url).sort(), [
    'https://bifrost.vanillacake.cn/api/v1/previews/closed',
    'https://bifrost.vanillacake.cn/api/v1/previews/expired',
  ])

  harness.storage[activeKey]['1'].preview.expiresAt = past
  harness.listeners.alarm({ name: `${alarmPrefix}1` })
  await harness.flush()

  assert.equal(harness.storage[activeKey]['1'], undefined)
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.alarms.has(`${alarmPrefix}1`), false)
  assert.deepEqual(harness.tabUpdates.at(-1), {
    tabId: 1,
    url: 'https://www.kookapp.cn/channels/1',
  })
  assert.equal(
    harness.fetchRequests.at(-1).url,
    'https://bifrost.vanillacake.cn/api/v1/previews/valid'
  )
})

test('clears preview state when its tab leaves the preview origin', async () => {
  const future = new Date(Date.now() + 60_000).toISOString()
  const harness = createHarness({
    active: {
      8: {
        mode: 'site',
        ruleIds: [1008],
        preview: { token: 'preview-8', expiresAt: future },
        previewOrigin: 'https://main.bifrost.vanillacake.cn',
        controlOrigin: 'https://bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
      },
    },
    rules: [{ id: 1008 }],
    tabs: [{ id: 8, url: 'https://main.bifrost.vanillacake.cn/channels/8' }],
  })

  harness.listeners.updated(
    8,
    { url: 'https://www.kookapp.cn/channels/8' },
    { id: 8, url: 'https://www.kookapp.cn/channels/8' }
  )
  await harness.flush()

  assert.equal(harness.storage[activeKey]['8'], undefined)
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.alarms.has(`${alarmPrefix}8`), false)
  assert.equal(
    harness.fetchRequests.at(-1).url,
    'https://bifrost.vanillacake.cn/api/v1/previews/preview-8'
  )
})

test('reports capabilities used to detect a stale service worker', async () => {
  const harness = createHarness()
  const result = await sendMessage(harness, { type: 'get-extension-capabilities' })

  assert.equal(result.ok, true)
  assert.equal(result.capabilities.protocolVersion, 5)
  assert.deepEqual(
    [...result.capabilities.commands],
    [
      'apply-configuration-group',
      'apply-site-preview',
      'remove-preview',
      'apply-site-preview-transaction',
      'remove-preview-transaction',
    ]
  )
  assert.equal(harness.sessionRules.length, 0)
  assert.deepEqual(harness.storage[activeKey], {})
})

test('rejects the legacy Remote redirect command with an actionable reload instruction', async () => {
  const harness = createHarness()
  const result = await sendMessage(harness, {
    type: 'apply-remote-preview',
    tabId: 9,
    webappOrigin: 'https://www.kookapp.cn',
    hotModuleUrl: 'https://bifrost.vanillacake.cn/preview/hot-module',
  })

  assert.equal(result.ok, false)
  assert.match(result.message, /chrome:\/\/extensions/)
  assert.match(result.message, /重新加载/)
  assert.equal(harness.sessionRules.length, 0)
  assert.deepEqual(harness.storage[activeKey], {})
})

test('applies a site preview with one tab-scoped session header rule', async () => {
  const harness = createHarness({
    tabs: [{ id: 11, url: 'https://main.bifrost.vanillacake.cn/channels/11' }],
  })
  const expiresAt = new Date(Date.now() + 60_000).toISOString()

  const applied = await sendMessage(harness, {
    type: 'apply-site-preview',
    tabId: 11,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    controlOrigin: 'https://bifrost.vanillacake.cn',
    officialOrigin: 'https://www.kookapp.cn',
    originalUrl: 'https://www.kookapp.cn/channels/11',
    targetUrl: 'https://main.bifrost.vanillacake.cn/channels/11',
    preview: { token: 'site-preview', expiresAt, selections: [] },
  })

  assert.equal(applied.ok, true)
  assert.equal(harness.sessionRules.length, 1)
  assert.deepEqual(harness.sessionRules[0].condition.tabIds, [11])
  assert.deepEqual(harness.sessionRules[0].action.requestHeaders, [
    { header: 'x-cuddly-preview-token', operation: 'set', value: 'site-preview' },
  ])
})

test('applies rules, state, and navigation in one background transaction', async () => {
  const harness = createHarness({
    tabs: [{ id: 14, url: 'https://www.kookapp.cn/channels/14?from=official#voice' }],
  })
  const expiresAt = new Date(Date.now() + 60_000).toISOString()

  const applied = await sendMessage(harness, {
    type: 'apply-site-preview-transaction',
    tabId: 14,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    controlOrigin: 'https://bifrost.vanillacake.cn',
    officialOrigin: 'https://www.kookapp.cn',
    originalUrl: 'https://www.kookapp.cn/channels/14?from=official#voice',
    targetUrl: 'https://main.bifrost.vanillacake.cn/channels/14?from=official#voice',
    preview: { token: 'transaction-preview', expiresAt, selections: [] },
  })

  assert.equal(applied.ok, true)
  assert.equal(harness.storage[activeKey]['14'].preview.token, 'transaction-preview')
  assert.equal(harness.sessionRules.length, 1)
  assert.equal(harness.alarms.get(`${alarmPrefix}14`).when, Date.parse(expiresAt))
  assert.deepEqual(harness.tabUpdates, [
    {
      tabId: 14,
      url: 'https://main.bifrost.vanillacake.cn/channels/14?from=official#voice',
    },
  ])
})

test('finishes an apply transaction even when its popup no longer receives the response', async () => {
  const harness = createHarness({ tabs: [{ id: 15, url: 'https://www.kookapp.cn/channels/15' }] })
  const expiresAt = new Date(Date.now() + 60_000).toISOString()

  assert.equal(
    harness.listeners.message(
      {
        type: 'apply-site-preview-transaction',
        tabId: 15,
        previewOrigin: 'https://main.bifrost.vanillacake.cn',
        controlOrigin: 'https://bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
        originalUrl: 'https://www.kookapp.cn/channels/15',
        targetUrl: 'https://main.bifrost.vanillacake.cn/channels/15',
        preview: { token: 'closed-popup-preview', expiresAt, selections: [] },
      },
      {},
      () => undefined
    ),
    true
  )
  await harness.flush()

  assert.equal(harness.storage[activeKey]['15'].preview.token, 'closed-popup-preview')
  assert.equal(harness.sessionRules.length, 1)
  assert.deepEqual(harness.tabUpdates, [
    { tabId: 15, url: 'https://main.bifrost.vanillacake.cn/channels/15' },
  ])
})

test('rejects a transaction target outside the declared preview origin before mutation', async () => {
  const harness = createHarness({ tabs: [{ id: 16, url: 'https://www.kookapp.cn/channels/16' }] })
  const expiresAt = new Date(Date.now() + 60_000).toISOString()

  const applied = await sendMessage(harness, {
    type: 'apply-site-preview-transaction',
    tabId: 16,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    controlOrigin: 'https://bifrost.vanillacake.cn',
    officialOrigin: 'https://www.kookapp.cn',
    originalUrl: 'https://www.kookapp.cn/channels/16',
    targetUrl: 'https://attacker.example/channels/16',
    preview: { token: 'invalid-target-preview', expiresAt, selections: [] },
  })

  assert.equal(applied.ok, false)
  assert.match(applied.message, /configured preview origin/)
  assert.deepEqual(harness.storage[activeKey], {})
  assert.equal(harness.sessionRules.length, 0)
  assert.equal(harness.tabUpdates.length, 0)
  assert.equal(harness.fetchRequests.length, 0)
})

test('revokes the previous token only after a replacement is active', async () => {
  const future = new Date(Date.now() + 60_000).toISOString()
  const harness = createHarness({
    active: {
      12: {
        mode: 'site',
        ruleIds: [1012],
        preview: { token: 'old-preview', expiresAt: future },
        previewOrigin: 'https://main.bifrost.vanillacake.cn',
        controlOrigin: 'https://bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
      },
    },
    rules: [{ id: 1012 }],
    tabs: [{ id: 12, url: 'https://main.bifrost.vanillacake.cn/channels/12' }],
  })

  const applied = await sendMessage(harness, {
    type: 'apply-site-preview',
    tabId: 12,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    controlOrigin: 'https://bifrost.vanillacake.cn',
    officialOrigin: 'https://www.kookapp.cn',
    originalUrl: 'https://main.bifrost.vanillacake.cn/channels/12',
    targetUrl: 'https://main.bifrost.vanillacake.cn/channels/12',
    preview: { token: 'new-preview', expiresAt: future, selections: [] },
  })

  assert.equal(applied.ok, true)
  assert.equal(harness.storage[activeKey]['12'].preview.token, 'new-preview')
  assert.equal(harness.sessionRules.length, 1)
  assert.equal(harness.sessionRules[0].action.requestHeaders[0].value, 'new-preview')
  assert.deepEqual(
    harness.fetchRequests.map((request) => request.url),
    ['https://bifrost.vanillacake.cn/api/v1/previews/old-preview']
  )
})

test('revokes a failed replacement and restores the previous local preview', async () => {
  const future = new Date(Date.now() + 60_000).toISOString()
  const harness = createHarness({
    active: {
      13: {
        mode: 'site',
        ruleIds: [1013],
        preview: { token: 'stable-preview', expiresAt: future },
        previewOrigin: 'https://main.bifrost.vanillacake.cn',
        controlOrigin: 'https://bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
      },
    },
    rules: [{ id: 1013 }],
    tabs: [{ id: 13, url: 'https://main.bifrost.vanillacake.cn/channels/13' }],
    alarmCreateFailures: 1,
  })

  const applied = await sendMessage(harness, {
    type: 'apply-site-preview',
    tabId: 13,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    controlOrigin: 'https://bifrost.vanillacake.cn',
    officialOrigin: 'https://www.kookapp.cn',
    originalUrl: 'https://main.bifrost.vanillacake.cn/channels/13',
    targetUrl: 'https://main.bifrost.vanillacake.cn/channels/13',
    preview: { token: 'failed-preview', expiresAt: future, selections: [] },
  })

  assert.equal(applied.ok, false)
  assert.equal(harness.storage[activeKey]['13'].preview.token, 'stable-preview')
  assert.equal(harness.sessionRules.length, 1)
  assert.equal(harness.sessionRules[0].action.requestHeaders[0].value, 'stable-preview')
  assert.deepEqual(
    harness.fetchRequests.map((request) => request.url),
    ['https://bifrost.vanillacake.cn/api/v1/previews/failed-preview']
  )
})

test('restores the previous preview when transactional apply navigation fails', async () => {
  const future = new Date(Date.now() + 60_000).toISOString()
  const harness = createHarness({
    active: {
      17: {
        mode: 'site',
        ruleIds: [1017],
        preview: { token: 'stable-preview', expiresAt: future },
        previewOrigin: 'https://main.bifrost.vanillacake.cn',
        controlOrigin: 'https://bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
      },
    },
    rules: [{ id: 1017 }],
    tabs: [{ id: 17, url: 'https://main.bifrost.vanillacake.cn/channels/17' }],
    tabUpdateFailures: 1,
  })

  const applied = await sendMessage(harness, {
    type: 'apply-site-preview-transaction',
    tabId: 17,
    previewOrigin: 'https://main.bifrost.vanillacake.cn',
    controlOrigin: 'https://bifrost.vanillacake.cn',
    officialOrigin: 'https://www.kookapp.cn',
    originalUrl: 'https://main.bifrost.vanillacake.cn/channels/17',
    targetUrl: 'https://main.bifrost.vanillacake.cn/channels/17',
    preview: { token: 'failed-preview', expiresAt: future, selections: [] },
  })

  assert.equal(applied.ok, false)
  assert.match(applied.message, /Tab update failed/)
  assert.equal(harness.storage[activeKey]['17'].preview.token, 'stable-preview')
  assert.equal(harness.sessionRules.length, 1)
  assert.equal(harness.sessionRules[0].action.requestHeaders[0].value, 'stable-preview')
  assert.equal(harness.alarms.get(`${alarmPrefix}17`).when, Date.parse(future))
  assert.deepEqual(
    harness.fetchRequests.map((request) => request.url),
    ['https://bifrost.vanillacake.cn/api/v1/previews/failed-preview']
  )
})

test('removes preview state and returns to the official origin in one transaction', async () => {
  const future = new Date(Date.now() + 60_000).toISOString()
  const harness = createHarness({
    active: {
      18: {
        mode: 'site',
        ruleIds: [1018],
        preview: { token: 'remove-preview', expiresAt: future },
        previewOrigin: 'https://main.bifrost.vanillacake.cn',
        controlOrigin: 'https://bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
      },
    },
    rules: [{ id: 1018 }],
    tabs: [
      {
        id: 18,
        url: 'https://main.bifrost.vanillacake.cn/channels/18?from=preview#text',
      },
    ],
  })

  const removed = await sendMessage(harness, {
    type: 'remove-preview-transaction',
    tabId: 18,
  })

  assert.equal(removed.ok, true)
  assert.equal(harness.storage[activeKey]['18'], undefined)
  assert.equal(harness.sessionRules.length, 0)
  assert.deepEqual(harness.tabUpdates, [
    { tabId: 18, url: 'https://www.kookapp.cn/channels/18?from=preview#text' },
  ])
  assert.deepEqual(
    harness.fetchRequests.map((request) => request.url),
    ['https://bifrost.vanillacake.cn/api/v1/previews/remove-preview']
  )
})

test('restores preview state and does not revoke it when remove navigation fails', async () => {
  const future = new Date(Date.now() + 60_000).toISOString()
  const harness = createHarness({
    active: {
      19: {
        mode: 'site',
        ruleIds: [1019],
        preview: { token: 'keep-preview', expiresAt: future },
        previewOrigin: 'https://main.bifrost.vanillacake.cn',
        controlOrigin: 'https://bifrost.vanillacake.cn',
        officialOrigin: 'https://www.kookapp.cn',
      },
    },
    rules: [{ id: 1019 }],
    tabs: [{ id: 19, url: 'https://main.bifrost.vanillacake.cn/channels/19' }],
    tabUpdateFailures: 1,
  })

  const removed = await sendMessage(harness, {
    type: 'remove-preview-transaction',
    tabId: 19,
  })

  assert.equal(removed.ok, false)
  assert.match(removed.message, /Tab update failed/)
  assert.equal(harness.storage[activeKey]['19'].preview.token, 'keep-preview')
  assert.equal(harness.sessionRules.length, 1)
  assert.equal(harness.sessionRules[0].action.requestHeaders[0].value, 'keep-preview')
  assert.equal(harness.alarms.get(`${alarmPrefix}19`).when, Date.parse(future))
  assert.equal(harness.fetchRequests.length, 0)
})
