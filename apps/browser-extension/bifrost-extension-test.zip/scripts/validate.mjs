import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const manifest = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8'))
if (manifest.manifest_version !== 3) throw new Error('Browser extension must use Manifest V3')
if (manifest.version !== '0.10.2')
  throw new Error('Browser extension release must be version 0.10.2')
if (!manifest.permissions?.includes('alarms')) {
  throw new Error('Browser extension must declare the alarms permission')
}
for (const file of [
  'popup.html',
  'popup.css',
  'popup.js',
  'auth-session.js',
  'popup-state.js',
  'popup-tabs.js',
  'configuration-groups.js',
  'branch-picker.js',
  'build-queue.js',
  'binding-selection.js',
  'environment-selection.js',
  'preview-routing.js',
  'extension-protocol.js',
  'service-worker.js',
]) {
  await readFile(path.join(root, file))
}

const popupHtml = await readFile(path.join(root, 'popup.html'), 'utf8')
for (const requiredId of [
  'module-list',
  'queue-list',
  'queue-summary',
  'job-detail-dialog',
  'job-detail-content',
  'job-detail-cancel',
  'apply-button-wrap',
  'projects-tab',
  'queue-tab',
  'projects-panel',
  'project-version-tabs',
  'requirements-tab',
  'branches-tab',
  'requirements-panel',
  'branches-panel',
  'requirements-list',
  'configuration-group-edit-dialog',
  'configuration-group-delete-dialog',
  'branch-picker-dropdown',
  'branch-picker-search',
  'branch-picker-list',
  'branch-picker-count',
  'auth-gate',
  'login-button',
  'identity-panel',
  'identity-name',
  'logout-button',
  'workspace-tabs',
  'environment-bar',
  'environment-select',
  'active-title',
]) {
  if (!popupHtml.includes(`id="${requiredId}"`)) {
    throw new Error(`Browser extension popup is missing #${requiredId}`)
  }
}
if (popupHtml.includes('Proudly Crafted With CakeDesign.')) {
  throw new Error('Browser extension popup must not include the CakeDesign credit line')
}
if (popupHtml.includes('branch-picker-dialog')) {
  throw new Error('Branch picker must use an anchored dropdown instead of a full-screen dialog')
}
const popupJs = await readFile(path.join(root, 'popup.js'), 'utf8')
const statusBarMarkup = popupHtml.match(/<footer\s+[^>]*id="status-bar"[^>]*>/s)?.[0] || ''
if (
  !popupJs.includes('elements.statusText.title = message') ||
  !popupJs.includes("elements.statusText.removeAttribute('title')") ||
  !statusBarMarkup.includes('role="status"') ||
  !statusBarMarkup.includes('aria-live="polite"') ||
  !statusBarMarkup.includes('aria-atomic="true"')
) {
  throw new Error(
    'Popup status messages must expose their complete text through title and an atomic live region'
  )
}
if (!popupJs.includes("api('/api/v1/environments')") || popupJs.includes('/matrix')) {
  throw new Error(
    'Popup environments must come from the environment catalog, not a Revision matrix'
  )
}
const previewRoutingJs = await readFile(path.join(root, 'preview-routing.js'), 'utf8')
if (!previewRoutingJs.includes('environmentSlug') || previewRoutingJs.includes('hasSelection')) {
  throw new Error('Preview routing must support environment-only all-official sessions')
}
for (const removedIdentityFeature of [
  'ACTOR_KEY',
  'ACTOR_ID_KEY',
  'actor-name',
  'x-cuddly-actor',
  'popup-identity',
]) {
  if (popupHtml.includes(removedIdentityFeature) || popupJs.includes(removedIdentityFeature)) {
    throw new Error(
      `Browser extension still contains custom actor behavior: ${removedIdentityFeature}`
    )
  }
}
for (const match of popupJs.matchAll(/document\.querySelector\('#([^']+)'\)/g)) {
  if (!popupHtml.includes(`id="${match[1]}"`)) {
    throw new Error(`popup.js references missing element #${match[1]}`)
  }
}
const popupCss = await readFile(path.join(root, 'popup.css'), 'utf8')
if (!popupCss.includes('width: 560px;') || !popupCss.includes('height: 600px;')) {
  throw new Error('Browser extension popup must stay within the Chromium 800x600 limit')
}
if (!popupCss.includes('grid-template-columns: minmax(166px, 0.32fr) minmax(180px, 1fr) auto;')) {
  throw new Error('Browser extension module rows must reserve 166px for project names')
}
if (
  !popupCss.includes('.module-loading-spinner') ||
  !popupJs.includes("elements.moduleList.setAttribute('aria-busy', 'true')") ||
  !popupJs.includes("spinner.setAttribute('aria-hidden', 'true')")
) {
  throw new Error('Browser extension module list must expose an accessible loading state')
}
if (!popupJs.includes('if (branch || isSite) {')) {
  throw new Error('Official Remote selections must omit the redundant module metadata row')
}
const branchPickerJs = await readFile(path.join(root, 'branch-picker.js'), 'utf8')
if (popupJs.includes('queueJumpButton') || branchPickerJs.includes('showModal(')) {
  throw new Error('Popup still contains the legacy queue jump or modal branch picker behavior')
}
const authSessionJs = await readFile(path.join(root, 'auth-session.js'), 'utf8')
const serviceWorkerJs = await readFile(path.join(root, 'service-worker.js'), 'utf8')
if (!authSessionJs.includes("credentials: 'include'") || !popupJs.includes('csrfToken')) {
  throw new Error('Popup API requests must carry the authenticated session and CSRF token')
}
if (
  !serviceWorkerJs.includes('/api/v1/auth/session') ||
  !serviceWorkerJs.includes("'x-cuddly-csrf'") ||
  serviceWorkerJs.includes("credentials: 'omit'")
) {
  throw new Error('Service worker mutations must carry the authenticated session and CSRF token')
}
console.log('[browser-extension] manifest and entry files are valid')
